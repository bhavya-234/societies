import * as dotenv from 'dotenv';
dotenv.config();
import express from 'express';
const app = express();
import logger from './src/logger';
import cron from 'node-cron';
import 'fs';
import path from 'path';
import { resolve } from 'path'
import cors from 'cors'
import { init as initDb } from './src/config/db'
const PORT = process.env.PORT || 8000;
import router from './src/api/index';
import bodyParser from 'body-parser';
import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from "swagger-ui-express";
import swaggerJson from './swagger.json';
import type { ErrorRequestHandler } from "express";
import net from 'net';

const fs = require('fs');

const publicFolder = resolve(__dirname, './public')
process.env.DIR_ROOT = __dirname;

const allowedOrigins = ['http://103.174.56.65:3009', 'http://103.174.56.169:8091', 'http://localhost:3009', 'http://10.96.47.103:8091', 'https://registration.ap.gov.in'];

initDb();
app.use(express.json());
//app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(publicFolder))
app.use(cors({
    origin: '*',
}))
app.disable('x-powered-by');
app.use(function (req, res, next) {
    const origin = req.headers.origin;
    const ContentSecurityPolicy =  `default-src 'self'  http://103.174.56.65:3009 http://localhost:3009 http://localhost:4008 http://103.174.56.65:4008 http://103.174.56.169:8091;  
    script-src 'self' ; 
    child-src http://103.174.56.65:3009 http://103.174.56.65:4008 http://103.174.56.169:8091 http://localhost:3009 http://localhost:4008; 
    img-src * 'self' data: https:;`
  
 
    if (origin && allowedOrigins.includes(origin)) {

        res.setHeader('Access-Control-Allow-Origin', origin);
    }
    // res.header('Access-Control-Allow-Origin', '*');
    res.header('X-Frame-Options', 'SAMEORIGIN');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE');
    res.header('Access-Control-Expose-Headers', 'Content-Length');
    res.header('Access-Control-Allow-Headers', 'Accept, Authorization, Content-Type, X-Requested-With, Range');
    res.header('X-XSS-Protection', '1; mode=block');
    res.header('X-Content-Type-Options', 'nosniff');
    res.header('Expires', '0');
    res.header('Pragma', 'no-cache');
    res.header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    res.header('Cache-Control', 'private, must-revalidate, max-age=0, no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    // res.header('Content-Security-Policy', `default-src 'self' 'unsafe-inline' 'unsafe-eval' http://103.174.56.65:3009 http://localhost:3009 http://localhost:4008 http://103.174.56.65:4008 http://103.174.56.169:8091 http://10.96.47.103:8091; script-src 'self' 'unsafe-inline'; child-src http://103.174.56.65:3009 http://103.174.56.65:4008 http://103.174.56.169:8091 http://localhost:3009 http://localhost:4008 http://10.96.47.103:8091; img-src * 'self' data: https:;`);
    // res.header('Content-Security-Policy', `default-src 'self' 'unsafe-inline' 'unsafe-eval' http://103.174.56.65:3009 http://localhost:3009 http://localhost:4008 http://103.174.56.65:4008 http://103.174.56.169:8091  script-src 'self' 'unsafe-inline'; child-src http://103.174.56.65:3009 http://103.174.56.65:4008 http://103.174.56.169:8091 http://localhost:3009 http://localhost:4008 img-src * 'self' data: https:;`);
    res.header('Content-Security-Policy', ContentSecurityPolicy.replace(/\s{2,}/g, ' ').trim());
   
    res.removeHeader("X-Powered-By");
    const allowedMethods = ['TRACE'];
     if (allowedMethods.includes(req.method)) {
        res.status(404).send(
            {
                status: false,
                message: "Method cannot be allowed",
                code: 404
            }
        );
        return res.sendStatus(401);
    } else if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    } else {
        return next();
    }
   
});

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerJson));

app.get("/", (req, res): void => {
    res.send("Hello Typescript with Node.js!")
});

/*
app.get("/downloads/:id/:fileName", (req, res):void => {
    const { id, fileName } = req.params;


    console.log("<==== process.env.DIR_ROOT ====>", process.env.DIR_ROOT);
    //console.log("<==== id ====>", id);
    //console.log("<==== fileName ====>", fileName);
    //console.log("<==== __dirname ====>", __dirname);

    const path = process.env.DIR_ROOT + `/uploads/${id}/${fileName}`;

    console.log("<==== path ====>", path);

    const file = fs.createReadStream(path)
    var stat = fs.statSync(path);
    const filename = fileName;//(new Date()).toISOString()
    res.setHeader('Content-Length', stat.size);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="' + filename + '"');
    file.pipe(res);
});
*/
app.use('/api/', router);

const errorHandler: ErrorRequestHandler = (err, req, res, next) => { };
app.use(errorHandler);

app.use((err, req, res, next) => {
    try {
        let errorJSON = {};
        if (err.statusCode != undefined)
            errorJSON["statusCode"] = err.statusCode;
        else if (err.status != undefined)
            errorJSON["statusCode"] = err.status;
        else
            errorJSON["statusCode"] = 500;

        errorJSON["message"] = err.message;
        errorJSON["type"] = err.type;
        if (err.status === 500 || err.statusCode === 500) {
            errorJSON["status"] = "Internal Server Error";
            res.status(500).send(errorJSON);
        }
        else if (err.status === 400 || err.statusCode === 400) {
            errorJSON["status"] = "Bad Request";
            res.status(400).send(errorJSON);
        }
        else if (err.status === 401 || err.statusCode === 401) {
            errorJSON["status"] = "Unauthorized";
            res.status(401).send(errorJSON);
        }
        else if (err.status === 403 || err.statusCode === 403) {
            errorJSON["status"] = "Forbidden";
            res.status(403).send(errorJSON);
        }
        else if (err.status === 404 || err.statusCode === 404) {
            errorJSON["status"] = "Not Found";
            res.status(404).send(errorJSON);
        }
        else if (err.status === 412 || err.statusCode === 412) {
            errorJSON["status"] = "Precondition Failed";
            res.status(412).send(errorJSON);
        }
    } catch (err) {
        logger.error("error in index :::: ", err);
    }
    let completeUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    logger.error(`${err.status || err.statusCode} - ${res.statusMessage} - ${err.message} - ${completeUrl} - ${req.method} - ${req.ip}`,);
})
// const folderToDelete = 'logs';
// const absPath = path.join(__dirname, folderToDelete);
// logger.info("abs",absPath);
// //const oneMinuteFromNow = new Date(Date.now() + 60 * 1000);

// cron.schedule('0 0 * * *', () => {
//   try {
//     fs.rmdirSync(absPath, { recursive: true });
//     console.log('Folder deleted successfully:', folderToDelete);
//   } catch (err) {
//     console.error('Error deleting the folder:', err);
//   }
// });

const server = net.createServer((socket) => {

    const clientLocalAddress = socket.localAddress;

    console.log(`Client's Local IP Address: ${clientLocalAddress}`);
})



app.listen(PORT, (): void => {
    logger.info(`Server Running here 👉 http://localhost:${PORT}`);
});