// import { DaSociety } from '../models/types/index';
import moment from 'moment';
import { ObjectId } from 'mongoose';
import { DaSociety, DASocietyMembers } from '../models/index';

export const getDaSocities = async (req: any, district: any) => {
    const sort = '_id';
    let perPage: any = req.query ? req.query.perPage : 10;
    let page:any = req.query ? req.query.page : 1;
    if(!perPage) {
        perPage = 10;
    }
    if(!page) {
        page = 1;
    }
    const skip: any = (parseInt(page) - 1) * parseInt(perPage);
    const limit = parseInt(perPage);
    const status = req.query.status;
    let fromDate:any = req.query.from ? req.query.from : '';
    if(fromDate) {
        fromDate = moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD');
    }
    
    let toDate:any = req.query.to ? req.query.to : '';
    if(toDate) {
        toDate = moment(toDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
    } else {
        toDate = moment().format('YYYY-MM-DD');
    }

    const filterAndCond:any = [];
    const filerOrCond:any = [];
    
    if(fromDate && toDate) {
        filterAndCond.push({ createdAt: { $gte: new Date(fromDate), $lte: new Date(toDate) } } );
    } 
    if(status) {
        filerOrCond.push({"status": { $regex: status, $options: "i" }});
    }
    
    const filterObject:any = {district: district, status: { $ne: 'Incomplete' }};
    if(filterAndCond.length) {
        filterObject['$and'] = filterAndCond;
    }
    if(filerOrCond.length) {
        filterObject['$or'] = filerOrCond;
    }
    
    const totalCount=await DaSociety.find(filterObject).countDocuments();
    const dasocieties = await DaSociety.find(filterObject).sort({createdAt: -1}).skip(skip).limit(limit).allowDiskUse(true);     
    
    return { dasocieties, totalCount };
}

export const _createSociety = async (payload: any) => {
    return await new DaSociety(payload).save();
}

export const _getDaSociety = async (id: string) => {
    return await DaSociety.findOne({_id: id });
}

export const _getDaSocietyByAppId = async (id: string) => {
    return await DaSociety.findOne({applicationNumber: id });
}

export const _getUserSocietyDetails = async (userId: ObjectId) => {
    return await DaSociety.findOne({ userId: userId });
}
export const _createSocietyMember = async (payload: DASocietyMembers) => {
    return await DASocietyMembers.insertMany(payload);
}

export const _checkSociety = async (societyName: string, district: string) => { 
    return await DaSociety.findOne({ societyName: {$regex: societyName.replace(/\s+/g, ' ').trim(), $options: "i"}, district: district, status: {$ne: 'Rejected'},isActive:true });
}

export const _updateSociety = async (id:any, payload: any) => {

    return await DaSociety.findByIdAndUpdate({_id:id},{$set:{...payload},},{ returnOriginal: false });
}

export const _updateSocietyInActive = async (id:any) => {

    return await DaSociety.findByIdAndUpdate({applicationNumber:id},{$set:{isActive:false}},{ returnOriginal: false });
}
export const _updateReApplySociety = async (id:any, payload: any) => {

    return await DaSociety.findByIdAndUpdate({_id:id},{...payload},{ returnOriginal: false });
}

export const _saveHistory = async (id:any) => {

    let historyData:any = await _getDaSociety(id);
    console.log("id::",id)
    historyData.historyDetails = [];

    if(historyData?.status == 'Approved' || historyData?.status == 'Rejected')
    {
        return await DaSociety.findOneAndUpdate(
            { _id: id },
            {
                $push: { historyDetails: historyData },
            },
        );
    }
    return false;
}

export const _downloadsHistory = async (id:any, payload: any) => {

    return await DaSociety.findOneAndUpdate(
        { _id: id },
        {
            $push: { downloadsHistory: payload },
            isdownload: true
        },
    );
}

export const _downloadsByLawHistory = async (id:any, payload: any) => {

    return await DaSociety.findOneAndUpdate(
        { _id: id },
        {
            $push: { downloadsByeLawHistory: payload },
            isByLawDownload: true
        },
    );
}

export const _sendSMS = async (id: string, deptUpdatedBy: string, messageToApplicant: Object) => {

   // console.log("<=== messageToApplicant ===>", messageToApplicant);

    return await DaSociety.findOneAndUpdate(
        { _id: id },
        {
            deptUpdatedBy: deptUpdatedBy,
            $push: { messageToApplicant: messageToApplicant },
        },
    );
}

export const _processingHistoryUpdate = async (id: string, deptUpdatedBy: string, remarksData: Object) => {
    return await DaSociety.findOneAndUpdate(
        { _id: id },
        {
            deptUpdatedBy: deptUpdatedBy,
            $push: { processingHistory: remarksData },
        },
    );
}

export const _paymentResponseUpdate = async (id: string, paymentResponseData: Object, status: any,paymentStatus:any) => {
    return await DaSociety.findOneAndUpdate(
        { _id: id },
        {
            status: status,
            paymentStatus: paymentStatus,
            $push: { paymentDetails: paymentResponseData },
        },
    );
}
export const _statusUpdate = async (id: string, status: any) => {
    return await DaSociety.findOneAndUpdate(
        { _id: id },
        {
            status: status
        },
    );
}
export const _fetchAuthorityDetails = async () => {
    return await DaSociety.find(
        {status:['AppealedToHA','AcceptedByHA']}
    );
}
