import { body, query, param, check, validationResult } from 'express-validator'
import express, { Request, Response, NextFunction } from 'express';

export const validateSocietyName = () => {
    return [
        body('societyName').notEmpty().withMessage('Firm Name is not allowed to be empty'),
        body('district').notEmpty().withMessage('District is not allowed to be empty'),
        checkErrors,
    ]
}

export const validateSMS = () => {
    return [
        body('message').notEmpty().withMessage('Message is not allowed to be empty'),
        checkErrors,
    ]
}


export const validateCreateNewSociety = () => {
    return [
        body('societyName').notEmpty().withMessage('Society Name is not allowed to be empty'),
        body('district').notEmpty().withMessage('District is not allowed to be empty'),
        body('firstName').notEmpty().withMessage('First Name is not allowed to be empty'),
        body('lastName').notEmpty().withMessage('Last Name is not allowed to be empty'),
        body('email').notEmpty().withMessage('Email is not allowed to be empty'),
        body('alternateEmail').notEmpty().withMessage('Alternate Email is not allowed to be empty'),
        body('mobileNumber').notEmpty().withMessage('Mobile Number is not allowed to be empty'),
        body('aadharNumber').notEmpty().withMessage('Aadhar Number is not allowed to be empty'),
        body('registrationType').notEmpty().withMessage('Registration Type is not allowed to be empty'),
        checkErrors,
    ]
}

export const validateLogin = () => {
    return [
        body('otp').notEmpty().withMessage('Aadhar Number is not allowed to be empty'),
        //body('password').notEmpty().withMessage('Password is not allowed to be empty'),
        checkErrors,
    ]
}
export const validateDepartmentChangePassword = () => {
    return [
        // body('oldPassword').notEmpty().withMessage('Old Password is not allowed to be empty'),
        body('password').notEmpty().withMessage('Password is not allowed to be empty'),
        checkErrors,
    ]
}
export const validatedepartmentLogin = () => {
    return [
        body('userNameOrEmail').notEmpty().withMessage('User Id is not allowed to be empty'),
        body('password').notEmpty().withMessage('Password is not allowed to be empty'),
        checkErrors,
    ]
}

export const validateCheckUser = () => {
    return [
        body('email').notEmpty().withMessage('email is not allowed to be empty'),
        body('aadharNumber').notEmpty().withMessage('Aadhar Number is not allowed to be empty'),
        checkErrors,
    ]
}

export const validatecheckUserAadhar = () => {
    return [
        body('aadharNumber').notEmpty().withMessage('Aadhar Number is not allowed to be empty'),
        checkErrors,
    ]
}

export const checkErrors = (req: Request, res: Response, next: NextFunction) => {
    const errors = validationResult(req)

    if (errors.isEmpty()) {
        return next()
    }

    return res.status(400).send({
        success: false,
        message: errors.array()[0].msg,
        data: {}
    });
}
export const validateUpdateuser = () => {
    return [
        body('AadharNumber').notEmpty().withMessage('aadharNumber is not allowed to be empty'),
        body('SocietyName').notEmpty().withMessage('name is not allowed to be empty'),
        body('relationName').notEmpty().withMessage('relationName is not allowed to be empty'),
        body('doorNo').notEmpty().withMessage('doorNo is not allowed to be empty'),
        body('street').notEmpty().withMessage('street is not allowed to be empty'),
        body('district').notEmpty().withMessage('district is not allowed to be empty'),
        body('mandal').notEmpty().withMessage('mandal is not allowed to be empty'),
        body('villageOrCity').notEmpty().withMessage('villageOrCity is not allowed to be empty'),
        body('pinCode').notEmpty().withMessage('pinCode is not allowed to be empty'),
        body('mobileNumber').notEmpty().withMessage('mobileNumber is not allowed to be empty'),
        body('email').notEmpty().withMessage('email is not allowed to be empty'),
        body('category').notEmpty().withMessage('category is not allowed to be empty'),
        body('generalBodyMeeting').notEmpty().withMessage('generalBodyMeeting is not allowed to be empty'),
        body('nameOfRegistrationDistrict').notEmpty().withMessage('nameOfRegistrationDistrict is not allowed to be empty'),
        // body('aim').notEmpty().withMessage('aim is not allowed to be empty'),
        // body('objective').notEmpty().withMessage('objective is not allowed to be empty'),
        body('membershipConditions').notEmpty().withMessage('memeberConditions is not allowed to be empty'),
        body('meetingConditions').notEmpty().withMessage('meetingConditions is not allowed to be empty'),
        body('quorumSize').notEmpty().withMessage('quorumSize is not allowed to be empty'),
        body('documentType').notEmpty().withMessage('document Type is not allowed to be empty'),
        body('documentName').notEmpty().withMessage('documentName is not allowed to be empty'),
        body('memberType').notEmpty().withMessage('memberType is not allowed to be empty'),
        body('memberName').notEmpty().withMessage('memberName is not allowed to be empty'),
        body('joiningDate').notEmpty().withMessage('joiningDate is not allowed to be empty'),
        body('role').notEmpty().withMessage('role is not allowed to be empty'),
        body('age').notEmpty().withMessage('age is not allowed to be empty'),
        body('occupation').notEmpty().withMessage('occupation is not allowed to be empty'),
        body('qualification').notEmpty().withMessage('qualification is not allowed to be empty'),
        body('role').notEmpty().withMessage('role is not allowed to be empty'),
        body('soundMind').notEmpty().withMessage('soundMind is not allowed to be empty'),
        body('insolvent').notEmpty().withMessage('insolvent is not allowed to be empty'),
        body('offense').notEmpty().withMessage('offense is not allowed to be empty'),
        body('appointment').notEmpty().withMessage('appointment is not allowed to be empty'),
        body('officeBearers').notEmpty().withMessage('officeBearers is not allowed to be empty'),
        body('finance').notEmpty().withMessage('finance is not allowed to be empty'),
        body('auditor').notEmpty().withMessage('auditor is not allowed to be empty'),
        body('raisingFunds').notEmpty().withMessage('raisingFunds is not allowed to be empty'),
        body('liabilityConditions').notEmpty().withMessage('liabilityConditions is not allowed to be empty'),
        body('otherMatters').notEmpty().withMessage('otherMatters is not allowed to be empty'),
        checkErrors,
    ]
}

