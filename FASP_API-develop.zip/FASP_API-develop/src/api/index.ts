import express from 'express';
import { UserController } from './controllers/UserController';
import { AuthController } from './controllers/AuthController';
import { SocietyController } from './controllers/SocietyController';
//import { NationalEmblemPreventionController } from './controllers/NationalEmblemPreventionController';
import { NationalEmblemPreventionController } from './controllers/NationalEmblemsPreventionController';
const router = express.Router();
import { isLogin, isAdmin } from './middleware/auth';

import {  validateCreateNewSociety,  validateLogin, validatedepartmentLogin, validateCheckUser, validateSocietyName, validateSMS, validatecheckUserAadhar, validateDepartmentChangePassword}  from './middleware/validations';

import { setAppNumber, societyDocsUpload} from '../utils/functions';
import { Request, Response, NextFunction } from 'express';
import { MasterController } from './controllers/MasterController';
import { PaymentController } from './controllers/PaymentController';
import multer from 'multer';

const upload = multer({});
const generateAppNumber = (req: Request, res: Response, next: NextFunction) => {
    setAppNumber();
    next();
}

//userController
router.post('/users/createSociety', validateCreateNewSociety(), generateAppNumber, UserController.createFirmSocietyUser);
router.get('/users', isLogin, UserController.getallUsers);
router.get('/users/:id', isLogin, UserController.getUserById);
router.put('/users/update/:id', isLogin, UserController.updateUsers);
router.post('/checkUser', validateCheckUser(), UserController.checkUser);
router.post('/checkUserAadhar', validatecheckUserAadhar(), UserController.checkUserAadhar);


//Authentication
router.post('/login', validateLogin(), AuthController.loginUser);
router.post('/departmentLogin', validatedepartmentLogin(), AuthController.loginDepartment);
router.post('/reset', isLogin, AuthController.resetUser);
router.get('/getRefreshToken', isLogin, AuthController.getRefreshToken);
router.post('/verifyOTP', UserController.verifyOTP)
router.get('/societies/reports', isLogin, isAdmin, SocietyController.reports);
router.post('/department/changePassword', isLogin, isAdmin, validateDepartmentChangePassword(), AuthController.changePassword);
router.post('/department/update', isLogin, isAdmin, upload.single('selfSignedSignature'), UserController.updateDepartmentUser);
router.get('/logout', isLogin, AuthController.Logout);
router.post('/societies/redirectPayment', SocietyController.RedirectPayment);
router.post('/societies/redirectcertificate', SocietyController.RedirectCertificate);
router.post('/societies/redirectbylawcertificate', SocietyController.RedirectBylawCertificate);
router.post('/sendSMSMail',SocietyController.sendSMSMail)
//DA Societies
router.post('/societies/check', validateSocietyName(), SocietyController.checkSociety);
router.post('/societies/changeName/:id', validateSocietyName(), SocietyController.changeName);
router.post('/societies/update',isLogin,societyDocsUpload,SocietyController.updateSociety);
router.get('/societies', isLogin, isAdmin, SocietyController.getAllSocieties);
router.get('/societies/:id', isLogin, SocietyController.getSociety);
router.get('/societies/getSocietyByAppId/:id', isLogin, SocietyController.getSocietyByAppId);
router.put('/societies/sendSMS/:id', validateSMS(), isLogin, isAdmin, SocietyController.sendSMS);
router.post('/societies/remarks', isLogin, isAdmin, SocietyController.processingHistory);
router.post('/societies/downloads/:id', isLogin, SocietyController.downloadsHistory);
router.post('/societies/byeLawdownloads/:id', isLogin, SocietyController.downloadsByLawHistory);
router.get('/certificateDetails/:id', isLogin, UserController.getDepartmentCertificateDetails);

router.post('/department/dataEntry', isLogin, isAdmin,societyDocsUpload, SocietyController.SocietyDataEntry);

router.post('/checkAvailability',NationalEmblemPreventionController.checkAvailability) 
router.get('/getDistricts', MasterController.getDistricts);
router.post('/getDistrictsMandals', MasterController.getDistrictsMandals);
router.post('/getDistrictsMandalVillages', MasterController.getDistrictsMandalVillages);
router.post('/getDistrictDdoCode', MasterController.getDistrictDdoCode);

router.get('/getPaymentDetails/:id', isLogin, PaymentController.getPaymentDetails);
router.post('/paymentResponseDetails/:id', isLogin, PaymentController.paymentResponseDetails);
router.post('/confirmDephaseTransaction/:id', isLogin, isAdmin, PaymentController.confirmDephaseTransaction);

router.get('/downloads/:id/:fileName', SocietyController.downloadFile);
router.get('/fetchAuthorityDetails', SocietyController.fetchAuthorityDetails);
export default router;

