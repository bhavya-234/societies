import express, { Request, Response } from 'express';
import { User, DepartmentUsers } from '../../models/index'
import { _checkUser, createUser, _checkUserAadhar, _checkVerifyOTP, _getUUIDByAadharNumber, updatecaptcha } from '../../services/UserService';
import { generateJWTToken } from '../../utils/functions'
import { _checkSociety, _createSociety } from '../../services/SocietyService';
import { userSession } from '../middleware/auth';
const CryptoJS = require('crypto-js')
import logger from '../../logger';
import moment from 'moment';

export const getallUsers = async (req: Request, res: Response) => {
    try {
        const users = await User.find({}, { password: 0 });
        return res.json(users);
    } catch (error) {
        return res.status(500).json({ message: 'Internal server error', success: false, data: {} });
    }

}
export const getUserById = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const users = await User.findOne({
            _id: id
        }, { password: 0 });

        if (!users) {
            const error = new Error('User does not exist');
            return res.status(500).json(error)
        }

        res.json(users);
    } catch (error) {
        logger.error(`error-`, error);
        return res.status(500).json({ message: 'Internal server error', success: false, data: {} });
    }

};
export const getDepartmentCertificateDetails = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const user = await DepartmentUsers.findOne({
            _id: id
        }, { _id: 0, fullName: 1, district: 1, signature: 1 });

        if (!user) {
            const userDetailsEnc = CryptoJS.AES.encrypt(JSON.stringify({ message: "User does not exist.", success: false, data: {} }), process.env.SECRET_KEY).toString();

            //const error = new Error('User does not exist');
            return res.status(400).send(userDetailsEnc);

        }
        // else if(user.district!=userSession.district){
        // const userDetailsEnc = CryptoJS.AES.encrypt(JSON.stringify({ message: "unauthorized request.", success: false, data: {} }), process.env.SECRET_KEY).toString();

        //     return res.status(400).send(userDetailsEnc);
        // }

        const userDetailsEnc = CryptoJS.AES.encrypt(JSON.stringify({ message: "User data fetched successfully.", success: true, data: user }), process.env.SECRET_KEY).toString();

        return res.status(200).send(userDetailsEnc);

    } catch (error) {
        return res.status(500).json({ message: 'Internal server error', success: false, data: {} });
    }
};
export const checkUser = async (req: Request, res: Response) => {

    let { email, aadharNumber } = req.body;
    aadharNumber = JSON.parse(CryptoJS.AES.decrypt(aadharNumber, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8));
    console.log("<================  userCheck Start  ================>");
    const resp = await _getUUIDByAadharNumber(aadharNumber.toString())
    if (resp.data?.status == "Success") {
        aadharNumber = resp.data.UUID
    }
    else {
        return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
    }
    const userCheck = await _checkUser(email, aadharNumber);
    console.log("<================  userCheck  ================>", userCheck);
    req.body.userKey = CryptoJS.AES.decrypt(req.body.userKey, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8)

    console.log("<================  userKey  ================>", req.body.userKey);
    console.log("req.body.captchaVal",req.body.captchaVal)
    if(req.body.captchaVal=="" ){
        return res.status(400).send({ success: false, message: "Please enter valid captcha details", data: {} });
    }else if(req.body.userKey==""){
        return res.status(400).send({ success: false, message: "Please enter valid captcha details", data: {} });
    }else if (req.body.captchaVal == req.body.userKey) {
        if (userCheck) {
            // if(req.body.loginAttemptsLeft==undefined)
            //     req.body.loginAttemptsLeft=5;
            // if (req.body &&  req.body.loginAttemptsLeft > 0 ) {
            //     req.body = req.body.loginAttemptsLeft - 1;       
            // }
            // return res.status(404).send({Success:false,message:`Invalid Request. ${req.body.loginAttemptsLeft > 0 ? `${req.body.loginAttemptsLeft} attempts left.` : `Login is blocked for 5 minutes.`}`});
            // delete req.body.userKey;
            logger.info(`user already exists -${email}`);
            return res.status(200).send({
                success: false,
                message: 'Invalid Request!',
                data: {}
            });
           
        }
        else {
            logger.info(`Invalid Credentials -${email}`);
            return res.status(200).send({
                success: true,
                message: 'Invalid Credentials',
                data: {}
            });

        }
    } else {
        return res.status(400).send({ success: false, message: "Please enter valid captcha details", data: {} });

    }
};

export const checkUserAadhar = async (req: Request, res: Response) => {

    let { aadharNumber } = req.body;

    aadharNumber = JSON.parse(CryptoJS.AES.decrypt(aadharNumber, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8));

    console.log("<================  userCheck Start  ================>", aadharNumber);
    const resp = await _getUUIDByAadharNumber(aadharNumber.toString())
    if (resp.data?.status == "Success") {
        aadharNumber = resp.data.UUID
    }
    else {
        return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
    }


    req.body.userKey = CryptoJS.AES.decrypt(req.body.userKey, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8)

    console.log("<================  userKey  ================>", req.body.userKey);
    if(req.body.captchaVal=="" ){
        return res.status(400).send({ success: false, message: "Please enter valid captcha details", data: {} });
    }else if(req.body.userKey==""){
        return res.status(400).send({ success: false, message: "Please enter valid captcha details", data: {} });
    }else if (req.body.captchaVal == req.body.userKey) {
        const userCheck = await _checkUserAadhar(aadharNumber);
        console.log("<================  userCheck  ================>", userCheck);       
        if (userCheck) {
            
           let userObj= await User.findOne({_id:userCheck._id,captchaVal:req.body.captchaVal})
           console.log("userObj",userObj)
           if(userObj){
            return res.status(200).send({
                success: false,
                message: 'Invalid Captcha',
                data: {}
            });
           }
            await updatecaptcha(userCheck._id,req.body.captchaVal)
            const refId = CryptoJS.AES.encrypt(userCheck._id.toString(), process.env.SECRET_KEY).toString();
            logger.info(`success- ${refId}`);

            console.log("<================  req.body.captchaVal  ================>", req.body.captchaVal);
            
            return res.status(200).send({
                success: true,
                message: 'Success!',
                data: { refId: refId }
            });
        }
        else {
            logger.error(`user is not available`);
            
            return res.status(200).send({
                success: false,
                message: 'Invalid Credentials',
                data: {}
            });

        }
    } else {
        return res.status(400).send({ success: false, message: "Please enter valid captcha details", data: {} });

    }
};
export const verifyOTP = async (req: Request, res: Response) => {

    const { otp } = req.body;
    //console.log("<================  otp Request  ================>", otp);

    var bytes = CryptoJS.AES.decrypt(otp, process.env.SECRET_KEY);
    var otpData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));


    if (otpData.aadharNumber == '')
        return res.status(400).send({ success: false, message: "Aadhaar Number is not allowed to be empty", data: {} });
    else if (otpData.transactionNumber == '')
        return res.status(400).send({ success: false, message: "Transaction Number is not allowed to be empty", data: {} });
    else if (otpData.otp == '')
        return res.status(400).send({ success: false, message: "OTP is not allowed to be empty", data: {} });

    console.log("<================  userCheck Start  ================>");
    const otpResponse = await _checkVerifyOTP(otpData);
    console.log("<================  userCheck  ================>", otpResponse);

    if (otpResponse.status == 200) {

        if (otpResponse.data.status != 'Success') {
            return res.status(200).send({
                success: false,
                message: otpResponse.data.message,
                userInfo: {}
            });
        }
        else {
            const userDetailsEnc = CryptoJS.AES.encrypt(JSON.stringify(otpResponse.data), process.env.SECRET_KEY).toString();
            return res.status(200).send({
                success: true,
                message: 'OTP Verified',
                userInfo: userDetailsEnc
            });
        }
    }
    else {
        logger.error(`something went wrong`);
        return res.status(200).send({
            success: false,
            message: 'Something went wrong. Please try again',
            userInfo: {}
        });

    }
};
export const createFirmSocietyUser = async (req: Request, res: Response) => {
    try {
        const request: any = { ...req.body }

        let { registrationType, firmName, societyName, district, email, alternateEmail, aadharNumber, loginOtp, transactionNumber } = request;
        console.log("aadharNumber:::", Buffer.from(aadharNumber, 'base64').toString())
        // aadharNumber = CryptoJS.AES.decrypt(aadharNumber, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8)
        
        let otpData = {
            aadharNumber:aadharNumber,
            transactionNumber: transactionNumber,
            otp: loginOtp.toString()
        }
        const otpResponse = await _checkVerifyOTP(otpData);


        if (otpResponse.status == 200) {
            console.log("otpResponse.data::", otpResponse.data)
            if (otpResponse.data.status != 'Success') {
                return res.status(200).send({
                    success: false,
                    message: otpResponse.data.message,
                    data: {}
                });
            }
            else {
                aadharNumber = CryptoJS.AES.decrypt(aadharNumber, process.env.IGRS_SECRET_KEY).toString(CryptoJS.enc.Utf8);

                // aadharNumber = Buffer.from(aadharNumber, 'base64').toString()
                console.log("<================  registrationType  ================>", registrationType);
                if (registrationType != 'firm' && registrationType != 'society') throw new Error;

                if (email === alternateEmail) return res.status(200).send({ message: "Email and alternate email should not be same", success: false, data: {} });

                console.log("<================  userCheck Start  ================>");
                const resp = await _getUUIDByAadharNumber(aadharNumber)
                if (resp.data?.status == "Success") {
                    aadharNumber = resp.data.UUID
                    request.aadharNumber = resp.data.UUID
                }
                else {
                    return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                }
                const userCheck = await _checkUser(email, aadharNumber);
                console.log("<================  userCheck  ================>", userCheck);

                if (userCheck) {
                    logger.warn(`user already exists -${email}`);
                    return res.status(200).send({
                        success: false,
                        message: 'Invalid Request!',
                        data: {}
                    });
                }

                else if (registrationType == 'society') {
                    const societyCheck = await _checkSociety(societyName, district);
                    console.log("<================  societyName  ================>", societyCheck);
                    if (societyCheck) {
                        return res.status(200).send({ message: "Society already exists!", success: false, data: {} });
                    }
                }

                let user = await createUser(request);
                console.log("<================  user  ================>", user);
                if (!user) {
                    return res.status(200).send({ message: "Invalid Request!", success: false, data: {} });
                }

                let applicationNumber = '';
                let applicationId;

                applicationNumber = 'SCR' + Date.now() + ((Math.random() * 100000).toFixed());
                const societyPayload = {
                    societyName: societyName,
                    district: district,
                    userId: user._id,
                    applicationNumber: applicationNumber,
                    createdBy: userSession.email,
                    version: process.env.E_VERSION,
                    clientLocalAddress: req.body.clientLocalAddress,
                }

                console.log("<================  firmPayload  ================>", societyPayload);

                const society = await _createSociety(societyPayload);
                console.log("<================  society  ================>", society);

                if (!society) {
                    return res.status(200).send({
                        success: false,
                        message: 'Unable to create society. Please try again',
                        data: {}
                    });
                } else {
                    applicationId = society._id;
                }
                user.userType = 'user';
                user.applicationNumber = applicationNumber;
                user.applicationId = applicationId;

                user.token = generateJWTToken(user);
                return res.status(200).send({
                    success: true,
                    message: 'User Saved Sucessfully!',
                    data: CryptoJS.AES.encrypt(JSON.stringify(user), process.env.SECRET_KEY).toString()
                });
            }

        }
        else {
            logger.error(`something went wrong`);
            return res.status(200).send({
                success: false,
                message: 'Something went wrong. Please try again',
                userInfo: {}
            });

        }
    } catch (error) {
        console.log("<================  error  ================>", error);
        return res.status(500).send({
            success: false,
            message: "Unable to create user. Please try again",
            data: {}
        });
    }
}

export const updateDepartmentUser = async (req: Request, res: Response) => {
    try {
        const { fullName, mobileNumber } = req.body;
        const signature = req.file?.buffer.toString('base64');

        //console.log("<================  signature  ================>", signature);
        //console.log("<================  signature Mime Type ================>", req.file?.mimetype);
        //console.log("<================  fullName  ================>", fullName);
        //console.log("<================  mobileNumber  ================>", mobileNumber);

        if (mobileNumber && mobileNumber.length < 10)
            return res.status(400).send({ message: "Enter valid mobile number", success: false, data: {} });

        if (req.file && req.file?.mimetype != 'image/jpeg')
            return res.status(400).send({ message: "Upload valid signature", success: false, data: {} });

        const user = await DepartmentUsers.findById({ _id: userSession._id })
        //console.log("<================  Dept User  ================>", user);
        //return false;

        if (!user) {
            return res.status(200).send({ message: "User doesn't exists!", success: false, data: {} });
        }
        const updateUser = {
            fullName: fullName,
            mobileNumber: mobileNumber,
            signature: signature,
            updatedBy: userSession.email,
            version: process.env.E_VERSION
        };
        const result = await DepartmentUsers.findOneAndUpdate({ _id: userSession._id }, updateUser);

        return res.status(200).send({ message: "User saved successfully.", success: true, data: {} });
    }
    catch (error) {
        return res.status(500).send({ message: "Something went wrong, please try again", success: false, data: {} });
    }
}
export const updateUsers = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        // console.log(id);

        const users = await User.findById({ _id: id })
        if (!users) {
            return res.status(500).json({ message: 'doesnot exist' })
        }
        const {
            userName,
            dob,
            firstName,
            lastName,
            gender,
            email,
            password,
            roleType,
            status,
            createdBy,
            modifiedBy,
            updatedBy, } = req.body;
        const newUser = {
            userName,
            dob,
            firstName,
            lastName,
            gender,
            email,
            password,
            roleType,
            status,
            createdBy,
            modifiedBy,
            updatedBy,
        };
        const result = await User.findOneAndUpdate({ _id: id }, newUser);
        res.json(result);

    }
    catch (error) {
        logger.error(`error-`, error);
        return res.status(500).json({ message: 'Internal server error', success: false, data: {} });

    }
}

/*
export const deleteUser =async (req: Request, res: Response)=>{
    try{
        const {id}=req.params;
        const result = await User.deleteOne({_id:id})
        res.status(200).json(result);
 
    }
    catch(error){
        return res.status(500).json(error);
 
    }
 
}
*/
export * as UserController from './UserController';