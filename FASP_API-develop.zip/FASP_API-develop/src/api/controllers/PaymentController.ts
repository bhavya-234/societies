import express, { Request, Response } from 'express';
import logger from '../../logger';
import { PaymentsInformation } from '../../models/index'
import { _paymentResponseUpdate } from '../../services/SocietyService';
import { DaSociety } from '../../models/index';
import { userSession } from '../middleware/auth';
import { _checkVerifyPayment } from '../../services/UserService';

export const getPaymentDetails = async (req: Request, res: Response) => {
    try {
        const id = userSession._id;
        const applicationNumber = req.params.id;

        console.log("userSession._id", userSession._id)

        if (userSession.userType == "user") {
            const societyData: any = await DaSociety.findOne({ applicationNumber: applicationNumber, userId: id })
            console.log("societyData.applicationNumber}", societyData.applicationNumber)
            if (!societyData) {
                return res.status(401).send({ message: 'Unauthorized Access', success: true, data: {} });

                //return res.json(paymentDetails);
            } else {
                const societyDataNew: any = await DaSociety.findOne({ historyDetails: [], processingHistory: [] })

                const paymentDetails = await PaymentsInformation.findOne({ applicationNumber: applicationNumber }).sort({ createdAt: -1 });
                if (paymentDetails) {
                    const paymentdata = await _checkVerifyPayment(paymentDetails.departmentTransID)
                    if (paymentdata) {

                        if (societyDataNew && paymentDetails.totalAmount == paymentdata.data.data.totalAmount && paymentDetails.totalAmount == 500) {
                            if (paymentDetails.transactionStatus == "Failure") {
                                return res.status(200).send({ message: 'Payment failed', success: true, data: {} });

                            } else {
                                return res.status(200).send({ message: 'Payment Details Fetched Successfully', success: true, data: { paymentDetails: paymentDetails } });
                            }
                        } else if (!societyDataNew && paymentDetails.totalAmount == paymentdata.data.data.totalAmount) {
                            if (paymentDetails.transactionStatus == "Failure") {
                                return res.status(200).send({ message: 'Payment failed', success: true, data: {} });

                            } else {
                                return res.status(200).send({ message: 'Payment Details Fetched Successfully', success: true, data: { paymentDetails: paymentDetails } });
                            }
                        } else {
                            return res.status(400).send({ message: 'Payment Invalid', success: true, data: { paymentDetails: paymentDetails } });

                        }

                    } else {
                        return res.status(400).send({ message: 'Payment Failed', success: true, data: { paymentDetails: paymentDetails } });

                    }
                } else {
                    return res.status(204).send({ message: 'No Data Found', success: true, data: {} });
                }
            }
        } else {
            const paymentDetails = await PaymentsInformation.findOne({ applicationNumber: applicationNumber }).sort({ createdAt: -1 });
            if (paymentDetails) {
                if (paymentDetails.transactionStatus == "Failure") {
                    return res.status(200).send({ message: 'Payment failed', success: true, data: {} });

                } else {
                    return res.status(200).send({ message: 'Payment Details Fetched Successfully', success: true, data: { paymentDetails: paymentDetails } });
                }
            } else {
                return res.status(204).send({ message: 'No Data Found', success: true, data: {} });
            }
        }
    } catch (error) {
        return res.status(500).json({ message: 'Internal server error', success: false, data: {} });
    }
}

export const paymentResponseDetails = async (req: Request, res: Response) => {
    try {
        const paymentResponseData = {
            applicationNumber: req.body.applicationNumber,
            departmentTransID: req.body.departmentTransID,
            cfmsTransID: req.body.cfmsTransID,
            transactionStatus: req.body.transactionStatus,
            amount: req.body.amount,
            totalAmount: req.body.totalAmount,
            paymentMode: req.body.paymentMode,
            bankTransID: req.body.bankTransID,
            bankTimeStamp: req.body.bankTimeStamp,
            isUtilized: req.body.isUtilized,
            createdAt: req.body.createdAt
        }

        let status = 'Incomplete';
        let paymentStatus = false;
        if (req.body.transactionStatus == "Success") {
            status = 'submitted';
            paymentStatus = true;
        }

        console.log("<=====  paymentResponseData  =====>", paymentResponseData);

        const paymentDetails = await _paymentResponseUpdate(req.params.id, paymentResponseData, status, paymentStatus);
        return res.status(200).send({ message: 'Payment Response Details Saved Successfully', success: true, data: {} });
    } catch (error) {
        return res.status(500).json({ message: 'Internal server error', success: false, data: {} });
    }
}

export const confirmDephaseTransaction = async (req: Request, res: Response) => {
    try {
        await PaymentsInformation.findOneAndUpdate(
            { departmentTransID: req.params.id },
            {
                isUtilized: true
            },
        );

        await DaSociety.findOneAndUpdate(
            { "paymentDetails.departmentTransID": req.params.id },
            {
                "paymentDetails.$.isUtilized": true
            },
        );

        return res.status(200).send({ message: 'Dephase Saved Successfully', success: true, data: {} });
    } catch (error) {
        return res.status(500).json({ message: 'Internal server error', success: false, data: {} });
    }
}

export * as PaymentController from './PaymentController';