import express, { Request, Response } from 'express';
import logger from '../../logger';
import { _checkAvailability } from '../../services/NationalEmblemPreventionService';


export const checkAvailability = async(req: Request, res: Response) =>{

    const {registrationName} = req.body;
    console.log("<================  userCheck Start  ================>");
    const firmCheck = await _checkAvailability(registrationName);
    console.log("<================  userCheck  ================>", firmCheck);

    if(firmCheck.length) {
        logger.error(`Name is not available under national emblem act`);
        return res.status(200).send({
            success: false,
            message: 'Name is not available under national emblem act',
            data: {}
        });              
    }
    else{
        logger.info(`name is available ${registrationName}`);
        return res.status(200).send({
            success: true,
            message: 'Name is available',
            data: {}
        });              

    }
};




export * as NationalEmblemPreventionController from './NationalEmblemsPreventionController';