import { Request, Response } from 'express';
import { DaSociety, User } from '../../models/index';
import { getDocs } from '../../utils/functions';
import { getDaSocities, _createSociety, _updateSociety, _getDaSociety, _createSocietyMember, _checkSociety, _sendSMS, _processingHistoryUpdate, _saveHistory, _downloadsHistory, _downloadsByLawHistory, _paymentResponseUpdate, _updateReApplySociety, _statusUpdate, _fetchAuthorityDetails, _getDaSocietyByAppId, _updateSocietyInActive } from '../../services/SocietyService';
import moment from 'moment';
import { ObjectId } from 'mongodb'
import { userSession } from '../middleware/auth';
import logger from '../../logger';
import axios from 'axios';
import { _getAadharNumberByUUID, _getUUIDByAadharNumber, createUser } from '../../services/UserService';
const CryptoJS = require('crypto-js')
const fs = require('fs');
const Path = require('path');
var xl = require('excel4node');
const nodemailer = require("nodemailer");

export const checkSociety = async (req: Request, res: Response) => {
    try {
        const { societyName, district } = req.body;
        console.log("<================  societyName  ================>", societyName);

        const society = await _checkSociety(societyName, district);

        console.log("<================  society  ================>", society);

        if (society) {
            return res.status(200).send({ message: "Society already exists!", success: false, data: {} });
        }

        return res.status(200).send({ message: 'Society is available to register', success: true, data: {} });
    } catch (error) {
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }
};
export const RedirectPayment = async (req: Request, res: Response) => {

    res.writeHead(301, {

        'Location': `${process.env.REDIRECTURL}`

    }).end();
}
export const RedirectCertificate = async (req: Request, res: Response) => {

    res.writeHead(301, {

        'Location': `${process.env.REDIRECTCERTIFICATEURL}`

    }).end();
}
export const RedirectBylawCertificate = async (req: Request, res: Response) => {

    res.writeHead(301, {

        'Location': `${process.env.REDIRECTBYLAWCERTIFICATEURL}`

    }).end();
}

export const changeName = async (req: Request, res: Response) => {
    try {
        const { societyName, district } = req.body;
        console.log("<================  societyName  ================>", societyName);
        console.log("<================  district  ================>", district);
        console.log("<================  req.params.id  ================>", req.params.id);

        const society = await _checkSociety(societyName, district);

        console.log("<================  society  ================>", society);

        if (society) {
            return true;
            //res.status(200).send({ message: "Society already exists!", success: false, data: {} });
        }
        else {
            const payload = {
                societyName: societyName,
                district: district,
                status: 'Incomplete'
            }
            const daSociety = await _updateSociety(req.params.id, payload);
            return false;
            //res.status(200).send({ message: 'Society Name changed successfully', success: true, data: {society: daSociety} });         
        }

    } catch (error) {
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }

};

export const reports = async (req: Request, res: Response) => {
    try {

        let approved = 0;
        let rejected = 0;
        let notViewed = 0;
        let forwarded = 0;
        let open = 0;

        const firms = await DaSociety.find({ district: userSession.district, status: { $ne: 'Incomplete' } }, { status: 1 })

        firms.forEach(firm => {
            if (firm.status == 'Approved')
                approved += 1;
            if (firm.status == 'Rejected')
                rejected += 1;
            if (firm.status == 'Not Viewed')
                notViewed += 1;
            if (firm.status == 'Forwarded')
                forwarded += 1;
            if (firm.status == 'Open')
                open += 1;

            console.log("<================  firm  ================>", firm);
        });

        console.log("<================  approved  ================>", approved);
        console.log("<================  rejected  ================>", rejected);
        console.log("<================  notViewed  ================>", notViewed);
        console.log("<================  forwarded  ================>", forwarded);
        console.log("<================  open  ================>", open);

        const reports = {
            district: userSession.district,
            approved: approved,
            rejected: rejected,
            notViewed: notViewed,
            forwarded: forwarded,
            open: open
        }

        return res.status(200).send({ message: 'Reports generated successfully', success: true, data: { reports } });

    }
    catch (error) {
        console.log('error-', error);
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }
}

export const getAllSocieties = async (req: Request, res: Response) => {
    try {

        if (userSession.district) {
            const { dasocieties, totalCount } = await getDaSocities(req, userSession.district);
            //await makePdf(dasocieties);
            // await makeExcel(dasocieties);
            const data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Get DaSocieties details successfully done', success: true, data: { dasocieties, totalCount } }), process.env.SECRET_KEY).toString()
            return res.status(200).send(data);
        }
        else {
            const data = CryptoJS.AES.encrypt(JSON.stringify({ success: false, message: "Invalid User", data: {} }), process.env.SECRET_KEY).toString();
            return res.status(401).send(data);
        }

    } catch (error) {
        logger.error(`error-`);
        const data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Internal server error', success: false, data: {} }), process.env.SECRET_KEY).toString();
        return res.status(500).send(data);
    }

}
const isSocietyInvalid = (req: any, res: any) => {
    return new Promise(function (resolve, reject) {
        const body: any = req.body;
        if (!body['applicantDetails']) {
            resolve({ "success": false, "message": "applicantDetails is not allowed to be empty", "data": {} })

        } else if (!body['applicantDetails']['aadharNumber']) {
            resolve({ "success": false, "message": "applicantDetails.aadharNumber is not allowed to be empty", "data": {} })

        } else if (body['applicantDetails']) {
            const data = body['applicantDetails'];
            const applicantDetails = [
                //{ key: 'aadharNumber', reg: /^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$/ },
                { key: 'name', reg: /^[A-Za-z\s.]*$/ },
                { key: 'relationName', reg: /^[A-Za-z\s.]*$/ },
                { key: 'relationType', reg: /^[A-Za-z\s/]*$/ },
                { key: 'role', reg: /^[A-Za-z\s.]*$/ },
                { key: 'gender', reg: /^[A-Za-z\s]*$/ },
                { key: 'age', reg: /[0-9]/ },
                // { key: 'doorNo', reg: /[A-Za-z0-9/-]|,/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'state', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'country', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'district', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'mandal', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'villageOrCity', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                { key: 'pinCode', reg: /[0-9]/ },
                { key: 'mobileNumber', reg: /^\d{10}$/ },
                // { key: 'email', reg: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ },

            ];

            applicantDetails.some(obj => {
                if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": { applicantDetails } })
                    reject('rejected');
                    return true;
                }
            });
        }
        if (body['contactDetails']) {
            console.log('contactDetails................................');
            const data = body['contactDetails'];
            const contactDetails = [
                //{ key: 'landPhoneNumber', reg: /^\d+$/ },
                { key: 'mobileNumber', reg: /^\d{10}$/ },
                // { key: 'email', reg: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ },
                // { key: 'landlineNumber', reg: /^\d{10}$/ },
            ];
            contactDetails.forEach(obj => {
                if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })
                    reject('rejected');
                    return true;
                }
            });
        }
         if(body['district']||body['societyName']){
            resolve({ "success": false, "message": ` format is invalid`, "data": {} })
            reject('rejected');
            return true;
            }
           
        // if (body['societyDetails']) {
        //     console.log('societydetails................................');
        //     const societyData = body['societyDetails'];
        //     const societydetails = [

        //         // { key: 'userId', reg: /[A-Za-z0-9/-]|,/ },
        //         // { key: 'societyName', reg:/^[A-Za-z\s.]*$/ },
        //         { key: 'category', reg: /^[A-Za-z\s]*$/ },
        //         { key: 'generalBodyMeeting', reg: /[A-Za-z0-9/-]|,/ },
        //         { key: 'doorNo', reg: /[A-Za-z0-9/-]|,/ },
        //         { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
        //         { key: 'state', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
        //         { key: 'district', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
        //         { key: 'villageOrCity', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
        //         { key: 'mandal', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
        //         { key: 'pinCode', reg: /[0-9]/ },
        //         { key: 'nameOfRegistrationDistrict', reg: /^[a-zA-Z0-9\s,'-]*$/ },
        //         { key: 'aim', reg: /^[a-zA-Z0-9\s,'-]*$/ },
        //         { key: 'objective', reg: /^[a-zA-Z0-9\s,'-]*$/ },
        //         { key: 'mobileNumber', reg: /^\d{10}$/ },
        //         { key: 'email', reg: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ },

        //     ];

        //     // societyData.some((data: any) => {
        //     //     let isInvalid = false;
        //     //     societydetails.some(obj => {
        //     //         if (data[obj.key] && !obj.reg.test(data[obj.key])) {
        //     //             resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {societydetails} })
        //     //             isInvalid = true;

        //     //             return true;
        //     //         }
        //     //     });
        //     //     return isInvalid;
        //     // });
        //     societydetails.some(obj => {
        //         if (societyData[obj.key] && !obj.reg.test(societyData[obj.key])) {
        //             resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {societydetails} })
        //             reject('rejected');
        //             return true;
        //         }
        //     });
        // }
        if (body['memberDetails']) {
            console.log('memberDetails................................');
            const memberData = body['memberDetails'];
            const memberDetails = [
                { key: 'gender', reg: /^[A-Za-z\s]*$/ },
                { key: 'mobileNumber', reg: /^\d{10}$/ },
                // { key: 'email', reg: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ },
                { key: 'memberType', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                //{ key: 'aadharNumber', reg: /^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$/ },
                { key: 'memberName', reg: /^[A-Za-z\s.]*$/ },
                { key: 'relationName', reg: /^[A-Za-z\s.]*$/ },
                { key: 'role', reg: /^[A-Za-z\s.]*$/ },
                { key: 'occupation', reg: /^[A-Za-z\s]*$/ },
                { key: 'qualification', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'joiningDate', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'doorNo', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'district', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'mandal', reg:  /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'villageOrCity',  reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'pinCode', reg: /[0-9]/ }

            ];
            memberDetails.some(obj => {
                if (memberData[obj.key] && !obj.reg.test(memberData[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": { memberDetails } })
                    reject('rejected');
                    return true;
                }
            });
        }
        if (body['byeLaws']) {
            console.log('byeLaws................................');
            const data = body['byeLaws'];

            const byeLaws = [
                { key: 'societyName', reg: /^[A-Za-z\s.]*$/ },
                // { key: 'doorNo', reg: /[A-Za-z0-9/-]|,/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'state', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'district', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'villageOrCity', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'mandal',  reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/},
                { key: 'pinCode', reg: /[0-9]/ },
                { key: 'quorumSize', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'documentType', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'documentName', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'uploadDocument', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'mobileNumber', reg: /^\d{10}$/ },
                // { key: 'email', reg: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ },

            ];
            byeLaws.some(obj => {
                if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": { byeLaws } })

                    return true;
                }
            });

        }
        if (body['quorumMembers']) {
            console.log('quorumMembers................................');
            const quorumMembersData = body['quorumMembers'];
            const quorumMembers = [
                { key: 'memberType', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                //{ key: 'aadharNumber', reg: /^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$/ },
                { key: 'memberName', reg: /^[A-Za-z\s.]*$/ },
                { key: 'relationName', reg: /^[A-Za-z\s.]*$/ },
                { key: 'role', reg: /^[A-Za-z\s.]*$/ },
                { key: 'occupation', reg: /^[A-Za-z\s]*$/ },
                { key: 'qualification', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'joiningDate', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'doorNo', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'district', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'mandal', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/},
                // { key: 'villageOrCity', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                { key: 'pinCode', reg: /[0-9]/ }
            ];
            quorumMembers.some(obj => {
                if (quorumMembersData[obj.key] && !obj.reg.test(quorumMembersData[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })

                    return true;
                }
            });
        }
        if (body['auditorDetails']) {
            console.log('auditorDetails................................');
            const data = body['auditorDetails'];
            const auditorDetails = [
                { key: 'auditorName', reg: /^[A-Za-z\s.]*$/ },
                { key: 'mobileNumber', reg: /^\d{10}$/ },
                // { key: 'email', reg: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ },
                // { key: 'doorNo', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'district', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'mandal', reg:  /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'villageOrCity',  reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                { key: 'pinCode', reg: /[0-9]/ }
            ];
            auditorDetails.forEach(obj => {
                if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })

                    return true;
                }
            });
        }

     

        if (body['dissolution']) {
            console.log('dissolution................................');
            const dissolutionData = body['dissoluteSociety'];
            const dissolveSociety = [
                { key: 'reasonForDissolution', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'effectDate', reg: /[0-9]/ },
                { key: 'disposedDetails', reg: /^[a-zA-Z0-9\s,'-]*$/ }
            ];
            dissolveSociety.some(obj => {
                if (dissolutionData[obj.key] && !obj.reg.test(dissolutionData[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })

                    return true;
                }
            });
        }
        if (body['windingUpSociety']) {
            console.log('winding................................');
            const windingData = body['windingUpSociety'];
            const windingSociety = [
                { key: 'dateOfDissolution', reg: /[0-9]/ },
                { key: 'propertyDisposal', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'dateOfMeeting', reg: /[0-9]/ },
                { key: 'minutesWindingUp', reg: /^[a-zA-Z0-9\s,'-]*$/ },
            ];
            windingSociety.some(obj => {
                if (windingData[obj.key] && !obj.reg.test(windingData[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })

                    return true;
                }
            });
        }
        resolve(false);
    })
}
export const SocietyDataEntry = async (req: Request, res: Response) => {
    try {

        const files = req.files as { [fieldname: string]: Express.Multer.File[] };
        const attachments = getDocs(files);
        attachments.forEach((x: any) => { x.destination = `./uploads/0`, x.path = `./uploads/0/${x.originalname}` })
        
        if (req.body.isNameChange == "true"||req.body.isAimChange == "true"||req.body.isAddressChange == "true") {
            let societyDetails = await _updateSociety(req.body.id, req.body);
            if (societyDetails) {
                await _saveHistory(req.body.id);
                return res.status(200).send({ success: true, message: "Society updated successfully", data: { societyDetails: societyDetails }  });
                // let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: { societyDetails: societyDetails } }), process.env.SECRET_KEY).toString();
                // return res.status(200).send(da);
            }
        } else {
            let registrationNumber=req.body.registrationNumber;
            const applicationNumber = 'SCR' + Date.now() + ((Math.random() * 100000).toFixed());
            let registrationYear = req.body.registrationYear;
            const societyData: any = await DaSociety.findOne({ registrationYear: registrationYear, district: userSession.district }, { registrationNumber: 1, registrationYear: 1, district: 1 }).sort({ registrationNumber: -1 })
            if (societyData && societyData.registrationNumber > 0 && societyData.registrationYear == registrationYear && societyData.district == userSession.district) {
                registrationNumber = societyData.registrationNumber + 1;
            }
            const reqBodySociety = { ...req.body, applicationNumber: applicationNumber, registrationNumber: registrationNumber, paymentStatus: true, approvedRejectedById: userSession._id, deptUpdatedBy: userSession._id, documentAttached: attachments }
            const society = await _createSociety(reqBodySociety);
            if (society) {
                await _saveHistory(society._id);
                return res.status(200).send({
                    success: true,
                    message: 'Society details saved successfully',
                    data: {}
                });
            }
            else {
                return res.status(200).send({
                    success: false,
                    message: 'Internal error',
                    data: {}
                });
            }
        }
        // }
    } catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
}
export const updateSociety = async (req: Request, res: Response) => {
    try {
        const existingSoc = await _getDaSociety(req.body.id)
        const existingMembers = await _getDaSociety(req.body.id)

        const files = req.files as { [fieldname: string]: Express.Multer.File[] }

        const attachments = getDocs(files);

        if (req.body.isRegistration == "Yes") {
            req.body.applicantDetails.aadharNumber = CryptoJS.AES.decrypt(req.body.applicantDetails.aadharNumber, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8);
            req.body.applicantDetails.name = CryptoJS.AES.decrypt(req.body.applicantDetails.name, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8);
            req.body.applicantDetails.relationName = CryptoJS.AES.decrypt(req.body.applicantDetails.relationName, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8);
            // req.body.applicantDetails.aadharNumber = Buffer.from(req.body.applicantDetails.aadharNumber, 'base64').toString();
            // req.body.applicantDetails.name = Buffer.from(req.body.applicantDetails.name, 'base64').toString();
            // req.body.applicantDetails.relationName = Buffer.from(req.body.applicantDetails.relationName, 'base64').toString();
            if (req.body.memberDetails?.length > 0) {
                for await (let pd of req.body.memberDetails) {
                    // pd.aadharNumber = Buffer.from(pd.aadharNumber, 'base64').toString();
                    // pd.memberName = Buffer.from(pd.memberName, 'base64').toString();
                    // pd.relationName = Buffer.from(pd.relationName, 'base64').toString();
                        pd.aadharNumber = CryptoJS.AES.decrypt(pd.aadharNumber, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8);
               
                    pd.memberName = CryptoJS.AES.decrypt(pd.memberName, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8);
                    pd.relationName = CryptoJS.AES.decrypt(pd.relationName, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8);
               
                }
                
            }
        //    if(req.body.district!=""){
        //     return res.status(404).send({ message: `Society details are not found for`, success: false, data: {} });
      
        //    }
        }
        if (req.body.isNameChange && attachments.length < 2) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        else if (req.body.isAmalgamChange && req.body.societyName != undefined && attachments.length < 6) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        else if (req.body.isAimChange && req.body.societyName != undefined && attachments.length < 2) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        else if (req.body.byeLaws && req.body.byeLaws?.societyName != undefined && attachments.length < 6) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        else if (req.body.isFiling?.length > 0 && attachments.length < 1) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        else if (req.body.membersList?.length > 0 && attachments.length < 3) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        else if (req.body.isAddressChange?.length > 0 && attachments.length < 1) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        else if (req.body.isMemorandumChange?.length > 0 && attachments.length < 2) {
            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: "Please upload  all Documents!", success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(500).send(data);
        }
        if (attachments?.length > 0) {
            if (attachments.some(x => x.originalname.split('_')[0] === 'byeLaws')) {
                const val = attachments.find(x => x.originalname.split('_')[0] === 'byeLaws')
                req.body = { ...req.body, documentAttached: [...attachments], byeLawDocLink: val.originalname }
            }
            else {
                req.body = { ...req.body, documentAttached: [...attachments] }
            }
        }

        let applicationDetails = req.body.applicantDetails;
        if (applicationDetails?.aadharNumber && applicationDetails.aadharNumber != '') {
            const resp = await _getUUIDByAadharNumber(applicationDetails.aadharNumber.toString())
            if (resp.data?.status == "Success") {
                applicationDetails.aadharNumber = resp.data.UUID
            }
            else {
                let data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(500).send(data);
            }
        }

        let memberDetails = req.body.memberDetails;
        if (memberDetails && memberDetails.length > 0) {

            for await (let pd of memberDetails) {
                if (pd.aadharNumber) {
                    const resp = await _getUUIDByAadharNumber(pd.aadharNumber.toString())
                    console.log("resp memberdetails", resp)
                    if (resp.data?.status == "Success") {
                        pd.aadharNumber = resp.data.UUID
                    }
                    else {
                        let data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                        return res.status(500).send(data);
                    }
                }
            }
        }

        if (req.body.isResubmission == 'true') {
            const applicationNo = 'SCR' + Date.now() + ((Math.random() * 100000).toFixed());
            const re = {
                $set: {
                    ...req.body, applicationNumber: applicationNo, isResubmission: true, status: "Incomplete", updatedBy: req.body.updatedBy,
                    clientLocalAddress: req.body.clientLocalAddress,
                    version: process.env.E_VERSION,
                },
                $unset: {
                    memberDetails: [],
                    doorNo: "",
                    generalBodyMeeting: "",
                    mandal: "",
                    nameOfRegistrationDistrict: "",
                    pinCode: "",
                    street: "",
                    villageOrCity: "",
                    isdownload: false,
                    aim: "",
                    objective: "",
                    category: "",
                    byeLaws: {},
                    quorumMembers: [],
                    documentAttached: [],
                    mobileNumber: "",
                    email: "",
                    auditorDetails: {},
                    applicantDetails: {}
                }
            }
            let data = await isSocietyInvalid(req, res);
            if (data) {

                let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            let societyDetails = await _updateReApplySociety(req.body.id, re);
            let applicantDetails = societyDetails?.applicantDetails;
            let memberDetails = societyDetails?.memberDetails;
            if (applicantDetails?.aadharNumber && applicantDetails?.aadharNumber?.toString() != null) {
                const resp = await _getAadharNumberByUUID(applicantDetails.aadharNumber.toString())
                if (resp.data?.status == "Success") {
                    applicantDetails.aadharNumber = resp.data.UID
                }
                else {
                    let data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                    return res.status(500).send(data);
                }
            }
            if (memberDetails != undefined && memberDetails?.length > 0) {
                for await (let pd of memberDetails) {
                    if (pd.aadharNumber?.toString() != "") {
                        const resp = await _getAadharNumberByUUID(pd.aadharNumber.toString())
                        if (resp.data?.status == "Success") {
                            pd.aadharNumber = resp.data.UID
                        }
                        else {
                            let data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                            return res.status(500).send(data);
                        }
                    }
                }
            }
            let result = CryptoJS.AES.encrypt(JSON.stringify({ message: 'DaSocieties updated successfully', success: true, data: { societyDetails: societyDetails } }), process.env.SECRET_KEY).toString();
            return res.status(200).send(result);
        }
        await _saveHistory(req.body.id);
        if (req.body.formType === 'Appeal') {
            const resp = await _statusUpdate(req.body.id, "AppealedToHA")
            let result = CryptoJS.AES.encrypt(JSON.stringify({ message: "success", success: true, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(200).send(result);
        }
        if (req.body.formType === 'Accept') {
            const resp = await _statusUpdate(req.body.id, "AcceptedByHA")
            let result = CryptoJS.AES.encrypt(JSON.stringify({ message: "success", success: true, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(200).send(result);
        }
        if (req.body.formType === 'payment') {
            const resp = await _paymentResponseUpdate(req.body.id, {}, "Not Viewed", true)
            let result = CryptoJS.AES.encrypt(JSON.stringify({ message: "success", success: true, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(200).send(result);
        }
        if (req.body.isNameChange == "true") {
            let data = await isSocietyInvalid(req, res);
            if (data) {
                let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            if (req.body.isMemorandumChange == "true") {

            }
            // memberDetails: req.body.memberDetails,
            let payload: any = {
                documentAttached: req.body.documentAttached,
                applicantDetails: req.body.applicantDetails,
                societyName: req.body.societyName,
                newNameDateEffect: moment().format("YYYY-MM-DD"),
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                processingHistory: [],
                isNameChange: true,
                isAddressChange: false,
                isAimChange: false,
                isFiling: false,
                isAmalgamChange: false,
                isSocietyDissolved: false,
                isSocietyWinding: false,
                isMemorandumChange: false,
            }
            if (req.body.isMemorandumChange == "true") {
                payload = {
                    ...payload, memberDetails: req.body.memberDetails,
                    isMemorandumChange: true,
                    isNameChange: false,
                    isAddressChange: false,
                    isAimChange: false,
                    isFiling: false,
                    isAmalgamChange: false,
                    isSocietyDissolved: false,
                    isSocietyWinding: false,
                }
            }
            if (req.body.isAimChange == "true") {

                payload = {
                    ...payload, aim: req.body.aim,
                    objective: req.body.objective,
                    isAimChange: true,
                    isMemorandumChange: false,
                    isNameChange: false,
                    isAddressChange: false,
                    isFiling: false,
                    isAmalgamChange: false,
                    isSocietyDissolved: false,
                    isSocietyWinding: false,
                    updatedBy: req.body.updatedBy,
                    clientLocalAddress: req.body.clientLocalAddress,
                    version: process.env.E_VERSION,
                }
            }

            let societyDetails = await _updateSociety(req.body.id, payload);
            if (societyDetails) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }
        }
        if (req.body.isSocietyDissolved == true) {
            // let reg = /^[A-Za-z \s]*$/
            let data = await isSocietyInvalid(req, res);
            if (data) {
                let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            const payload = {
                documentAttached: req.body.documentAttached,
                applicantDetails: req.body.applicantDetails,
                dissolutionOfSociety: req.body.dissolutionOfSociety,
                effectDate: moment().format("YYYY-MM-DD"),
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                isNameChange: false,
                isAddressChange: false,
                processingHistory: [],
                isAimChange: false,
                isFiling: false,
                isAmalgamChange: false,
                isSocietyDissolved: true,
                isSocietyWinding: false,
                isMemorandumChange: false,
            }
            let dissolutionOfSociety = await _updateSociety(req.body.id, payload);
            if (dissolutionOfSociety) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Dissolution updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }

        }
        if (req.body.isSocietyWinding == true) {
            let data = await isSocietyInvalid(req, res);
            if (data) {
                let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            const payload = {
                documentAttached: req.body.documentAttached,
                applicantDetails: req.body.applicantDetails,
                dateOfDissolution: moment().format("YYYY-MM-DD"),
                dateOfMeeting: moment().format("YYYY-MM-DD"),
                minutesOfMeetingDesc: req.body.windingSociety.minutesOfMeetingDesc,
                propertyDisposal: req.body.windingSociety.propertyDisposal,
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                isNameChange: false,
                isAddressChange: false,
                isAimChange: false,
                processingHistory: [],
                isFiling: false,
                isAmalgamChange: false,
                isSocietyDissolved: false,
                isSocietyWinding: true,
                isMemorandumChange: false,
            }
            let windingUpSociety = await _updateSociety(req.body.id, payload);
            if (windingUpSociety) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Winding-Up updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }

        }
        if (req.body.isAimChange == "true") {

            let reg = /^[a-zA-Z0-9\s,'-]*$/
            let data = await isSocietyInvalid(req, res);
            if (data) {
                let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            if (!req.body['aim']) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "aim is not allowed to be empty", success: false, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            else if (!reg.test(req.body['aim'])) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "aim format is invalid", success: false, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            else if (!req.body['objective']) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "objective is not allowed to be empty", success: false, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            else if (!reg.test(req.body['objective'])) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "objective format is invalid", success: false, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            const payload = {
                documentAttached: req.body.documentAttached,
                applicantDetails: req.body.applicantDetails,
                aim: req.body.aim,
                objective: req.body.objective,
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                isAimChange: true,
                isNameChange: false,
                processingHistory: [],
                isAddressChange: false,
                isFiling: false,
                isAmalgamChange: false,
                isSocietyDissolved: false,
                isSocietyWinding: false,
                isMemorandumChange: false,
            }
            let societyDetails = await _updateSociety(req.body.id, payload);
            if (societyDetails) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }
        }
        if (req.body.isAddressChange == "true") {
            let requestData = {
                oldAddress: {
                    doorNo: existingSoc?.doorNo,
                    street: existingSoc?.street,
                    district: existingSoc?.district,
                    mandal: existingSoc?.mandal,
                    villageOrCity: existingSoc?.villageOrCity,
                    pinCode: existingSoc?.pinCode
                },
                documentAttached: req.body.documentAttached,
                doorNo: req.body.doorNo,
                street: req.body.street,
                district: req.body.district,
                mandal: req.body.mandal,
                villageOrCity: req.body.villageOrCity,
                pinCode: req.body.pinCode,
                isAddressChange: true,
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                isNameChange: false,
                isAimChange: false,
                processingHistory: [],
                isFiling: false,
                isAmalgamChange: false,
                isSocietyDissolved: false,
                isSocietyWinding: false,
                isMemorandumChange: false,

            }
            let societyDetails = await _updateSociety(req.body.id, requestData);
            if (societyDetails) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }
        }
        if (req.body.isAmalgamChange == "true") {
            let requestData = {
                oldSociety: { ...existingSoc },

                documentAttached: req.body.documentAttached,
                societyName: req.body.societyName,
                aim: req.body.aim,
                objective: req.body.objective,
                doorNo: req.body.doorNo,
                street: req.body.street,
                state: req.body.state,
                memberDetails: req.body.memberDetails,
                country: req.body.country,
                district: req.body.district,
                mandal: req.body.mandal,
                villageOrCity: req.body.villageOrCity,
                pinCode: req.body.pinCode,
                isAmalgamChange: true,
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                isNameChange: false,
                isAddressChange: false,
                isAimChange: false,
                processingHistory: [],
                isFiling: false,
                incomingmemberDetails: req.body.incomingmemberDetails,
                incomingSocietyAmalgamDetails: req.body.incomingSocietyAmalgamDetails,
                isSocietyDissolved: false,
                isSocietyWinding: false,
                isMemorandumChange: false,

            }

            let societyDetails = await _updateSociety(req.body.id, requestData);
            if (societyDetails) {
                if (req.body.incomingSocietyAmalgamDetails?.length > 0) {
                    req.body.incomingSocietyAmalgamDetails.forEach(async x => {
                        await _updateSocietyInActive(x.incomingSocietyDetails.applicationNumber);
                    })
                }
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }
        }
        if (req.body.isFiling == "true") {

            let data = await isSocietyInvalid(req, res);
            if (data) {
                let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }

            const payload = {
                documentAttached: req.body.documentAttached,
                applicantDetails: req.body.applicantDetails,
                societyName: req.body.societyName,
                memberDetails: req.body.memberDetails,
                venue: req.body.venue,
                dateOfAnnualMeeting: moment().format("YYYY-MM-DD"),
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                processingHistory: [],
                isNameChange: false,
                isAddressChange: false,
                isAimChange: false,
                isFiling: true,
                isAmalgamChange: false,
                isSocietyDissolved: false,
                isSocietyWinding: false,
                isMemorandumChange: false,
            }
            let societyDetails = await _updateSociety(req.body.id, payload);
            if (societyDetails) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }
        }
        if (req.body.isMemorandumChange == "true") {
            let data = await isSocietyInvalid(req, res);
            if (data) {
                let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            const payload = {
                documentAttached: req.body.documentAttached,
                applicantDetails: req.body.applicantDetails,
                societyName: req.body.societyName,
                memberDetails: req.body.memberDetails,
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,
                isMemorandumChange: true,
                isAnnualChange: false,
                processingHistory: [],
                isNameChange: false,
                isAddressChange: false,
                isAimChange: false,
                isFiling: false,
                isAmalgamChange: false,
                isSocietyDissolved: false,
                isSocietyWinding: false,

            }
            let societyDetails = await _updateSociety(req.body.id, payload);
            if (societyDetails) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }
        }
        if (req.body.membersList == "true") {
            if (req.body['memberType']) {
                const reg = /[A-Za-z0-9/-]|,/
                if (!reg.test(req.body['memberType'])) {
                    let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": `memberType format is invalid`, "data": {} }), process.env.SECRET_KEY).toString();
                    return res.status(400).send(da);
                }
            }
            else {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": "memberType is not allowed to be empty", "data": {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            if (req.body['memberName']) {
                const reg = /^[a-zA-Z0-9\s,'-]*$/
                if (!reg.test(req.body['memberName'])) {
                    let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": `memberName format is invalid`, "data": {} }), process.env.SECRET_KEY).toString();
                    return res.status(400).send(da);
                }
            }
            else {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": "memberName is not allowed to be empty", "data": {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            if (req.body['relationName']) {
                const reg = /^[a-zA-Z0-9\s,'-]*$/
                if (!reg.test(req.body['relationName'])) {
                    let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": `relationName format is invalid`, "data": {} }), process.env.SECRET_KEY).toString();
                    return res.status(400).send(da);
                }
            }
            else {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": "relationName is not allowed to be empty", "data": {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            if (req.body['age']) {
                const reg = /[0-9]/
                if (!reg.test(req.body['age'])) {
                    let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": `age format is invalid`, "data": {} }), process.env.SECRET_KEY).toString();
                    return res.status(400).send(da);
                }
            }
            else {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": "age is not allowed to be empty", "data": {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            if (req.body['role']) {
                const reg = /^[a-zA-Z0-9\s,'-]*$/
                if (!reg.test(req.body['role'])) {
                    let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": `role format is invalid`, "data": {} }), process.env.SECRET_KEY).toString();
                    return res.status(400).send(da);
                }
            }

            else {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": "role is not allowed to be empty", "data": {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }
            if (req.body['occupation']) {
                const reg = /^[a-zA-Z0-9\s,'-]*$/
                if (!reg.test(req.body['occupation'])) {
                    let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": `occupation format is invalid`, "data": {} }), process.env.SECRET_KEY).toString();
                    return res.status(400).send(da);
                }
            }
            else {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ "success": false, "message": "occupation is not allowed to be empty", "data": {} }), process.env.SECRET_KEY).toString();
                return res.status(400).send(da);
            }

            let requestData = {
                oldMembers: { ...existingMembers },
                documentAttached: req.body.documentAttached,
                ...req.body.membersDetails,
                applicantDetails: req.body.applicantDetails,
                contactDetails: req.body.contactDetails,
                dateOfAnnualMeeting: moment().format("YYYY-MM-DD"),
                membersList: true,
                status: 'Incomplete',
                updatedBy: req.body.updatedBy,
                clientLocalAddress: req.body.clientLocalAddress,
                version: process.env.E_VERSION,

            }

            let memberDetails = await _updateSociety(req.body.id, requestData);
            if (memberDetails) {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: "Society updated successfully", success: true, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(200).send(da);
            }
        }

        let data = await isSocietyInvalid(req, res);
        if (data) {
            let da = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString();
            return res.status(400).send(da);
        }
        let societyDetails = await _updateSociety(req.body.id, req.body);
        let applicantDetailses = societyDetails?.applicantDetails;
        let memberDetailses = societyDetails?.memberDetails;
        if (applicantDetailses?.aadharNumber && applicantDetailses?.aadharNumber?.toString() != null) {
            const resp = await _getAadharNumberByUUID(applicantDetailses.aadharNumber.toString())
            if (resp.data?.status == "Success") {
                applicantDetailses.aadharNumber = resp.data.UID
            }
            else {
                let da = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(500).send(da);
            }
        }
        if (memberDetailses != undefined && memberDetailses?.length > 0) {
            for await (let pd of memberDetailses) {
                if (pd.aadharNumber?.toString() != "") {
                    const resp = await _getAadharNumberByUUID(pd.aadharNumber.toString())
                    console.log(resp)
                    if (resp.data?.status == "Success") {
                        pd.aadharNumber = resp.data.UID
                    }
                    else {
                        let da = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                        return res.status(500).send(da);
                    }
                }
            }
        }
        let da = CryptoJS.AES.encrypt(JSON.stringify({ message: 'DaSocieties updated successfully', success: true, data: { societyDetails: societyDetails } }), process.env.SECRET_KEY).toString();
        return res.status(200).send(da);

    } catch (error) {
        logger.error(`error-`);
        let da = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Internal server error', success: false, data: {} }), process.env.SECRET_KEY).toString();
        return res.status(500).send(da);
    }

}

export const downloadsHistory = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        const payload = {
            amount: req.body.amount,
            downloadDate: moment().format(),
        }
        await _downloadsHistory(req.params.id, payload);

        return res.status(200).send({ message: 'Downloads saved successfully', success: true, data: {} });

    }
    catch (error) {
        logger.error(`error-`, error);
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }
}

export const downloadsByLawHistory = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        const payload = {
            amount: req.body.amount,
            downloadDate: moment().format(),
        }

        await _downloadsByLawHistory(req.params.id, payload);

        return res.status(200).send({ message: 'Bye-Laws download saved successfully', success: true, data: {} });

    }
    catch (error) {
        logger.error(`error-`, error);
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }
}


export const getSociety = async (req: Request, res: Response) => {
    try {
        const id = Buffer.from(req.params.id, 'base64').toString();
        if (!ObjectId.isValid(id)) {
            let result = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Society id not found', success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(404).send(result);
        }
        let daSociety = await _getDaSociety(id);
        if (userSession.district !== daSociety?.district) {
            let result = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Unauthorized request', success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(401).send(result);
        }

        if (daSociety?.status === 'Not Viewed') {
            if (userSession.role == 'DLS' || userSession.role == 'DR') {
                const payload = {
                    status: 'Open'
                }
                daSociety = await _updateSociety(daSociety._id, payload);
            }
        }

        if (!daSociety) {
            let result = CryptoJS.AES.encrypt(JSON.stringify({ message: `Society details are not found for ${id}`, success: false, data: {} }), process.env.SECRET_KEY).toString();
            return res.status(404).send(result);
        }

        let applicantDetails = daSociety.applicantDetails;
        let memberDetails = daSociety.memberDetails;
        if (applicantDetails?.aadharNumber && applicantDetails?.aadharNumber?.toString() != null) {
            const resp = await _getAadharNumberByUUID(applicantDetails.aadharNumber.toString())
            if (resp.data?.status == "Success") {
                applicantDetails.aadharNumber = resp.data.UID
            }
            else {
                let result = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                return res.status(500).send(result);
            }
        }
        if (memberDetails?.length > 0) {
            for await (let pd of memberDetails) {
                if (pd.aadharNumber?.toString() != "") {
                    const resp = await _getAadharNumberByUUID(pd.aadharNumber.toString())
                    if (resp.data?.status == "Success") {
                        pd.aadharNumber = resp.data.UID
                    }
                    else {
                        let result = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} }), process.env.SECRET_KEY).toString();
                        return res.status(500).send(result);
                    }
                }
            }
        }
        let result = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Get Society details successfully done', success: true, data: { daSociety } }), process.env.SECRET_KEY).toString();
        return res.status(200).send(result);
    } catch (error) {
        let result = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Internal server error', success: false, data: {} }), process.env.SECRET_KEY).toString();
        return res.status(500).send(result);
    }

};

export const getSocietyByAppId = async (req: Request, res: Response) => {
    try {
        const id = Buffer.from(req.params.id, 'base64').toString();
        if (!id) {
            return res.status(404).send({ message: `Society id not found`, success: false, data: {} });
        }
        let daSociety = await _getDaSocietyByAppId(id);
        if (!daSociety) {
            return res.status(404).send({ message: `Society details are not found for ${id}`, success: false, data: {} });
        }

        let applicantDetails = daSociety.applicantDetails;
        let memberDetails = daSociety.memberDetails;
        if (applicantDetails?.aadharNumber && applicantDetails?.aadharNumber?.toString() != null) {
            const resp = await _getAadharNumberByUUID(applicantDetails.aadharNumber.toString())
            if (resp.data?.status == "Success") {
                applicantDetails.aadharNumber = resp.data.UID
            }
            else {
                return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
            }
        }
        if (memberDetails?.length > 0) {
            for await (let pd of memberDetails) {
                if (pd.aadharNumber?.toString() != "") {
                    const resp = await _getAadharNumberByUUID(pd.aadharNumber.toString())
                    if (resp.data?.status == "Success") {
                        pd.aadharNumber = resp.data.UID
                    }
                    else {
                        return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                    }
                }
            }
        }
        return res.status(200).send({ message: 'Get Society details successfully done', success: true, data: { daSociety } });
    } catch (error) {
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }

};

export const sendSMS = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        const society = await DaSociety.findById({ _id: id })
        if (!society) {
            return res.status(404).send({ message: 'Society does not exits!', success: false, data: {} });
        }
        const user = await User.findById({ _id: society.userId })
        if (!user) {
            return res.status(404).send({ message: 'User does not exits!', success: false, data: {} });
        }

        const smsMessage = {
            number: user.mobileNumber,
            message: req.body.message,
            sentDate: moment().format(),
        }

        //console.log("<=== smsMessage ===>", smsMessage);
        const result = await _sendSMS(id, userSession._id, smsMessage);
        return res.status(200).send({ message: 'SMS Sent successfully', success: true, data: {} });
    }
    catch (error) {
        console.log(`error-`, error);
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }
}

export const processingHistory = async (req: Request, res: Response) => {
    try {
        if (!req.body.remark) {
            return res.status(404).send({ message: 'Remark data is not allowed to be empty', success: false, data: {} });
        }
        let bytesreq = CryptoJS.AES.decrypt(req.body.remark, process.env.SECRET_KEY);
        let remarkData = JSON.parse(bytesreq.toString(CryptoJS.enc.Utf8));
        let societyId = remarkData.id
        const reg = /^[A-Za-z\s]*$/;
        if (!remarkData.remarks) {
            return res.status(404).send({ message: 'Remarks is not allowed to be empty', success: false, data: {} });
        } else if (remarkData.remarks && !reg.test(remarkData.remarks)) {
            return res.status(404).send({ message: 'Remarks format is invalid!', success: false, data: {} });
        } else if (req.body.status && !reg.test(req.body.status)) {
            return res.status(404).send({ message: 'Status format is invalid!', success: false, data: {} });
        }
        const society = await DaSociety.findById({ _id: societyId })
        if (!society) {
            return res.status(404).send({ message: 'Society does not exits!', success: false, data: {} });
        }
        if (remarkData.status == "Approved" && society.status == "Rejected") {
            return res.status(404).send({ message: `Society is already rejected you cannot approve it`, success: false, data: {} });
        }
        else if (remarkData.status == "AcceptedByHA" && society.status == "Rejected") {
            return res.status(404).send({ message: `Society is already approved you cannot reject it`, success: false, data: {} });
        }
        else if (remarkData.status == "Rejected" && society.status == "Approved") {
            return res.status(404).send({ message: `Society is already approved you cannot reject it`, success: false, data: {} });
        }
        let status = "Forwarded By DLS";
        let applicationStatus = 'Forwarded';
        let societyStatus = 'Pending';
        if (remarkData.status) {
            status = remarkData.status;
            applicationStatus = remarkData.status;
            let payload;
            if (remarkData.status == "Approved") {
                //societyStatus = 'Active';


                let registrationNumber: any = 1;
                let registrationYear: any = moment().format('YYYY');
                if ((!society.registrationNumber || society.registrationNumber <= 0) && society.district == userSession.district) {
                    let registrationYear = moment().format('YYYY');
                    const societyData: any = await DaSociety.findOne({ registrationYear: registrationYear, district: userSession.district }, { registrationNumber: 1, registrationYear: 1, district: 1 }).sort({ registrationNumber: -1 })
                    console.log('<============= societyData =============>', societyData);


                    if (societyData && societyData.registrationNumber > 0 && societyData.registrationYear == registrationYear && societyData.district == userSession.district) {
                        registrationNumber = societyData.registrationNumber + 1;
                    }
                    console.log('<============= registrationNumber =============>', registrationNumber);
                }
                else {
                    registrationNumber = society.registrationNumber ? society.registrationNumber : '';
                    registrationYear = society.registrationYear ? society.registrationYear : '';
                }
                if (society.isAddressChange) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',

                        isFiling: false,
                        isNameChange: false,
                        isMemorandumChange: false,
                        isMemberChanged: false,
                        isAddressChange: true,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldAddress: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }
                else if (society.isAmalgamChange) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isAddressChange: false,
                        isMemorandumChange: false,
                        isMemberChanged: false,
                        isFiling: false,
                        isAmalgamChange: true,
                        isAimChange: false,
                        societyName: req.body.societyName,
                        aim: req.body.aim,
                        memberDetails: req.body.memberDetails,
                        objective: req.body.objective,
                        doorNo: req.body.doorNo,
                        street: req.body.street,
                        state: req.body.state,
                        country: req.body.country,
                        district: req.body.district,
                        mandal: req.body.mandal,
                        villageOrCity: req.body.villageOrCity,
                        pinCode: req.body.pinCode,
                        incomingmemberDetails: req.body.incomingmemberDetails,
                        incomingSocietyAmalgamDetails: req.body.incomingSocietyAmalgamDetails,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }
                else if (society.membersList) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,

                        isAmalgamChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        membersList: true,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                } else if (society.isFiling) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isFiling: true,
                        isNameChange: false,
                        isMemorandumChange: false,
                        isMemberChanged: false,
                        isAddressChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldAddress: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                        memberDetails: req.body.memberDetails
                    }
                }
                else if (society.isAimChange) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        isMemorandumChange: false,
                        isAddressChange: false,
                        isAmalgamChange: false,
                        isAimChange: true,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                } else if (society.isMemorandumChange) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isAddressChange: false,
                        isMemberChanged: false,
                        isMemorandumChange: true,
                        isFiling: false,
                        isAmalgamChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }
                else if (society.isNameChange) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: true,
                        isMemberChanged: false,
                        isFiling: false,
                        isAmalgamChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        membersList: true,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                } else if (society.isSocietyDissolved) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        isMemorandumChange: false,
                        isFiling: false,
                        isAmalgamChange: false,
                        isAddressChange: false,
                        isAimChange: false,
                        isSocietyDissolved: true,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                        dissolutionOfSociety: req.body.dissolutionOfSociety
                    }
                }
                else if (society.isSocietyWinding) {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        isAddressChange: false,
                        isFiling: false,
                        isAmalgamChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: true,
                        membersList: true,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }

                else {
                    payload = {
                        status: 'Approved',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        isfiling: false,
                        isAddressChange: false,
                        isAimChange: false,
                        isAmalgamChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        isMemorandumChange: false,
                        membersList: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }

            }

            if (remarkData.status == "AcceptedByHA") {

                let registrationNumber: any = 1;
                let registrationYear: any = moment().format('YYYY');
                if ((!society.registrationNumber || society.registrationNumber <= 0) && society.district == userSession.district) {
                    let registrationYear = moment().format('YYYY');
                    const societyData: any = await DaSociety.findOne({ registrationYear: registrationYear, district: userSession.district }, { registrationNumber: 1, registrationYear: 1, district: 1 }).sort({ registrationNumber: -1 })
                    console.log('<============= societyData =============>', societyData);


                    if (societyData && societyData.registrationNumber > 0 && societyData.registrationYear == registrationYear && societyData.district == userSession.district) {
                        registrationNumber = societyData.registrationNumber + 1;
                    }
                    console.log('<============= registrationNumber =============>', registrationNumber);
                }
                else {
                    registrationNumber = society.registrationNumber ? society.registrationNumber : '';
                    registrationYear = society.registrationYear ? society.registrationYear : '';
                }
                if (society.isAddressChange) {
                    payload = {
                        status: 'AcceptedByHA',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        isAddressChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldAddress: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }
                else if (society.isAmalgamChange) {
                    payload = {
                        status: 'AcceptedByHA',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        memberDetails: req.body.memberDetails,
                        isAmalgamChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }
                else if (society.membersList) {
                    payload = {
                        status: 'AcceptedByHA',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        isAmalgamChange: false,
                        isAimChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        membersList: true,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        oldSociety: {},
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }

                else {
                    payload = {
                        status: 'AcceptedByHA',
                        societyStatus: 'Active',
                        isNameChange: false,
                        isMemberChanged: false,
                        isAddressChange: false,
                        isAimChange: false,
                        isAmalgamChange: false,
                        isSocietyDissolved: false,
                        isSocietyWinding: false,
                        isAnnualChange: false,
                        isMemorandumChange: false,
                        membersList: false,
                        registrationNumber: registrationNumber,
                        registrationYear: registrationYear,
                        approvedRejectedById: userSession._id,
                        isResubmission: false,
                    }
                }

            }

            else {
                if (status == 'Rejected') {
                    payload = {
                        status: status,
                        societyStatus: 'Pending',
                        isResubmission: false,
                    }
                }
            }
            await _updateSociety(societyId, payload);
        }
        else {
            let payload = {
                status: applicationStatus,
                societyStatus: 'Pending',
            }
            await _updateSociety(societyId, payload);
        }
        const date: any = society.createdAt
        const remarksData = {
            designation: userSession.userName,
            status: status,
            remarks: remarkData.remarks,
            attachements: [],
            applicationTakenDate: moment(date.now).format('YYYY-MM-DD'),
            applicationProcessedDate: moment().format(),
        }

        console.log("<===========  remarksData  ==========>", remarksData);

        const result = await _processingHistoryUpdate(societyId, userSession._id, remarksData);
        return res.status(200).send({ message: 'Remarks Saved successfully', success: true, data: {} });

    }
    catch (error) {
        logger.error(`error-`, error);
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }

};

export const downloadFile = async (req: Request, res: Response) => {

    try {
        const { id, fileName } = req.params;


        console.log("<==== process.env.DIR_ROOT ====>", process.env.DIR_ROOT);
        //console.log("<==== id ====>", id);
        //console.log("<==== fileName ====>", fileName);
        //console.log("<==== __dirname ====>", __dirname);

        const path = process.env.DIR_ROOT + `/uploads/${id}/${fileName}`;

        if (fs.existsSync(path)) {

            console.log("<==== path ====>", path);

            const file = fs.createReadStream(path)
            var stat = fs.statSync(path);
            const filename = fileName;//(new Date()).toISOString()
            res.setHeader('Content-Length', stat.size);
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'attachment; filename="' + filename + '"');
            file.pipe(res);
        }
        else {
            return res.status(500).send();
        }

    }
    catch (error) {
        logger.error(`error-`, error);
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }
}


export const sendFiles = async (req: Request, res: Response) => {
    try {
        const uploadedFile = req.file;
        console.log("fileeeeeee", uploadedFile);
        res.send('File uploaded successfully.');
    }
    catch (err) {
        logger.error(`error-`);
        res.send({ message: 'Internal server error', success: false, data: {} })
    }
}
export const fetchAuthorityDetails = async (req: Request, res: Response) => {
    try {
        const data = await _fetchAuthorityDetails()
        return res.status(200).send({ message: 'Fetched data successfully', success: true, data: data });

    }
    catch (error) {
        logger.error(`error-`, error);
        return res.status(500).send({ message: 'Internal server error', success: false, data: {} });
    }

}
export const sendSMSMail = async (req: any, res: any) => {
    try {
        let xmlString = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" ' +
            'xmlns:nic="http://nic.com/"><soapenv:Header/><soapenv:Body><nic:sendSms_New>' +
            '<phoneNo>' + req.body.phoneNumber + '</phoneNo><content>' + `Your Application is ` + req.body.status + '</content>' +
            '<templateId>' + `1007176258326536442` + '</templateId></nic:sendSms_New></soapenv:Body>' +
            '</soapenv:Envelope>';

        await axios({

            url: "http://igrs.ap.gov.in:7004/SMS_Service/SmsService?wsdl",

            data: xmlString,

            method: 'POST',

            headers: {

                'Accept': 'text/xml',

                'Content-Type': 'text/xml'

            }

        })
        let transporter = nodemailer.createTransport({
            host: "smtp-mail.outlook.com",
            port: 587,
            //secure: false,
            ssl: true,
            auth: {
                user: "support.igrs@criticalriver.com",
                pass: "Rockstar@1234",
            },
        });
        await transporter.sendMail({
            from: '"Firms" <support.igrs@criticalriver.com>', // sender address
            to: req.body.email, // list of receivers
            subject: "Sub: Firms Status", // Subject line
            //text: "Dear User, ", // plain text body
            html: `Dear User, <br>
                    Firms Application is ${req.body.status}`
        });

        return res.status(200).send({ success: true })

    } catch (error) {
        return res.status(500).send({ message: "Something went wrong, please try again", success: false, data: {} });
    }

}

export * as SocietyController from './SocietyController';