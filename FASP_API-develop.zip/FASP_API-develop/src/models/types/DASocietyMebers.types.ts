import { Document, Schema } from 'mongoose';

export interface DASocietyMembers {
    societyId: string,
    memberName: string,
    gender: string,
    fatherOrHusbandName: string,
    age: number,
    occupation: string,
    role: string,
    doorNo: string,
    street: string,
    country: number,
    state: number,
    district: number,
    mandal: number,
    villageOrCity: number,
    pinCode: number,
}