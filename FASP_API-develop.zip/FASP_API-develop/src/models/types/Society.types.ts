import { Date, Document, Schema } from 'mongoose';

export interface DaSociety {
    acceptorapprove:string,
    majority:string,
    acceptorapprove1:string,
    majority1:string,
    societyName:string,
    applicationNumber:string,
    doorNo: string,
    street: string,
    state: string,
    country:string,
    district: string,
    mandal: string,
    villageOrCity: string,
    pinCode: number,
    isActive:boolean,
    isResubmission: boolean, 
    userId: Schema.Types.ObjectId,
    category: string,
    generalBodyMeeting: string,
    RegistrationDistrict: string,
    newNameDateEffect:Date,
    byeLawDocLink:string,
    reasonForOutgoing:string,
    isAddressChange:boolean,
    isAimChange:boolean,
    isFiling:boolean,
    isNameChange:boolean,
    isAmalgamChange:boolean,
    isSocietyDissolved:boolean,
    isSocietyWinding:boolean,
    isMemorandumChange:boolean,
    aim: String, 
    objective: String, 
    mobileNumber: String, 
    email: String,
    nameOfRegistrationDistrict: String,
    dateOfAnnualMeeting: Date,
    venue:String,
    annualListDocType: string,
    annualListDocName: string,
    joiningofnewmember:string,
    membersagreedwithbyelaws:string,
    joiningofnewmemberapprovedbyQuorum:string,
    updatedBy:string,
    ipAddress:string,
    version:Number,
    approvedRejectedById?: Schema.Types.ObjectId,
    applicantDetails: {
        email:string,
        mobileNumber: Number,
        aadharNumber: string,
        name: string,
        relationName: string,
        relationType: string,
        role: string,
        age: Number,
        gender: string,
        doorNo: string,
        street: string,
        district: string,
        country: string,
        state: string,
        mandal: string,
        VillageOrCity: string,
        pinCode: number
    },
    incomingSocietyDetails: {
        amalgamStatus:string,
        reasonForAmalgam: string,
        societyName: string,
        applicationNumber:string,
        aim:string,
        objective:string,
        doorNo: string,
        street: string,
        state: string,
        country: string,
        district: string,
        mandal: string,
        villageOrCity: string,
        pinCode:  Number ,
        category: string,

    },
    contactDetails: {
        mobileNumber: number,
        email: string,
        landlineNumber: Number
    },
    byeLaws: {
        societyName: String
        quorumSize: String
        documentType: String
        documentName: String
        uploadDocuments: String
        doorNo: String 
        street: String 
        state: String 
        country:string,
        district : String 
        mandal: String 
        villageOrCity: String 
        pinCode: Number 
        mobileNumber: Number 
        email: String 
        membershipConditions:  string
        finance:  string
           auditor:  string
           raisingFunds:  string
           officeBearers:  string
           liabilityConditions:  string
           meetingConditions:  string
           otherMatters:  string
    },
    auditorDetails:{
        auditorName: String
        mobileNumber: Number,
        Email: String,
        doorNo: String,
        street: String,
        district: String,
        mandal: String,
        villageOrCity: String,
        pinCode: number

    },
    dissolutionOfSociety:{
        reasonForDissolution: string,
        effectDate: Date,
        disposedDetails:string,
        isSocietyProperties:string
        isSettlementByeLaws:string
        isSocietyLiabilities:string
        isByeLawsProperties: string
        isDissolutionAgreed:string
        isDissolutionApproved:string,
        underSection:boolean,
        generalBodyMeetingDate:Date
    },
    // annualDetails:{
    //     dateOfAnnualMeeting: Date,
    //     venue:String,
    //     annualDocType: string,
    //     annualDocName: string
    // },
    oldAddress:{
        doorNo: string,
        street: string,
        state: string,
        country:string,
        district: string,
        mandal: string,
        villageOrCity: string,
        pinCode: number,
    },
    membersList:{
        active: boolean,
        reasonForOutgoing: string,
    }
    oldMembers:{
        memberType: string,
        memberName: string,
        relationName:string,
        relationType: string,
        age: Number,
        role: string,
        occupation: string,
        joiningDate: Date,

    },
    windingUpSociety:{
        dateOfDissolution:Date,
        propertyDisposal:string,
        dateOfMeeting:Date,
        minutesOfMeetingDesc:string,
        isClaimsSociety:string
        isSocietyProperties:string
       isWindingMember:string
       liabilityConditions:string
       isByeLawsProperties:string
    }
    // divisionOfSociety:{
    //     reasonForDivision:string,
    //     societyDivide:string,
    //     societyOne:string,
    //     societyTwo:string,
    //     societyOneMember:string,
    //     societyTwoMember:string
        
    // }
    incomingSocietyAmalgamDetails:Array<incomingSocietyAmalgamDetails>,
    memberDetails: Array<MemberDetails>,
    incomingmemberDetails:Array<incomingmemberDetails>,
   // quorumMembers: Array<quorumMembers>,
    documentAttached: Array<any>,
    messageToApplicant?: Array<messageToApplicant>
    processingHistory: Array<ProcessingHistory>,
    status: string,
    societyStatus: string,
    paymentDetails: Array<paymentDetails>,
    createdAt?: Date,
    updatedAt?: Date,
    historyDetails:Array<any>,
    isdownload: boolean,
    isByLawDownload: boolean,
    downloadsHistory:Array<any>,
    downloadsByeLawHistory:Array<any>,
    registrationNumber: number,
    registrationYear: number,
}
export interface DocumentAttached extends Document {
    id: string
    name: string, size: number, mimetype: string, path: string,
}
export interface messageToApplicant {
    number: string,
    message: string,
    sentDate: string,
}
export interface ProcessingHistory {
    designation: string,
    status: string,
    remarks: string,
    applicationTakenDate: Date,
    applicationProcessedDate: Date,
}

export interface paymentDetails {
    applicationNumber: string,
    departmentTransID: string,
    cfmsTransID: number,
    transactionStatus: string,
    amount: number,
    totalAmount: number,
    paymentMode: string,
    bankTransID: number,
    bankTimeStamp: Date,
    isUtilized: boolean,
    createdAt: Date
}
export interface incomingSocietyAmalgamDetails{
    incomingSocietyDetails: {
        amalgamStatus:string,
        reasonForAmalgam: string,
        societyName: string,
        applicationNumber:string,
        aim:string,
        objective:string,
        doorNo: string,
        street: string,
        state: string,
        country: string,
        district: string,
        mandal: string,
        villageOrCity: string,
        pinCode:  Number ,
        category: string,

    },
    incomingmemberDetails:Array<incomingmemberDetails>,
}
export interface MemberDetails {
    reasonForAmalgam: string,
    termination:string,
    soundMind: string
    inSolvent: string
    firstNoticeDate:Date
    secondNoticeDate:Date
    thirdNoticeDate:Date
    offense: string
    appointment: string
    memberType: string,
    aadharNumber: string,
    memberName: string,
    status:string,
    relationName: string,
    relationType: string,
    joiningDate: Date,
    // role: string,
    age: Number,
    occupation: string,
    qualification: string,
    role: string,
    doorNo: string,
    street: string,
    gender:string,
    country: string,
    state: string,
    district : string,
    mandal: string,
    villageOrCity: string,
    pinCode: Number,
    email:string,
    mobileNumber:Number,
    noticeTime:string,
   
}
export interface incomingmemberDetails {
    reasonForAmalgam: string,
    termination:string,
    soundMind: string
    inSolvent: string
    offense: string
    appointment: string
    memberType: string,
    aadharNumber: string,
    memberName: string,
    status:string,
    relationName: string,
    relationType: string,
    joiningDate: Date,
    // role: string,
    age: Number,
    occupation: string,
    qualification: string,
    role: string,
    doorNo: string,
    street: string,
    gender:string,
    country: string,
    state: string,
    district : string,
    mandal: string,
    villageOrCity: string,
    pinCode: Number,
    email:string,
    mobileNumber:Number
   
}
// export interface quorumMembers{
//     memberType: string,
//     aadhaarNumber: Number,
//     memberName: string,
//     role:string,
//     occupation:string,
//     qualification: string,
//     relationName:string,
//     relationType: string,
//     joiningDate: string,
//     doorNo: string,
//     street: string,
//     state: string,
//     country:string,
//     district : string,
//     mandal: string,
//     villageOrCity: string,
//     pinCode: Number
    
// }