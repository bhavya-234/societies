import { Document, Schema } from 'mongoose';

export interface DepartmentUsers {
    id: string,
    userName: string,
    firstName: string,
    lastName: string,
    middleName: string,
    email: string,
    password: string,
    mobileNumber: number,
    role: string,
    district: string,
    signature:string,
    fullName:string,
    status: string,
    loginAttemptCount:number,
    loginAttemptTime:Date,
    lastLogin:Date,
    token:string,
    updatedBy:string,
    ipAddress:string,
    version:number
}