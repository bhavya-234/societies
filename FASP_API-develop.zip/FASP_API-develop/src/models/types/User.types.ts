import { Document, Schema } from 'mongoose';

export interface User {
    id: string,
    firstName: string,
    lastName: string,
    password: string,
    email: string,
    captchaVal:string,
    alternateEmail: string,
    mobileNumber: number,
    aadharNumber: string,
    registrationType: string,
    status: string,
    lastLogin: Date,
    token:string,
    district:string
}