import mongoose, { Schema } from 'mongoose';
import  {DASocietyMembers}  from './types';
import moment from 'moment';
const now = moment().format();

const { Types: { ObjectId } } = Schema
const DASocietyMembersSchema: Schema = new Schema({
    societyId: ObjectId,
    memberName: { type: String },
    gender: { type: String },
    fatherOrHusbandName: { type: String },
    age: { type: Number },
    occupation: { type: String },
    role: { type: String },
    doorNo: { type: String },
    street: { type: String },
    country: { type: String },
    state: { type: String },
    district : { type: String },
    mandal: { type: String },
    villageOrCity: { type: String },
    pinCode: { type: Number },
    createdAt: { type: Date, default:  now},
    updatedAt: { type: Date }
});

DASocietyMembersSchema.pre('save', async function (next) {
    try{
        this.updatedAt = now;
        next();
    } catch (err) { console.error(err); }
});

const DASocietyMembers = mongoose.model<DASocietyMembers>('SocietyMembers', DASocietyMembersSchema);
export default DASocietyMembers;