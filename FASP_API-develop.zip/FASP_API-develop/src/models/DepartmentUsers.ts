import mongoose, { Schema } from 'mongoose';
import  {DepartmentUsers}  from './types';
import moment from 'moment';
const now = moment().format();

const { Types: { ObjectId } } = Schema
const departmentUsersSchema: Schema = new Schema({
    firstName: { type: String, require: true },
    middleName: { type: String, require: false },
    lastName: { type: String, require: true  },
    userName: { type: String, require: true,
        index: {
            unique: true
        },   
    },
    email: {
        type: String,
        trim: true,
        lowercase: true,
        index: {
            unique: true
        },
        required: true,
    },
    password: { type: String, require: true  },
    mobileNumber: { type: Number, require: true  },
    role: { type: String },
    signature:{type:String},
    fullName:{type:String},
    district: { type: String },
    createdAt: { type: Date, default:  now},
    updatedAt: { type: Date },
    status: { type: String, default:'Active' },
    loginAttemptTime:{type:Date},
    loginAttemptCount:{type:Number},
    lastLogin:{type:Date},
    token:{type:String},
    updatedBy:{type:String},
    ipAddress:{type:String},
    version:{type:Number},
});

departmentUsersSchema.pre('save', async function (next) {
    try{
        this.updatedAt = now;
        next();
    } catch (err) { console.error(err); }
});

const DepartmentUsers = mongoose.model<DepartmentUsers>('DepartmentUsers', departmentUsersSchema, 'departmentUsers');
export default DepartmentUsers;