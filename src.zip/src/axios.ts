import axios from "axios"
import instance from "./redux/api"
import { get } from "lodash"
import CryptoJS from "crypto-js"

export const useEmailVerify = async (data: any) => {
  return await instance
    .post("/emailVerification", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseSignUp = async (data: any) => {
  return await instance
    .post("/signup", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const GetStatusCount = async () => {
  return await instance
    .get("/societies/reports")
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}
export const useUserLoginData = async (data: any) => {
  console.log(instance)
  return await instance
    .post("/login", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}
export const useGetDistrictList = async (token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .get("getDistricts", mytoken)
    .then((res: any) => {
      return {
        success: true,
        data: res.data,
      }
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e?.response?.data,
      }
    })
}

export const useGetMandalList = async (data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("getDistrictsMandals", data, mytoken)
    .then((res: any) => {
      return {
        success: true,
        data: res.data,
      }
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}
export const useGetVillagelList = async (data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("getDistrictsMandalVillages", data, mytoken)
    .then((res: any) => {
      return {
        success: true,
        data: res.data,
      }
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}


export const UseGetWenlandSearch = async (data: any) => {
  return await instance
    .get("/villages/CurrentPahaniDetailsSRO?vgcode=" + data.vgcode + "&sryno=" + data.sryno)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const useSROOfficeList = async (id: any) => {
  return await instance
    .get("/villages?districtId=" + id)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}




export const getSroDetails = async (id: any) => {
  return await instance
    .get(`/villages/sroDetails/${id}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const UseCreateApplication = async (data: any) => {
  return await instance
    .post("/documents", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const useGetApplicationDetails = async (data: any) => {
  if (data?.status == undefined) {
    return await instance
      .get("/documents/" + data)
      .then((res: any) => {
        return res.data
      })
      .catch((e: any) => {
        console.log(e.response)
        return {
          status: false,
          message: e.message,
        }
      })
  } else {
    return await instance
      .get(`/documents?status=${data.status}`)
      .then((res: any) => {
        return res.data
      })
      .catch((e: any) => {
        return {
          status: false,
          message: e.response.data.error,
        }
      })
  }
}
export const useSavePartyDetails = async (data: any) => {
  console.log(data)
  return await instance
    .post("/parties", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}
export const changePassword = async (data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("/department/changePassword", data, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}
export const profileUpdate = async (data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("/department/update", data, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const useSaveRepresentDetails = async (data: any) => {
  console.log(data)
  return await instance
    .post("/parties/representative", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const useUpdatePartyDetails = async (data: any) => {
  return await instance
    .put("/parties", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const useDeleteParty = async (data: any) => {
  return await instance
    .delete("/parties/" + data.applicationId + "/" + data.id)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}
export const UseSlotBooking = async (data: any) => {
  await instance
    .post("/slots/appointment", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}
export const UseSlotBookingDetails = async (data: any) => {
  return await instance
    .get("/slots/slotBooking/" + `${data.sroOfcNum}?dateForSlot=${data.dateForSlot}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseAddProperty = async (data: any) => {
  return await instance
    .post("/properties", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const UseAddCovenant = async (data: any) => {
  return await instance
    .post("/covanants", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const UseSetPresenter = async (data: any) => {
  return await instance
    .put("/parties/updatePresenter", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const UseDeleteApplication = async (applicationId: string, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .delete("/documents/" + applicationId, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const useDeleterepresentative = async (data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .delete("/parties/representative/" + data.partyId + "/" + data.parentPartyId, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const useDeleteProperty = async (data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .delete("/properties/" + data.applicationId + "/" + data.propertyId, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const UseChangeStatus = async (data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .put("/documents", data, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data,
      }
    })
}

export const UseReportDownload = async (info: any) => {
  return await instance
    .get(`/reports/${info.type}/${info.applicationId}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const LinkedDocumentApi = async (info: any) => {
  return await instance
    .get(
      `/ob/partyOrProperty?sroCode=${info.sroCode}&documentId=${info.documentId}&regYear=${info.regYear}`
    )
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetVillageCode = async (sroCode: any) => {
  return await instance
    .get(`/ob/villagesbyODb/${sroCode}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetHabitation = async (VillageCode: any, type: string) => {
  return await instance
    .get(`/ob/habitation/${type}/${VillageCode}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetSurveynoList = async (villagecode: any) => {
  return await instance
    .get(`/ob/marketValue/classicWiseDetails?villageCode=${villagecode}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetMarketValue = async (type: string, villagecode: any) => {
  return await instance
    .get(`/ob/marketValue/${type}/${villagecode}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetMarketClassicValue = async (survayno: string, villagecode: any) => {
  return await instance
    .get(`/ob/marketValue/classicWiseDetails?villageCode=${villagecode}&serveyNo=${survayno}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetDoorWiseValue = async (WARD_NO: any, BLOCK_NO: any, habitation: any) => {
  return await instance
    .get(
      `/ob/marketValue/DoorWiseDetails?wardNo=${WARD_NO}&blockNo=${BLOCK_NO}&habitation=${habitation}`
    )
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetLinkDocDetails = async (sroCode: any, linkDocNo: any, regYear: any) => {
  return await instance
    .get(`/ob/partyOrProperty?sroCode=${sroCode}&documentId=${linkDocNo}&regYear=${regYear}`)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetAadharOTP = async (data: any) => {
  return await axios
    .post(process.env.AADHAR_URL + "/generateOTPByAadharNumber", { aadharNumber: data })
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      return { status: "Failure" }
    })
}

export const UseGetAadharDetails = async (data: any) => {
  if (process.env.SECRET_KEY) {
    const enc = CryptoJS.AES.encrypt(JSON.stringify(data), process.env.SECRET_KEY).toString()
    return await instance
      .post("/verifyOTP", { otp: enc })
      .then((res: any) => {
        if (process.env.SECRET_KEY) {
          let bytes = CryptoJS.AES.decrypt(res.data.userInfo, process.env.SECRET_KEY)
          let re = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
          return re
        }
      })
      .catch((e: any) => {
        return {
          status: false,
          message: get(e, "response.data.message", "Aadhaar OTP validation failed"),
        }
      })
  }
}
export const getDeptSignature = async (id: any, token: string) => {

  let mytoken = { headers: { Authorization: `Bearer ${token}` } }

  return await instance

    .get("/certificateDetails/" + id, mytoken)

    .then((res: any) => {

      if (process.env.SECRET_KEY) {

        let bytes = CryptoJS.AES.decrypt(res.data, process.env.SECRET_KEY)

        let re = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))

        return re

      }

    })

    .catch((e: any) => {

      console.log(e.message)

      return {

        status: false,

        message: e.response.data.error,

      }

    })

}
export const VerifyTransactionDetails = async (data: any) => {
  return await axios
    .post(process.env.PAYMENT_REDIRECT_URL + "/verifyCfmsTransactionByDepartmentID", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      return {
        status: false,
        message: get(e, "response.data.message", "Transaction details verification failed"),
      }
    })
}

export const DefaceTransactionDetails = async (data: any) => {
  return await axios
    .post(process.env.PAYMENT_REDIRECT_URL + "/defaceCfmsTransactionByDepartmentID", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      return {
        status: false,
        message: get(e, "response.data.message", "Transaction details verification failed"),
      }
    })
}

export const UpdateSocietyStatus = async (id: any, data: any, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("/paymentResponseDetails/" + id, data, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const useUserLogin = async (LogiDetails: any) => {}

export const getSocietyDetailsbyAppNo = async (applicationId: string, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .get("/societies/getSocietyByAppId/" + btoa(applicationId), mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e?.response?.data?.error,
      }
    })
}
export const getSocietyDetails = async (applicationId: string, token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .get("/societies/" + btoa(applicationId), mytoken)
    .then((res: any) => {
      if (process.env.SECRET_KEY) {
        let bytes = CryptoJS.AES.decrypt(res.data, process.env.SECRET_KEY)
        let re = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
        return re
      }
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e?.response?.data?.error,
      }
    })
}
export const getSocietyDetailsdata = async ( token: string) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .get("/fetchAuthorityDetails", mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}
export const downloadSocietyCertificate = async (
  data: any,
  applicationId: string,
  token: string
) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("/societies/downloads/" + applicationId, data, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const downloadByeLawCertificate = async (
  data: any,
  applicationId: string,
  token: string
) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("/societies/byeLawdownloads/" + applicationId, data, mytoken)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}
export const updateSocietyDetails = async (applicationId: string, token: string, data: any) => {
  let mytoken = { headers: { Authorization: `Bearer ${token}` } }
  return await instance
    .post("/societies/update", data, mytoken)
    .then((res: any) => {
      if (process.env.SECRET_KEY) {
        let bytes = CryptoJS.AES.decrypt(res.data, process.env.SECRET_KEY)
        let re = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
        return re
      }
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response?.data?.error,
      }
    })
}

// google translate api

export const googleAPI = async (value: string) => {
  return await axios
    .get(
      `https://translation.googleapis.com/language/translate/v2?key=AIzaSyBVlw_vinovo_c3ahlPb7atXlN99I-wu9Q&source=en&target=te&q=${value}`
    )
    .then((res: any) => {
      return res.data
    })
    .catch((err) => {
      return {}
    })
}

export const UseSaveMortagageDetails = async (data: any) => {
  return await instance
    .post("payments/MORTAGAGE/create", data)
    .then((res: any) => {
      console.log(res.data)
      return res.data
    })
    .catch((e: any) => {
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseSaveRelationDetails = async (data: any) => {
  return await instance
    .post("payments/GIFT/create", data)
    .then((res: any) => {
      console.log(res.data)
      return res.data
    })
    .catch((e: any) => {
      return {
        status: false,
        message: e.message,
      }
    })
}
export const UseSaveSaleDetails = async (data: any) => {
  return await instance
    .post("payments/SALE/create", data)
    .then((res: any) => {
      console.log(res.data)
      return res.data
    })
    .catch((e: any) => {
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseUpdatePaymentDetails = async (data: any) => {
  return await instance
    .put("/payments/update/" + data._id, data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseDeletePaymentDetails = async (id: any) => {
  return await instance
    .delete("/payments/delete" + id)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const GetCDMAData = async (data: any) => {
  return await instance
    .post("/villages/CDMAPropertyAssessmentDetails", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseGetPPCheck = async (data: any, type: string) => {
  return await instance
    .put(`/ob/pp_check/${type}`, data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseSaveCovinant = async (data: any) => {
  return await instance
    .post("/covanants", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseDelCovenant = async (data: any) => {
  return await instance
    .delete("/covanants/" + data.documentId + "/" + data.covId, data.covanants)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.response.data.error,
      }
    })
}

export const UseUpdateCovinant = async (data: any) => {
  return await instance
    .put("/covanants/" + data.documentId + "/" + data.covId, data.covanants)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e.message)
      return {
        status: false,
        message: e.message,
      }
    })
}

export const UseMVCalculator = async (data: any, type: string) => {
  return await instance
    .put("/ob/" + type + "/mvCalculator", data)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      console.log(e)
      return {
        status: false,
        message: e.message,
      }
    })
}
export const UseSaveDataEntrySocietyDetails = async (data: any, token: string) => {
  let myHeader = {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: `Bearer ${token}`,
    },
  }
  return await instance
    .post("/department/dataEntry", data, myHeader)
    .then((res: any) => {
      return res.data
    })
    .catch((e: any) => {
      return {
        status: false,
        message: e.response.data,
      }
    })
}