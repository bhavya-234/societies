import Header from "@/components/common/Header"
import Footer from "@/components/common/Footer"
import { useRouter } from "next/router"
import { Container, Col, Row } from "react-bootstrap"

export default function Layout({ children }: any) {
  const router = useRouter()

  let pageHeader = ""
  if (
    router.pathname == "/form2" ||
    router.pathname == "/form1" ||
    router.pathname == "/form1-2" ||
    router.pathname == "/forms"
  ) {
    pageHeader = "formTypeHeader"
  } else {
    pageHeader = "globalHeader"
  }
  return (
    <>
      <div className={`${pageHeader} pageWrapper`}>
        <Header />
        <div className="mainWrapper">
          {router.pathname != "/" &&
            router.pathname != "/societies/dashboard" &&
            router.pathname != "/societies" &&
            router.pathname != "/societies/viewDetails" &&
            router.pathname != "/societies/details" &&
            router.pathname != "/societies/societiesAmendment" &&
            router.pathname != "/listofAmendment" &&
            router.pathname != "/AmalgamationOfTheSociety" &&
            router.pathname != "/report" && (
              <div className="pageTopbtnsSec">
                <Container>
                  <Row>
                    <Col lg={12} md={12} xs={12}>
                      <div className="d-flex justify-content-end page-title mb-3">
                        {/* <div className="page-header-btns">
                          <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                            Go Back
                          </a>
                        </div> */}
                      </div>
                    </Col>
                  </Row>
                </Container>
              </div>
            )}
          <div className="pageInnerSec">{children}</div>
        </div>
        <Footer />
      </div>
    </>
  )
}
