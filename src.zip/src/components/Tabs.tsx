import router from 'next/router'
import React, { useEffect, useState } from 'react'
import styles from "@/styles/components/header.module.scss"
import { propTypes } from 'react-bootstrap/esm/Image'
import CryptoJS from "crypto-js"
interface Proptypes {
active:number
}
const DepartmentTab= (Proptypes) => {

  const [locData,setLocData]=useState<any>(null)
  const [activeTab, setActiveTab] = useState(0)
  useEffect(()=>{
    setActiveTab(Proptypes.active)
  })
  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLocData(data)
    }
  }, [])
  return (
    <div>
       <>
          <div className={styles.tabcontainer}>
            {locData?.role!="IG" &&
              ['REPORTS', 'REGISTRATIONS'].map((o, i) => {
                return (
                  <button key={o} className={i === activeTab ? styles.activeButton : styles.button} onClick={() => {
                    if (i == 0) {
                      router.push("/report")
                    } else if (i == 1) {
                      router.push("/societies")
                   }
                    setActiveTab(i);
                  }}>{o}</button>
                )
              })
            }
             {locData?.role=="IG" &&
              ['REGISTRATIONS'].map((o, i) => {
                return (
                  <button key={o} className={i === activeTab ? styles.activeButton : styles.button} onClick={() => {
                    if (i == 0) {
                      router.push("/report")
                    } else if (i == 1) {
                      router.push("/societies")
                   }
                    setActiveTab(i);
                  }}>{o}</button>
                )
              })
            }
          
          </div>

        </>
    </div>
  )
}

export default DepartmentTab

