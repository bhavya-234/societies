import { useState } from "react"
import Modal from "react-bootstrap/Modal"
import styles from "@/styles/Home.module.scss"
import { Col, Row } from "react-bootstrap"
import Image from "next/image"
import { useAppSelector, useAppDispatch } from "@/redux/hooks"
import { AadharPopupAction } from "@/redux/commonSlice"
import { useRouter } from "next/router"
import { CallingAxios, ShowMessagePopup } from "@/GenericFunctions"
import { UseGetAadharDetails, UseGetAadharOTP } from "@/axios"
import { AES } from "crypto-js"

interface AadharNumberDetailDTO {
  aadharNumber: string
  otp: string
  OTPResponse: { transactionNumber: string }
  KYCResponse: any
}

const initialAadharDetails = {
  aadharNumber: "",
  otp: "",
  OTPResponse: { transactionNumber: "" },
  KYCResponse: {},
}

const AadharPopup = () => {
  const [TempMemory, setTempMemory] = useState<any>({ AadharPresent: false })
  const [AadharNumberDerails, setAadharNumberDerails] =
    useState<AadharNumberDetailDTO>(initialAadharDetails)
  const AadharPopupMemory = useAppSelector((state) => state.common.AadharPopupMemory)
  const dispatch = useAppDispatch()
  const router = useRouter()

  const ReqOTP = () => {
    if (AadharNumberDerails.aadharNumber.length == 12) {
      let ExistingAadhar: any = []
      let count = ExistingAadhar.find((x: any) => x == AadharNumberDerails.aadharNumber)
      if (!count) {
        CallGetOTP()
      } else {
        ShowMessagePopup(false, "Duplivate Aadhar card entry is not allowed", "")
      }
    } else {
      dispatch(AadharPopupAction({ ...AadharPopupMemory, enable: false }))
      ShowMessagePopup(false, "Kindly enter valid Aadhar number", "/PartiesDetailsPage")
    }
  }
  const ReqDetails = async () => {
    let result = await CallingAxios(
      UseGetAadharDetails({
        aadharNumber: btoa(AadharNumberDerails.aadharNumber),
        transactionNumber: AadharNumberDerails.OTPResponse.transactionNumber,
        otp: AadharNumberDerails.otp,
      })
    )
    if (result.status && result.status === "Success") {
      let details = { ...AadharNumberDerails, KYCResponse: result.userInfo }
      // setAadharNumberDerails(details);
      setTempMemory({ AadharPresent: false })
      setAadharNumberDerails({
        aadharNumber: "",
        otp: "",
        OTPResponse: { transactionNumber: "" },
        KYCResponse: {},
      })
      dispatch(AadharPopupAction({ enable: false, status: true, response: true, data: details }))
    } else {
      ShowMessagePopup(false, "Aadhar card verification failed", "/PartiesDetailsPage")
      dispatch(AadharPopupAction({ ...AadharPopupMemory, enable: false }))
    }
  }

  const CallGetOTP = async () => {
    if (process.env.IGRS_SECRET_KEY) {
      const ciphertext = AES.encrypt(AadharNumberDerails.aadharNumber, process.env.IGRS_SECRET_KEY)
      let result = await CallingAxios(UseGetAadharOTP(ciphertext.toString()))
      if (result && result.status != "Failure") {
        setTempMemory({ AadharPresent: true })
        setAadharNumberDerails({ ...AadharNumberDerails, OTPResponse: result })
        ShowMessagePopup(true, "OTP Sent to Aadhaar Registered Mobile Number", "")
      } else {
        dispatch(AadharPopupAction({ ...AadharPopupMemory, enable: false }))
        ShowMessagePopup(false, "Aadhar OTP request failed", "/PartiesDetailsPage")
      }
    }
  }

  const onchange = (e: any) => {
    let addName = e.target.name
    let addValue = e.target.value
    if (addName == "aadharNumber") {
      if (addValue.length > 12) {
        addValue = AadharNumberDerails.aadharNumber
      }
    }
    setAadharNumberDerails({ ...AadharNumberDerails, [addName]: addValue })
  }

  return (
    <div className="home-main-sec">
      {AadharPopupMemory.enable && (
        <div className={styles.container}>
          <Modal.Dialog className={styles.modaldialog}>
            <div className={styles.modalHeaderInfo}>
              <Row className={styles.Modalheader}>
                <Col lg={10}>
                  <Modal.Title className={styles.ModalTitle}>Aadhaar Card Number</Modal.Title>
                </Col>
                <Col lg={2}>
                  <Modal.Header
                    closeButton
                    className={styles.Modalclose}
                    onClick={() => {
                      router.push("/")
                      setAadharNumberDerails(initialAadharDetails)
                      setTempMemory({ AadharPresent: false })
                      dispatch(AadharPopupAction({ ...AadharPopupMemory, enable: false }))
                    }}
                  ></Modal.Header>
                </Col>
              </Row>
            </div>
            <Modal.Body className={styles.succesxsodalbody}>
              <div>
                <Image
                  alt="Image"
                  height={90}
                  width={90}
                  className="adhaarImage"
                  src="/assets/adhar-img.png"
                />
              </div>
              <div>
                <text className={styles.AdharText}>
                  {!TempMemory.AadharPresent ? "Enter " : null}Aadhaar Card Number
                </text>
                {TempMemory.AadharPresent ? (
                  <input
                    disabled={true}
                    type="text"
                    placeholder={"xxxx xxxx x"}
                    value={"xxx xxxx x" + AadharNumberDerails.aadharNumber.substring(9, 12)}
                  />
                ) : (
                  <input
                    disabled={false}
                    type="number"
                    name="aadharNumber"
                    placeholder="xxxx xxxx xxxx"
                    value={AadharNumberDerails.aadharNumber}
                    onChange={onchange}
                  />
                )}
              </div>
              {TempMemory.AadharPresent ? (
                <div>
                  <text className={`${styles.AdharText} ${styles.OtpText}`}>Enter OTP</text>
                  <input
                    type="number"
                    placeholder="xxxxxx"
                    name={"otp"}
                    value={AadharNumberDerails.otp}
                    onChange={onchange}
                  />
                </div>
              ) : null}
              {!TempMemory.AadharPresent ? (
                <button className="proceedButton" onClick={ReqOTP}>
                  Submit
                </button>
              ) : (
                <button className="proceedButton" onClick={ReqDetails}>
                  Verify
                </button>
              )}
            </Modal.Body>
          </Modal.Dialog>
        </div>
      )}
    </div>
  )
}

export default AadharPopup
