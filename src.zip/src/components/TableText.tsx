import styles from "@/styles/components/Table.module.scss"

interface PropsTypes {
  label: string
  required: boolean
  LeftSpace: boolean
}

const TableText = ({ label, required, LeftSpace }: PropsTypes) => {
  return (
    <div>
      <text className={styles.columnText}>
        {label}
        {required && <span style={{ color: "red", marginLeft: "5px" }}>*</span>}
      </text>
    </div>
  )
}

export default TableText
