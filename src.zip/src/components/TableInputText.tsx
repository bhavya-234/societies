import { ShowMessagePopup } from "@/GenericFunctions"
import styles from "@/styles/components/Table.module.scss"

interface PropsTypes {
  type: string
  placeholder: string
  required: boolean
  value: string
  onChange: any
  name: string
  disabled?: boolean
  onMouseOut?: any
  onBlurCapture?: any
  min?: any
  max?: any
  dot?: boolean
  capital?: boolean
  splChar?: boolean
  tabIndex?: number
  maxLength?: number
  minLength?: number
  onKeyPress?: boolean
  onPaste?: any
}

const TableInputText = ({
  type,
  placeholder,
  required = false,
  value,
  name,
  onChange,
  onBlurCapture,
  disabled = false,
  onMouseOut,
  min,
  max,
  dot = true,
  capital = false,
  maxLength,
  minLength,
  splChar = true,
  tabIndex,
  onKeyPress = false,
  onPaste,
}: PropsTypes) => {
  const blockInvalidChar = (e: any) => {
    if (onKeyPress) {
      const keyCode = e.keyCode || e.which
      const keyValue = String.fromCharCode(keyCode)
      const isValid = new RegExp("[0-9]").test(keyValue)
      if (!isValid && e.key != "Backspace") {
        e.preventDefault()
      }
    }
    if (!splChar) {
      ;["/", "_", "+", "-"].includes(e.key) && e.preventDefault()
    }
    
    if (type == "number") {
      ;["e", "E", "+", "-"].includes(e.key) && e.preventDefault()
      if (maxLength && String(e.target.value).length >= maxLength && e.key != "Backspace") {
        e.preventDefault()
      }
      if (dot == false) {
        ;["."].includes(e.key) && e.preventDefault()
      }
    } else if (
      name === "transactionNo" ||
      name === "utrNumber" ||
      name === "doorNo" ||
      name === "plotNo" ||
      name === "survayNo" ||
      name === "layoutNo" ||
      name === "flatNo" ||
      name === "occupation" ||
      name === "qualification" ||
      name === "flatEastBoundry" ||
      name === "flatWestBoundry"
    ) {
      const regex = /[A-Za-z0-9/-]|,/
      if (!regex.test(e.key)) {
        e.preventDefault()
      }
    } else if (
      name == "mobileNumber" ||
      name == "pinCode"
    ) {
      const regex = /[0-9]/
      if (!regex.test(e.key) && e.key != "Backspace") {
        e.preventDefault()
      }
    } else if (name === "role" || name === "street" || name == "fullName") {
      const regex = /^[A-Za-z\s]*$/
      if (!regex.test(e.key)) {
        e.preventDefault()
      }
    }
  }

  return (
    <div>
      <input
        className={styles.columnInputBox}
        tabIndex={tabIndex}
        name={name}
        type={type}
        disabled={disabled}
        style={{ textTransform: (type != 'email' && type != 'password') ? 'uppercase' : 'none' }}
        placeholder={placeholder}
        required={required}
        value={value}
        onChange={onChange}
        onKeyDown={blockInvalidChar}
        onBlurCapture={onBlurCapture}
        onWheel={(event) => event.currentTarget.blur()}
        onBlur={onMouseOut ? onMouseOut : () => {}}
        min={min}
        max={max}
        minLength={minLength}
        maxLength={maxLength}
        onPaste={onPaste}
        autoComplete="off"
      />
    </div>
  )
}

export default TableInputText
