import React, { useRef, useState } from "react"
import { Container, Col, Row, Form, Button, Accordion, Modal } from "react-bootstrap"
import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import styles from "@/styles/components/Table.module.scss"
import { ShowMessagePopup } from "@/GenericFunctions"
import { ISFirmDetailsSMModel } from "@/models/types"

export default function Details() {
  const [firmDetails, setFirmDetails] = useState<ISFirmDetailsSMModel>({
    firmName: "",
    firmDurationFrom: "",
    firmDurationTo: "",
    industryType: "",
    businessType: "",
  })
  const [file, setFile] = useState<any>([])

  const inputRef = useRef<HTMLInputElement | null>(null)

  const [showErrorModal, setShowErrorModal] = useState<boolean>(false)
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false)

  const [newname, setNewname] = useState<string>("")
  const [doorNo, setDoorNo] = useState<string>("")
  const [pin, setPin] = useState<string>("")
  const [dname, setDname] = useState<string>("")
  const [dtype, setDtype] = useState<string>("")
  const [district, setDistrict] = useState<string>("")
  const [mandal, setMandal] = useState<string>("")
  const [village, setVillage] = useState<string>("")
  const [date, setDate] = useState<string>("")
  const [upload, setUpload] = useState<string>("")

  const [newnameErrorMessage, setNewnameErrorMessage] = useState<string>("")
  const [doorErrorMessage, setDoorErrorMessage] = useState<string>("")
  const [pinErrorMessage, setPinErrorMessage] = useState<string>("")
  const [dnameErrorMessage, setDnameErrorMessage] = useState<string>("")
  const [dtypeErrorMessage, setDtypeErrorMessage] = useState<string>("")
  const [districtErrorMessage, setDistrictErrorMessage] = useState<string>("")
  const [mandalErrorMessage, setMandalErrorMessage] = useState<string>("")
  const [villageErrorMessage, setVillageErrorMessage] = useState<string>("")
  const [dateErrorMessage, setDateErrorMessage] = useState<string>("")
  const [uploadErrorMessage, setUploadErrorMessage] = useState<string>("")

  const firmDetailsChange = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setFirmDetails(newInput)
  }

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    } else if (e.target.files[0].type != "image/jpeg" && e.target.files[0].type != "image/jpg") {
      ShowMessagePopup(false, "Please upload jpg type signature", "")
      e.target.value = ""
    }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  const handleButtonClick = () => {
    if (newname.trim() === "") {
      setNewnameErrorMessage("Please enter New Name")
      setShowErrorModal(true)
    } else {
      setNewnameErrorMessage("")
    }

    if (doorNo.trim() === "") {
      setDoorErrorMessage("Please enter door number")
      setShowErrorModal(true)
    } else {
      setDoorErrorMessage("")
    }

    if (pin.trim() === "") {
      setPinErrorMessage("Please enter Pin Code")
      setShowErrorModal(true)
    } else {
      setPinErrorMessage("")
    }
    if (dname.trim() === "") {
      setDnameErrorMessage("Please enter Document Name")
      setShowErrorModal(true)
    } else {
      setDnameErrorMessage("")
    }
    if (dtype.trim() === "" || dtype.trim() === "Select") {
      setDtypeErrorMessage("Please select Document Type")
      setShowErrorModal(true)
    } else {
      setDtypeErrorMessage("")
    }
    if (district.trim() === "" || district.trim() === "Select") {
      setDistrictErrorMessage("Please select District")
      setShowErrorModal(true)
    } else {
      setDistrictErrorMessage("")
    }
    if (mandal.trim() === "" || mandal.trim() === "Select") {
      setMandalErrorMessage("Please select Mandal")
      setShowErrorModal(true)
    } else {
      setMandalErrorMessage("")
    }
    if (village.trim() === "" || village.trim() === "Select") {
      setVillageErrorMessage("Please select Village/City")
      setShowErrorModal(true)
    } else {
      setVillageErrorMessage("")
    }
    if (date.trim() === "") {
      setDateErrorMessage("Please select Date")
      setShowErrorModal(true)
    } else {
      setDateErrorMessage("")
    }
    if (upload.trim() === "") {
      setUploadErrorMessage("Please Upload Document")
      setShowErrorModal(true)
    } else {
      setUploadErrorMessage("")
    }

    if (
      newname.trim() !== "" &&
      doorNo.trim() !== "" &&
      pin.trim() !== "" &&
      dname.trim() !== "" &&
      dtype.trim() !== "Select" &&
      district.trim() !== "Select" &&
      mandal.trim() !== "Select" &&
      village.trim() !== "Select" &&
      date.trim() !== ""
    ) {
      setShowPaymentModal(true)
    }
  }

  const handleCloseErrorModal = () => {
    setShowErrorModal(false)
  }

  const handleClosePaymentModal = () => {
    setShowPaymentModal(false)
  }

  return (
    <>
      <Container>
        <Row>
          <Col lg={12} md={12} xs={12}>
            <div className=" page-title mb-3">
              <div className="pageTitleLeft">
                <h1>Application for the change in the name of Society</h1>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <div className="societyRegSec">
        <div className="dahboardProcedureSec formsec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <Accordion defaultActiveKey={"1"}>
                  <Accordion.Item eventKey="1">
                    <Accordion.Body>
                      <div className="panelDesc">
                        <Row>
                          <Col lg={12} md={12} xs={12}>
                            <div className="regofAppBg mb-3">
                              <div className="formSectionTitle mb-4">
                                <h3>Applicant Details</h3>
                              </div>
                              <Row>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Enter Aadhaar Number"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="formGroup">
                                    <div>
                                      <Form.Control
                                        type="text"
                                        name="otpCode"
                                        required
                                        onChange={undefined}
                                        value={""}
                                      />
                                      <div className="verify btn btn-primary"> Verify</div>
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Name of the Applicant"
                                    LeftSpace={false}
                                    required={false}
                                  />
                                  <TableInputText
                                    type="text"
                                    disabled={true}
                                    placeholder="Enter Name of the Applicant"
                                    name="applicant"
                                    required
                                    onChange={undefined}
                                    value={""}
                                    maxLength={12}
                                  />
                                  <TableText
                                    label="Gender: Male / Age: 39"
                                    LeftSpace={false}
                                    required={false}
                                  />
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Relation Name"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <Form.Group className="inline">
                                    <div className="inline formGroup">
                                      <Form.Select name="relationType" onChange={() => {}} value={""}>
                                        <option className="text-center">S/O</option>

                                        <option className="text-center">D/O</option>

                                        <option className="text-center">W/O</option>

                                        <option className="text-center">H/O</option>
                                      </Form.Select>

                                      <input
                                        className="form-control"
                                        type="text"
                                        name="relationName"
                                        onChange={undefined}
                                        value={""}
                                        disabled={true}
                                      />
                                    </div>
                                  </Form.Group>
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Role" LeftSpace={false} required={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Role"
                                    name="role"
                                    required
                                    maxLength={12}
                                    value={""}
                                    onChange={undefined}
                                  />
                                </Col>
                              </Row>
                            </div>
                            <hr></hr>
                            <div className=" page-title mb-3">
                              <div className="formSectionTitle">
                                <h3>Address</h3>
                              </div>
                              <Row>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Door No" required={true} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Door No"
                                    name="door"
                                    required
                                    onChange={(e: any) => setDoorNo(e.target.value)}
                                    value={doorNo}
                                    maxLength={12}
                                  />
                                  {doorErrorMessage && (
                                    <p style={{ color: "red" }}>{doorErrorMessage}</p>
                                  )}
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Street" LeftSpace={false} required={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Street"
                                    name="street"
                                    required
                                    maxLength={12}
                                    value={""}
                                    onChange={undefined}
                                  />
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="District" required={true} LeftSpace={false} />
                                  <div className="inline formGroup">
                                    <select style={{ textTransform: 'uppercase' }}
                                      className={styles.columnDropDownBox}
                                      onChange={(e) => setDistrict(e.target.value)}
                                      value={district}
                                    >
                                      <option>Select</option>
                                      <option>a</option>
                                      <option>b</option>
                                      <option>c</option>
                                    </select>
                                  </div>
                                  {districtErrorMessage && (
                                    <p style={{ color: "red" }}>{districtErrorMessage}</p>
                                  )}
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Mandal" required={true} LeftSpace={false} />
                                  <div className="inline formGroup">
                                    <select style={{ textTransform: 'uppercase' }}
                                      className={styles.columnDropDownBox}
                                      onChange={(e) => setMandal(e.target.value)}
                                      value={mandal}
                                    >
                                      <option>Select</option>
                                      <option>a</option>
                                      <option>b</option>
                                      <option>c</option>
                                    </select>
                                  </div>
                                  {mandalErrorMessage && (
                                    <p style={{ color: "red" }}>{mandalErrorMessage}</p>
                                  )}
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Village/City"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <div className="inline formGroup">
                                    <select style={{ textTransform: 'uppercase' }}
                                      className={styles.columnDropDownBox}
                                      onChange={(e) => setVillage(e.target.value)}
                                      value={village}
                                    >
                                      <option>Select</option>
                                      <option>a</option>
                                      <option>b</option>
                                      <option>c</option>
                                    </select>
                                  </div>
                                  {villageErrorMessage && (
                                    <p style={{ color: "red" }}>{villageErrorMessage}</p>
                                  )}
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Pin Code" required={true} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Pin Code"
                                    name="pin"
                                    required
                                    onChange={(e: any) => setPin(e.target.value)}
                                    value={pin}
                                    maxLength={12}
                                  />
                                  {pinErrorMessage && (
                                    <p style={{ color: "red" }}>{pinErrorMessage}</p>
                                  )}
                                </Col>
                              </Row>
                              <hr></hr>
                              <div className="formSectionTitle">
                                <h3>Contact Details</h3>
                              </div>

                              <Row>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Landline Phone No"
                                    LeftSpace={false}
                                    required={false}
                                  />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Landline Phone No"
                                    name="landline"
                                    required
                                    onChange={undefined}
                                    value={""}
                                    maxLength={12}
                                  />
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Mobile No" LeftSpace={false} required={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Mobile No"
                                    name="mobile"
                                    required
                                    onChange={undefined}
                                    value={""}
                                    maxLength={12}
                                  />
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Email ID" LeftSpace={false} required={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder=" Enter Email ID"
                                    name="email"
                                    required
                                    onChange={undefined}
                                    value={""}
                                    maxLength={12}
                                  />
                                </Col>
                              </Row>
                            </div>
                          </Col>
                        </Row>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </Col>
            </Row>
          </Container>
          <Container className="mt-3">
            <Row>
              <Col lg={12} md={12} xs={12}>
                <Accordion defaultActiveKey={"1"}>
                  <Accordion.Item eventKey="1">
                    <Accordion.Body>
                      <div className="panelDesc">
                        <Row>
                          <Col lg={12} md={12} xs={12}>
                            <div className="regofAppBg mb-3">
                              <div className="formSectionTitle">
                                <h3>Society Details</h3>
                              </div>
                              <Row>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <Form.Group>
                                    <div className="d-flex justify-content-between">
                                      <Form.Label>Society Name</Form.Label>
                                      <button className="availability">Check Availability</button>
                                    </div>

                                    <Form.Control
                                      type="text"
                                      placeholder="Enter Society Name"
                                      name="firmName"
                                      onChange={firmDetailsChange}
                                      value={firmDetails.firmName}
                                    />
                                  </Form.Group>
                                </Col>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Society Type"
                                    LeftSpace={false}
                                    required={false}
                                  />
                                  <div className="inline formGroup">
                                    <select style={{ textTransform: 'uppercase' }} className={styles.columnDropDownBox}>
                                      <option>Select</option>
                                    </select>
                                  </div>
                                </Col>
                              </Row>
                              <hr></hr>

                              <div className="formSectionTitle">
                                <h3>
                                  Request Type<span style={{ color: "red" }}>*</span>
                                </h3>
                              </div>
                              <Row>
                                <Col lg={12} md={12} xs={12} className="mb-3">
                                  <div className="firmDuration">
                                    <Form.Check
                                      inline
                                      label="Please add Other Place of Business (If any)"
                                      value="Please add Other Place of Business (If any)"
                                      name="atwill"
                                      type="checkbox"
                                      className="fom-checkbox fw-bold small text-sm"
                                    />
                                  </div>
                                </Col>
                              </Row>
                            </div>
                          </Col>
                        </Row>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </Col>
            </Row>
          </Container>
          <Container className="mt-3">
            <Accordion defaultActiveKey={"2"}>
              <Accordion.Item eventKey="2">
                <Accordion.Header>Society Name Change</Accordion.Header>
                <Accordion.Body>
                  <div className="panelDesc">
                    <Row>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <TableText label="New Name" required={true} LeftSpace={false} />

                        <TableInputText
                          type="text"
                          placeholder=" Enter New Name"
                          name="newname"
                          required
                          onChange={(e: any) => setNewname(e.target.value)}
                          value={newname}
                          maxLength={12}
                        />
                        {newnameErrorMessage && (
                          <p style={{ color: "red" }}>{newnameErrorMessage}</p>
                        )}
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <TableText
                          label="New Name Date of Effect"
                          required={true}
                          LeftSpace={false}
                        />
                        <TableInputText
                          disabled={false}
                          type="date"
                          placeholder="Enter Name Date of Effect"
                          required={true}
                          name={"dateofeffect"}
                          onChange={(e: any) => setDate(e.target.value)}
                          value={date}
                        />
                        {dateErrorMessage && <p style={{ color: "red" }}>{dateErrorMessage}</p>}
                      </Col>
                    </Row>
                  </div>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </Container>
          <Container className="mt-3">
            <Accordion defaultActiveKey={"3"}>
              <Accordion.Item eventKey="3">
                <Accordion.Header>
                  Upload Society Releated Documents-(All Uploaded Documents should be in PDF format
                  only upto 5MB)
                </Accordion.Header>
                <Accordion.Body>
                  <div className="panelDesc">
                    <Row>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <TableText label="Document Type" required={true} LeftSpace={false} />
                        <div className="inline formGroup">
                          <select style={{ textTransform: 'uppercase' }}
                            className={styles.columnDropDownBox}
                            onChange={(e) => setDtype(e.target.value)}
                            value={dtype}
                          >
                            <option>Select</option>
                            <option>a</option>
                            <option>b</option>
                            <option>c</option>
                          </select>
                        </div>
                        {dtypeErrorMessage && <p style={{ color: "red" }}>{dtypeErrorMessage}</p>}
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <TableText label="Document Name" required={true} LeftSpace={false} />
                        <TableInputText
                          type="text"
                          placeholder=" Enter Document Name"
                          name="documentname"
                          required
                          onChange={(e: any) => setDname(e.target.value)}
                          value={dname}
                          maxLength={12}
                        />
                        {dnameErrorMessage && <p style={{ color: "red" }}>{dnameErrorMessage}</p>}
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <TableText label="Upload Document" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="affidavit"
                            ref={inputRef}
                            value={upload}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                          {uploadErrorMessage && (
                            <p style={{ color: "red" }}>{uploadErrorMessage}</p>
                          )}
                        </div>
                      </Col>
                    </Row>
                  </div>
                </Accordion.Body>
              </Accordion.Item>
            </Accordion>
          </Container>
          <Container className="mt-3">
            <Col lg={12} md={12} xs={12} className="mb-3">
              <Accordion defaultActiveKey={"4"}>
                <Accordion.Item eventKey="4">
                  <Accordion.Header>
                    <Row style={{ width: "100%" }}>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        S.No
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        Document Type
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        Document Name
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        Role
                      </Col>
                    </Row>
                  </Accordion.Header>
                  <Accordion.Body></Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </Col>
          </Container>
          <div className="text-center mt-3">
            <button className="verify btn btn-primary" onClick={handleButtonClick}>
              Make Payment
            </button>
          </div>
          <Modal show={showErrorModal} onHide={handleCloseErrorModal}>
            <Modal.Header closeButton>
              <Modal.Title>Error</Modal.Title>
            </Modal.Header>
            <Modal.Body className="text-center">
              <p>Please enter mandatory fields</p>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleCloseErrorModal}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>

          <Modal show={showPaymentModal} onHide={handleClosePaymentModal}>
            <Modal.Header closeButton>
              <Modal.Title>Make Payment</Modal.Title>
            </Modal.Header>
            <Modal.Body className="text-center">
              <img src="/assets/payment.svg" width={50} height={50} className="plus-circle-img" />
              <p>Are you sure you want to make payment?</p>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClosePaymentModal}>
                No
              </Button>
              <Button variant="primary" className="ms-2">
                Yes
              </Button>
            </Modal.Footer>
          </Modal>
        </div>
      </div>
    </>
  )
}
