import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import React, { useEffect, useRef, useState } from "react"
import { Col, Form, Row, Container } from "react-bootstrap"
import styles from "@/styles/components/Table.module.scss"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { useAppDispatch } from "@/hooks/reduxHooks"
import { UseGetAadharDetails, UseGetAadharOTP, getSocietyDetails, updateSocietyDetails } from "@/axios"
import { store } from "@/redux/store"
import instance from "@/redux/api"
import DynamicMandals from "@/pages/societies/dynamicMandals"
import DynamicVillages from "@/pages/societies/dynamicCities"
import { get } from "lodash"
import CryptoJS, { AES } from "crypto-js"
import { ShowMessagePopup } from "@/GenericFunctions"
import {
  ISApplicantDetailModel,
  ISDissolutionSocietyModel,
  ISRequestTypeModel,
} from "@/models/types"
import Swal from "sweetalert2"
interface DetailProps {
  checklistdissolution?: any
}
const DissolutionSociety = ({ checklistdissolution }: DetailProps) => {
  const dispatch = useAppDispatch()
  const [checklist, setChecklist] = useState<any>(checklistdissolution);
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [file, setFile] = useState<any>([])
  const [errors, setErrors] = useState<any>({})
  const [addSociety, setAddSociety] = useState<string>("")
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false)
  const [showreasonForDissolution, setShowreasonForDissolution] = useState<boolean>(true)
  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  const [token, setToken] = useState<string>("")
  const [districtList, setDistricts] = useState<any>([])
  const [currentDistrict, setCurrentDistrict] = useState<string>("")
  const [currentMandal, setCurrentMandal] = useState<string>("")
  const [TempMemory, setTempMemory] = useState<any>({ OTPRequested: false, AadharVerified: false })
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [isError, setIsError] = useState<boolean>(false)
  const [isPayNowClicked, setIsPayNowClicked] = useState<boolean>(false)
  const tableHeaders: string[] = [
    "Type",
    "Aadhaar No ",
    "Name of the Member",
    "Relation Name",
    "Age / Gender",
    "Role/Position",
    "Occupation",
    "Date of Joining",
    "Address",
    "Contact Details",
  ]
  const [display, setdisplay] = useState<boolean>(false)
  const [applicantDetails, setApplicantDetails] = useState<ISApplicantDetailModel>({
    aadharNumber: "",
    name: "",
    relationName: "",
    role: "",
    doorNo: "",
    relationType: "",
    age: "",
    gender: "",
    street: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    phone: "",
    mobileNumber: "",
    maskedAadhar: "",
    email: "",
  })
  const [membersDetails, setMembersDetails] = useState<any>([])
  const [societyDetails, setSocietyDetails] = useState<ISDissolutionSocietyModel>({
    societyName: "",
    generalBodyMeetingDate:"",
    category: "",
    reasonForDissolution: "",
    effectDate: "",
    disposedDetails: "",
    underSection: "",
    isSocietyProperties: "",
    isSettlementByeLaws: "",
    isScoietyLiabilities: "",
    isByeLawsProperties: "",
    isDissolutionAgreed: "",
    isDissolutionApproved: ""


  })
  const [requestType, setrequestType] = useState<ISRequestTypeModel>({
    isAimChange: "",
    societyNameChange: "",
    placeChange: "",
    isSocietyDissolved: "",
    filing: "",
  })

  useEffect(() => {
    setSocietyDetails({ ...societyDetails, uploadedDoc: file })
  }, [file])

  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
        // throw Error("Invalid File");
        ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
        e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])){
      if(!regex){
      ShowMessagePopup(false, "Please upload proper file name");
      e.target.value = "";
    }
  }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  async function getFileFromUrl(url: any, name: any, defaultType = "pdf") {
    const response = await instance.get(url, { responseType: "arraybuffer" })

    return new File([response.data], name, {
      type: defaultType,
    })
  }

  React.useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setToken(data.token)
    setLoggedInAadhar(data.aadharNumber)
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)
        getSocietyDetails(data.applicationId, data.token)
          .then((response) => {
            if (response?.success) {
              setExistingSocietyDetail(response.data.daSociety)
              setSocietyDetails({
                societyName: response.data.daSociety.societyName
                  ? response.data.daSociety.societyName
                  : "",
                category: response.data.daSociety.category
                  ? response.data.daSociety.category
                  : "",
                disposedDetails: "",
                underSection: "",
                effectDate: "",
                reasonForDissolution: "",
                generalBodyMeetingDate:"",
                isSocietyProperties: "",
                isSettlementByeLaws: "",
                isScoietyLiabilities: "",
                isByeLawsProperties: "",
                isDissolutionAgreed: "",
                isDissolutionApproved: ""
              })

              if (
                response.data.daSociety?.memberDetails &&
                response.data.daSociety?.memberDetails?.length > 0
              ) {
                response.data.daSociety.memberDetails.forEach(
                  (a: any) =>
                    (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber?.toString().substring(8, 12))
                )
                setMembersDetails([...response.data.daSociety.memberDetails])
              }

            }
          })
          .catch(() => {
            Loading(false)
          })
        Loading(false)
      })
      .catch(() => {
        Loading(false)
      })
  }, [])
  const ReqDetails = async (MyKey: any) => {
    let result = await CallingAxios(
      UseGetAadharDetails({
        aadharNumber: btoa(MyKey.aadharNumber),
        transactionNumber: MyKey?.OTPResponse?.transactionNumber,
        otp: MyKey.otpCode,
      })
    )
    if (
      result.status &&
      result.status === "Success" &&
      MyKey?.OTPResponse?.transactionNumber == result.transactionNumber.split(":")[1]
    ) {
      let latestData: any = {
        ...MyKey,
        name: result.userInfo.name ? result.userInfo.name : "",
        memberName: result.userInfo.name ? result.userInfo.name : "",
        relationType: result.userInfo.co ? result.userInfo.co.substring(0, 3) : "",
        relationName: result.userInfo.co ? result.userInfo.co.substring(4) : "",
        age: result.userInfo.dob ? ageCalculator(result.userInfo.dob) : "",
        gender: result.userInfo.gender == "M" ? "Male" : "Female",
        district: result.userInfo.dist ? result.userInfo.dist : "",
        pinCode: result.userInfo.pc ? result.userInfo.pc : "",
        street: result.userInfo.loc ? result.userInfo.street : "",
        villageOrCity: result.userInfo.vtc ? result.userInfo.vtc : "",
        doorNo: result.userInfo.house ? result.userInfo.house : "",
        address:
          (result.userInfo.lm ? result.userInfo.lm + ", \n" : "") +
          (result.userInfo.loc ? result.userInfo.loc + ", \n" : "") +
          (result.userInfo.dist ? result.userInfo.dist + ", \n" : "") +
          (result.userInfo.vtc ? result.userInfo.vtc : "") +
          (result.userInfo.pc ? "-" + result.userInfo.pc : ""),
        OTPResponse: result,
      }

      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails(latestData)
          setTempMemory({ OTPRequested: false, AadharVerified: true })
          break
        default:
          break
      }
    } else {
      ShowMessagePopup(false, "Please Enter Valid OTP", "")
    }
  }
  const ReqOTP = (MyKey: any) => {
    // if (MyKey.aadharNumber && MyKey.aadharNumber.length == 12) {
    CallGetOTP(MyKey)
    // } else {
    //   ShowMessagePopup(false, "Kindly enter valid Aadhar number", "")
    // }
  }
  const CallingAxios = async (myFunction: any) => {
    Loading(true)
    let result = await myFunction
    Loading(false)
    return result
  }

  const CallGetOTP = async (MyKey: any) => {
    if (process.env.IGRS_SECRET_KEY) {
       
      const ciphertext = AES.encrypt(MyKey.aadharNumber, process.env.IGRS_SECRET_KEY)
      let result = await CallingAxios(UseGetAadharOTP(ciphertext.toString()))
      
      if (result && result.status != "Failure") {
        switch (MyKey) {
          case applicantDetails:
            setTempMemory({ OTPRequested: true, AadharVerified: false })
            break

          default:
            break
        }
        switch (MyKey) {
          case applicantDetails:
            setApplicantDetails({ ...MyKey, OTPResponse: result })
            break
          default:
            break
        }
        ShowMessagePopup(
          true,
          "OTP Sent to Aadhaar Registered Mobile Number.",
          ""
        )
      }
    } else {
      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemory({ OTPRequested: false, AadharVerified: false })
          break
        default:
          break
      }
      ShowMessagePopup(false, "Please Enter Valid Aadhar", "")
    }
  }
  const applicantDetailsChange = (e: any) => {
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        e.target.value.length > 0 &&
        e.target.value.length > applicantDetails.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          applicantDetails.aadharNumber.substring(0, startpos) +
          applicantDetails.aadharNumber.substring(
            startpos + 1,
            applicantDetails.aadharNumber.length
          )
      }
      setApplicantDetails({
        ...applicantDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? applicantDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
      setApplicantDetails(newInput)
    }
    if (e.target.name === "reasonForDissolution") {
      setShowreasonForDissolution(e.target.checked)
    }
  }

  const societyDetailsChange = (e: any) => {
    setSocietyDetails({ ...societyDetails, [e.target.name]: e.target.value })
    if (e.target.name === "reasonForDissolution") {
      setShowreasonForDissolution(e.target.checked)
    }
  }

  const validateInputs = () => {
    let applicant: ISApplicantDetailModel = { ...applicantDetails }
    const errors: any = {}
    if (TempMemory.AadharVerified != true) {
      return ShowMessagePopup(false, "Plaese verify aadhar number")
    }
    if (societyDetails.isByeLawsProperties != "Yes") {
      return ShowMessagePopup(false, "Please select validate option for byelaw properties", "")
    }
    if (societyDetails.isDissolutionAgreed != 'Yes') {
      return ShowMessagePopup(false, "Please  select general body agreed for dissolution  ")
    }
    if (societyDetails.isDissolutionApproved != 'Yes') {
      return ShowMessagePopup(false, "Please select dissolution voted & approved by 2/3rd of the members present at the special meeting convened")
    }
    if (societyDetails.isScoietyLiabilities != "Yes") {
      return ShowMessagePopup(false, "Please select validate option for byelaw properties", "")
    }
    if (societyDetails.isSettlementByeLaws != 'Yes') {
      return ShowMessagePopup(false, "Please  select general body agreed for dissolution  ")
    }
    if (societyDetails.isSocietyProperties != 'Yes') {
      return ShowMessagePopup(false, "Please select dissolution voted & approved by 2/3rd of the members present at the special meeting convened")
    }

    setErrors({ ...errors })
    console.log("errors obj", errors)
    return errors
  }
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const [sentOTP, setSentOTP] = useState<boolean>(false)


  const handleSubmit = async (e: any) => {
    e.preventDefault()
    if (Object.keys(validateInputs()).length == 0) {

      const data = {
        applicantDetails: applicantDetails,
        societyDetails: societyDetails,

        ...requestType
      }

      const newData = new FormData()
      newData.append("applicantDetails[aadharNumber]", btoa(data.applicantDetails.aadharNumber))
      newData.append("applicantDetails[applicationNumber]", existingSocietyDetail.applicationNumber)
      newData.append("applicantDetails[name]", existingSocietyDetail.applicantDetails.name)
      newData.append("applicantDetails[doorNo]", existingSocietyDetail.applicantDetails.doorNo)
      newData.append("applicantDetails[street]", existingSocietyDetail.applicantDetails.street)
      newData.append("applicantDetails[age]", existingSocietyDetail.applicantDetails.age)
      newData.append("applicantDetails[gender]", existingSocietyDetail.applicantDetails.gender)
      newData.append("applicantDetails[country]", "India")
      newData.append("applicantDetails[state]", "Andhra Pradesh")
      newData.append("applicantDetails[district]", existingSocietyDetail.applicantDetails.district)
      newData.append("applicantDetails[mandal]", existingSocietyDetail.applicantDetails.mandal)
      newData.append("applicantDetails[villageOrCity]", existingSocietyDetail.applicantDetails.villageOrCity)
      newData.append("applicantDetails[pinCode]", existingSocietyDetail.applicantDetails.pinCode)
      newData.append("applicantDetails[mobileNumber]", existingSocietyDetail.applicantDetails.mobileNumber)
      newData.append("applicantDetails[relationType]", existingSocietyDetail.applicantDetails.relationType)
      newData.append("applicantDetails[relationName]", existingSocietyDetail.applicantDetails.relationName)
      newData.append("applicantDetails[role]", existingSocietyDetail.applicantDetails.role)
      newData.append("id", existingSocietyDetail._id)
      // newData.append("isAimChange", data.societyDetails.isAimChange)
      newData.append("aim", data.societyDetails.aim ? data.societyDetails.aim : "")
      newData.append("objective", data.societyDetails.objective ? data.societyDetails.objective : "")
      newData.append("country", "India")
      newData.append("state", "Andhra Pradesh")
      newData.append("dissolutionOfSociety[reasonForDissolution]", data.societyDetails.reasonForDissolution)
      newData.append("dissolutionOfSociety[effectDate]", data.societyDetails.effectDate)
     
      newData.append("dissolutionOfSociety[isSocietyProperties]", data.societyDetails.isSocietyProperties)
      newData.append("dissolutionOfSociety[isSettlementByeLaws]", data.societyDetails.isSettlementByeLaws)
      newData.append("dissolutionOfSociety[isScoietyLiabilities]", data.societyDetails.isScoietyLiabilities)
      newData.append("dissolutionOfSociety[isByeLawsProperties]", data.societyDetails.isByeLawsProperties)
      newData.append("dissolutionOfSociety[isDissolutionApproved]", data.societyDetails.isDissolutionApproved)
      newData.append("dissolutionOfSociety[isDissolutionAgreed]", data.societyDetails.isDissolutionAgreed)
      newData.append("dissolutionOfSociety[underSection]", data.societyDetails.underSection)
      newData.append("dissolutionOfSociety[disposedDetails]", data.societyDetails.disposedDetails)
      newData.append("dissolutionOfSociety[generalBodyMeetingDate]", data.societyDetails.generalBodyMeetingDate)
      newData.append("propertyDisposal", file.propertyDisposal)
      if (checklist &&
        checklist.length > 0 &&
        checklist.some((x: string) => x == "Dissolution and winding up of the society")) {
        newData.append("isSocietyDissolved", "true")
      } else {
        newData.append("isSocietyDissolved", "false")
      }

      let object: any = {}
      newData.forEach((value, key) => (object[key] = value))
      object.propertyDisposal = await file2Base64(file?.propertyDisposal)
      localStorage.setItem("AmendmentData", JSON.stringify(object))
      let code = 0
      const dis = districtList?.find((x: any) => x.name == existingSocietyDetail.district)
      if (dis) {
        code = dis.code
      }
      let count = checklist ? checklist.length : 0;
      const paymentsData = {
        type: "sra",
        source: "Society",
        deptId: existingSocietyDetail.applicationNumber,
        rmName: existingSocietyDetail.applicantDetails.name,
        rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
        mobile: existingSocietyDetail.applicantDetails.mobileNumber,
        email: existingSocietyDetail.applicantDetails.email,
        drNumber: code,
        rf: 300,
        uc: 0,
        oc: 0,
        returnURL: process.env.BACKEND_URL + "/societies/redirectPayment",
      }
      let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
      // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
      const encodedData = CryptoJS.AES.encrypt(
        JSON.stringify(paymentsData),
        'igrsSecretPhrase'
      ).toString()
      let paymentLink = document.createElement("a")
      paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
      //paymentLink.target = "_blank";
      paymentLink.click()
      setIsPayNowClicked(false)
      setTimeout(function () {
        paymentLink.remove()
      }, 1000)

    }
  }

  const file2Base64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      if (reader && reader != null && file) {
        reader.readAsDataURL(file)
        reader.onload = () => resolve(reader.result?.toString() || "")
        reader.onerror = (error) => reject(error)
      }
      else {
        resolve("")
      }
    })
  }

  const ShowAlert = (type: any, message: any) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }


  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  const verifyApplicantOtp = async () => {
    if (applicantDetails.otpCode) {
      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(applicantDetails.aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: applicantDetails.otpCode,
      })
      console.log("result:::", result)
      Loading(false)
      // let age =  ageInDays / 365 ;
      if (result.status && result.status === "Success") {
        let data: ISApplicantDetailModel = { ...applicantDetails }
        data["name"] = result.userInfo.name
        data["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        data["relationName"] = result.userInfo.co
        data["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data["street"] = result.userInfo.street
        data["district"] = result.userInfo.dist.toUpperCase()
        data["pinCode"] = result.userInfo.pc
        data["age"] = ageCalculator(result.userInfo.dob)
        data["otpVerified"] = "true"
        setApplicantDetails(data)
        // setMembersDetails(data)
        setCurrentDistrict(result.userInfo.dist.toUpperCase())
      } else {
        let data = { ...applicantDetails }
        data["otpVerified"] = "false"
        setApplicantDetails(data)
        ShowAlert(false, get(result, "message", "Aadhaar API Failed"))
      }
    }
  }
  const ageCalculator = (dateOfBirth: any) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    let month_diff = Date.now() - dob.getTime()
    let age_dt = new Date(month_diff)
    let year = age_dt.getUTCFullYear()
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }
  return (
    <div>
      <div className="societyRegSec mx-1">
        <div className="formsec">
          <div className="page-title mx-3">
            <h1>Dissolution of Society(Section 24)</h1>
          </div>
          <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
            <Container>
              <div className="regofAppBg">
                <div className="formSectionTitle">
                  <h3>Applicant Details</h3>
                </div>
                <text className={styles.warningText} style={{ color: "red" }}>
                  {errors.aadhaarNumber}
                </text>
                <Row>
                  <Col lg={3} md={3} xs={12} >
                    {!TempMemory.OTPRequested ? (
                      <Form.Group>
                        <TableText
                          label="Enter Aadhaar Number"
                          required={true}
                          LeftSpace={false}
                        />
                        <div className="formGroup">
                          <select
                            className="form-control"
                            name="aadharNumber"
                            onChange={(e: any) => {
                              if (!TempMemory.AadharVerified) {
                                applicantDetailsChange(e)
                              }
                            }}
                            disabled={TempMemory.AadharVerified}
                            required={true}
                            value={applicantDetails.aadharNumber}
                          >
                            <option>Select</option>
                            {membersDetails.map((item: any, i: any) => {
                              return (
                                <>{
                                  item.status != "InActive" ?
                                <option key={i + 1} value={item.aadharNumber}>
                                  {item.aadharNumber}
                                </option>:null}</>
                              )
                            })}
                          </select>
                          {!TempMemory.AadharVerified ? (
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                borderRadius: "2px",
                              }}
                              onClick={() => ReqOTP(applicantDetails)}
                              className="verify btn btn-primary"
                            >
                              Get OTP
                            </div>
                          ) : null}
                        </div>
                      </Form.Group>
                    ) : (
                      <Form.Group>
                        <TableText label="Enter OTP" required={true} LeftSpace={false} />
                        <div className="formGroup">
                          <TableInputText
                            disabled={false}
                            type="number"
                            placeholder="Enter OTP Received"
                            maxLength={6}
                            required={true}
                            name={"otpCode"}
                            value={applicantDetails.otpCode}
                            onChange={applicantDetailsChange}
                          />
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                              borderRadius: "2px",
                            }}
                            onClick={() => {
                              ReqDetails(applicantDetails)
                            }}
                            className="verify btn btn-primary"
                          >
                            Verify
                          </div>
                          <div style={{ display: "flex", justifyContent: "flex-end" }}>
                            <div
                              style={{
                                cursor: "pointer",
                                marginRight: "20px",
                                color: "blue",
                                fontSize: "10px",
                              }}
                              onClick={() => {
                                setTempMemory({ ...TempMemory, OTPRequested: false })
                              }}
                            >
                              clear
                            </div>
                          </div>
                        </div>
                      </Form.Group>
                    )}
                  </Col>

                </Row>


              </div>
              <div className="regofAppBg my-1">
                <div className="formSectionTitle">
                  <h3>Society Details</h3>
                </div>
                <Row>
                  <Col lg={3} md={12} sm={12} className="my-1">
                    <div className="d-flex justify-content-between ">
                      <div>
                        <TableText label={"Society Name"} required={false} LeftSpace={false} />{" "}
                      </div>
                      {/* <div
                        style={{ color: "#394E91", textDecoration: "underline" }}
                        className={styles.columnText}
                      >
                        Check Availability
                      </div> */}
                    </div>
                    <TableInputText
                      type="text"
                      placeholder="Enter Society Name"
                      required={true}
                      name="societyName"
                      disabled
                      value={existingSocietyDetail?.societyName}
                      onChange={()=>{}}
                    />
                  </Col>
                  <Col lg={3} md={12} sm={12} className="my-2">
                    <TableText label={"Society Type"} required={false} LeftSpace={false} />
                    <TableInputText
                      placeholder="enter category"
                      required
                      disabled
                      type="text"
                      name="category"
                      onChange={()=>{}}
                      value={existingSocietyDetail?.category}
                    />

                  </Col>
                </Row>
              </div>
              <div className="formSectionTitle">
                <h3>
                  Request Type <span style={{ color: "red" }}>*</span>
                </h3>
              </div>
              <div className="">
                <Form.Check
                  inline
                  label="Dissolution of Society"
                  value={requestType.isSocietyDissolved}
                  name="isSocietyDissolved"
                  type="checkbox"
                  className="fom-checkbox"
                  onChange={()=>{}}
                  checked={true}
                  disabled
                />
                {/* {errors.requestType && <span  style ={{color:"red"}} className={styles.columnText}>{errors.requestType}</span>} */}
              </div>
              <div className="regofAppBg my-1">
                <div className="formSectionTitle">
                  <TableText label={"Reason for Dissolution"} required={true} LeftSpace={false} />

                  <Row>
                    <Col lg={12} md={12} xs={12} className="mb-1">
                      <TableInputText
                        placeholder={"Enter the Reason for Dissolution"}
                        required={true}
                        value={
                          societyDetails.reasonForDissolution
                        }
                        onChange={societyDetailsChange}
                        name={"reasonForDissolution"}
                        type={"text"}
                      ></TableInputText>
                    </Col>

                    <Col lg={3} md={3} xs={3}>
                      <TableText label={"Date of Effect"} required={true} LeftSpace={false} />
                      <Form.Control
                        type="date"
                        placeholder="Enter Date"
                        name="effectDate"
                        required
                        onChange={societyDetailsChange}
                        value={societyDetails.effectDate}
                        className="durationTo"
                      />
                      {errors.newDate && (
                        <span style={{ color: "red" }} className={styles.columnText}>
                          {errors.newDate}
                        </span>
                      )}
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={12} md={12} xs={12} className=" d-flex mt-1 ">
                      <TableText
                        label="Whether the properties of the Society are settled as mentiond in the bye-Laws"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        required={true}
                        name="isByeLawsProperties"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isByeLawsProperties == "Yes"}
                      />

                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="isByeLawsProperties"
                        type="radio"
                        className="fom-checkbox mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isByeLawsProperties == "No"}

                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={8} md={12} xs={12} className=" d-flex ">
                      <TableText
                        // label="Has the general body agreed for dissolution"
                        label="Whether the general body meeting has been convinced or not?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        name="isDissolutionAgreed"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2 "
                        onChange={(e:any)=>{societyDetailsChange(e);setdisplay(true)}}
                        checked={societyDetails.isDissolutionAgreed == 'Yes'}
                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="isDissolutionAgreed"
                        type="radio"
                        className="fom-checkbox mb-2 "
                        onChange={(e:any)=>{societyDetailsChange(e);setdisplay(true)}}
                        checked={societyDetails.isDissolutionAgreed == 'No'}
                      />
                    </Col>
                  
                  </Row>
                  {display&&<Row><Col lg={3} md={3} xs={12} className="">
                      <TableText
                        label="General Body Meeting Date"
                        LeftSpace={true}
                        required={false}
                      />
                      <TableInputText
                        type="date"
                        placeholder="Enter Date"
                        name="generalBodyMeetingDate"
                        required
                        disabled={false}
                        onChange={societyDetailsChange}
                        value={societyDetails.generalBodyMeetingDate}
                      />
                    </Col></Row>}
                  <Row>
                    <Col lg={12} md={12} xs={12} className="d-flex ">
                      <TableText
                        label="Does the dissolution voted & approved by 2/3rd of the members present at the special meeting convened?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        name="isDissolutionApproved"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isDissolutionApproved == 'Yes'}
                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="isDissolutionApproved"
                        type="radio"
                        className="fom-checkbox mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isDissolutionApproved == 'No'}

                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={12} md={12} xs={12} className=" d-flex ">
                      <TableText
                        label="Are there any properties in the name of the Society?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        name="isSocietyProperties"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isSocietyProperties == "Yes"}

                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="isSocietyProperties"
                        type="radio"
                        className="fom-checkbox mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isSocietyProperties == "No"}

                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={12} md={12} xs={12} className=" d-flex ">
                      <TableText
                        label="Are there any claims & liabilities against the Society?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        name="isScoietyLiabilities"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isScoietyLiabilities == "Yes"}

                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="isScoietyLiabilities"
                        type="radio"
                        className="fom-checkbox mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isScoietyLiabilities == "No"}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={12} md={12} xs={12} className="d-flex ">
                      <TableText
                        label="Is the settlement/disposal of property made as mentioned in the Bye-Laws?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        name="isSettlementByeLaws"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2"
                        onChange={societyDetailsChange}
                        checked={societyDetails.isSettlementByeLaws == "Yes"}

                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="isSettlementByeLaws"
                        type="radio"
                        className="fom-checkbox mb-2"
                        onChange={societyDetailsChange}
                        checked={societyDetails.isSettlementByeLaws == "No"}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={12} md={12} xs={12} className="d-flex ">
                      <TableText
                        label="Whether the condition under section 25 Act has been compiled or not?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        name="underSection"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2"
                        onChange={societyDetailsChange}
                        checked={societyDetails.underSection == "Yes"}
                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="underSection"
                        type="radio"
                        className="fom-checkbox mb-2"
                        onChange={societyDetailsChange}
                        checked={societyDetails.underSection == "No"}

                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={3} md={3} xs={12} className="">
                      <TableText
                        label="Settlement/Disposal of Property"
                        LeftSpace={false}
                        required={true}
                      />
                      <div className="firmFile">
                        <Form.Control
                          type="file"
                          name="propertyDisposal"
                          ref={inputRef}
                          onChange={handleFileChange}
                          accept="application/pdf"
                        />
                        {/* {uploadErrorMessage && <p style={{ color: 'red' }}>{uploadErrorMessage}</p>} */}
                      </div>
                    </Col>
                    <Col lg={3} md={3} xs={12} className="mb-2">
                      <TableText
                        label="Details of the property disposed"
                        LeftSpace={false}
                        required={false}
                      />
                      <TableInputText
                        type="text"
                        placeholder="Enter Details of the property disposed"
                        name="disposedDetails"
                        required
                        disabled={false}
                        onChange={societyDetailsChange}
                        value={societyDetails.disposedDetails}
                      />
                    </Col>
                  </Row>
                </div>

              </div>
              <div className="text-center my-2">
                <button className="verify btn btn-primary">
                  Make Payment
                </button>
              </div>
              {/* </div> */}
            </Container>
          </Form>
        </div>
      </div>
    </div>
  )
}
export default DissolutionSociety
