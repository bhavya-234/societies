import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import React, { useEffect, useRef, useState } from "react"
import { Button, Col, Form, Modal, Row, Table } from "react-bootstrap"
import styles from "@/styles/components/Table.module.scss"
import { useAppDispatch } from "@/hooks/reduxHooks"
import Image from "next/image"
import { ISAnnualListApplicantDetails, ISAnnualListSocietyDetails } from "@/models/types"
import { UseGetAadharDetails, UseGetAadharOTP, getSocietyDetails } from "@/axios"
import CryptoJS, { AES } from "crypto-js"
import instance from "@/redux/api"
import { Loading, ShowMessagePopup } from "@/GenericFunctions"
import { PopupAction } from "@/redux/commonSlice"
import DynamicVillages from "./societies/dynamicCities"
import DynamicMandals from "./societies/dynamicMandals"
import router from "next/router"
import api from "@/redux/api"
import { get } from "lodash"
import moment from "moment"
interface DetailPropsAnnual {
  checkmemberlist?: any
}
const FillingListofMembers = ({ checkmemberlist }: DetailPropsAnnual) => {
  const dispatch = useAppDispatch()
  const [checklist, setChecklist] = useState<any>(checkmemberlist);
  const [token, setToken] = useState<string>("")
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  const [districtList, setDistricts] = useState<any>([])
  const [doctypelist] = useState<string[]>(["pdf"])
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [file, setFile] = useState<any>([])
  const [membersDetails, setMembersDetails] = useState<any>([])
  const [outgoingMembersDetails, setoutgoingMembersDetails] = useState<any>([])
  const [deleteindex, setDeleteIndex] = useState<any>(-1)
  const [deleteaadharNo, setDeleteaadharNo] = useState<any>(-1)
  const [errors, setErrors] = useState<any>({})
  const [isPayNowClicked, setIsPayNowClicked] = useState<boolean>(false)

  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false)

  const tableHeaders: string[] = [
    "Member Type",
    "Name of the Member",
    "Position",
    "Age / Gender",
    "Occupation",
    "Address",
    "Contact",
    "Action"
  ]
  const tableHeaders1: string[] = [
    "Member Type",
    "Name of the Member",
    "Position",
    "Age / Gender",
    "Occupation",
    "Address",
    "Contact",
    "Reason",
    "Action"
  ]
  const [TempMemory, setTempMemory] = useState<any>({ OTPRequested: false, AadharVerified: false })
  const [currentDistrict, setCurrentDistrict] = useState<string>("")
  const [AadharValidate, setAadharValidate] = useState<any>([])
  const [currentMandal, setCurrentMandal] = useState<string>("")
  const [applicantDetails, setapplicantDetails] = useState<ISAnnualListApplicantDetails>({
    aadharNumber: "",
    name: "",
    applicationNumber: "",
    relationName: "",
    role: "",
    doorNo: "",
    relationType: "",
    age: "",
    gender: "",
    street: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    phone: "",
    mobileNumber: "",
    maskedAadhar: "",
    email: "",
  })
  const [currentmemberDistrict, setCurrentmemberDistrict] = useState<any>([])
  const [currentmemberMandal, setCurrentmemberMandal] = useState<any>([])
  const [relationtypelist] = useState<any>(["S/O", "D/O", "W/O", "H/O"])
  const [typelist] = useState<any>(["Individual", "Coorporate"])
  const [roleList] = useState<any>([
    "President",
    "Vice President",
    "Secretary",
    "Joint Secretary",
    "Treasurer",
    "Member",
  ])
  const [societyDetails, setsocietyDetails] = useState<ISAnnualListSocietyDetails>({
    societyName: "",
    societytype: "",
    docType: "",
    docName: "",
    uploadedDoc: file,
    venue: "",
    dateOfAnnualMeeting: "",
  })
  const [displayOption, setDisplayOption] = useState<string>("display")
  const [docdisplay, setdocdisplay] = useState<boolean>(false)
  const [displayaadhar, setdisplayaadhar] = useState<boolean>(false)
  const refUpdate = useRef(null)
  const [FormErrors, setFormErrors] = useState<any>({})
  const handleMemberRemove = (index: number) => {
    const errors: any = {}
    if (SelectedMemberDetailsremove.reasonForOutgoing == "") {
      setShowVerification(true)

      errors["reasonForOutgoing"] = "*please select reason for outgoing."
      ShowMessagePopup(false, "please select reason for outgoing")
    } else if (TempMemorymemberremove.AadharVerified != true && SelectedMemberDetailsremove.reasonForOutgoing != "TERMINATED") {
      setShowVerification(true)
      errors["maskedAadhar"] = "*please validate aadhar."
      ShowMessagePopup(false, "please validate aadhar number")
    } else {
      setShowVerification(false)
      let data: any = [...membersDetails]
      let details: any = [...outgoingMembersDetails]
      details.push({ ...data[index], reasonForOutgoing: SelectedMemberDetailsremove.reasonForOutgoing })
      setIndexData(data[index])
      data.splice(index, 1)
      setMembersDetails(data)
      setoutgoingMembersDetails(details)
      setDeleteIndex(-1)

      setTempMemorymemberremove({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetailsremove({
        maskedAadhar: "",
        aadharNumber: "",
        termination: "",
        otpStatus: "",
        otpCode: "",
        otpVerified: "",
        reasonForOutgoing: "",
      })

    }
    setFormErrors({ ...errors })
    return errors
  }

  // const handleMemberRemoveoutgoing = (index: number) => {
  //   // 
  //   let data: any = [...membersDetails]
  //   let details: any = [...outgoingMembersDetails]
  //   data.push(details[index])
  //   details.splice(index, 1)
  //   setMembersDetails(data)
  //   setoutgoingMembersDetails(details)
  // }
  const districtmemberChange = (e: any) => {
    setCurrentmemberDistrict(e.target.value)
    setCurrentmemberMandal("")
  }
  const mandalmemberChange = (e: any) => {
    setCurrentmemberMandal(e.target.value)
  }
  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
        // throw Error("Invalid File");
        ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
        e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])){
      if(!regex){
      ShowMessagePopup(false, "Please upload proper file name");
      e.target.value = "";
    }
  }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }
  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  const [TempMemorymemberremove, setTempMemorymemberremove] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  const [TempMemoryterminate, setTempMemoryterminate] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  const [showVerification, setShowVerification] = useState(false);
  const handleClosePaymentModal = () => {
    setShowVerification(false)
  }
  const [TempMemorymember, setTempMemorymember] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  useEffect(() => {
    setsocietyDetails({ ...societyDetails, uploadedDoc: file })
  }, [file])
  const [reasonlist] = useState<any>(["RESIGNED", "TERMINATED", "DEATH"])

  const [SelectedMemberDetails, setSelectedMemberDetails] =
    useState<any>({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
  const [IndexData, setIndexData] = useState<any>({})
  const [SelectedMemberDetailsremove, setSelectedMemberDetailsremove] = useState<any>({
    maskedAadhar: "",
    noticeTime: "",
    aadharNumber: "",
    termination: "",
    firstNoticeDate: "",
    secondNoticeDate: "",
    thirdNoticeDate: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    reasonForOutgoing: "",
  })
  const applicantDetailsChange = (e: any) => {
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        e.target.value.length > 0 &&
        e.target.value.length > applicantDetails.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          applicantDetails.aadharNumber.substring(0, startpos) +
          applicantDetails.aadharNumber.substring(
            startpos + 1,
            applicantDetails.aadharNumber.length
          )
      }
      setapplicantDetails({
        ...applicantDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? applicantDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
      setapplicantDetails(newInput)
    }
  }
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const verifyOtp = async (index: number) => {
    if (AadharValidate[index].otpCode) {

      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(AadharValidate[index].aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: AadharValidate[index].otpCode,
      })
      Loading(false)
      if (result.status && result.status === "Success") {
        let data = [...AadharValidate]
        data[index]["otpVerified"] = "true"
        data[index]["memberName"] = result.userInfo.name
        // data[index]["fatherOrHusbandName"] = result.userInfo.co.split(":").pop().trim()
        data[index]["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        data[index]["age"] = ageCalculator(result.userInfo.dob)
        data[index]["country"] = result.userInfo.country
        data[index]["state"] = result.userInfo.state
        data[index]["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data[index]["street"] = result.userInfo.street
        data[index]["district"] = result.userInfo.dist.toUpperCase()
        data[index]["pinCode"] = result.userInfo.pc
        data[index]["relationName"] = result.userInfo.co
        setAadharValidate(data)
      } else {
        let data = [...AadharValidate]
        data[index]["otpVerified"] = "false"
        setAadharValidate(data)
        ShowMessagePopup(false, "Aadhaar API Failed")
      }
    }
  }


  const generateOtp = async (index: any) => {

    if (
      AadharValidate[index].aadharNumber &&
      AadharValidate[index].aadharNumber.length == 12 &&
      process.env.IGRS_SECRET_KEY
    ) {
      const ciphertext = AES.encrypt(
        AadharValidate[index].aadharNumber,
        process.env.IGRS_SECRET_KEY
      )
      let result = await UseGetAadharOTP(ciphertext.toString())

      if (result && result.status === "Success") {
        ShowMessagePopup(true, "OTP Sent Successfully")
        setSentOTP(true)
        setAadhaarOTPResponse(result)
        let data = [...AadharValidate]
        data[index]["otpStatus"] = "1"
        setAadharValidate(data)
      } else {
        ShowMessagePopup(false, get(result, "message", "Aadhaar API failed"))
        setAadhaarOTPResponse({})
        let data = [...AadharValidate]
        data[index]["otpStatus"] = "2"
        setAadharValidate(data)
      }
      // const newInput = () => ({ ...membersDetails, ["otpStatus"]: "1" })
      // membersDetails[index].otpCode = ""
      // setApplicantDetails(newInput)
    } else {
      ShowMessagePopup(false, "Kindly enter valid Aadhar number")
    }
  }
  const districtChange = (e: any) => {
    setCurrentDistrict(e.target.value)
    setCurrentMandal("")
  }
  const membersDetailsChange = (e: any) => {
    let tempDetails: any = { ...SelectedMemberDetails }
    let AddName = e.target.name
    let AddValue = e.target.value

    if (AddName == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        // SelectedMemberDetails.aadharNumber &&
        e.target.value.length > 0 &&
        e.target.value.length > SelectedMemberDetails?.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value && e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          SelectedMemberDetails?.aadharNumber?.substring(0, startpos) +
          SelectedMemberDetails?.aadharNumber?.substring(
            startpos + 1,
            SelectedMemberDetails?.aadharNumber?.length
          )
      }
      setSelectedMemberDetails({
        ...tempDetails,
        [AddName]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? SelectedMemberDetails?.aadharNumber + newNo : aadharNo,
      })
    } else {
      setSelectedMemberDetails({ ...tempDetails, [AddName]: AddValue })
    }
  }

  const terminaMemberChange = (e: any, index: any) => {
    let datanew = AadharValidate
    if (e.target.name == "maskedAadhar") {

      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (e.target.value.length > 0 && e.target.value.length > datanew[index]?.aadharNumber?.length) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }

      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          datanew[index].aadharNumber.substring(0, startpos) +
          datanew[index].aadharNumber.substring(startpos + 1, datanew[index].aadharNumber.length)
      }

      const det = {
        ...datanew[index],
        maskedAadhar: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? datanew[index].aadharNumber + newNo : aadharNo,
      }

      let aadhardata = [...AadharValidate]
      aadhardata[index] = det

      setAadharValidate(aadhardata)
    } else {
      const det = {
        ...datanew[index],
        [e.target.name]: e.target.value
      }

      let aadhardata = [...AadharValidate]
      aadhardata[index] = det

      setAadharValidate(aadhardata)
    }

  }


  const membersDetailsremove = (e: any) => {
    let tempDetails: any = { ...SelectedMemberDetailsremove }
    let AddName = e.target.name
    let AddValue = e.target.value

    if (AddName == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        // SelectedMemberDetails.aadharNumber &&
        e.target.value.length > 0 &&
        e.target.value.length > SelectedMemberDetailsremove?.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value && e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          SelectedMemberDetailsremove?.aadharNumber?.substring(0, startpos) +
          SelectedMemberDetailsremove?.aadharNumber?.substring(
            startpos + 1,
            SelectedMemberDetailsremove?.aadharNumber?.length
          )
      }
      setSelectedMemberDetailsremove({
        ...tempDetails,
        [AddName]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? SelectedMemberDetailsremove?.aadharNumber + newNo : aadharNo,
      })
      // let datanew:any={...SelectedMemberDetailsremove}
      // const det = {
      //   ...datanew[IndexData],
      //   maskedAadhar: newVal,
      //   firstNoticeDate:datanew[IndexData].firstNoticeDate ,
      //   secondNoticeDate:datanew[IndexData].secondNoticeDate ,
      //   thirdNoticeDate:datanew[IndexData].thirdNoticeDate ,
      //   termination:datanew[IndexData].termination,
      //   noticeTime:datanew[IndexData].noticetime,
      //   aadharNumber:
      //     newNo == "del" ? "" : newNo != "" ? datanew[IndexData].aadharNumber + newNo : aadharNo,
      // }
      // 
      // let aadhardata = [...outgoingMembersDetails]
      // aadhardata[index] = det
      // setoutgoingMembersDetails(aadhardata)

    } else {
      setSelectedMemberDetailsremove({ ...tempDetails, [AddName]: AddValue })
    }
  }
  const mandalChange = (e: any) => {
    setCurrentMandal(e.target.value)
  }

  const societyDetailsChange = (e: any) => {
    setsocietyDetails({ ...societyDetails, [e.target.name]: e.target.value })
    console.log("society deatils", societyDetails)
  }
  const [byelawDetails, setbyelawDetails] = useState<any>("")
  const validateInputs = () => {
    let applicant: ISAnnualListApplicantDetails = { ...applicantDetails }
    let society: ISAnnualListSocietyDetails = { ...societyDetails }
    const errors: any = {}

    if (TempMemory.AadharVerified != true) {
      return ShowMessagePopup(false, "Plaese verify aadhar number")
    }
    if (!applicant.aadharNumber) {
      errors.aadharNumber = "Please validate aadhar number"
      return ShowMessagePopup(false, "Please validate aadhar number")
    }
    if (membersDetails?.length < 3) {
      return ShowMessagePopup(false, "Minimum 3 EC members should me there in the society")
    }
    if (!societyDetails.dateOfAnnualMeeting) {
      return ShowMessagePopup(false, "Please select Date of Annual Meeting")
    }
    if (!societyDetails.venue) {
      return ShowMessagePopup(false, "Please enter the Venue/Place")
    }
    if (SelectedMemberDetailsremove.reasonForOutgoing == "TERMINATED") {
      if (SelectedMemberDetailsremove.termination == "No") {
        return ShowMessagePopup(false, "Please select validate option for termination")
      }
      if (SelectedMemberDetailsremove.termination == "Yes") {
        AadharValidate.map((form, index) => {
          if (AadharValidate?.length > 0 && AadharValidate.some((x: any) => x.aadharNumber?.toString() == form.aadharNumber?.toString())
          ) {
            return ShowMessagePopup(false, `Aadhar is already existing please enter new aadhar number ${index}`)
          }
          // if (parseInt(AadharValidate.length) != parseInt(byelawDetails.quorumSize)) {
          //   return ShowMessagePopup(false, "Please validate all Aadhar numbers")
          // }
        })
      }
    }
    setErrors({ ...errors })
    console.log("errors obj", errors)
    return errors
  }
  const ageCalculator = (dateOfBirth: any) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    //calculate month difference from current date in time
    let month_diff = Date.now() - dob.getTime()

    //convert the calculated difference in date format
    let age_dt = new Date(month_diff)

    //extract year from date
    let year = age_dt.getUTCFullYear()

    //now calculate the age of the user
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }

  const handleMemberRemoveoutgoing = (index: number) => {
    let data: any = [...membersDetails]
    let details: any = [...outgoingMembersDetails]
    let removedmember = { ...details[index], reasonForOutgoing: "" }
    data.push(removedmember)
    details.splice(index, 1)
    setMembersDetails(data)
    setoutgoingMembersDetails(details)
  }

  const ReqDetails = async (MyKey: any) => {
    let result = await CallingAxios(
      UseGetAadharDetails({
        aadharNumber: btoa(MyKey.aadharNumber),
        transactionNumber: MyKey?.OTPResponse?.transactionNumber,
        otp: MyKey.otpCode,
      })
    )
    if (
      result.status &&
      result.status === "Success" &&
      MyKey?.OTPResponse?.transactionNumber == result.transactionNumber.split(":")[1]
    ) {
      let latestData: any = {
        ...MyKey,
        name: result.userInfo.name ? result.userInfo.name : "",
        memberName: result.userInfo.name ? result.userInfo.name : "",
        relationType: result.userInfo.co ? result.userInfo.co.substring(0, 3) : "",
        relationName: result.userInfo.co ? result.userInfo.co.substring(4) : "",
        age: result.userInfo.dob ? ageCalculator(result.userInfo.dob) : "",
        gender: result.userInfo.gender == "M" ? "Male" : "Female",
        district: result.userInfo.dist ? result.userInfo.dist : "",
        pinCode: result.userInfo.pc ? result.userInfo.pc : "",
        street: result.userInfo.loc ? result.userInfo.street : "",
        villageOrCity: result.userInfo.vtc ? result.userInfo.vtc : "",
        doorNo: result.userInfo.house ? result.userInfo.house : "",
        address:
          (result.userInfo.lm ? result.userInfo.lm + ", \n" : "") +
          (result.userInfo.loc ? result.userInfo.loc + ", \n" : "") +
          (result.userInfo.dist ? result.userInfo.dist + ", \n" : "") +
          (result.userInfo.vtc ? result.userInfo.vtc : "") +
          (result.userInfo.pc ? "-" + result.userInfo.pc : ""),
        OTPResponse: result,
      }

      switch (MyKey) {
        case applicantDetails:
          setapplicantDetails(latestData)
          setTempMemory({ OTPRequested: false, AadharVerified: true })
          break
        case SelectedMemberDetails:
          setSelectedMemberDetails(latestData)
          setTempMemorymember({ OTPRequested: false, AadharVerified: true })
          break
        case SelectedMemberDetailsremove:
          setSelectedMemberDetailsremove(latestData)
          setTempMemorymemberremove({ OTPRequested: false, AadharVerified: true })
          break
        case AadharValidate:
          setAadharValidate(latestData)
          setTempMemoryterminate({ OTPRequested: false, AadharVerified: true })
          break
        default:
          break
      }
    } else {
      ShowMessagePopup(false, "Please Enter Valid OTP", "")
    }
  }

  const ReqOTP = (MyKey: any) => {
    if (MyKey.aadharNumber && MyKey.aadharNumber.length == 12) {
      CallGetOTP(MyKey)
    } else {
      ShowMessagePopup(false, "Kindly enter valid Aadhar number", "")
    }
  }
  const CallingAxios = async (myFunction: any) => {
    Loading(true)
    let result = await myFunction
    Loading(false)
    return result
  }

  const CallGetOTP = async (MyKey: any) => {
    if (process.env.IGRS_SECRET_KEY) {
      // 
      const ciphertext = AES.encrypt(MyKey.aadharNumber, process.env.IGRS_SECRET_KEY)
      let result = await CallingAxios(UseGetAadharOTP(ciphertext.toString()))
      // 
      if (result && result.status != "Failure") {
        switch (MyKey) {
          case applicantDetails:
            setTempMemory({ OTPRequested: true, AadharVerified: false })
            break
          case SelectedMemberDetails:
            setTempMemorymember({ OTPRequested: true, AadharVerified: false })
            break
          case SelectedMemberDetailsremove:
            setTempMemorymemberremove({ OTPRequested: true, AadharVerified: false })
            break
          case AadharValidate:
            setTempMemoryterminate({ OTPRequested: true, AadharVerified: false })
            break
          default:
            break
        }
        switch (MyKey) {
          case applicantDetails:
            setapplicantDetails({ ...MyKey, OTPResponse: result })
            break
          case SelectedMemberDetails:
            setSelectedMemberDetails({ ...MyKey, OTPResponse: result })
            break
          case SelectedMemberDetailsremove:
            setSelectedMemberDetailsremove({ ...MyKey, OTPResponse: result })
            break
          case AadharValidate:
            setAadharValidate({ ...MyKey, OTPResponse: result })
            break
          default:
            break
        }
        ShowMessagePopup(
          true,
          "OTP Sent to Aadhaar Registered Mobile Number.",
          ""
        )
      }
    } else {
      switch (MyKey) {
        case applicantDetails:
          setapplicantDetails({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemory({ OTPRequested: false, AadharVerified: false })
          break
        case SelectedMemberDetails:
          setSelectedMemberDetails({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemorymember({ OTPRequested: false, AadharVerified: false })
          break
        case AadharValidate:
          setAadharValidate({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemoryterminate({ OTPRequested: false, AadharVerified: false })
          break
        case SelectedMemberDetailsremove:
          setSelectedMemberDetailsremove({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemorymemberremove({ OTPRequested: false, AadharVerified: false })
          break
        default:
          break
      }
      ShowMessagePopup(false, "Please Enter Valid Aadhar", "")
    }
  }
  React.useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data) {
      setToken(data.token)
      setLoggedInAadhar(data.aadharNumber)
      setapplicantDetails({
        ...applicantDetails,
        applicationNumber: data.applicationNumber,
      })
      instance
        .get("/getDistricts")
        .then((response) => {
          setDistricts(response.data)
          getSocietyDetails(data.applicationId, data.token)
            .then((response) => {
              if (response?.success) {
                setExistingSocietyDetail(response.data.daSociety)
                if (
                  response.data.daSociety?.memberDetails &&
                  response.data.daSociety?.memberDetails?.length > 0
                ) {
                  response.data.daSociety.memberDetails.forEach(
                    (a: any) =>
                      (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber?.toString().substring(8, 12))
                  )
                  setMembersDetails([...response.data.daSociety.memberDetails])
                }
                setsocietyDetails({
                  societyName: "",
                  societytype: "",
                  docType: "",
                  docName: "",
                  uploadedDoc: file,
                  venue: "",
                  dateOfAnnualMeeting: "",
                })
                if (response.data.daSociety.byeLaws) {

                  let quorumCount = 0
                  response.data.daSociety.memberDetails.forEach((x: any) => {
                    if (x.status == "Active") {
                      quorumCount++
                    }
                  })
                  setbyelawDetails({
                    ...byelawDetails,
                    quorumSize: Math.round((quorumCount / 2) + 1),
                  })
                  let data: any = [];
                  for (let i = 0; i < Math.round((quorumCount / 2) + 1); i++) {

                    data.push({
                      aadharNumber: "",
                      maskedAadhar: "",
                      otpStatus: "",
                      otpCode: "",
                      otpVerified: "",

                    },)
                  }
                  setAadharValidate(data)
                }
              }
            })
            .catch(() => {
              Loading(false)
            })
          Loading(false)
        })
        .catch(() => {
          Loading(false)
        })
    }
  }, [])
  // const submitHandler = () => {
  //   if (Object.keys(validateInputs()).length == 0) {
  //     console.log("final details", applicantDetails)
  //   } else {
  //     //  ShowAlert(false, "please fill all the details")
  //   }
  // }
  const file2Base64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      if (reader && reader != null && file) {
        reader?.readAsDataURL(file)
        reader.onload = () => resolve(reader.result?.toString() || "")
        reader.onerror = (error) => reject(error)
      }
      else {
        resolve("")
      }
    })
  }
  const handleMemberAdd = () => {

    let object: any = { ...SelectedMemberDetails }
    if (
      object.aadharNumber == "" ||
      object.relationType == "" ||
      object.gender == "" ||
      object.age == "" ||
      object.doorNo == "" ||
      object.district == "" ||
      object.mandal == "" ||
      object.villageOrCity == "" ||
      object.pinCode == "" ||
      object.relationName == "" ||
      object.mobileNumber == "" ||
      object.joiningDate == "" ||
      object.role == "" ||
      object.qualification == "" ||
      object.memberType == "" ||

      object.occupation == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for New member", "")
    } else if (object.soundMind !== "Yes") {
      return ShowMessagePopup(false, "Please select validate option for soundMind", "")
    } else if (object.inSolvent !== "No") {
      return ShowMessagePopup(false, "Please select validate option for insolvent", "")
    } else if (!object.memberType) {
      return ShowMessagePopup(false, "Please select member type", "")
    }
    else if (object.offense !== "No") {
      return ShowMessagePopup(false, "Please select validate option for offense", "")
    } else if (object.appointment !== "No") {
      return ShowMessagePopup(false, "Please select validate option for appointment", "")
    } else if (!object.mandal) {
      return ShowMessagePopup(false, "Please select mandal", "")
    } else if (!object.villageOrCity) {
      return ShowMessagePopup(false, "Please select village or city", "")
    } else if (
      object.mobileNumber &&
      (object.mobileNumber.length != 10 ||
        (object.mobileNumber.length == 10 &&
          object.mobileNumber.charAt(0) != "6" &&
          object.mobileNumber.charAt(0) != "7" &&
          object.mobileNumber.charAt(0) != "8" &&
          object.mobileNumber.charAt(0) != "9"))
    ) {
      return ShowMessagePopup(false, "Please enter vaild mobile number", "")
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some((x: any) => x.aadharNumber?.toString() == object.aadharNumber?.toString() && x.status == "Active")
    ) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }

      )
      return ShowMessagePopup(
        false,
        "Aadhaar number is already exist. Please enter new aadhaar number",
        ""
      )
    } else if (parseInt(object.age) < 18) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }
      )
      return ShowMessagePopup(false, "Minimum age of partner should be 18", "")
    } else if (parseInt(object.share) < 0 || parseInt(object.share) >= 100) {
      return ShowMessagePopup(false, "share should be above 0 and less than 100 percent", "")
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some((x: any) => parseInt(x.mobileNumber) == parseInt(object.mobileNumber))
    ) {
      return ShowMessagePopup(
        false,
        "Mobile number is already exist. Please enter new mobile number",
        ""
      )
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some(
        (x: any) =>
          x.email != "" &&
          x.email?.length > 0 &&
          x.email.trim() != "" &&
          object.email != "" &&
          object.email.length > 0 &&
          object.email.trim() != "" &&
          x.email.toLowerCase() == object.email.toLowerCase()
      )
    ) {
      return ShowMessagePopup(false, "email is already exist. Please enter new email", "")
    }
    let Details: any[] = [...membersDetails]
    Details.push(object)
    setMembersDetails(Details)
    setTempMemorymember({ OTPRequested: false, AadharVerified: false })
    setSelectedMemberDetails({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, "New Member Added Successfully", "")
  }
  const submitHandler = async (e: any) => {
    e.preventDefault()
    if (validateInputs()) {
      const data = {
        applicantDetails: applicantDetails,
        outgoingMembersDetails: outgoingMembersDetails,
        societyDetails: societyDetails,
        membersDetails: [...membersDetails.filter((x: any) => x.memberName.trim())],

      }
      const newData = new FormData()
      newData.append("id", existingSocietyDetail._id)
      newData.append("applicantDetails[aadharNumber]", btoa(data.applicantDetails.aadharNumber))
      newData.append("applicantDetails[applicationNumber]", existingSocietyDetail.applicationNumber)
      newData.append("applicantDetails[name]", existingSocietyDetail.applicantDetails.name)
      newData.append("applicantDetails[doorNo]", existingSocietyDetail.applicantDetails.doorNo)
      newData.append("applicantDetails[street]", existingSocietyDetail.applicantDetails.street)
      newData.append("applicantDetails[age]", existingSocietyDetail.applicantDetails.age)
      newData.append("applicantDetails[gender]", existingSocietyDetail.applicantDetails.gender)
      newData.append("applicantDetails[country]", "India")
      newData.append("applicantDetails[state]", "Andhra Pradesh")
      newData.append("applicantDetails[district]", existingSocietyDetail.applicantDetails.district)
      newData.append("applicantDetails[mandal]", existingSocietyDetail.applicantDetails.mandal)
      newData.append("applicantDetails[villageOrCity]", existingSocietyDetail.applicantDetails.villageOrCity)
      newData.append("applicantDetails[pinCode]", existingSocietyDetail.applicantDetails.pinCode)
      newData.append("applicantDetails[mobileNumber]", existingSocietyDetail.applicantDetails.mobileNumber)
      newData.append("applicantDetails[relationType]", existingSocietyDetail.applicantDetails.relationType)
      newData.append("applicantDetails[relationName]", existingSocietyDetail.applicantDetails.relationName)
      newData.append("venue", data.societyDetails.venue)
      newData.append("dateOfAnnualMeeting", data.societyDetails.dateOfAnnualMeeting)
     let memberdata = [...membersDetails, ...outgoingMembersDetails]
      for (let j = 0; j < memberdata.length; j++) {
        newData.append("memberDetails[" + j + "][email]", memberdata[j].email)
        newData.append("memberDetails[" + j + "][mobileNumber]", memberdata[j].mobileNumber)
        newData.append("memberDetails[" + j + "][qualification]", memberdata[j].qualification)
        newData.append("memberDetails[" + j + "][joiningDate]", memberdata[j].joiningDate)
        newData.append("memberDetails[" + j + "][memberType]", memberdata[j].memberType)
        newData.append("memberDetails[" + j + "][aadharNumber]", btoa(memberdata[j].aadharNumber))
        newData.append("memberDetails[" + j + "][memberName]", memberdata[j].memberName)
        newData.append("memberDetails[" + j + "][relationName]", memberdata[j].relationName)
        newData.append("memberDetails[" + j + "][relationType]", memberdata[j].relationType)
        newData.append("memberDetails[" + j + "][occupation]", memberdata[j].occupation)
        newData.append("memberDetails[" + j + "][age]", memberdata[j].age)
        newData.append("memberDetails[" + j + "][gender]", memberdata[j].gender)
        newData.append("memberDetails[" + j + "][role]", memberdata[j].role)
        newData.append("memberDetails[" + j + "][doorNo]", memberdata[j].doorNo)
        newData.append("memberDetails[" + j + "][street]", memberdata[j].street)
        newData.append("memberDetails[" + j + "][country]", "India")
        newData.append("memberDetails[" + j + "][state]", "Andhra Pradesh")
        newData.append("memberDetails[" + j + "][district]", memberdata[j].district)
        newData.append("memberDetails[" + j + "][mandal]", memberdata[j].mandal)
        newData.append("memberDetails[" + j + "][villageOrCity]", memberdata[j].villageOrCity)
        newData.append("memberDetails[" + j + "][pinCode]", memberdata[j].pinCode)

        if (memberdata[j].reasonForOutgoing != "" && memberdata[j].reasonForOutgoing != undefined) {
          newData.append("memberDetails[" + j + "][reasonForOutgoing]", memberdata[j].reasonForOutgoing)
          if (memberdata[j].reasonForOutgoing == "TERMINATED") {
            newData.append("memberDetails[" + j + "][noticeTime]", memberdata[j].noticeTime)

            newData.append("memberDetails[" + j + "][termination]", memberdata[j].termination)
            newData.append("memberDetails[" + j + "][firstNoticeDate]", memberdata[j].firstNoticeDate)
            newData.append("memberDetails[" + j + "][secondNoticeDate]", memberdata[j].secondNoticeDate)
            newData.append("memberDetails[" + j + "][thirdNoticeDate]", memberdata[j].thirdNoticeDate)
          }
          newData.append("memberDetails[" + j + "][status]", "InActive")
        } else {
          newData.append("memberDetails[" + j + "][status]", "Active")
        }
      }
      Object.keys(file).forEach(async (value: any, key: any) => {
        newData.append(key, value)
      })
      newData.append("country", "India")
      newData.append("state", "Andhra Pradesh")
      if (checklist &&
        checklist.length > 0 &&
        checklist.some((x: string) => x == "Filing of list of members")) {
        newData.append("isFiling", "true")
      } else {
        newData.append("isFiling", "false")
      }
      let object: any = {}
      let keys = Object.keys(file)
      let values: any = Object.values(file)
      newData.forEach((value, key) => (object[key] = value))
      let i = 0

      for await (let item of values) {
        object[keys[i]] = await file2Base64(item)
        i++

      }
      // values.forEach(async (item: any, i: any) => {
      //   
      //   object[keys[i]] = await file2Base64(item)
      // })
      // Object.keys(file).forEach(async (value: any, key: any) => {
      //   
      //   object[value] = await file2Base64(file.value)
      // })

      console.log("keys", Object.keys(file))
      // object.byeLaws = await file2Base64(file?.byeLaws)
      // object.declaration = await file2Base64(file?.declaration)
      // object.supportingDoc = await file2Base64(file?.supportingDoc)
      // object.selfSignedDeclaration = await file2Base64(file?.selfSignedDeclaration)
      localStorage.setItem("AmendmentData", JSON.stringify(object))

      let code = 0
      const dis = districtList?.find((x: any) => x.name == existingSocietyDetail.district)
      if (dis) {
        code = dis.code
      }
      let count = checklist.length
      const paymentsData = {
        type: "sra",
        source: "Society",
        deptId: existingSocietyDetail.applicationNumber,
        rmName: existingSocietyDetail.applicantDetails.name,
        rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
        mobile: existingSocietyDetail.applicantDetails.mobileNumber,
        email: existingSocietyDetail.applicantDetails.email,
        drNumber: code,
        rf: 300,
        uc: 0,
        oc: 0,
        returnURL: process.env.BACKEND_URL + "/societies/redirectPayment",
      }
      let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
      // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
      const encodedData = CryptoJS.AES.encrypt(
        JSON.stringify(paymentsData),
        'igrsSecretPhrase'
      ).toString()
      let paymentLink = document.createElement("a")
      paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
      //paymentLink.target = "_blank";
      paymentLink.click()
      setIsPayNowClicked(false)
      setTimeout(function () {
        paymentLink.remove()
      }, 1000)
    }
    const ShowAlert = (type: any, message: any) => {
      dispatch(PopupAction({ enable: true, type: type, message: message,redirectOnSuccess:"/login" }))
    }
  }
  // const ShowAlert = (type: any, message: any) => {
  //     dispatch(PopupAction({ enable: true, type: type, message: message }))
  // }
  return (
    <div>
      <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={submitHandler} autoComplete="off">
        <div className="societyRegSec mx-3">
          <div className="formsec">
            <div className="page-title">
              <h1>Filling of Annual List(Section 9)</h1>
            </div>
            <div className="regofAppBg my-1">
              <div className="formSectionTitle">
                <h3>Applicant Details</h3>
              </div>
              <Row>
                <Col lg={3} md={3} xs={12} >
                  {!TempMemory.OTPRequested ? (
                    <Form.Group>
                      <TableText
                        label="Enter Aadhaar Number"
                        required={true}
                        LeftSpace={false}
                      />
                      <div className="formGroup">
                        <select style={{ textTransform: 'uppercase' }}
                          className="form-control"
                          name="aadharNumber"
                          onChange={(e: any) => {
                            if (!TempMemory.AadharVerified) {
                              applicantDetailsChange(e)
                            }
                          }}
                          disabled={TempMemory.AadharVerified}
                          required={true}
                          value={applicantDetails.aadharNumber}
                        >
                          <option>Select</option>
                          {membersDetails.map((item: any, i: any) => {
                            return (
                              <>{
                                item.status != "InActive" ?
                                  <option key={i + 1} value={item.aadharNumber}>
                                    {item.aadharNumber}
                                  </option> : null}</>
                            )
                          })}
                        </select>
                        {!TempMemory.AadharVerified ? (
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                              borderRadius: "2px",
                            }}
                            onClick={() => ReqOTP(applicantDetails)}
                            className="verify btn btn-primary"
                          >
                            Get OTP
                          </div>
                        ) : null}
                      </div>
                    </Form.Group>
                  ) : (
                    <Form.Group>
                      <TableText label="Enter OTP" required={true} LeftSpace={false} />
                      <div className="formGroup">
                        <TableInputText
                          disabled={false}
                          type="number"
                          placeholder="Enter OTP Received"
                          maxLength={6}
                          required={true}
                          name={"otpCode"}
                          value={applicantDetails.otpCode}
                          onChange={applicantDetailsChange}
                        />
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            borderRadius: "2px",
                          }}
                          onClick={() => {
                            ReqDetails(applicantDetails)
                          }}
                          className="verify btn btn-primary"
                        >
                          Verify
                        </div>
                        <div style={{ display: "flex", justifyContent: "flex-end" }}>
                          <div
                            style={{
                              cursor: "pointer",
                              marginRight: "20px",
                              color: "blue",
                              fontSize: "10px",
                            }}
                            onClick={() => {
                              setTempMemory({ ...TempMemory, OTPRequested: false })
                            }}
                          >
                            clear
                          </div>
                        </div>
                      </div>
                    </Form.Group>
                  )}
                </Col>
              </Row>
            </div>

            <div className="formSectionTitle">
              <h3>
                Request Type <span style={{ color: "red" }}>*</span>
              </h3>
            </div>
            <div >
              <Form.Check
                inline
                label="Filling of Annual List"
                value="FillingofAnnualList"
                name="isFiling"
                type="checkbox"
                className="fom-checkbox"
                disabled
                onChange={()=>{}}
                checked={true}
              />
              {/* {errors.requestType && <span  style ={{color:"red"}} className={styles.columnText}>{errors.requestType}</span>} */}
            </div>
            <div className="regofAppBg my-1">
              <div className="formSectionTitle">
                <h3>Details of Annual Meeting</h3>
              </div>
              <Row>
                <Col lg={3} md={12} sm={12} >
                  <TableText label={"Date of Annual Meeting "} required={false} LeftSpace={false} />
                  <Form.Control
                    type="date"
                    placeholder="Enter Date of Annual Meeting"
                    name="dateOfAnnualMeeting"
                    onChange={societyDetailsChange}
                    value={societyDetails.dateOfAnnualMeeting}
                    className="durationTo"
                  />
                  {errors.newdate && (
                    <span style={{ color: "red" }} className={styles.columnText}>
                      {errors.newdate}
                    </span>
                  )}
                </Col>
                <Col lg={3} md={12} sm={12} >
                  <TableText label={"Venue/Place "} required={false} LeftSpace={false} />
                  <TableInputText
                    type="text"
                    placeholder="Enter Venue/Place"
                    required={true}
                    name="venue"
                    value={societyDetails.venue}
                    onChange={societyDetailsChange}
                  />

                </Col>
                {/* <Col lg={3} md={4} xs={12} className="mb-3">
                  <TableText
                    label=" Size of the Quorum"
                    required={false}
                    LeftSpace={false}
                  />
                  <TableInputText
                    disabled={true}
                    type="text"
                    placeholder="Enter Quorum Size"
                    required={false}
                    name="quorumSize"
                    value={byelawDetails.quorumSize}
                    onChange={() => { }}
                  />
                </Col> */}
              </Row>
            </div>
            <div className="regofAppBg my-1">
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="formSectionTitle my-1">
                    <h3>Incoming /Existing Member List</h3>
                  </div>
                </Col>
              </Row>
              <Table striped bordered className="tableData" style={{ width: "100%" }}>
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>Aadhaar No</th>
                    <th>Name of the member</th>
                    <th>Relation Name</th>
                    <th>Age/Gender</th>
                    <th>Role/Position</th>
                    <th>Occupation</th>
                    <th>Date of Joining</th>
                    <th>Address</th>
                    <th>Contact</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {membersDetails?.length > 0 && membersDetails.map((item: any, i: number) => {
                    return (
                      <>{
                        item.status != "InActive" ?
                          <tr>
                            <td
                              className="text-wrap-table" title={item.memberType}
                            >
                              {item.memberType}
                            </td>

                            <td className="text-wrap-table" title={item.maskedAadhar} >

                              {item.maskedAadhar = "XXXXXXXX" + item.aadharNumber?.toString().substring(8, 12)}

                            </td>
                            {/* <td>{item.memberType}</td> */}

                            <td className="text-wrap-table" title={item.memberName}>{item.memberName}</td>
                            <td className="text-wrap-table" title={item.relationName}>{item.relationName}</td>
                            <td className="text-wrap-table" title={`${item.age}/${item.gender}`}>{item.age} / {item.gender}</td>
                            <td className="text-wrap-table" title={item.role}>{item.role}</td>
                            <td className="text-wrap-table" title={item.occupation}>{item.occupation}</td>
                            <td className="text-wrap-table" title={item.joiningDate}>{item.joiningDate}</td>
                            <td className="text-wrap-table" title={`${item.doorNo},${item.street},${item.district},${item.mandal},${item.villageOrCity},${item.pinCode}`}
                            >
                              {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                            </td>
                            <td
                              className="text-wrap-table"
                              title={item.mobileNumber}
                            >
                              {item.mobileNumber}
                            </td>
                            <td>
                              <Image
                                alt="Image"
                                height={20}
                                width={20}
                                src="/assets/delete-icon.svg"
                                style={{ cursor: "pointer" }}
                                onClick={() => {
                                  setShowVerification(true)
                                  setDeleteIndex(i)
                                  setSelectedMemberDetailsremove({ ...SelectedMemberDetails, maskedAadhar: item.maskedAadhar, aadharNumber: item.aadharNumber })

                                  // handleMemberRemove(i)
                                }}
                              />
                            </td>
                          </tr> : null
                      }</>
                    )
                  })}
                </tbody>
              </Table>
              <Modal show={showVerification} onHide={handleClosePaymentModal} style={{ paddingTop: "10%" }}>
                <Modal.Header closeButton>
                  <Modal.Title>
                    Aadhar verification and Reason
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <div className="societyRegSec">
                    <Form className={`formsec ${styles.RegistrationInput}`} autoComplete="off">
                      <div className="regofAppBg mx-4">
                        <Row>
                          <Col lg={8} md={4} xs={12} className="mb-3 mx-5">
                            <TableText label="Reason for Outgoing" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="reasonForOutgoing"
                              required={true}
                              onChange={membersDetailsremove}
                              value={SelectedMemberDetailsremove.reasonForOutgoing}
                            >
                              <option>Select</option>
                              {reasonlist.map((item: any, i: number) => {
                                return (
                                  <option key={i + 1} value={item}>
                                    {item}
                                  </option>
                                )
                              })}
                            </select>
                            <text className={styles.warningText} style={{ color: "red", fontSize: "12px" }}>
                              {FormErrors.reasonForOutgoing}
                            </text>
                          </Col>
                          {SelectedMemberDetailsremove.reasonForOutgoing == "TERMINATED" ? null : <Col lg={8} md={3} xs={12} className="mb-3 mx-5">
                            {!TempMemorymemberremove.OTPRequested ? (
                              <Form.Group>
                                <TableText
                                  label="Enter Aadhaar Number"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <div className="formGroup">
                                  <TableInputText
                                    disabled={TempMemorymemberremove.AadharVerified}
                                    type="text"
                                    maxLength={12}
                                    placeholder="Enter Aadhaar Number"
                                    required={false}
                                    dot={false}
                                    name={"maskedAadhar"}
                                    value={SelectedMemberDetailsremove.maskedAadhar}
                                    onChange={() => {

                                    }}
                                    onKeyPress={true}
                                    onPaste={(e: any) => e.preventDefault()}
                                  />
                                  {!TempMemorymemberremove.AadharVerified ? (
                                    //  <Col lg={3} md={3} xs={12} className="mb-3">
                                    <div
                                      style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        borderRadius: "2px",
                                      }}
                                      onClick={() => ReqOTP(SelectedMemberDetailsremove)}
                                      className="verify btn btn-primary"
                                    >
                                      Get OTP
                                    </div>
                                  ) : null}
                                </div>
                              </Form.Group>
                            ) : (
                              <Form.Group>
                                <TableText
                                  label="Enter OTP"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <div className="formGroup">
                                  <TableInputText
                                    disabled={false}
                                    type="number"
                                    placeholder="Enter OTP Received"
                                    maxLength={6}
                                    required={false}
                                    name={"otpCode"}
                                    value={SelectedMemberDetailsremove.otpCode}
                                    onChange={membersDetailsremove}
                                  />
                                  <div
                                    style={{
                                      display: "flex",
                                      justifyContent: "center",
                                      alignItems: "center",
                                      borderRadius: "2px",
                                    }}
                                    onClick={() => {
                                      ReqDetails(SelectedMemberDetailsremove)
                                    }}
                                    className="verify btn btn-primary"
                                  >
                                    Verify
                                  </div>
                                  <div
                                    style={{ display: "flex", justifyContent: "flex-end" }}
                                  >
                                    <div
                                      style={{
                                        cursor: "pointer",
                                        marginRight: "20px",
                                        color: "blue",
                                        fontSize: "10px",
                                      }}
                                      onClick={() => {
                                        setTempMemorymemberremove({
                                          ...TempMemorymemberremove,
                                          OTPRequested: false,
                                        })
                                      }}
                                    >
                                      clear
                                    </div>
                                  </div>
                                </div>
                              </Form.Group>
                            )}
                            <text className={styles.warningText} style={{ color: "red", fontSize: "12px" }}>
                              {FormErrors.maskedAadhar}
                            </text>
                          </Col>
                          }

                        </Row>
                      </div></Form></div>
                </Modal.Body>
                <Modal.Footer style={{ justifyContent: "center" }}>
                  <div style={{ alignItems: "center" }}>
                    <Button variant="primary" onClick={() => { handleMemberRemove(deleteindex) }}>
                      submit
                    </Button>
                  </div>
                </Modal.Footer>
              </Modal>
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="formSectionTitle my-1">
                    <h3>Outgoing EC Member List</h3>
                  </div>
                </Col>
              </Row>

              <Table striped bordered className="tableData listData">
                <thead>
                  <tr>
                    <th>Type</th>
                    <th>Aadhaar No</th>
                    <th>Name of the member</th>
                    <th>Relation Name</th>
                    <th>Age/Gender</th>
                    <th>Role/Position</th>
                    <th>Occupation</th>
                    <th>Date of Joining</th>
                    <th>Address</th>
                    <th>Contact</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {outgoingMembersDetails?.length > 0 && outgoingMembersDetails?.map((item: any, i: number) => {
                    return (
                      <tr>
                        <td
                          className="text-wrap-table" title={item.memberType}
                        >
                          {item.memberType}
                        </td>

                        <td className="text-wrap-table" title={item.maskedAadhar} >

                          {item.maskedAadhar}
                        </td>
                        {/* <td>{item.memberType}</td> */}
                        <td className="text-wrap-table" title={item.memberName}>{item.memberName}</td>
                        <td className="text-wrap-table" title={item.relationName}>{item.relationName}</td>
                        <td className="text-wrap-table" title={`${item.age}/${item.gender}`}>{item.age} / {item.gender}</td>
                        <td className="text-wrap-table" title={item.role}>{item.role}</td>
                        <td className="text-wrap-table" title={item.occupation}>{item.occupation}</td>
                        <td className="text-wrap-table" title={item.joiningDate}>{item.joiningDate}</td>
                        <td className="text-wrap-table" title={`${item.doorNo},${item.street},${item.district},${item.mandal},${item.villageOrCity},${item.pinCode}`}
                        >
                          {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                        </td>
                        <td
                          className="text-wrap-table"
                          title={item.mobileNumber}
                        >
                          {item.mobileNumber}
                        </td>
                        <td>
                          <Image
                            alt="Image"
                            height={20}
                            width={20}
                            src="/assets/delete-icon.svg"
                            style={{ cursor: "pointer" }}
                            onClick={() => {
                              handleMemberRemoveoutgoing(i)
                            }}
                          />
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </Table>
              <Row>
                <Col lg={10} md={12} xs={12} className="d-flex mt-2">
                  <TableText
                    label="Any Incoming EC Members"
                    LeftSpace={false}
                    required={false}
                  />
                  <Form.Check
                    inline
                    label="Yes"
                    required={true}
                    name="anyincomingmembers"
                    type="radio"
                    className="fom-checkbox mx-3"
                    onChange={() => setDisplayOption("display")}
                    value="Yes"
                    checked={displayOption === "display"}
                  />
                  {docdisplay ? <></> : <Form.Check
                    inline
                    label="No"
                    value="No"
                    name="anyincomingmembers"
                    type="radio"
                    className="fom-checkbox"
                    checked={displayOption === "not-display"}
                    onChange={() => setDisplayOption("not-display")}
                  />}
                </Col>
              </Row>
              {displayOption === "display" && (
                <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={submitHandler} autoComplete="off">
                  <div className="regofAppBg mb-3 dahboardProcedureSec">
                    <>
                      <div className="societyMemberDetailsList">
                        <Row className="membersDetailsList">
                          <div className="societyMemberDetailsList">
                            <Row className="membersDetailsList d-flex align-items-center"></Row>
                            <Row className="membersDetailsList">
                              <Col lg={3} md={3} xs={12} >
                                <Form.Group>
                                  <TableText
                                    label="Member Type"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="memberType"
                                    required={false}
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.memberType}
                                  >
                                    <option>Select</option>
                                    {typelist.map((item: any, i: number) => {
                                      return (
                                        <option key={i + 1} value={item}>
                                          {item}
                                        </option>
                                      )
                                    })}
                                  </select>
                                </Form.Group>
                              </Col>

                              <Col lg={3} md={3} xs={12} >

                                {!TempMemorymember.OTPRequested ? (
                                  <Form.Group>
                                    <TableText
                                      label="Enter Aadhaar Number"
                                      required={true}
                                      LeftSpace={false}
                                    />
                                    <div className="formGroup">
                                      <TableInputText
                                        disabled={TempMemorymember.AadharVerified}
                                        type="text"
                                        maxLength={12}
                                        placeholder="Enter Aadhaar Number"
                                        required={false}
                                        dot={false}
                                        name={"maskedAadhar"}
                                        value={SelectedMemberDetails.maskedAadhar}
                                        onChange={(e: any) => {
                                          if (!TempMemorymember.AadharVerified) {
                                            membersDetailsChange(e)
                                          }
                                        }}
                                        onKeyPress={true}
                                        onPaste={(e: any) => e.preventDefault()}
                                      />
                                      {!TempMemorymember.AadharVerified ? (
                                        <div
                                          style={{
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                            borderRadius: "2px",
                                          }}
                                          onClick={() => ReqOTP(SelectedMemberDetails)}
                                          className="verify btn btn-primary"
                                        >
                                          Get OTP
                                        </div>
                                      ) : null}
                                    </div>
                                  </Form.Group>
                                ) : (
                                  <Form.Group>
                                    <TableText
                                      label="Enter OTP"
                                      required={false}
                                      LeftSpace={false}
                                    />
                                    <div className="formGroup">
                                      <TableInputText
                                        disabled={false}
                                        type="number"
                                        placeholder="Enter OTP Received"
                                        maxLength={6}
                                        required={false}
                                        name={"otpCode"}
                                        value={SelectedMemberDetails.otpCode}
                                        onChange={membersDetailsChange}
                                      />
                                      <div
                                        style={{
                                          display: "flex",
                                          justifyContent: "center",
                                          alignItems: "center",
                                          borderRadius: "2px",
                                        }}
                                        onClick={() => {
                                          ReqDetails(SelectedMemberDetails)
                                        }}
                                        className="verify btn btn-primary"
                                      >
                                        Verify
                                      </div>
                                      <div
                                        style={{ display: "flex", justifyContent: "flex-end" }}
                                      >
                                        <div
                                          style={{
                                            cursor: "pointer",
                                            marginRight: "20px",
                                            color: "blue",
                                            fontSize: "10px",
                                          }}
                                          onClick={() => {
                                            setTempMemorymember({
                                              ...TempMemorymember,
                                              OTPRequested: false,
                                            })
                                          }}
                                        >
                                          clear
                                        </div>
                                      </div>
                                    </div>
                                  </Form.Group>
                                )}
                              </Col>

                              <Col lg={3} md={3} xs={12} >
                                <Form.Group>
                                  <TableText
                                    label="Name of the Member"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    // className="form-control"
                                    name="memberName"
                                    disabled
                                    required={false}
                                    placeholder="Enter Name of the Member"
                                    onChange={()=>{}}
                                    value={SelectedMemberDetails.memberName}
                                    type={"text"}
                                  />
                                  <Row className={styles.columnText}>
                                    <Col lg={9} md={4} xs={12}>
                                      Gender:{SelectedMemberDetails.gender}/Age:
                                      {SelectedMemberDetails.age}
                                    </Col>
                                  </Row>
                                </Form.Group>
                              </Col>

                              <Col lg={3} md={3} xs={12} >
                                <Form.Group className="inline">
                                  <TableText
                                    label="Relation Name"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <div className="inline formGroup">
                                    <Form.Select
                                      name="relationType"
                                      onChange={(event) => membersDetailsChange(event)}
                                      disabled={false}
                                      required={false}
                                      value={SelectedMemberDetails.relationType}
                                    >
                                      <option>Select</option>
                                      {relationtypelist.map((item: any, i: number) => {
                                        return (
                                          <option key={i + 1} value={item}>
                                            {item}
                                          </option>
                                        )
                                      })}
                                    </Form.Select>
                                    <input

                                      className="form-control"
                                      type="text"
                                      name="relationName"
                                      onChange={()=>{}}
                                      value={SelectedMemberDetails.relationName}
                                      disabled={true}
                                      required={false}
                                    />
                                  </div>
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={2} xs={12} >
                                <Form.Group>
                                  <TableText
                                    label="Role/Position"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="role"
                                    required={false}
                                    onChange={(event) =>
                                      membersDetailsChange(event)
                                    }
                                    value={SelectedMemberDetails.role}
                                  >
                                    <option>Select</option>
                                    {roleList.map((item: any) => {
                                      return <option value={item}>{item}</option>
                                    })}
                                  </select>
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} >
                                <Form.Group>
                                  <TableText
                                    label="Occupation"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                  type="text"
                                    required={false}
                                     name="occupation"
                                    placeholder="Enter Occupation"
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.occupation}
                                  />
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} >
                                <Form.Group>
                                  <TableText
                                    label="Qualification"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                  type="text"
                                    required={false}
                                    name="qualification"
                                    placeholder="Enter Qualification"
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.qualification}
                                  />
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} >
                                <Form.Group>
                                  <TableText
                                    label="Date of Joining as a Member"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <input
                                    required={false}
                                    type="date"
                                    className="form-control"
                                    name="joiningDate"
                                    placeholder="DD/MM/YYYY"
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.joiningDate}
                                  />
                                </Form.Group>
                              </Col>
                              <div className="formSectionTitle">
                                <h3>Address</h3>
                              </div>

                              <Col lg={3} md={3} xs={12} >
                                <TableText label="Door No" required={true} LeftSpace={false} />
                                <TableInputText
                                  disabled={false}
                                  type="text"
                                  placeholder="Enter Door No"
                                  required={false}
                                  name="doorNo"
                                  onChange={(event: any) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.doorNo}
                                />
                              </Col>

                              <Col lg={3} md={3} xs={12} >
                                <TableText
                                  label="Street Name"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <TableInputText
                                  disabled={false}
                                  type="text"
                                  placeholder="Enter Street Name"
                                  required={false}
                                  name="street"
                                  onChange={(event: any) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.street}
                                />
                              </Col>
                              <Col lg={3} md={3} xs={12} >
                                <TableText label="District" required={true} LeftSpace={false} />
                                <select style={{ textTransform: 'uppercase' }}
                                  className="form-control"
                                  name="district"
                                  onChange={(event) => {
                                    membersDetailsChange(event)
                                    districtmemberChange(event)
                                  }}
                                  value={SelectedMemberDetails.district}
                                >
                                  <option>Select</option>
                                  {districtList.map((item: any, i: any) => {
                                    return (
                                      <option key={i + 1} value={item.name}>
                                        {item.name}
                                      </option>
                                    )
                                  })}
                                </select>
                              </Col>

                              <Col lg={3} md={3} xs={12} >
                                <TableText label="Mandal" required={true} LeftSpace={false} />
                                <select style={{ textTransform: 'uppercase' }}
                                  className="form-control"
                                  name="mandal"
                                  id={"mandal"}
                                  placeholder="Mandal"
                                  onChange={(event) => {
                                    membersDetailsChange(event)
                                    mandalmemberChange(event)
                                  }}
                                  value={SelectedMemberDetails.mandal}
                                // defaultValue={"Select"}
                                >
                                  <option>Select</option>
                                  {currentmemberDistrict && (
                                    <DynamicMandals
                                      currentDistrict={currentmemberDistrict}
                                      setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                    ></DynamicMandals>
                                  )}</select>
                              </Col>

                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText label="Village" required={true} LeftSpace={false} />
                                <select style={{ textTransform: 'uppercase' }}
                                  className="form-control"
                                  name="villageOrCity"
                                  id={"villageOrCity"}
                                  placeholder="Village/City"
                                  onChange={(event) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.villageOrCity}
                                // defaultValue={"Select"}
                                >
                                  <option>Select</option>
                                  {currentmemberDistrict && currentmemberMandal && <DynamicVillages
                                    currentDistrict={currentmemberDistrict}
                                    currentMandal={currentmemberMandal}
                                    setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                  ></DynamicVillages>}

                                </select>
                              </Col>

                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText label="PIN Code" required={true} LeftSpace={false} />
                                <Form.Control
                                  disabled={false}
                                  type="text"
                                  maxLength={6}
                                  placeholder="Enter PIN Code"
                                  required={false}
                                  name={"pinCode"}
                                  onChange={(event) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.pinCode}
                                  onKeyPress={onNumberOnlyChange}
                                />
                              </Col>
                              <div className="formSectionTitle">
                                <h3>Contact Details</h3>
                              </div>

                              <Col lg={3} md={3} xs={12} >
                                <TableText
                                  label="Mobile Number"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <Form.Control
                                  disabled={false}
                                  type="text"
                                  maxLength={10}
                                  placeholder="Enter Mobile Number"
                                  required={false}
                                  name={"mobileNumber"}
                                  onChange={(event) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.mobileNumber}
                                  onKeyPress={onNumberOnlyChange}
                                />
                              </Col>
                              <Col lg={3} md={3} xs={12} >
                                <TableText
                                  label="Email Address"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <Form.Control
                                  disabled={false}
                                  type="text"
                                  placeholder="Enter Email Address"
                                  required={false}
                                  maxLength={40}
                                  minLength={15}
                                  name={"email"}
                                  onChange={(event) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.email}
                                />
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is of sound mind?"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="soundMind"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="Yes"
                                      checked={SelectedMemberDetails.soundMind === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="soundMind"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="No"
                                      checked={SelectedMemberDetails.soundMind === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is declared to be insolvent or an undischarged insolvent?"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="inSolvent"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="Yes"
                                      checked={SelectedMemberDetails.inSolvent === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="inSolvent"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="No"
                                      checked={SelectedMemberDetails.inSolvent === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is convicted of an offense of moral turpitude? "
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="offense"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="Yes"
                                      checked={SelectedMemberDetails.offense === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="offense"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="No"
                                      checked={SelectedMemberDetails.offense === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is disqualified for such an appointment by an order of a court?"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="appointment"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="Yes"
                                      checked={SelectedMemberDetails.appointment === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="appointment"
                                      onChange={(event) => membersDetailsChange(event)}
                                      value="No"
                                      checked={SelectedMemberDetails.appointment === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                          </div>
                        </Row>

                      </div>{" "}
                    </>
                    <Row>
                      <Col lg={12} md={12} xs={12} className="mb-4">
                        <div className="addotherBtnInfo text-center">
                          <div onClick={() => { handleMemberAdd(); setdocdisplay(true) }} className="btn btn-primary addPartner">
                            Add Member
                          </div>
                        </div>
                      </Col>
                    </Row>

                  </div>
                </Form>

              )}
            </div>
            <div className="regofAppBg my-2">
              <Row>
                {displayOption === "not-display" ? <></> : <>
                  <div className="formSectionTitle">
                    <h3>
                      Documents
                    </h3>
                  </div>
                  <Col lg={3} md={3} xs={12}>
                    <TableText label="Self Signed Declaration of New Member" required={false} LeftSpace={false} />
                    <div className="firmFile">
                      <Form.Control
                        type="file"
                        required={true}
                        name="selfSignedDeclaration"
                        ref={inputRef}
                        onChange={handleFileChange}
                        accept="application/pdf"
                      />
                    </div>
                  </Col>
                  <Col lg={3} md={3} xs={12}>
                    <TableText label="Declaration by Quorum & Members" required={true} LeftSpace={false} />

                    <div className="firmFile">
                      <Form.Control
                        type="file"
                        name="declaration"
                        ref={inputRef}
                        required={true}
                        onChange={handleFileChange}
                        accept="application/pdf"
                      />
                    </div>
                  </Col></>}
              </Row>
              <div className="uploadFirmList my-1">
                <h3>
                  Upload Society Related Documents-(All Uploaded Documents should be in PDF format
                  only upto 5MB )
                </h3>
              </div>
              <Row>
                <Row>

                  {/* </>} */}
                  {outgoingMembersDetails?.length > 0 && outgoingMembersDetails?.map((item: any, i: number) => {
                    return (
                      <Row>
                        {item.reasonForOutgoing === "RESIGNED" &&
                          <Col lg={3} md={6} xs={12}>
                            <div className="firmFile">
                              <Form.Group controlId="formFile">
                                <Form.Label>
                                  {item.memberName} Resigned
                                </Form.Label>
                                <Form.Control
                                  type="file"
                                  id={`${item.memberName}_resigned`}
                                  name={`${item.memberName}_resigned`}
                                  ref={inputRef}
                                  required={true}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </Form.Group>
                            </div>
                          </Col>}
                        {item.reasonForOutgoing === "TERMINATED" && <>

                          <Col lg={3} md={6} xs={12}>

                            <div className="firmFile">
                              <Form.Group controlId="formFile">
                                <Form.Label>
                                  <TableText label={`${item.memberName}_Terminated`} required={true} LeftSpace={false} />

                                </Form.Label>
                                <Form.Control
                                  type="file"
                                  required={true}
                                  id={`${item.memberName}_Terminated`}
                                  name={`${item.memberName}_Terminated`}
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </Form.Group>
                            </div>
                          </Col>

                          <Col lg={3} md={3} xs={12} className="mt-1">
                            <TableText label={`${item.memberName}_SelfSignedDeclaration of Outgoing Member`} required={true} LeftSpace={false} />
                            <div className="firmFile">
                              <Form.Control
                                type="file"
                                required={true}
                                id={`${item.memberName}_selfSignedDeclaration`}
                                name={`${item.memberName}_selfSignedDeclaration`}
                                ref={inputRef}
                                onChange={handleFileChange}
                                accept="application/pdf"
                              />
                            </div>
                          </Col>
                          <Col lg={10} md={4} xs={12}>
                            <div className="firmDuration d-flex">
                              <label>
                                <p className="fom-checkbox fw-bold small text-sm me-2">
                                  Whether the Termination of an Member has been accepted by the majority of EC members in the
                                  society?
                                </p>
                              </label>
                              <Form.Check
                                inline
                                label="Yes"
                                value="Yes"
                                name="termination"
                                onChange={(e: any) => {
                                  const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                  if (index > -1) { outgoingMembersDetails[index].termination = "Yes" }
                                  membersDetailsremove(e);
                                  setdisplayaadhar(true)
                                }
                                }
                                // onChange={(e: any) => { membersDetailsremove(e); setdisplayaadhar(true) }}
                                type="radio"
                                className="fom-checkbox fw-bold small text-sm"
                                checked={SelectedMemberDetailsremove.termination === "Yes"}
                              />
                              <Form.Check
                                inline
                                label="No"
                                value="No"
                                name="termination"
                                type="radio"
                                // onChange={(e: any) => { membersDetailsremove(e); setdisplayaadhar(false) }}
                                onChange={(e: any) => {
                                  const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                  if (index > -1) { outgoingMembersDetails[index].termination = "No" }
                                  membersDetailsremove(e);
                                  setdisplayaadhar(false)
                                }
                                }
                                className="fom-checkbox fw-bold small text-sm"
                                checked={SelectedMemberDetailsremove.termination === "No"}
                              />
                            </div>
                          </Col>
                          {/* <Row> */}
                          {displayaadhar && AadharValidate?.length > 0 &&
                            <>
                              <Row>
                                {AadharValidate.map((form, index) => {
                                  return (
                                    <>
                                      <Col lg={3} md={3} xs={12} className="mb-3">
                                        <Form.Group>
                                          <TableText
                                            label="Aadhaar Number"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <div className="formGroup">
                                            {(!form.otpStatus ||
                                              form.otpStatus == "2" ||
                                              form.otpVerified == "true") && (
                                                <div>
                                                  <TableInputText
                                                    type="text"
                                                    placeholder="Enter Aadhaar Number"
                                                    name="maskedAadhar"
                                                    required={true}
                                                    maxLength={12}
                                                    onKeyPress={true}
                                                    onPaste={(e: any) => e.preventDefault()}
                                                    disabled={form.otpVerified == "true"}
                                                    onChange={(event: any) =>
                                                      terminaMemberChange(event, index)
                                                    }
                                                    value={form.maskedAadhar}
                                                  />
                                                  {!form.otpStatus && (
                                                    <div
                                                      className="verify btn btn-primary"
                                                      onClick={() => {
                                                        if (form.maskedAadhar?.length == 12) {
                                                          let count = 0;
                                                          AadharValidate.forEach((x: any) => {
                                                            if (x.maskedAadhar == form.maskedAadhar) {
                                                              count++;
                                                            }
                                                          })
                                                          if (count < 2) {
                                                            membersDetails.some((x: any) => {
                                                              if (x.maskedAadhar == form.maskedAadhar && x.status == "Active") {
                                                                generateOtp(index)
                                                              } else {
                                                                ShowMessagePopup(false, "Aadhar is not in the existing EC Members")
                                                              }
                                                            })
                                                          }
                                                          else {
                                                            ShowMessagePopup(false, "Aadhar is already taken")
                                                          }
                                                        }
                                                      }}
                                                    >
                                                      Get OTP
                                                    </div>
                                                  )}
                                                </div>
                                              )}
                                            {form.otpStatus == "1" &&
                                              form.otpVerified != "true" && (
                                                <div>
                                                  <TableInputText
                                                    type="number"
                                                    placeholder="Enter OTP"
                                                    name="otpCode"
                                                    onKeyPress={true}
                                                    required
                                                    onChange={(event) =>
                                                      terminaMemberChange(event, index)
                                                    }
                                                    value={form.otpCode}
                                                  />
                                                  <div
                                                    className="verify btn btn-primary"
                                                    onClick={() => verifyOtp(index)}
                                                  >
                                                    Verify
                                                  </div>
                                                  <div
                                                    style={{
                                                      display: "flex",
                                                      justifyContent: "flex-end",
                                                    }}
                                                  >
                                                    <div
                                                      style={{
                                                        cursor: "pointer",
                                                        marginRight: "20px",
                                                        color: "blue",
                                                        fontSize: "10px",
                                                      }}
                                                      onClick={(e: any) => {
                                                        let datanew = AadharValidate
                                                        const det = {
                                                          ...datanew[index],
                                                          otpStatus: "", otpVerified: "", aadharNo: "", maskedAadhar: ""
                                                        }
                                                        let aadhardata = [...AadharValidate]
                                                        aadhardata[index] = det
                                                        setAadharValidate(aadhardata)
                                                      }}
                                                    >
                                                      clear
                                                    </div>
                                                  </div>
                                                </div>
                                              )}
                                          </div>
                                        </Form.Group>
                                      </Col>
                                    </>
                                  )
                                })}
                              </Row>
                            </>
                          }
                          {/* </Row> */}
                          <Row>
                            <Col lg={3} md={6} xs={12}>
                              <div className="firmFile">
                                <Form.Group controlId="formFile">
                                  <Form.Label>
                                    <TableText label={`${item.memberName}_Notice 1`} required={true} LeftSpace={false} />
                                  </Form.Label>
                                  <Form.Control
                                    type="file"
                                    required={true}
                                    id={`${item.memberName}_firstNotice`}
                                    name={`${item.memberName}_firstNotice`}
                                    ref={inputRef}
                                    onChange={handleFileChange}
                                    accept="application/pdf"
                                  />
                                </Form.Group>
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText label={`${item.memberName}_Notice 1 Date`} required={true} LeftSpace={false} />
                              <TableInputText
                                disabled={false}
                                type="date"
                                max={moment(moment().toDate()).format("YYYY-MM-DD")}
                                placeholder="Enter Door No"
                                required={true}
                                // id={`${item.memberName}_firstNoticeDate`}
                                name={"firstNoticeDate"}
                                onChange={(e: any) => {

                                  const index: any = outgoingMembersDetails.findIndex((x: any) => x._id == IndexData._id)
                                  if (index > -1) { outgoingMembersDetails[index].firstNoticeDate = e.target.value }
                                }}
                                value={SelectedMemberDetailsremove.firstNoticeDate} />
                            </Col>
                          </Row>
                          <Row>
                            <Col lg={3} md={6} xs={12}>
                              <div className="firmFile">
                                <Form.Group controlId="formFile">
                                  <Form.Label>
                                    <TableText label={`${item.memberName}_Notice 2`} required={true} LeftSpace={false} />
                                  </Form.Label>
                                  <Form.Control
                                    type="file"
                                    required={true}
                                    id={`${item.memberName}_secondNotice`}
                                    name={`${item.memberName}_secondNotice`}
                                    ref={inputRef}
                                    onChange={handleFileChange}
                                    accept="application/pdf"
                                  />
                                </Form.Group>
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText label={`${item.memberName}_Notice 2 Date`} required={true} LeftSpace={false} />
                              <TableInputText
                                disabled={false}
                                type="date"
                                placeholder="Enter Date"
                                required={true}
                                // id={`${item.memberName}_firstNoticeDate`}
                                name={"secondNoticeDate"}
                                max={moment(moment().toDate()).format("YYYY-MM-DD")}
                                onChange={(e: any) => {
                                  const index: any = outgoingMembersDetails.findIndex((x: any) => x._id == IndexData._id)
                                  if (index > -1) { outgoingMembersDetails[index].secondNoticeDate = e.target.value }
                                }}
                                // onChange={membersDetailsremove}
                                value={SelectedMemberDetailsremove.secondNoticeDate} />
                            </Col></Row>
                          <Row>
                            <Col lg={3} md={6} xs={12}>
                              <div className="firmFile">
                                <Form.Group controlId="formFile">
                                  <Form.Label>
                                    <TableText label={`${item.memberName}_Notice 3`} required={true} LeftSpace={false} />
                                  </Form.Label>
                                  <Form.Control
                                    type="file"
                                    required={true}
                                    id={`${item.memberName}_thirdNotice`}
                                    name={`${item.memberName}_thirdNotice`}
                                    ref={inputRef}
                                    onChange={handleFileChange}
                                    accept="application/pdf"
                                  />
                                </Form.Group>
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText label={`${item.memberName}_Notice 3 Date`} required={true} LeftSpace={false} />
                              <TableInputText
                                disabled={false}
                                type="date"
                                placeholder="Enter Date"
                                required={true}
                                // id={`${item.memberName}_firstNoticeDate`}
                                name={"thirdNoticeDate"}
                                max={moment(moment().toDate()).format("YYYY-MM-DD")}
                                onChange={(e: any) => {
                                  const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                  if (index > -1) { outgoingMembersDetails[index].thirdNoticeDate = e.target.value }
                                }}
                                value={SelectedMemberDetailsremove.thirdNoticeDate} />
                            </Col>
                          </Row>
                          <Col lg={3} md={6} xs={12}>
                            <div className="firmFile">
                              <Form.Group controlId="formFile">
                                <Form.Label>
                                  <TableText label={`${item.memberName}_Resolution of Committee`} required={true} LeftSpace={false} />
                                </Form.Label>
                                <Form.Control
                                  type="file"
                                  required={true}
                                  id={`${item.memberName}_committeeResolution`}
                                  name={`${item.memberName}_committeeResolution`}
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </Form.Group>
                            </div>
                          </Col>
                          <Col lg={10} md={4} xs={12}>
                            <div className="firmDuration d-flex">
                              <label>
                                <p className="fom-checkbox fw-bold small text-sm me-2">
                                  Whether the EC Members followed the 15 days time period in between each notice or not?
                                </p>
                              </label>
                              <Form.Check
                                inline
                                label="Yes"
                                value="Yes"
                                name="noticeTime"
                                onChange={(e: any) => {
                                  const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                  if (index > -1) { outgoingMembersDetails[index].noticeTime = "Yes" }
                                  membersDetailsremove(e)
                                }
                                }
                                type="radio"
                                className="fom-checkbox fw-bold small text-sm"
                                checked={SelectedMemberDetailsremove.noticeTime === "Yes"}
                              />
                              <Form.Check
                                inline
                                label="No"
                                value="No"
                                name="noticeTime"
                                type="radio"
                                onChange={(e: any) => {
                                  const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                  if (index > -1) { outgoingMembersDetails[index].noticeTime = "No" }
                                  membersDetailsremove(e)
                                }
                                }
                                className="fom-checkbox fw-bold small text-sm"
                                checked={SelectedMemberDetailsremove.noticeTime === "No"}
                              />
                            </div>
                          </Col>
                        </>}
                        {item.reasonForOutgoing === "DEATH" &&
                          <Col lg={3} md={6} xs={12}>
                            <div className="firmFile">
                              <Form.Group controlId="formFile">
                                <Form.Label>
                                  {item.memberName} Death
                                </Form.Label>
                                <Form.Control
                                  type="file"
                                  required={true}
                                  id={`${item.memberName}_Death`}
                                  name={`${item.memberName}_Death`}
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </Form.Group>
                            </div>
                          </Col>}
                      </Row>
                    )
                  })}
                </Row>
              </Row>
            </div>

            <div className="text-center my-2">
              <button className="verify btn btn-primary">
                Make Payment
              </button>
            </div>
            {/* </div> */}
          </div>
        </div>
      </Form>
    </div>
  )
}
export default FillingListofMembers
