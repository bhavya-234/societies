import React, { useState, useEffect } from "react"
import { Col, Container, Row, Form } from "react-bootstrap"
import { get } from "lodash"

import styles from "@/styles/pages/Forms.module.scss"
import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import { useRouter } from "next/router"
import { ALPHANUMERIC, checkCaptcha, randomString } from '../utils';
import Captcha from '../components/Captcha';
import { useAppSelector, useAppDispatch } from "@/redux/hooks"
import instance from "@/redux/api"
import { resetLoginDetails, signUp, verifyUserReg } from "@/redux/loginSlice"
import { PopupAction, setCaptcha } from "@/redux/commonSlice"
import { UseGetAadharDetails, UseGetAadharOTP } from "@/axios"
import castyles from '../styles/pages/Mixins.module.scss';
import { NameValidation } from "@/utils"
import Button from "@/components/Button"
import Head from "next/head"
import CryptoJS, { AES } from "crypto-js"
import { ISDefaultLoginDetailsModel } from "@/models/types"
import { ShowMessagePopup } from "@/GenericFunctions"

const initialLoginDetails: ISDefaultLoginDetailsModel = {
  maskedAadhar: "",
  registrationType: "society",
  firstName: "",
  lastName: "",
  email: "",
  mobileNumber: "",
  aadharNumber: "",
  societyName: "",
  alternateEmail: "",
  district: "",
}

const SocietyRegistration = () => {
  const dispatch = useAppDispatch()
  const router = useRouter()
  const [LoginDetails, setLoginDetails] = useState<ISDefaultLoginDetailsModel>(initialLoginDetails)
  const [FormErrors, setFormErrors] = useState<any>({})
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [otp, setOTP] = useState<string>("")
  const [loading, setLoading] = useState<boolean>(false)
  const [districts, setDistricts] = useState<any>([])

  const [isCheckFirm, setIsCheckFirm] = useState<boolean>(false)
  const [isCheckFirmBtn, setIsCheckFirmBtn] = useState<boolean>(true)

  const [isCheckNation, setIsCheckNation] = useState<boolean>(false)
  const [inputValue, setInputValue] = useState<any>("");
  const [isBtnDisabled, setIsBtnDisabled] = useState<boolean>(false)

  const verifyUserRegData = useAppSelector((state) => state.login.verifyUserRegData)
  const verifyUserRegLoading = useAppSelector((state) => state.login.verifyUserRegLoading)
  const verifyUserRegMsg = useAppSelector((state) => state.login.verifyUserRegMsg)

  const signUpData = useAppSelector((state) => state.login.signUpData)
  const signUpLoading = useAppSelector((state) => state.login.signUpLoading)
  const signUpMsg = useAppSelector((state) => state.login.signUpMsg)
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})

  const redirectToPage = (location: string) => {
    router.push({
      pathname: location,
    })
  }

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")

    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data) {
      if (data.userType == "user") {
        router.push("/societies/dashboard")
      } else {
        router.push("/societies")
      }
    }
    instance.get("/getDistricts").then((response) => {
      setDistricts(response.data)
    })
  }, [])

  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid && event.key != "Backspace") {
      event.preventDefault()
      return
    }
  }

  useEffect(() => {
    instance.get("/getDistricts").then((response) => {
      setDistricts(response.data)
    })
  }, [])

  const ShowAlert = (type: boolean, message: string, redirectOnSuccess: string) => {
    dispatch(PopupAction({ enable: true, type, message, redirectOnSuccess }))
  }

  const onChange = (e: any) => {
    let addName = e.target.name
    let addValue = e.target.value
    if (addName == "firstName") {
      addValue = NameValidation(addValue)
    } else if (addName == "lastName") {
      addValue = NameValidation(addValue)
    } else if (addName == "societyName") {
      addValue = NameValidation(addValue)
    }
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (e.target.value.length > 0 && e.target.value.length > LoginDetails.aadharNumber.length) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          LoginDetails.aadharNumber.substring(0, startpos) +
          LoginDetails.aadharNumber.substring(startpos + 1, LoginDetails.aadharNumber.length)
      }
      setLoginDetails({
        ...LoginDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? LoginDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      setLoginDetails({ ...LoginDetails, [addName]: addValue })
    }
    if (
      LoginDetails.firstName != "" &&
      LoginDetails.societyName != "" &&
      LoginDetails.aadharNumber != "" &&
      LoginDetails.mobileNumber != ""
    ) {
      setIsBtnDisabled(true)
    } else {
      setIsBtnDisabled(false)
    }
  }

  const validate = () => {
    const errors: any = {}
    const logDetails: any = { ...LoginDetails }
    if (
      !logDetails.firstName ||
      logDetails.firstName.length < 2 ||
      logDetails.firstName.length > 30
    ) {
      errors["firstName"] = "*First Name should contain 2 - 30 characters."
    }
    if (!logDetails.lastName || logDetails.lastName.length < 2 || logDetails.lastName.length > 30) {
      errors["lastName"] = "*Last Name should contain 2 - 30 characters."
    }
    if (
      !logDetails.societyName ||
      logDetails.societyName.length < 4 ||
      logDetails.societyName.length > 50
    ) {
      errors["societyName"] = "*Society Name should contain 4 - 20 characters."
    }
    if (LoginDetails.mobileNumber && LoginDetails.mobileNumber.length < 10) {
      errors["mobileNumber"] = "*Please enter a valid mobile number"
    }
    if (LoginDetails.email === LoginDetails.alternateEmail) {
      errors["alternateEmail"] = "*Alternate email should not be same as email"
    }
    if (LoginDetails.aadharNumber && LoginDetails.aadharNumber.length < 12) {
      errors["aadharNumber"] = "*Please enter a valid 12 digit aadhaar number"
    }
    setFormErrors({ ...errors })
    return errors
  }

  const checkFields = () => {
    if (!LoginDetails.email && !LoginDetails.mobileNumber && !LoginDetails.aadharNumber) {
      ShowAlert(
        false,
        "Please provide details for atleast on these fields (Mobile No, Aadhaar No)",
        ""
      )
      return false
    }
    return true
  }

  const checkFirmDB = (e: any) => {
    e.preventDefault()
    const errors: any = {}
    const logDetails: any = { ...LoginDetails }
    setLoading(true)
    let ob: any = {
      societyName: LoginDetails.societyName.trim(),
      district: LoginDetails.district,
    }
    if (
      !logDetails.societyName ||
      logDetails.societyName.trim().length < 4 ||
      logDetails.societyName.trim().length > 50
    ) {
      errors["societyName"] = "*Society Name should contain 4 - 20 characters."
    } else if (
      !logDetails.district ||
      logDetails.district == "select" ||
      logDetails.district == "--Select--"
    ) {
      errors["district"] = "*Please select district."
    } else {
      let obj: any = {
        registrationName: LoginDetails.societyName.trim(),
      }
      instance
        .post("checkAvailability", obj)
        .then((response: any) => {
          if (response.data.success == false) {
            ShowAlert(false, response.data.message, "")
            setIsCheckNation(false)
          }
          if (response.data.success == true) {
            instance
              .post("societies/check", ob)
              .then((response: any) => {
                if (
                  response.data.message == "Society already exists!" &&
                  response.data.success == false
                ) {
                  ShowAlert(false, "Society name is already exists!", "")
                }
                if (
                  response.data.message == "Society is available to register" &&
                  response.data.success == true
                ) {
                  ShowAlert(true, "Society name is available to register", "")
                  setIsCheckFirm(true)
                  setIsCheckFirmBtn(false)
                } else {
                  setIsCheckFirm(false)
                  setIsCheckFirmBtn(true)
                }
              })
              .catch((error) => {
                if (error.message == "Request failed with status code 400") {
                  ShowAlert(false, "Society Name & District is Mandatory", "")
                }
              })
          } else {
            setIsCheckNation(false)
          }
          setLoading(false)
        })
        .catch((error) => {
          if (error.message == "Request failed with status code 400") {
            ShowAlert(false, "Society Name & District is Mandatory", "")
          }
        })
    }
    setFormErrors({ ...errors })
  }

  const backStepHandle = (e: any) => {
    setIsCheckFirm(false)
    setIsCheckFirmBtn(true)
  }

  let checkFirmSec = "enableFields"

  if (isCheckFirmBtn == false) {
    checkFirmSec = "disableFields"
  } else {
    checkFirmSec = "enableFields"
  }

  const onSubmit = async (e: any) => {
    e.preventDefault()
    if (checkFields() && !Object.keys(validate()).length) {
      let data:any={
        secretkey:process.env.SECRET_KEY,
      }
      let ob: any = {
        firstName: LoginDetails.firstName,
        lastName: LoginDetails.lastName,
        societyName: LoginDetails.societyName,
        alternateEmail: LoginDetails.alternateEmail,
        registrationType: LoginDetails.registrationType,
        district: LoginDetails.district,
        captchaVal:inputValue,
        userKey: CryptoJS.AES.encrypt(inputValue,data.secretkey).toString()
     
      }
      if (LoginDetails.email) {
        ob["email"] = LoginDetails.email
      }
      if (LoginDetails.mobileNumber) {
        ob["mobileNumber"] = LoginDetails.mobileNumber
      }
      if (LoginDetails.aadharNumber) {
        ob["aadharNumber"] = LoginDetails.aadharNumber
      }
      if (inputValue == "") {
        ShowMessagePopup(false, "Please Enter The Capctha");
      } else {
        let captchaCheck: any = await checkCaptcha(inputValue);
        if (captchaCheck === false) {
          ShowMessagePopup(false, "Please Enter Valid Capctha");
          dispatch(setCaptcha(randomString(6, ALPHANUMERIC)));
        } else {
          dispatch(
            verifyUserReg({
              ...ob,
            })
          )
        }
        setInputValue("")
      }
    }
  }

  useEffect(() => {
    if (Object.keys(verifyUserRegData).length && verifyUserRegData.success == true) {
      ; (async () => {
        if (LoginDetails.mobileNumber && LoginDetails.aadharNumber && process.env.IGRS_SECRET_KEY) {
          setLoading(true)
          const ciphertext = AES.encrypt(LoginDetails.aadharNumber, process.env.IGRS_SECRET_KEY)
          let result = await UseGetAadharOTP(ciphertext.toString())
          if (result && result.status === "Success") {
            ShowAlert(true, "OTP Sent to Aadhaar Registered Mobile Number", "")
            setSentOTP(true)
            setAadhaarOTPResponse(result)
          } else {
            ShowAlert(false, get(result, "message", "Aadhaar API Failed"), "")
            setAadhaarOTPResponse({})
            dispatch(setCaptcha(randomString(6, ALPHANUMERIC)));
          }
          setLoading(false)
          
        }
      })()
    } else if (verifyUserRegData.success == false) {
      ShowAlert(false, verifyUserRegData.message, "")
      dispatch(setCaptcha(randomString(6, ALPHANUMERIC)));
    }
  }, [verifyUserRegData])

  useEffect(() => {
    if (verifyUserRegMsg) {
      ShowAlert(false, verifyUserRegMsg, "")
    }
  }, [verifyUserRegMsg])

  useEffect(() => {
    return () => {
      dispatch(resetLoginDetails())
    }
  }, [])

  const onRegister = async (e: any) => {
    e.preventDefault()

    if (LoginDetails.mobileNumber && LoginDetails.aadharNumber) {

      // window.alert(captchaCheck);
      // setLoading(true)
      // let result: any = await UseGetAadharDetails({
      //   aadharNumber: btoa(LoginDetails.aadharNumber),
      //   transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
      //   otp: otp,
      // })
      // if (result.status && result.status === "Success") {
      callSignUp(true)
    }
    // } else {
    //   ShowAlert(false, result.message, "")
    // }
    //setLoading(false)
    //   setInputValue("")
    // }
    // }
  }

  const callSignUp = (flag: boolean) => {
    let ob: any = {
      firstName: LoginDetails.firstName,
      lastName: LoginDetails.lastName,
      societyName: LoginDetails.societyName.trim(),
      alternateEmail: LoginDetails.alternateEmail,
      registrationType: LoginDetails.registrationType,
      district: LoginDetails.district,
    }
    if (LoginDetails.email) {
      ob["email"] = LoginDetails.email
    }
    if (LoginDetails.mobileNumber) {
      ob["mobileNumber"] = LoginDetails.mobileNumber
    }
    if (LoginDetails.aadharNumber) {
      
      let secretkey:any=process.env.IGRS_SECRET_KEY;
      console.log("secretkey--",secretkey);
      console.log("LoginDetails.aadharNumber",LoginDetails.aadharNumber);
      ob["aadharNumber"] =  CryptoJS.AES.encrypt( LoginDetails.aadharNumber, secretkey).toString()
      // ob["aadharNumber"] = btoa(LoginDetails.aadharNumber)
      

    }
    dispatch(
      signUp({
        ...ob,
        loginOtp: flag ? parseInt(otp) : "",
        transactionNumber: aadhaarOTPResponse.transactionNumber
      })
    )
  }

  useEffect(() => {
    if (Object.keys(signUpData).length && signUpData.success) {
      ShowAlert(true, "Account Registered Successfully!", "/login")
    } else if (Object.keys(signUpData).length && !Object.keys(signUpData?.data)?.length) {
      ShowMessagePopup(false, "Error occurred while register")
    }
  }, [signUpData])
  useEffect(() => {
    if (signUpMsg) {
      ShowAlert(false, signUpMsg, "")
    }
  }, [signUpMsg])

  return (
    <div className="regMainWarp">
      <Head>
        <title>Registration - Societies</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>
      <div className={styles.RegistrationMain}>
        <div className="logiRegMainSec">
          <div className="societyRegSec">
            <Container>
              <div className="regContainerSec">
                <div className="formsec">
                  {sentOTP ? (
                    <form
                      className={`${styles.RegistrationInput} ${loading || signUpLoading ? styles.disableForm : ""
                        }`}
                      onSubmit={onRegister}
                    >
                      <div className="enterOTPForm">
                        <div className="formSectionTitle mb-3">
                          <h3 className="p-0 d-flex align-items-center">
                            <button
                              className={styles.rightButton}
                              onClick={() => setSentOTP(false)}
                              type="button"
                            >
                              <img className="enterBackImg" src="/assets/back-icon.svg" />
                            </button>{" "}
                            <span className={styles.enterOTPText}>Enter OTP</span>
                          </h3>
                        </div>
                        <div className="mb-3">
                          <Form.Control
                            type="text"
                            placeholder="Enter OTP"
                            required={true}
                            name="otp"
                            value={otp}
                            maxLength={6}
                            onChange={(e) => {
                              setOTP(e.target.value)
                            }}
                            onKeyPress={onNumberOnlyChange}
                          />
                        </div>
                        <Row className="p">
                          <Col lg={5} md={6} xs={6}>
                            <div className={styles.pdesingleColumn}>
                              <Button
                                type="submit"
                                btnName="Register"
                                status={loading || signUpLoading}
                                disabled={verifyUserRegLoading || loading}
                              ></Button>
                            </div>
                          </Col>


                          <Col lg={7} md={6} xs={6} className={styles.flexColumn}>
                            <div className={styles.flexColumn}>
                              <span className={`${styles.checkText} ${styles.scheckText}`}>
                                Did not receive OTP?
                              </span>
                              <button
                                type="button"
                                className={styles.rightButton}
                                onClick={onSubmit}
                              >
                                Resend OTP
                              </button>
                            </div>
                          </Col>
                        </Row>
                      </div>
                    </form>
                  ) : (
                    <form
                      onSubmit={onSubmit}
                      autoComplete="off"
                      className={`formsec ${styles.RegistrationInput} ${loading || verifyUserRegLoading ? styles.disableForm : ""
                        }`}
                    >
                      <div className="regNewStarSec">
                        <div className="d-flex justify-content-between mb-3">
                          <div className="formSectionTitle">
                            <h3>New Registration!</h3>
                          </div>
                        </div>

                        <div className="firmRegList formsec">
                          <div className="defaultDisable">
                            <Form.Check
                              inline
                              label="Registration of Societies"
                              name="registrationType"
                              type="radio"
                              id="society"

                              value="society"
                              checked={LoginDetails.registrationType == "society"}
                              onChange={onChange}
                            />
                          </div>
                        </div>

                        <div className="firmRegFieldsList regofAppBg">
                          <div className="note requiredData mb-3">
                            <p>All fields are mandatory</p>
                          </div>
                          <div className="TopFieldsSec">
                            <Row>
                              <Col lg={6} md={6} xs={12} className="mb-3">
                                <div className="d-flex justify-content-between">
                                  <TableText
                                    label={"Society Name"}
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  {isCheckFirm && (
                                    <div className="firmAvailablebtns">
                                      {LoginDetails.societyName.trim().length > 0 &&
                                        LoginDetails.district &&
                                        LoginDetails.district !== "select" &&
                                        LoginDetails.district !== "--Select--" && (
                                          <div onClick={backStepHandle} className="availability">
                                            Change Name
                                          </div>
                                        )}
                                    </div>
                                  )}
                                </div>
                                {!isCheckFirm && (
                                  <Form.Control
                                    type="text"
                                    placeholder="Enter Society Name"
                                    required={true}
                                    name="societyName"
                                    value={LoginDetails.societyName}
                                    onChange={onChange}
                                    minLength={4}
                                    maxLength={50}
                                  />
                                )}

                                {isCheckFirm && (
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Society Name"
                                    required={true}
                                    name="societyName"
                                    value={LoginDetails.societyName}
                                    onChange={onChange}
                                    disabled={true}
                                  />
                                )}

                                <text className={styles.warningText} style={{ color: "red" }}>
                                  {FormErrors.societyName}
                                </text>
                              </Col>

                              <Col lg={6} md={6} xs={12} className="mb-3">
                                <TableText label={"District"} required={true} LeftSpace={false} />

                                {!isCheckFirm && (
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="district"
                                    required
                                    value={LoginDetails.district}
                                    onChange={onChange}
                                  >
                                    <option value="select">--Select--</option>
                                    {districts.map((item: any, i: number) => {
                                      return (
                                        <option key={i} value={item.name}>
                                          {item.name}
                                        </option>
                                      )
                                    })}
                                  </select>
                                )}
                                <text className={styles.warningText} style={{ color: "red" }}>
                                  {FormErrors.district}
                                </text>
                                {isCheckFirm && (
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="district"
                                    required
                                    value={LoginDetails.district}
                                    onChange={onChange}
                                    disabled
                                  >
                                    <option value="select">--Select--</option>
                                    {districts.map((item: any, i: number) => {
                                      return (
                                        <option key={i} value={item.name}>
                                          {item.name}
                                        </option>
                                      )
                                    })}
                                  </select>
                                )}
                              </Col>

                              {!isCheckFirm && (
                                <div className="firmAvailablebtns">
                                  {(LoginDetails.societyName.trim() == "" ||
                                    LoginDetails.societyName.trim().length < 4 ||
                                    !LoginDetails.district ||
                                    LoginDetails.district == "select" ||
                                    LoginDetails.district == "--Select--") && (
                                      <Col lg={12} md={12} xs={12} className="disable">
                                        <div className="btn btn-secondary checkFirm disabled">
                                          Check Availability
                                        </div>
                                      </Col>
                                    )}

                                  {LoginDetails.societyName.trim().length > 3 &&
                                    LoginDetails.district &&
                                    LoginDetails.district !== "select" &&
                                    LoginDetails.district !== "--Select--" && (
                                      <Col lg={12} md={12} xs={12} className="mb-3 firmAvail">
                                        <Button
                                          type="button"
                                          onClick={checkFirmDB}
                                          status={verifyUserRegLoading || loading}
                                          btnName="Check Availability"
                                        ></Button>
                                      </Col>
                                    )}
                                </div>
                              )}
                            </Row>
                          </div>

                          {isCheckFirm && (
                            <div className="availableForm">
                              <Row>
                                <Col lg={6} md={6} xs={12} className="mb-3">
                                  <TableText
                                    label={"First Name"}
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <Form.Control
                                    type="text"
                                    placeholder="Enter First Name"
                                    required={true}
                                    name="firstName"
                                    value={LoginDetails.firstName}
                                    onChange={onChange}
                                    autoComplete="off"
                                    minLength={3}
                                    maxLength={30}
                                  />
                                  <text className={styles.warningText} style={{ color: "red" }}>
                                    {FormErrors.firstName}
                                  </text>
                                </Col>

                                <Col lg={6} md={6} xs={12} className="mb-3">
                                  <TableText
                                    label={"Last Name"}
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <Form.Control
                                    type="text"
                                    placeholder="Enter Last Name"
                                    required={true}
                                    name="lastName"
                                    autoComplete="off"
                                    value={LoginDetails.lastName}
                                    onChange={onChange}
                                    minLength={1}
                                    maxLength={30}
                                  />
                                  <text className={styles.warningText} style={{ color: "red" }}>
                                    {FormErrors.lastName}
                                  </text>
                                </Col>

                                <Col lg={6} md={6} xs={12} className="mb-3">
                                  <TableText label={"Email ID"} required={true} LeftSpace={false} />
                                  <Form.Control
                                    type="email"
                                    placeholder="Enter Email ID"
                                    required={true}
                                    name="email"
                                    autoComplete="off"
                                    value={LoginDetails.email}
                                    onChange={onChange}
                                    minLength={15}
                                    maxLength={40}
                                  />
                                </Col>

                                <Col lg={6} md={6} xs={12} className="mb-3">
                                  <TableText
                                    label={"Alternate Email ID"}
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <Form.Control
                                    type="email"
                                    placeholder="Enter Alternate Email ID"
                                    required={true}
                                    autoComplete="off"
                                    name="alternateEmail"
                                    value={LoginDetails.alternateEmail}
                                    onChange={onChange}
                                    minLength={15}
                                    maxLength={40}
                                  />
                                  <text className={styles.warningText} style={{ color: "red" }}>
                                    {FormErrors.alternateEmail}
                                  </text>
                                </Col>

                                <Col lg={6} md={6} xs={12} className="mb-3">
                                  <TableText
                                    label={"Mobile Number"}
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <Form.Control
                                    type="text"
                                    placeholder="Enter Mobile Number"
                                    required={true}
                                    name="mobileNumber"
                                    autoComplete="off"
                                    value={LoginDetails.mobileNumber}
                                    onChange={onChange}
                                    onKeyPress={onNumberOnlyChange}
                                    maxLength={10}
                                  />
                                  <text className={styles.warningText} style={{ color: "red" }}>
                                    {FormErrors.mobileNumber}
                                  </text>
                                </Col>

                                <Col lg={6} md={6} xs={12} className="mb-3">
                                  <TableText
                                    label={"Aadhaar Number"}
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <Form.Control
                                    type="text"
                                    placeholder="Enter Aadhaar Number"
                                    required={true}
                                    name="maskedAadhar"
                                    value={LoginDetails.maskedAadhar}
                                    onChange={onChange}
                                    autoComplete="off"
                                    onKeyPress={onNumberOnlyChange}
                                    maxLength={12}
                                    onPaste={(e) => e.preventDefault()}
                                  />
                                  <text className={styles.warningText} style={{ color: "red" }}>
                                    {FormErrors.aadharNumber}
                                  </text>
                                </Col>
                              </Row>
                              <Row className={`mt-4 ${castyles.captchaCon}`}>
                                <Col lg={4} md={6} xs={6}><Captcha /></Col>
                                <Col lg={8} md={6} xs={6}>
                                  <div className='d-flex'>
                                    <input value={inputValue} className={castyles.captchaInput} onChange={(e) => { setInputValue(e.target.value); }} />
                                  </div>
                                </Col>
                              </Row>
                              <div className="d-flex justify-content-between text-center">
                                <div className={styles.pdesingleColumn}>
                                  {!isBtnDisabled && (
                                    <Button
                                      type="submit"
                                      btnName="Send OTP"
                                      disabled={true}
                                      status={loading || verifyUserRegLoading}
                                    ></Button>
                                  )}

                                  {isBtnDisabled && (
                                    <Button
                                      type="submit"
                                      btnName="Send OTP"
                                      status={loading || verifyUserRegLoading}
                                    ></Button>
                                  )}
                                </div>

                                <div className={styles.flexColumn}>
                                  <span className={`${styles.checkText} ${styles.scheckText}`}>
                                    Already have an account?
                                  </span>
                                  <button
                                    className={styles.rightButton}
                                    onClick={() => {
                                      redirectToPage("/login")
                                    }}
                                    type="button"
                                  >
                                    Login
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </form>
                  )}
                </div>
              </div>
            </Container>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SocietyRegistration