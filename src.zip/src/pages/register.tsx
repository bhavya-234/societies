import { useState } from "react"
import Head from "next/head"
import { useRouter } from "next/router"
import { Container, Row, Col, Accordion } from "react-bootstrap"
import Login from "./login"
import { ISFirmDetailsModel, ISSocietyDetailsSMModel } from "@/models/types"

import styles from "@/styles/pages/Forms.module.scss"
const initialDetails: any = {
  registrationType: "society",
}

const Register = () => {
  const router = useRouter()
  let regClass: any = ""

  const [regFirm, setRegFirm] = useState<any>(initialDetails)
  const [activeTab, setActiveTab] = useState<number>(0)
  const [isFirmReg, setIsFirmReg] = useState<boolean>(false)
  const [isSocietyReg, setIsSocietyReg] = useState<boolean>(false)
  const [isLogin, setISLogin] = useState<boolean>(false)
  const [isregType, setIsRegType] = useState<string>("firm")

  const [firmDetails, setFirmDetails] = useState<ISFirmDetailsModel>({
    firmName: "",
    district: "",
    firstName: "",
    lastName: "",
    emailID: "",
    alternameEmailID: "",
    aadharNumber: "",
    mobileNumber: "",
    relationwithFirm: "",
  })

  const [societyDetails, setSocietyDetails] = useState<ISSocietyDetailsSMModel>({
    societyName: "",
    district: "",
    firstName: "",
    lastName: "",
    emailID: "",
    alternameEmailID: "",
    aadharNumber: "",
    mobileNumber: "",
    relationwithFirm: "",
  })

  const onChange = (e: any) => {
    let addName = e.target.name
    let addValue = e.target.value
    setRegFirm({ ...regFirm, [addName]: addValue })
  }

  const firmDetailsChange = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setFirmDetails(newInput)
  }

  const societyDetailsChange = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setSocietyDetails(newInput)
  }

  const loginhandleChange = () => {
    setISLogin(true)
    setIsRegType(regFirm.registrationType)
  }
  const tabs: string[] = ["Procedure", "Checklist"]
  const renderTabHeaders = (): any => {
    return tabs.map((item: string, index: number) => {
      return (
        <div
          className={activeTab === index ? styles.activeTabHeaderlogin : styles.tabHeaderlogin}
          key={index} onClick={() => {
            setActiveTab(index)
          }}
        >
          {item}
        </div>
      )
    })
  }
  return (
    <>
      <Head>
        <title>Registration of Society</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      {!isLogin && (
        <div className={`${regClass} logiRegMainSec regAccordionSec`}>
          <div className="societyRegSec">
            <Container>
              <div className="regMainFitSec">

                <div className="regContainerSec p-0">
                  <Row>
                    <Col lg={12} md={12} xs={12}>
                      <div className="d-flex justify-content-between align-items-center page-title mb-0">
                        <div className="pageTitleLeft">
                          <h1>Registration of Society</h1>
                        </div>
                      </div>

                    </Col>
                  </Row>
                  <Row>
                  <Row>
                <Col lg={5} md={4} xs={12}>
                  <div className={styles.tabContainer} id="tabDiv">
                    {renderTabHeaders()}
                  </div>
                </Col>
              </Row>
                  </Row>

                  <Row>
                    <Col lg={9} md={6} xs={12}>

                      <div className="dashboardRegSec">
                        {activeTab === 0 &&
                          <div className="dashboardInfologin">
                            <h6>Society registration</h6>
                            <ul>
                              <li>
                                The user has to submit an online application by providing the
                                required details and upload required documents (as shown in
                                checklist).
                              </li>
                              <li>
                                The user then has to make requisite payment through the online
                                portal.
                              </li>
                              <li>
                                The user then has to send the original documents to District
                                Registrar Office, either through courier/RPAD or by dropping
                                them at the drop-box located at the District Registrar office.
                              </li>
                            </ul>

                            <div>
                              <h6>Procedure at the District Registrar Office</h6>
                            </div>

                            <div>
                              <h6>Sr. Assistant Level:</h6>
                              <ul>
                                <li>
                                  The documents (Memorandum of Society, Rules and Regulations,
                                  ID and address Proof of EC Members, Registered lease
                                  agreement/Declaration if office is in own premises) received
                                  at the Office of District Registrar will be verified by Senior
                                  Assistant against the details provided in the online
                                  application.
                                </li>

                                <li>
                                  Upon successful verification, a recommendation for approval is
                                  made to District Registrar.
                                </li>

                                <li>
                                  In case of verification being unsuccessful, the applicant will
                                  be directed to make necessary changes to the application
                                </li>
                              </ul>
                            </div>

                            <h6>District Registrar Level:</h6>
                            <ul>
                              <li>
                                Based on the recommendation provided by Sr. Assistant, District
                                Registrar approves the registration
                              </li>

                              <li>
                                With the approval, the District Registrar also digitally signs
                                the registration certificate.
                              </li>

                              <li>
                                In case of verification being unsuccessful, the applicant will
                                be directed to make necessary changes to the application.
                              </li>
                            </ul>
                          </div>}
                        {activeTab === 1 &&
                          <div className="dashboardInfologin">
                            <div >
                              <h6>
                                After submitting online application of Society, the following
                                documents in original shall be submitted in
                              </h6>
                              <ol>
                                <li>Acknowledgment containing reference number</li>
                                <li>Memorandum of Society</li>
                                <li>Minimum 7 Members(General Body).</li>
                                <li>Minimum 3 Executive Committee Members(out of General Body).</li> 
                                {/* <li>For Registration of Societies minimum 7 members are mandatory as per Society Act</li> */}
                                <li>Rules and Regulations</li>
                                <li>ID Proof of EC Members</li>
                                <li>Address proof of EC Members</li>
                                <li>Passport Size photographs of all EC Members</li>
                                <li>
                                  Registered lease agreement if office is in rented premises or
                                  Declaration if office is in own premises and no rent is
                                  collected from Society Citizen must submit all original papers
                                  either by courier/RPAD or handover in person in the concerned
                                  District Registrar Office quoting online application reference
                                  number.
                                </li>
                              </ol>
                            </div>

                            <p>
                              <strong>
                                Address of District Registrar Office can be found by
                              </strong>{" "}
                              <a href="#">clicking the Link</a>
                            </p>
                            <p>
                              Certificate will be issued within three days from the date of
                              receipt of original application and other connected documents, if
                              everything is in order or further information/documents will be
                              required by the District Registrar for completion of registration.
                            </p>
                          </div>}

                      </div>
                    </Col>

                    <Col lg={3} md={6} xs={12}>
                      <div className="regTypeFieldSec">
                        <div className="mainPageImg">
                          <img src="/assets/home-societies-img.jpg" alt="home-societies-img.jpg" />
                        </div>
                        <div className="firmSubmitSec">
                          <Row style={{ alignItems: "center", justifyContent: "center" }}>
                            <Col lg={8} md={6} xs={6}>
                              <a href="/login" className="btn btn-primary login">
                                Login
                              </a></Col></Row>
                          <Row style={{ alignItems: "center", justifyContent: "center" }}>
                            <Col lg={8} md={6} xs={6}>
                              <a href="/societyRegistration" className="btn btn-primary login">
                                Register
                              </a></Col></Row>
                        </div>
                      </div>
                    </Col>
                  </Row>
                </div>
              </div>
            </Container>
          </div>
        </div>
      )}
      {isLogin && (
        <div className={`${regClass} logiRegMainSec`}>
          <div className="societyRegSec">
            <Container>
              <div className="regContainerSec">
                <Login isregType={isregType} setIsRegType={setIsRegType} setISLogin={setISLogin} />
              </div>
            </Container>
          </div>
        </div>
      )}
    </>
  )
}
export default Register
