import React, { useState } from "react"
import instance from "../../redux/api"
import { store } from "@/redux/store"
import { LoadingAction } from "@/redux/commonSlice"

interface DynamicVillageProps {
  currentDistrict: any
  currentMandal: any
  setDetails?: () => void
}

export default function DynamicVillages({
  currentDistrict,
  currentMandal,
  setDetails,
}: DynamicVillageProps) {
  console.log(currentDistrict, currentMandal)
  const [villageList, setVillageList] = useState([])
  let data = {
    districtName: currentDistrict,
    mandalName: currentMandal,
  }
  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }

  React.useEffect(() => {
    if (currentDistrict && currentDistrict != null && currentMandal) {
      Loading(true)
      instance
        .post("/getDistrictsMandalVillages", data)
        .then((response) => {
          const vList = response.data.map((item: { villageName: string }) => {
            return item.villageName
          })
          setVillageList(vList)
          Loading(false)
          setDetails && setDetails()
        })
        .catch(() => {
          Loading(false)
        })
    }
  }, [currentMandal])

  return (
    <>
      {villageList &&
        villageList.length > 0 &&
        villageList.map((village: any, i: number) => {
          return (
            <option key={village + i} value={village}>
              {village}
            </option>
          )
        })}
    </>
  )
}
