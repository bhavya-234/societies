import { ShowMessagePopup } from "@/GenericFunctions"
import {
  UseGetAadharDetails,
  UseGetAadharOTP,
  getSocietyDetails,
  updateSocietyDetails,
} from "@/axios"
import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import { useAppDispatch } from "@/hooks/reduxHooks"
import {
  IApplicationDetailsModel,
  IByLawsDetailsModel,
  IContactDetailsModel,
  IExistingMemberDetailsModel,
  ISocitiesDetailsModel,
} from "@/models/societyTypes"
import instance from "@/redux/api"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { store } from "@/redux/store"
import styles from "@/styles/pages/Forms.module.scss"
import CryptoJS, { AES } from "crypto-js"
import { get } from "lodash"
import Head from "next/head"
import Image from "next/image"
import { useRouter } from "next/router"
import React, { useEffect, useRef, useState } from "react"
import { Button, Col, Container, Form, Row, Table } from "react-bootstrap"
import Swal from "sweetalert2"
import DynamicVillages from "./dynamicCities"
import DynamicMandals from "./dynamicMandals"
import { saveLoginDetails } from "@/redux/loginSlice"

const tabs: string[] = ["Applicant Details", "Society Details", "Executive Committee Member Details", "Bye-Laws"]

interface DetailsProps {
  requests?: any
  setRequests?: any
  setIsAdding?: boolean
}

export default function Details({ requests, setRequests, setIsAdding }: DetailsProps) {
  const [addSociety, setAddSociety] = useState<string>("")
  const [isResubmission, setIsResubmission] = useState<string>("false")
  const [isError, setIsError] = useState<boolean>(false)
  const [refId, setRefId] = useState<string>("")
  const [otp, setOTP] = useState<string>("")

  const [errorMessage, setErrorMessage] = useState<string>("")
  const [changeradio, setChangeradio] = useState<string>("")
  const [districtList, setDistricts] = useState<any>([])
  const [token, setToken] = useState<string>("")
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [isPayNowClicked, setIsPayNowClicked] = useState<boolean>(false)
  const [TempMemory, setTempMemory] = useState<any>({ OTPRequested: false, AadharVerified: false })
  const [TempMemorybyelaws, setTempMemorybyelaws] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  const [TempMemorymember, setTempMemorymember] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })

  const [display, setdisplay] = useState<boolean>(false)
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const [aadhaarUserResponse, setAadhaarUserResponse] = useState<any>({})
  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  // const [existingMembers, setexistingMembers] = useState<any>({})
  const [currentDistrict, setCurrentDistrict] = useState<any>([])
  const [currentMandal, setCurrentMandal] = useState<any>([])
  // setCurrentsocietyDistrict
  const [currentsocietyDistrict, setCurrentsocietyDistrict] = useState<any>([])
  const [currentsocietyMandal, setCurrentsocietyMandal] = useState<any>([])
  const [currentmemberDistrict, setCurrentmemberDistrict] = useState<any>([])
  const [currentmemberMandal, setCurrentmemberMandal] = useState<any>([])
  const [currentauditorDistrict, setCurrentauditorDistrict] = useState<any>([])
  const [currentauditorMandal, setCurrentauditorMandal] = useState<any>([])

  const [errors, setErrors] = useState<any>({})
  const router = useRouter()
  const dispatch = useAppDispatch()
  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }
  const [locData, setLocData] = useState<any>({})

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLocData(data)
    }

  }, [])
  // const popupState = () => {
  //   let data: any = localStorage.getItem("FASPLoginDetails")
  //   if (!data || data == null || data == "") {
  //     router.push("/")
  //   }
  // }
  // useEffect(() => {
  //   window.addEventListener("popstate", () => {
  //     popupState()
  //   })
  //   return () => {
  //     window.removeEventListener("popstate", () => {
  //       popupState()
  //     })
  //   }
  // }, [])
  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }
  const [roleList] = useState<any>([
    "President",
    "Vice President",
    "Secretary",
    "Joint Secretary",
    "Treasurer",
    "Member",
  ])
  const [typelist] = useState<any>(["Individual", "Corporate"])
  const [relationtypelist] = useState<any>(["S/O", "D/O", "W/O", "H/O"])

  // let Documentsoption: any = useAppSelector((state) => state.form.DocumentDetails)
  const file2Base64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = () => resolve(reader.result?.toString() || "")
      reader.onerror = (error) => reject(error)
    })
  }
  const [categorylist] = useState<any>([
    "Promotion of Art",
    "Fine Art",
    "Charity",
    "Crafts",
    "Religion",
    "Sports",
    "Literature",
    "Culture",
    "Science",
    "Political Education",
    "Philosophy",
    "Public Purpose",
  ])
  const [applicantDetails, setApplicantDetails] = useState<IApplicationDetailsModel>({
    maskedAadhar: "",
    aadharNumber: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    applicationNumber: "",
    name: "",
    relationType: "",
    relationName: "",
    role: "",
    gender: "",
    age: "",
    doorNo: "",
    street: "",
    country: "",
    state: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    email: "",
    mobileNumber: "",
  })

  const [activeTab, setActiveTab] = useState<number>(0)
  const renderTabHeaders = (): any => {
    return tabs.map((item: string, index: number) => {
      return (
        <div
          className={activeTab === index ? styles.activeTabHeaderlogin : styles.tabHeaderlogin}
          key={index}
        // onClick={() => {
        //   if (activeTab === 0) {
        //     if (Object.keys(validateForm()).length != 0) {
        //       setActiveTab(activeTab + 1)
        //     } else {
        //       ShowAlert(false, " wrong")
        //     }
        //   } else if (activeTab === 1) {
        //     if (Object.keys(validateForm()).length != 0) {
        //       setActiveTab(activeTab + 1)
        //     } else {
        //       ShowAlert(false, " wrong")
        //     }
        //   } else if (activeTab === 2) {
        //     if (Object.keys(validateForm()).length != 0) {
        //       setActiveTab(activeTab + 1)
        //     } else {
        //       ShowAlert(false, " wrong")
        //     }
        //   }
        // }}
        >
          {item}
        </div>
      )
    })
  }

  const [societyDetails, setSocietyDetails] = useState<ISocitiesDetailsModel>({
    societyName: "",
    category: "",
    generalBodyMeeting: "",
    doorNo: "",
    street: "",
    state: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    aim: "",
    objective: "",
    mobileNumber: "",
    email: "",

    nameOfRegistrationDistrict: "",
  })
  const [byelawDetails, setbyelawDetails] = useState<IByLawsDetailsModel | any>({
    maskedAadhar: "",
    societyName: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    relationType: "",
    doorNo: "",
    street: "",
    state: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    quorumSize: "",
    memberName: "",
    memberType: "",
    aadharNumber: "",
    relationName: "",
    joiningDate: "",
    qualification: "",
    occupation: "",
    role: "",
    mobileNumber: "",
    email: "",
    // phone: "",
    membershipConditions: "",
    finance: "",
    auditor: "",
    raisingFunds: "",
    officeBearers: "",
    liabilityConditions: "",
    meetingConditions: "",
    otherMatters: "",
  })
  const [auditorDetails, setauditorDetails] = useState<IByLawsDetailsModel | any>({
    auditorName: "",
    mobileNumber: "",
    email: "",
    doorNo: "",
    Street: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
  })

  const auditorDetailsChange = (event: any) => {
    let data: any = { ...auditorDetails }
    data[event.target.name] = event.target.value
    setauditorDetails(data)
  }
  async function getFileFromUrl(url: any, name: any, defaultType = "pdf") {
    const response = await instance.get(url, { responseType: "arraybuffer" })

    return new File([response.data], name, {
      type: defaultType,
    })
  }
  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  const goToPrevTab = (): void => {
    if (document.getElementById("tabDiv")) {
      document.getElementById("tabDiv")?.scrollIntoView()
    }
    setActiveTab(activeTab < 1 ? activeTab : activeTab - 1)
  }
  const paynowclicked = () => {
    if (Object.keys(validateForm()).length === 0) {

      setIsPayNowClicked(true)
    } else {
      ShowAlert(false, "please fill required fields")
    }
  }

  const ageCalculator = (dateOfBirth: any) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    //calculate month difference from current date in time
    let month_diff = Date.now() - dob.getTime()

    //convert the calculated difference in date format
    let age_dt = new Date(month_diff)

    //extract year from date
    let year = age_dt.getUTCFullYear()

    //now calculate the age of the user
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }

  React.useEffect(() => {
    Loading(true)
    const isResubmit: any = localStorage.getItem("isResubmission")
    if (isResubmit == "true") {
      setIsResubmission("true")
    }
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data) {
      setToken(data.token)
      setLoggedInAadhar(data.aadharNumber)
      setApplicantDetails({
        ...applicantDetails,
        applicationNumber: data.applicationNumber,
      })
      instance
        .get("/getDistricts")
        .then((response) => {
          setDistricts(response.data)
          getSocietyDetails(data.applicationId, data.token)
            .then((response) => {
              if (response?.success) {
                if (!isResubmit) {
                  setExistingSocietyDetail(response.data.daSociety)
                  if (response.data.daSociety.societyDetails) {
                    setSocietyDetails({
                      ...societyDetails,
                      category: response.data.daSociety.category
                        ? response.data.daSociety.category
                        : "",
                      generalBodyMeeting: response.data.daSociety.generalBodyMeeting
                        ? response.data.daSociety.generalBodyMeeting
                        : "",
                      doorNo: response.data.daSociety.doorNo
                        ? response.data.daSociety.doorNo
                        : "",
                      street: response.data.daSociety.street
                        ? response.data.daSociety.street
                        : "",
                      state: response.data.daSociety.state
                        ? response.data.daSociety.state
                        : "Andhra Pradesh",
                      district: response.data.daSociety?.district
                        ? response.data.daSociety?.district
                        : "",
                      mandal: response.data.daSociety.mandal
                        ? response.data.daSociety.mandal
                        : "",
                      villageOrCity: response.data.daSociety.villageOrCity
                        ? response.data.daSociety.villageOrCity
                        : "",
                      pinCode: response.data.daSociety.pinCode
                        ? response.data.daSociety.pinCode
                        : "",
                      societyName: response.data.daSociety?.societyName
                        ? response.data.daSociety?.societyName
                        : "",
                      aim: response.data.daSociety?.aim
                        ? response.data.daSociety?.aim
                        : "",
                      objective: response.data.daSociety?.objective
                        ? response.data.daSociety?.objective
                        : "",
                      mobileNumber: response.data.daSociety.mobileNumber
                        ? response.data.daSociety.mobileNumber
                        : "",
                      email: response.data.daSociety.email
                        ? response.data.daSociety.email
                        : "",
                      nameOfRegistrationDistrict: response.data.daSociety.societyDetails
                        ?.nameOfRegistrationDistrict
                        ? response.data.daSociety.nameOfRegistrationDistrict
                        : "",
                    })
                  }
                  if (
                    response.data.daSociety?.memberDetails &&
                    response.data.daSociety?.memberDetails?.length > 0
                  ) {
                    response.data.daSociety.memberDetails.forEach(
                      (a: any) =>
                        (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber?.toString().substring(8, 12))
                    )
                    setMembersDetails([...response.data.daSociety.memberDetails])
                  }
                  if (response.data.daSociety.auditorDetails) {
                    setauditorDetails({
                      ...auditorDetails,
                      auditorName: response.data.daSociety.auditorDetails.auditorName,
                      mobileNumber: response.data.daSociety.auditorDetails.mobileNumber,
                      email: response.data.daSociety.auditorDetails.email,
                      doorNo: response.data.daSociety.applicantDetails.doorNo,
                      street: response.data.daSociety.applicantDetails.street,
                      district: response.data.daSociety.applicantDetails.district,
                      mandal: response.data.daSociety.applicantDetails.mandal,
                      villageOrCity: response.data.daSociety.applicantDetails.villageOrCity,
                      pinCode: response.data.daSociety.applicantDetails.pinCode,
                    })
                    setCurrentauditorDistrict(response.data.daSociety.auditorDetails.district)
                    setCurrentauditorMandal(response.data.daSociety.auditorDetails.mandal)
                  }
                  if (response.data.daSociety.byeLaws) {
                    setbyelawDetails({
                      ...byelawDetails,
                      quorumSize: Math.round((response.data.daSociety.memberDetails.length / 2) + 1),
                      societyName: response.data.daSociety.byeLaws.name,
                      gender: response.data.daSociety.byeLaws.gender,
                      doorNo: response.data.daSociety.byeLaws.doorNo,
                      street: response.data.daSociety.byeLaws.street,
                      country: response.data.daSociety.byeLaws.country,
                      state: response.data.daSociety.byeLaws.state,
                      district: response.data.daSociety.byeLaws.district,
                      mandal: response.data.daSociety.byeLaws.mandal,
                      villageOrCity: response.data.daSociety.byeLaws.villageOrCity,
                      pinCode: response.data.daSociety.byeLaws.pinCode,
                      email: response.data.daSociety.byeLaws.email,
                      mobileNumber: response.data.daSociety.byeLaws.mobileNumber,
                    })
                  }
                  if (response.data.daSociety.applicantDetails) {
                    setApplicantDetails({
                      ...applicantDetails,
                      applicationNumber: data.applicationNumber,
                      email: response.data.daSociety.applicantDetails.email,
                      mobileNumber: response.data.daSociety.applicantDetails.mobileNumber,
                      maskedAadhar:
                        "XXXXXXXX" +
                        response.data.daSociety.applicantDetails.aadharNumber
                          ?.toString()
                          .substring(8, 12),
                      aadharNumber: response.data.daSociety.applicantDetails.aadharNumber,
                      name: response.data.daSociety.applicantDetails.name,
                      gender: response.data.daSociety.applicantDetails.gender,
                      doorNo: response.data.daSociety.applicantDetails.doorNo,
                      street: response.data.daSociety.applicantDetails.street,
                      country: response.data.daSociety.applicantDetails.country,
                      state: response.data.daSociety.applicantDetails.state,
                      district: response.data.daSociety.applicantDetails.district,
                      mandal: response.data.daSociety.applicantDetails.mandal,
                      villageOrCity: response.data.daSociety.applicantDetails.villageOrCity,
                      pinCode: response.data.daSociety.applicantDetails.pinCode,
                      relationType: response.data.daSociety.applicantDetails.relationType,
                      relationName: response.data.daSociety.applicantDetails.relationName,
                      role: response.data.daSociety.applicantDetails.role,
                      age: response.data.daSociety.applicantDetails.age,
                      // otpStatus: "1",
                      // otpCode: "1",
                      // otpVerified: "true",
                    })

                    setCurrentDistrict(response.data.daSociety.applicantDetails.district)
                    setCurrentMandal(response.data.daSociety.applicantDetails.mandal)
                  }
                  if (response.data.daSociety.contactDetails) {
                    setContactDetails({
                      mobileNumber: response.data.daSociety.contactDetails.mobileNumber,
                      fax: response.data.daSociety.contactDetails.fax,
                      email: response.data.daSociety.contactDetails.email,
                      phone: response.data.daSociety.contactDetails.phone,
                      deliveryType: response.data.daSociety.contactDetails.deliveryType,
                    })
                  }
                  if (response.data.daSociety.documentAttached?.length) {
                    response.data.daSociety.documentAttached.forEach((z: any) => {
                      if (z.originalname) {
                        // const fileName=z.originalname.split('_')[1]
                        // const url='/assets/downloads/Societies-Self-Signed-Certificate.pdf'
                        // const link = document.createElement('a');
                        // link.href =url;
                        // link.setAttribute('download',fileName)
                        // document.body.appendChild(link);
                        // link.click();
                        // document.body.removeChild(link);
                        const fileName = z.originalname.split("_")[1]
                        getFileFromUrl(
                          `/downloads/${response.data.daSociety._id}/${z.originalname}`,
                          fileName
                        ).then((response) => {
                          let inputEle = document.getElementById(
                            fileName.split(".")[0]
                          ) as HTMLInputElement
                          if (inputEle !== null) {
                            const dataTransfer = new DataTransfer()
                            dataTransfer.items.add(response)
                            inputEle.files = dataTransfer.files
                            const newInput = (data: any) => ({
                              ...data,
                              [fileName.split(".")[0]]: response,
                            })
                            setFile(newInput)
                          }
                        })
                      }
                    })
                  }
                }
                else {
                  setSocietyDetails({
                    ...societyDetails,
                    district: response.data.daSociety?.district
                      ? response.data.daSociety?.district
                      : "",
                    societyName: response.data.daSociety?.societyName
                      ? response.data.daSociety?.societyName
                      : "",
                  })
                }
              }
            })
            .catch(() => {
              Loading(false)
            })
          Loading(false)
        })
        .catch(() => {
          Loading(false)
        })
    }
  }, [])
  const [contactDetails, setContactDetails] = useState<IContactDetailsModel>({
    mobileNumber: "",
    email: "",
    phone: "",
    fax: "",
    deliveryType: "",
  })
  // const [conditions, setconditions] = useState<any>([
  //   {
  //     soundMind: "Yes",
  //     inSolvent: "No",
  //     offense: "No",
  //     appointment: "No",
  //     otpStatus: "1",
  //     otpCode: "1",
  //     otpVerified: "true",
  //   },])
  const [indexmember, setindexmember] = useState<any>(-1)
  const [membersDetails, setMembersDetails] = useState<any>([
    // {
    //   memberType: "",
    //   relationName: "",
    //   joiningDate: "",
    //   qualification: "",
    //   soundMind: "",
    //   inSolvent: "",
    //   offense: "",
    //   appointment: "",
    //   maskedAadhar: "",
    //   aadharNumber: "",
    //   gender: "",
    //   role: "",
    //   age: "",
    //   otpStatus: "",
    //   otpCode: "",
    //   otpVerified: "",
    //   occupation: "",
    //   doorNo: "",
    //   street: "",
    //   country: "India",
    //   state: "Andhra Pradesh",
    //   district: "",
    //   mandal: "",
    //   villageOrCity: "",
    //   pinCode: "",

    //   mobileNumber: "",
    //   email: "",
    //   memberName: "",
    //   relationType: "",
    // },
  ])
  const [checkedList, setCheckedList] = useState<string[]>([])

  const [checkedItems, setCheckedItems] = useState<any[]>([])
  const changeCheck = (e: React.ChangeEvent<HTMLInputElement>) => {
    const checkedValue = e.target.value
    const isChecked = e.target.checked
    // 
    if (isChecked) {
      setCheckedList((prevCheckedList) => [...prevCheckedList, checkedValue])
      //  array list
      const checkedItem = membersDetails.find((item: any) => item?.memberName == checkedValue)
      if (checkedItem && !checkedItems.some((item) => item?.memberName === checkedValue)) {
        setCheckedItems((prevCheckedItems) => [...prevCheckedItems, checkedItem])
      } else {
        setCheckedList((prevCheckedList) =>
          prevCheckedList.filter((value) => value !== checkedValue)
        )
      }
    } else {
      setCheckedList((prevCheckedList) => prevCheckedList.filter((value) => value !== checkedValue))
      setCheckedItems((prevCheckedItems) =>
        prevCheckedItems.filter((item) => item?.memberName !== checkedValue)
      )
    }
  }
  console.log("checked", checkedItems)
  const [selectedCount, setSelectedCount] = useState(0)
  const handleCheckboxChange = (event: any) => {
    const checkbox = event.target
    if (checkbox.checked) {
      if (selectedCount >= 3) {
        checkbox.checked = false
        return
      }
      setSelectedCount(selectedCount + 1)
    } else {
      setSelectedCount(selectedCount - 1)
    }
  }
  const validateForm = () => {
    // 
    const errors: any = {}
    const byelawDet = { ...byelawDetails }
    const auditorDet = { ...auditorDetails }
    const societyDet = { ...societyDetails }
    const applicantDet = { ...applicantDetails }
    const memberDet = [{ ...membersDetails }]
    let nameRegex = /^[a-zA-Z ]{2,50}$/
    if (activeTab === 0) {
      // if (!applicantDet.aadharNumber) {
      //   ShowMessagePopup(false, "Please validate aadhar number")
      //   return false
      // } else if (applicantDet.aadharNumber !== "") {
      //   if (applicantDet.otpCode == "") {
      //     ShowMessagePopup(false, "Please validate aadhar number")
      //     return false
      //   }
      // }
      if (!applicantDet.relationName) {
        ShowMessagePopup(false, "Please Enter Relation Name")
        return false
      }
      if (!applicantDet.role) {
        ShowMessagePopup(false, "Please Enter role")
        return false
      }
      if (!applicantDet.doorNo) {
        ShowMessagePopup(false, "Please enter door number")
        return false
      }
      if (!applicantDet.district) {
        ShowMessagePopup(false, "Please select Applicant District")
        return false
      }
      if (!applicantDet.mandal) {
        ShowMessagePopup(false, `Please enter Applicant Mandal`)
        return false
      }
      if (!applicantDet.villageOrCity) {
        ShowMessagePopup(false, "Please enter Applicant Village Or City")
        return false
      }
      if (!applicantDet.pinCode || applicantDet?.pinCode?.toString()?.length != 6) {
        ShowMessagePopup(false, "Please enter pinCode")
        return false
      }
    } else if (activeTab === 1) {
      if (!societyDet.category) {
        ShowMessagePopup(false, "Please enter Category")
        return false
      }
      if (!societyDet.generalBodyMeeting) {
        ShowMessagePopup(false, "Please enter Eeneral Body Meeting")
        return false
      }
      if (!societyDet.doorNo) {
        ShowMessagePopup(false, "Please enter door number")
        return false
      }
      if (!societyDet.mandal) {
        ShowMessagePopup(false, "Please enter Mandal")
        return false
      }
      if (!societyDet.villageOrCity) {
        ShowMessagePopup(false, "Please enter Village Or City")
        return false
      }
      if (!societyDet.pinCode || societyDet?.pinCode?.toString()?.length != 6) {
        ShowMessagePopup(false, "Please enter pinCode")
        return false
      }
      if (!societyDet.aim) {
        ShowMessagePopup(false, "Please enter Aim of the Society")
        return false
      }
      if (!societyDet.objective) {
        ShowMessagePopup(false, "Please enter objective of the society")
        return false
      }
      if (!societyDet.mobileNumber) {
        ShowMessagePopup(false, "Please enter phone number")
        return false
      }
      return true

    } else if (activeTab === 2) {
      if (membersDetails.length < 3) {
        const remainingMem = 3 - membersDetails.length
        ShowMessagePopup(
          false,
          `Please add ${remainingMem} more member${remainingMem == 1 ? "" : "s"
          } to continue payment`
        )
        return false;
      }
      return true;
    } else if (activeTab === 3) {

      if (byelawDet.membershipConditions !== "Yes") {
        ShowMessagePopup(false, "Please select validate option membership Conditions")
        return false
      }
      if (byelawDet.finance !== "Yes") {
        ShowMessagePopup(false, "Please select validate option finance")
        return false
      }
      if (byelawDet.auditor == "No") {
        ShowMessagePopup(false, "Please select validate option auditor")
        return false
      }
      if (byelawDet.auditor == "Yes") {
        if (!auditorDet.auditorName) {
          ShowMessagePopup(false, "Please enter the Name of the Auditor")
          return false
        }
        if (!auditorDet.mobileNumber) {
          ShowMessagePopup(false, "Please enter the Mobile Number")
          return false
        }

        if (!auditorDet.doorNo) {
          ShowMessagePopup(false, "Please enter the Door No ")
          return false
        }

        if (!auditorDet.district) {
          ShowMessagePopup(false, "Please enter the District ")
          return false
        }
        if (!auditorDet.mandal) {
          ShowMessagePopup(false, "Please enter the Mandal")
          return false
        }
        if (!auditorDet.villageOrCity) {
          ShowMessagePopup(false, "Please enter the  villageOrCity ")
          return false
        }
        if (!auditorDet.pinCode || auditorDet?.pinCode?.toString()?.length != 6) {
          ShowMessagePopup(false, "Please enter the  pinCode ")
          return false
        }
      }
      if (byelawDet.raisingFunds !== "Yes") {
        ShowMessagePopup(false, "Please select validate option raisingFunds")
        return false
      }
      if (byelawDet.officeBearers !== "Yes") {
        ShowMessagePopup(false, "Please select validate option officeBearers")
        return false
      }
      if (byelawDet.liabilityConditions !== "Yes") {
        ShowMessagePopup(false, "Please select validate option liabilityConditions")
        return false
      }
      if (byelawDet.meetingConditions !== "Yes") {
        ShowMessagePopup(false, "Please select validate option meetingConditions")
        return false
      }
      if (byelawDet.otherMatters !== "Yes") {
        ShowMessagePopup(false, "Please select validate option otherMatters")
        return false
      }
      return true
    } else {
      return true
    }
    setErrors({ ...errors })
    return errors
  }

  const [file, setFile] = useState<any>([])
  const [existingMembersdetails, setexistingMembersdetails] = useState<
    IExistingMemberDetailsModel[]
  >([
    {
      memberType: "",
      relationName: "",
      joiningDate: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      address: "",
      occupation: "",
      mobileNumber: "",
      memberName: "",
    },
  ])
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [maxTotalMembers, setMaxTotalMembers] = useState<number>(1)
  const tableHeaders2: any = [
    // <>
    //   {" "}
    //   <Form.Check
    //     style={{ height: "50%", paddingBottom: "10px", marginLeft: "10px" }}
    //     inline
    //     label=""
    //     name=""
    //     type="checkbox"
    //     className="fom-checkbox my-1"
    //     onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
    //       const value = e.target.checked
    //       const checkedItems = [...membersDetails]
    //       const selectedItems: string[] = []
    //       if (value) {
    //         checkedItems.forEach((element: any) => {
    //           selectedItems.push(element.memberName)
    //         })
    //       } else {
    //         selectedItems.splice(0, selectedItems.length)
    //       }
    //       setCheckedList(selectedItems)
    //       setCheckedItems(selectedItems)
    //     }}
    //     checked={checkedList.length === membersDetails.length}

    //   />
    // </>,
    "Type",
    "Aadhaar No ",
    "Name of the Member",
    "Relation Name",
    "Age / Gender",
    "Role/Position",
    "Occupation",
    "Date of Joining",
    "Address",
    "Contact",
  ]
  const [SelectedMemberDetails, setSelectedMemberDetails] =
    useState<any>({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })

  const [updatedmemberdetails, setupdatedmemberdetails] = useState<any>([])
  // const handleMemberAdd = (event: any) => {
  //   let tempdetails = { ...membersDetails }
  //   event.preventDefault();
  //   let details:any[]=[...updatedmemberdetails]
  //   membersDetails.push(tempdetails)
  //   setupdatedmemberdetails("")
  //   console.log("updated", updatedmemberdetails)
  // }
  const handleMemberUpdate = (index: any) => {
    let object: any = { ...SelectedMemberDetails }
    if (
      object.aadharNumber == "" ||
      object.relationType == "" ||
      object.gender == "" ||
      object.memberType == "" ||
      object.age == "" ||
      object.doorNo == "" ||
      object.district == "" ||
      object.mandal == "" ||
      object.villageOrCity == "" ||
      object.pinCode == "" ||
      object.relationName == "" ||
      object.mobileNumber == "" ||
      object.joiningDate == "" ||
      object.role == "" ||
      object.qualification == "" ||
      object.occupation == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for Updated Member", "")
    } else if (object.soundMind !== "Yes") {
      return ShowMessagePopup(false, "Please select validate option for soundMind", "")
    } else if (object.inSolvent !== "No") {
      return ShowMessagePopup(false, "Please select validate option for insolvent", "")
    }
    else if (object.offense !== "No") {
      return ShowMessagePopup(false, "Please select validate option for offense", "")
    } else if (object.appointment !== "No") {
      return ShowMessagePopup(false, "Please select validate option for appointment", "")
    } else if (!object.memberType) {
      return ShowMessagePopup(false, "Please select member type", "")
    } else if (!object.mandal) {
      return ShowMessagePopup(false, "Please select mandal", "")
    } else if (!object.villageOrCity) {
      return ShowMessagePopup(false, "Please select village or city", "")
    }

    let Details: any[] = [...membersDetails]
    Details.splice(index, 1, object)
    setMembersDetails([...Details])
    console.log("index", index)
    setTempMemorymember({ OTPRequested: false, AadharVerified: false })
    setSelectedMemberDetails({
      //   OTPResponse: { transactionNumber: "" },
      // KYCResponse: {},
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, " Member Updated Successfully", "")
    setindexmember(-1)
  }
  const handleMemberAdd = () => {
    // 
    let object: any = { ...SelectedMemberDetails }
    if (
      object.aadharNumber == "" ||
      object.relationType == "" ||
      object.gender == "" ||
      object.age == "" ||
      object.doorNo == "" ||
      object.district == "" ||
      object.mandal == "" ||
      object.villageOrCity == "" ||
      object.pinCode == "" ||
      object.relationName == "" ||
      object.mobileNumber == "" ||
      object.joiningDate == "" ||
      object.role == "" ||
      object.qualification == "" ||
      object.memberType == "" ||

      object.occupation == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for New member", "")
    } else if (object.soundMind !== "Yes") {
      return ShowMessagePopup(false, "Please select validate option for soundMind", "")
    } else if (object.inSolvent !== "No") {
      return ShowMessagePopup(false, "Please select validate option for insolvent", "")
    } else if (!object.memberType) {
      return ShowMessagePopup(false, "Please select member type", "")
    }
    else if (object.offense !== "No") {
      return ShowMessagePopup(false, "Please select validate option for offense", "")
    } else if (object.appointment !== "No") {
      return ShowMessagePopup(false, "Please select validate option for appointment", "")
    } else if (!object.mandal) {
      return ShowMessagePopup(false, "Please select mandal", "")
    } else if (!object.villageOrCity) {
      return ShowMessagePopup(false, "Please select village or city", "")
    } else if (
      object.mobileNumber &&
      (object.mobileNumber.length != 10 ||
        (object.mobileNumber.length == 10 &&
          object.mobileNumber.charAt(0) != "6" &&
          object.mobileNumber.charAt(0) != "7" &&
          object.mobileNumber.charAt(0) != "8" &&
          object.mobileNumber.charAt(0) != "9"))
    ) {
      return ShowMessagePopup(false, "Please enter vaild mobile number", "")
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some((x: any) => x.aadharNumber?.toString() == object.aadharNumber?.toString())
    ) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }

      )
      return ShowMessagePopup(
        false,
        "Aadhaar number is already exist. Please enter new aadhaar number",
        ""
      )
    } else if (parseInt(object.age) < 18) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }
      )
      return ShowMessagePopup(false, "Minimum age of partner should be 18", "")
    } else if (parseInt(object.share) < 0 || parseInt(object.share) >= 100) {
      return ShowMessagePopup(false, "share should be above 0 and less than 100 percent", "")
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some((x: any) => parseInt(x.mobileNumber) == parseInt(object.mobileNumber))
    ) {
      return ShowMessagePopup(
        false,
        "Mobile number is already exist. Please enter new mobile number",
        ""
      )
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some(
        (x: any) =>
          x.email != "" &&
          x.email?.length > 0 &&
          x.email.trim() != "" &&
          object.email != "" &&
          object.email.length > 0 &&
          object.email.trim() != "" &&
          x.email.toLowerCase() == object.email.toLowerCase()
      )
    ) {
      return ShowMessagePopup(false, "email is already exist. Please enter new email", "")
    }
    let Details: any[] = [...membersDetails]
    Details.push(object)
    setMembersDetails(Details)
    setTempMemorymember({ OTPRequested: false, AadharVerified: false })
    setSelectedMemberDetails({
      //   OTPResponse: { transactionNumber: "" },
      // KYCResponse: {},
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, "New Member Added Successfully", "")
  }
  const ref = useRef(null)
  const refUpdate = useRef(null)
  const refDelete = useRef(null)
  const handlebyelawAdd = () => {
    setbyelawDetails({
      ...byelawDetails,
      //   OTPResponse: { transactionNumber: "" },
      // KYCResponse: {},
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
  }
  const Radiobutton = {
    list: [
      { value: "Yes", label: "Yes" },
      { value: "No", label: "No" },
    ],
  }
  const handleUploadClick = () => {
    inputRef.current?.click()
  }
  const generateOtp = async () => {
    if (SelectedMemberDetails.otpCode) {
      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(SelectedMemberDetails.aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: SelectedMemberDetails.otpCode,
      })
      console.log("result:::", result)
      Loading(false)

      // let age =  ageInDays / 365 ;
      if (result.status && result.status === "Success") {
        let data = { ...SelectedMemberDetails }
        data["name"] = result.userInfo.name
        data["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        data["country"] = result.userInfo.country
        data["relationName"] = result.userInfo.co
        data["state"] = result.userInfo.state
        data["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data["street"] = result.userInfo.street
        data["district"] = result.userInfo.dist.toUpperCase()
        data["pinCode"] = result.userInfo.pc
        data["age"] = ageCalculator(result.userInfo.dob)
        data["otpVerified"] = "true"
        setSelectedMemberDetails(data)
        // setMembersDetails(data)
        setCurrentDistrict(result.userInfo.dist.toUpperCase())
      } else {
        let data = { ...applicantDetails }
        data["otpVerified"] = "false"
        setSelectedMemberDetails(data)
        ShowAlert(false, get(result, "message", "Aadhaar API Failed"))
      }
    }
  }
  const verifyOtp = async () => {
    if (SelectedMemberDetails.otpCode) {
      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(SelectedMemberDetails.aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: SelectedMemberDetails.otpCode,
      })
      console.log("result:::", result)
      Loading(false)

      // let age =  ageInDays / 365 ;
      if (result.status && result.status === "Success") {
        let data = { ...SelectedMemberDetails }
        data["name"] = result.userInfo.name
        data["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        data["country"] = result.userInfo.country
        data["relationName"] = result.userInfo.co
        data["state"] = result.userInfo.state
        data["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data["street"] = result.userInfo.street
        data["district"] = result.userInfo.dist.toUpperCase()
        data["pinCode"] = result.userInfo.pc
        data["age"] = ageCalculator(result.userInfo.dob)
        data["otpVerified"] = "true"
        setSelectedMemberDetails(data)
        // setMembersDetails(data)
        setCurrentDistrict(result.userInfo.dist.toUpperCase())
      } else {
        let data = { ...SelectedMemberDetails }
        data["otpVerified"] = "false"
        setSelectedMemberDetails(data)
        ShowAlert(false, get(result, "message", "Aadhaar API Failed"))
      }
    }
  }
  const countryList = ["India"]
  const stateList = ["Andhra Pradesh"]

  const genderList = ["Female", "Male", "Other"]

  const [mandals, setmandals] = useState<any>([])
  const [applicantCities, setApplicantCities] = useState<any>([])

  const [societyMandals, setSocietyMandals] = useState<any>([])
  const [societyCities, setSocietyCities] = useState<any>([])

  // useEffect(() => {
  //   console.log('mounted');
  //   return () => console.log('unmounting...');
  // }, [currentDistrict,currentMandal])
  const ReqDetails = async (MyKey: any) => {
    let result = await CallingAxios(
      UseGetAadharDetails({
        aadharNumber: btoa(MyKey.aadharNumber),
        transactionNumber: MyKey?.OTPResponse?.transactionNumber,
        otp: MyKey.otpCode,
      })
    )
    if (
      result.status &&
      result.status === "Success" &&
      MyKey?.OTPResponse?.transactionNumber == result.transactionNumber.split(":")[1]
    ) {
      let latestData: any = {
        ...MyKey,
        name: result.userInfo.name ? result.userInfo.name : "",
        memberName: result.userInfo.name ? result.userInfo.name : "",
        relationType: result.userInfo.co ? result.userInfo.co.substring(0, 3) : "",
        relationName: result.userInfo.co ? result.userInfo.co.substring(4) : "",
        age: result.userInfo.dob ? ageCalculator(result.userInfo.dob) : "",
        gender: result.userInfo.gender == "M" ? "Male" : "Female",
        district: result.userInfo.dist ? result.userInfo.dist : "",
        pinCode: result.userInfo.pc ? result.userInfo.pc : "",
        street: result.userInfo.loc ? result.userInfo.street : "",
        villageOrCity: result.userInfo.vtc ? result.userInfo.vtc : "",
        doorNo: result.userInfo.house ? result.userInfo.house : "",
        address:
          (result.userInfo.lm ? result.userInfo.lm + ", \n" : "") +
          (result.userInfo.loc ? result.userInfo.loc + ", \n" : "") +
          (result.userInfo.dist ? result.userInfo.dist + ", \n" : "") +
          (result.userInfo.vtc ? result.userInfo.vtc : "") +
          (result.userInfo.pc ? "-" + result.userInfo.pc : ""),
        OTPResponse: result,
      }

      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails(latestData)
          setTempMemory({ OTPRequested: false, AadharVerified: true })
          break
        case SelectedMemberDetails:
          setSelectedMemberDetails(latestData)
          setTempMemorymember({ OTPRequested: false, AadharVerified: true })
          break

        default:
          break
      }
    } else {
      ShowMessagePopup(false, "Please Enter Valid OTP", "")
      setApplicantDetails({
        ...applicantDetails,
        otpCode: "",

      })
    }
  }
  const ReqOTP = (MyKey: any) => {
    if (MyKey.aadharNumber && MyKey.aadharNumber.length == 12) {
      CallGetOTP(MyKey)
    } else {
      ShowMessagePopup(false, "Kindly enter valid Aadhar number", "")
    }
  }
  const CallingAxios = async (myFunction: any) => {
    Loading(true)
    let result = await myFunction
    Loading(false)
    return result
  }

  const CallGetOTP = async (MyKey: any) => {
    if (process.env.IGRS_SECRET_KEY) {
      const ciphertext = AES.encrypt(MyKey.aadharNumber, process.env.IGRS_SECRET_KEY)
      let result = await CallingAxios(UseGetAadharOTP(ciphertext.toString()))

      if (result && result.status != "Failure") {
        switch (MyKey) {
          case applicantDetails:
            setTempMemory({ OTPRequested: true, AadharVerified: false })
            break
          case SelectedMemberDetails:
            setTempMemorymember({ OTPRequested: true, AadharVerified: false })
            break
          default:
            break
        }
        switch (MyKey) {
          case applicantDetails:
            setApplicantDetails({ ...MyKey, OTPResponse: result })
            break
          case SelectedMemberDetails:
            setSelectedMemberDetails({ ...MyKey, OTPResponse: result })
            break
          default:
            break
        }
        ShowMessagePopup(
          true,
          "OTP Sent to Aadhaar Registered Mobile Number.",
          ""
        )
      }
      else {

        switch (MyKey) {
          case applicantDetails:
            setApplicantDetails({
              ...MyKey,
              otpCode: "",
              OTPResponse: { transactionNumber: "" },
              KYCResponse: {},
            })
            setTempMemory({ OTPRequested: false, AadharVerified: false })
            break
          case SelectedMemberDetails:
            setSelectedMemberDetails({
              ...MyKey,
              otpCode: "",
              OTPResponse: { transactionNumber: "" },
              KYCResponse: {},
            })
            setTempMemorymember({ OTPRequested: false, AadharVerified: false })
            break
          default:
            break
        }
        ShowMessagePopup(false, "Please Enter Valid Aadhar", "")
        setApplicantDetails({
          ...applicantDetails,
          maskedAadhar: "",

        })
      }
    }
  }
  // const handleChange = (event) => { const { value: inputValue } = event?.target;

  // if (inputValue.includes('.com')) {
  // setValue(inputValue.slice(0, inputValue.indexOf('.com') + 4)); } else { setValue(inputValue); } };
  const [displayOption, setDisplayOption] = useState("display")
  const applicantDetailsChange = (e: any) => {
    let TempDetails: IApplicationDetailsModel = { ...applicantDetails }
    let AddName = e.target.name
    let AddValue = e.target.value
    // if(AddName=="email"){
    //   handleChange()
    // }

    if (AddName == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        e.target.value.length > 0 &&
        e.target.value.length > applicantDetails.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          applicantDetails.aadharNumber.substring(0, startpos) +
          applicantDetails.aadharNumber.substring(
            startpos + 1,
            applicantDetails.aadharNumber.length
          )
      }
      setApplicantDetails({
        ...TempDetails,
        [AddName]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? applicantDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      setApplicantDetails({ ...TempDetails, [AddName]: AddValue })
    }
  }
  const membersDetailsChange = (e: any) => {
    let tempDetails: any = { ...SelectedMemberDetails }
    let AddName = e.target.name
    let AddValue = e.target.value

    if (AddName == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        // SelectedMemberDetails.aadharNumber &&
        e.target.value.length > 0 &&
        e.target.value.length > SelectedMemberDetails?.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value && e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          SelectedMemberDetails?.aadharNumber?.substring(0, startpos) +
          SelectedMemberDetails?.aadharNumber?.substring(
            startpos + 1,
            SelectedMemberDetails?.aadharNumber?.length
          )
      }
      setSelectedMemberDetails({
        ...tempDetails,
        [AddName]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? SelectedMemberDetails?.aadharNumber + newNo : aadharNo,
      })
    } else {
      setSelectedMemberDetails({ ...tempDetails, [AddName]: AddValue })
    }
  }
  const districtChange = (e: any) => {
    // if(e.target.name == 'district'){
    //   setmandals([])
    //   setApplicantCities([])

    setCurrentDistrict(e.target.value)
    setCurrentMandal("")
    // }
  }

  const mandalChange = (e: any) => {
    setCurrentMandal(e.target.value)
  }

  // const districtsocietyChange = (e: any) => {
  //   setCurrentsocietyDistrict(e.target.value)
  //   setCurrentsocietyMandal("")
  // }
  const mandalsocietyChange = (e: any) => {
    setCurrentsocietyMandal(e.target.value)
  }

  const districtmemberChange = (e: any) => {
    setCurrentmemberDistrict(e.target.value)
    setCurrentmemberMandal("")
  }
  const mandalmemberChange = (e: any) => {
    setCurrentmemberMandal(e.target.value)
  }

  const districtauditorChange = (e: any) => {
    setCurrentauditorDistrict(e.target.value)
    setCurrentauditorMandal("")
  }
  const mandalauditorChange = (e: any) => {
    setCurrentauditorMandal(e.target.value)
  }
  const contactDetailsChange = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setContactDetails(newInput)
  }

  const societyDetailsChange = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setSocietyDetails(newInput)
    // handleChange(e)
  }
  const byelawsDetailsChange = (e: any) => {
    // let byelawDet=byelawDetails
    const data = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    // if(e.target.name=="quorumSize"){
    //   const dataquorum=(membersDetails.length/2)+1
    //   setbyelawDetails({...byelawDetails,quorumSize:dataquorum})
    // }
    setbyelawDetails(data)
  }
  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if (fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])) {
      // throw Error("Invalid File");
      ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
      e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if (fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])) {
      if (!regex) {
        ShowMessagePopup(false, "Please upload proper file name");
        e.target.value = "";
      }
    }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  const handleMemberRemove = (index: number) => {
    let data: any = [...membersDetails]
    data.splice(index, 1)
    setMembersDetails(data)
  }
  const handleMemberEdit = (index: number) => {
    Loading(true)
    setTimeout(() => {
      setCurrentmemberDistrict(membersDetails[index].district)
      setCurrentmemberMandal(membersDetails[index].mandal)
      setindexmember(index)
      setTempMemorymember({ OTPRequested: false, AadharVerified: true })

      setSelectedMemberDetails(membersDetails[index])

      console.log("membersDetails[index]", membersDetails[index])
      Loading(false)
    }, 800);

  }
  const handleSubmit = async (e: any) => {
    e.preventDefault()

    if (validateForm()) {

      const {
        idProofs,
        memorandum,
        byeLaws,
        affidavit,
        affidavitByAuditor,
        selfSignedDeclaration,
      } = file

      const idProofsDoc = idProofs

      const memorandumDoc = memorandum

      const affidavitByAuditorDoc = affidavitByAuditor

      const affidavitDoc = affidavit
      const byeLawsDoc = byeLaws
      const selfDoc = selfSignedDeclaration

      const data: any = {
        applicantDetails: applicantDetails,
        contactDetails: contactDetails,
        societyDetails: societyDetails,
        idProofs: idProofs,
        byelawDetails: byelawDetails,
        auditorDetails: auditorDetails,
        memorandum: memorandum,
        affidavitByAuditor: affidavitByAuditor,
        byeLaws: byeLaws,
        secretkey:process.env.SECRET_KEY,
        affidavit: affidavit,
        selfSignedDeclaration: selfSignedDeclaration,
        membersDetails: [...membersDetails.filter((x: any) => x.memberName.trim())],
      }
      const newData = new FormData()

      if (!existingSocietyDetail?.isResubmission && isResubmission == "true") {
        newData.append("isResubmission", "true")
      }
      let applicantaadhar = CryptoJS.AES.encrypt(data.applicantDetails.aadharNumber, data.secretkey).toString()
        
      newData.append("applicantDetails[aadharNumber]", CryptoJS.AES.encrypt(data.applicantDetails.aadharNumber,data.secretkey).toString())
      // newData.append("applicantDetails[applicationNumber]", existingSocietyDetail.applicationNumber)
      newData.append("applicantDetails[name]", CryptoJS.AES.encrypt(data.applicantDetails.name, data.secretkey).toString())
      newData.append("applicantDetails[relationType]", data.applicantDetails.relationType)
      newData.append("applicantDetails[age]", data.applicantDetails.age)
      newData.append("applicantDetails[role]", data.applicantDetails.role)
      newData.append("applicantDetails[relationName]", CryptoJS.AES.encrypt(data.applicantDetails.relationName, data.secretkey).toString())
      newData.append("applicantDetails[gender]", data.applicantDetails.gender)
      newData.append("applicantDetails[doorNo]", data.applicantDetails.doorNo)
      newData.append("applicantDetails[street]", data.applicantDetails.street)
      newData.append("applicantDetails[country]", "India")
      newData.append("applicantDetails[state]", "Andhra Pradesh")
      newData.append("applicantDetails[district]", data.applicantDetails.district)
      newData.append("applicantDetails[mandal]", data.applicantDetails.mandal)
      newData.append("applicantDetails[villageOrCity]", data.applicantDetails.villageOrCity)
      newData.append("applicantDetails[pinCode]", data.applicantDetails.pinCode)
      newData.append("applicantDetails[mobileNumber]", data.applicantDetails.mobileNumber)
      newData.append("applicantDetails[email]", data.applicantDetails.email)
      newData.append("isRegistration", "Yes")


      if (activeTab === 3) {
        newData.append("auditorDetails[auditorName]", data.auditorDetails.auditorName)
        newData.append("auditorDetails[email]", data.auditorDetails.email)
        newData.append("auditorDetails[mobileNumber]", data.auditorDetails.mobileNumber)
        newData.append("auditorDetails[doorNo]", data.auditorDetails.doorNo)
        newData.append("auditorDetails[street]", data.auditorDetails.street)
        newData.append("auditorDetails[district]", data.auditorDetails.district)
        newData.append("auditorDetails[mandal]", data.auditorDetails.mandal)
        newData.append("auditorDetails[villageOrCity]", data.auditorDetails.villageOrCity)
        newData.append("auditorDetails[pinCode]", data.auditorDetails.pinCode)
      }
      // newData.append("societydetails[societyName]", existingSocietyDetail.societyName)

      // 
      if (activeTab === 1) {
        // newData.append("societyName", existingSocietyDetail.societyName)
        newData.append("category", data.societyDetails.category)
        newData.append("generalBodyMeeting", data.societyDetails.generalBodyMeeting)
        newData.append("aim", data.societyDetails.aim)
        newData.append("objective", data.societyDetails.objective)
        // newData.append(
        //   "nameOfRegistrationDistrict",
        //   data.societyDetails.nameOfRegistrationDistrict
        // )
        newData.append("doorNo", data.societyDetails.doorNo)
        newData.append("street", data.societyDetails.street)
        newData.append("country", "India")
        newData.append("state", "Andhra Pradesh")
        // newData.append("district", existingSocietyDetail.district)
        newData.append("mandal", data.societyDetails.mandal)
        newData.append("villageOrCity", data.societyDetails.villageOrCity)
        newData.append("pinCode", data.societyDetails.pinCode)
        newData.append("mobileNumber", data.societyDetails.mobileNumber)
        newData.append("email", data.societyDetails.email)
      }

      if (activeTab === 3) {
        newData.append("byeLaws[societyName]", existingSocietyDetail.societyName)
        newData.append("byeLaws[quorumSize]", data.byelawDetails.quorumSize)
        newData.append("byeLaws[doorNo]", existingSocietyDetail.doorNo)
        newData.append("byeLaws[street]", existingSocietyDetail.street)
        newData.append("byeLaws[country]", "India")
        newData.append("byeLaws[state]", "Andhra Pradesh")
        newData.append("byeLaws[district]", existingSocietyDetail.district)
        newData.append("byeLaws[mandal]", existingSocietyDetail.mandal)
        newData.append("byeLaws[villageOrCity]", existingSocietyDetail.villageOrCity)
        newData.append("byeLaws[pinCode]", existingSocietyDetail.pinCode)
        newData.append("byeLaws[mobileNumber]", existingSocietyDetail.mobileNumber)
        newData.append("byeLaws[membershipConditions]", data.byelawDetails.membershipConditions)
        newData.append("byeLaws[finance]", data.byelawDetails.finance)
        newData.append("byeLaws[auditor]", data.byelawDetails.auditor)
        newData.append("byeLaws[email]", existingSocietyDetail.email)
        newData.append("byeLaws[raisingFunds]", data.byelawDetails.raisingFunds)
        newData.append("byeLaws[officeBearers]", data.byelawDetails.officeBearers)
        newData.append("byeLaws[liabilityConditions]", data.byelawDetails.liabilityConditions)
        newData.append("byeLaws[meetingConditions]", data.byelawDetails.meetingConditions)
        newData.append("byeLaws[otherMatters]", data.byelawDetails.otherMatters)

        newData.append("idProofs", idProofsDoc)
        newData.append("memorandum", memorandumDoc)
        newData.append("byeLaws", byeLawsDoc)
        newData.append("affidavitByAuditor", affidavitByAuditorDoc)
        newData.append("affidavit", affidavitDoc)
        newData.append("selfSignedDeclaration", selfDoc)
        // newData.append("quorumMembers", data.checkedItems)
      }
      newData.append("id", locData.applicationId)
      // if (activeTab === 3) {
      //   for (let j = 1; j < checkedItems?.length; j++) {
      //     if (checkedItems[j]?.aadharNumber) {
      //       // 
      //       newData.append("quorumMembers[" + j + "][mobileNumber]", checkedItems[j].mobileNumber)
      //       newData.append("quorumMembers[" + j + "][qualification]", checkedItems[j].qualification)
      //       newData.append("quorumMembers[" + j + "][joiningDate]", checkedItems[j].joiningDate)
      //       newData.append("quorumMembers[" + j + "][memberType]", checkedItems[j].memberType)
      //       newData.append("quorumMembers[" + j + "][aadharNumber]", checkedItems[j].aadharNumber)
      //       newData.append("quorumMembers[" + j + "][memberName]", checkedItems[j].memberName)
      //       newData.append("quorumMembers[" + j + "][relationName]", checkedItems[j].relationName)
      //       newData.append("quorumMembers[" + j + "][relationType]", checkedItems[j].relationType)
      //       newData.append("quorumMembers[" + j + "][occupation]", checkedItems[j].occupation)
      //       newData.append("quorumMembers[" + j + "][age]", checkedItems[j].age)
      //       newData.append("quorumMembers[" + j + "][gender]", checkedItems[j].gender)
      //       newData.append("quorumMembers[" + j + "][role]", checkedItems[j].role)
      //       newData.append("quorumMembers[" + j + "][doorNo]", checkedItems[j].doorNo)
      //       newData.append("quorumMembers[" + j + "][street]", checkedItems[j].street)
      //       newData.append("quorumMembers[" + j + "][country]", "India")
      //       newData.append("quorumMembers[" + j + "][state]", "Andhra Pradesh")
      //       newData.append("quorumMembers[" + j + "][district]", checkedItems[j].district)
      //       newData.append("quorumMembers[" + j + "][mandal]", checkedItems[j].mandal)

      //       newData.append("quorumMembers[" + j + "][villageOrCity]", checkedItems[j].villageOrCity)
      //       newData.append("quorumMembers[" + j + "][pinCode]", checkedItems[j].pinCode)
      //     }
      //   }
      // }
      // 
      if (activeTab === 2) {
        for (let j = 0; j < data.membersDetails.length; j++) {
          // 
          if (data.membersDetails[j].joiningDate) {
            // let aadharNumber = CryptoJS.AES.encrypt(data.membersDetails[j].aadharNumber, process.env.SECRET_KEY).toString()
            newData.append("memberDetails[" + j + "][email]", data.membersDetails[j].email)
            newData.append(
              "memberDetails[" + j + "][mobileNumber]",
              data.membersDetails[j].mobileNumber
            )
            newData.append(
              "memberDetails[" + j + "][qualification]",
              data.membersDetails[j].qualification
            )
            newData.append(
              "memberDetails[" + j + "][joiningDate]",
              data.membersDetails[j].joiningDate
            )
            newData.append("memberDetails[" + j + "][memberType]", data.membersDetails[j].memberType)

            newData.append(
              "memberDetails[" + j + "][aadharNumber]",CryptoJS.AES.encrypt(data.membersDetails[j].aadharNumber, data.secretkey).toString()
            )
            newData.append("memberDetails[" + j + "][memberName]",CryptoJS.AES.encrypt(data.membersDetails[j].memberName, data.secretkey).toString())
            newData.append(
              "memberDetails[" + j + "][relationName]",
              CryptoJS.AES.encrypt(data.membersDetails[j].relationName, data.secretkey).toString())
              // btoa(data.membersDetails[j].relationName)
            
            newData.append(
              "memberDetails[" + j + "][relationType]",
              data.membersDetails[j].relationType
            )
            newData.append("memberDetails[" + j + "][occupation]", data.membersDetails[j].occupation)
            newData.append("memberDetails[" + j + "][age]", data.membersDetails[j].age)
            newData.append("memberDetails[" + j + "][gender]", data.membersDetails[j].gender)
            newData.append("memberDetails[" + j + "][role]", data.membersDetails[j].role)
            newData.append("memberDetails[" + j + "][status]", "Active")
            newData.append("memberDetails[" + j + "][doorNo]", data.membersDetails[j].doorNo)
            newData.append("memberDetails[" + j + "][street]", data.membersDetails[j].street)
            newData.append("memberDetails[" + j + "][country]", "India")
            newData.append("memberDetails[" + j + "][state]", "Andhra Pradesh")
            newData.append("memberDetails[" + j + "][district]", data.membersDetails[j].district)
            newData.append("memberDetails[" + j + "][mandal]", data.membersDetails[j].mandal)
            newData.append("memberDetails[" + j + "][soundMind]", data.membersDetails[j].soundMind)
            newData.append("memberDetails[" + j + "][inSolvent]", data.membersDetails[j].inSolvent)
            newData.append("memberDetails[" + j + "][offense]", data.membersDetails[j].offense)
            newData.append("memberDetails[" + j + "][appointment]", data.membersDetails[j].appointment)
            newData.append(
              "memberDetails[" + j + "][villageOrCity]",
              data.membersDetails[j].villageOrCity
            )
            newData.append("memberDetails[" + j + "][pinCode]", data.membersDetails[j].pinCode)
          }
        }
      }

      updateSocietyDetails(existingSocietyDetail._id, token, newData)
        .then((response: any) => {
          // debugger
          if (response?.success) {
            // 
            setExistingSocietyDetail(response.data.societyDetails)
            localStorage.removeItem("isResubmission")
            setSocietyDetails({
              ...societyDetails,
              category: response.data.societyDetails?.category
                ? response.data.societyDetails?.category
                : "",
              generalBodyMeeting: response.data.societyDetails?.generalBodyMeeting
                ? response.data.societyDetails?.generalBodyMeeting
                : "",
              doorNo: response.data.societyDetails?.doorNo
                ? response.data.societyDetails?.doorNo
                : "",
              street: response.data.societyDetails?.street
                ? response.data.societyDetails?.street
                : "",
              state: response.data.societyDetails?.state
                ? response.data.societyDetails?.state
                : "Andhra Pradesh",
              district: response.data.societyDetails?.district
                ? response.data?.societyDetails?.district
                : "",
              mandal: response.data.societyDetails?.mandal
                ? response.data.societyDetails?.mandal
                : "",
              villageOrCity: response.data.societyDetails?.villageOrCity
                ? response.data.societyDetails?.villageOrCity
                : "",
              pinCode: response.data.societyDetails?.pinCode
                ? response.data.societyDetails?.pinCode
                : "",
              societyName: response.data.societyDetails?.societyName
                ? response.data.societyDetails?.societyName
                : "",
              aim: response.data.societyDetails?.aim
                ? response.data.societyDetails?.aim
                : "",
              objective: response.data.societyDetails?.objective
                ? response.data.societyDetails?.objective
                : "",
              mobileNumber: response.data.societyDetails?.mobileNumber
                ? response.data.societyDetails?.mobileNumber
                : "",
              email: response.data.societyDetails?.email
                ? response.data.societyDetails?.email
                : "",
              nameOfRegistrationDistrict: response.data.societyDetails
                ?.nameOfRegistrationDistrict
                ? response.data.societyDetails?.nameOfRegistrationDistrict
                : "",

            })
            setCurrentsocietyDistrict(response.data.societyDetails?.district)
            setCurrentsocietyMandal(response.data.societyDetails?.mandal)

            if (
              response.data.societyDetails?.memberDetails &&
              response.data.societyDetails?.memberDetails?.length > 0
            ) {
              response.data.societyDetails.memberDetails.forEach((a: any) => {
                a.maskedAadhar = "XXXXXXXX" + a.aadharNumber?.toString().substring(8, 12)
                a.soundMind = "Yes"
                a.inSolvent = "No"
                a.offense = "No"
                a.appointment = "No"
              })

              setMembersDetails([...response.data.societyDetails.memberDetails])
            }

            // if (
            //   response.data.societyDetails?.quorumMembers &&
            //   response.data.societyDetails?.quorumMembers?.length > 0
            // ) {
            //   setCheckedItems([...response.data.societyDetails?.quorumMembers])
            // }
            // if (response.data.societyDetails?.byelawDetails?.length) {
            //   response.data.societyDetails.byelawDetails.forEach(
            //     (a: any) =>
            //       (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber?.toString().substring(8, 12))
            //   )
            //   setbyelawDetails([...response.data.societyDetails.byelawDetails])
            // }
            if (response.data.societyDetails.applicantDetails) {

              setApplicantDetails({
                ...applicantDetails,
                applicationNumber: response.data.societyDetails.applicationNumber,
                maskedAadhar:
                  "XXXXXXXX" +
                  response.data.societyDetails.applicantDetails.aadharNumber
                    ?.toString()
                    .substring(8, 12),
                aadharNumber: response.data.societyDetails.applicantDetails.aadharNumber,
                name: response.data.societyDetails.applicantDetails.name,
                gender: response.data.societyDetails.applicantDetails.gender,
                doorNo: response.data.societyDetails.applicantDetails.doorNo,
                street: response.data.societyDetails.applicantDetails.street,
                country: response.data.societyDetails.applicantDetails.country,
                state: response.data.societyDetails.applicantDetails.state,
                district: response.data.societyDetails.applicantDetails.district,
                mandal: response.data.societyDetails.applicantDetails.mandal,
                age: response.data.societyDetails.applicantDetails.age,
                villageOrCity: response.data.societyDetails.applicantDetails.villageOrCity,
                pinCode: response.data.societyDetails.applicantDetails.pinCode,
                role: response.data.societyDetails?.applicantDetails.role,
                email: response.data.societyDetails?.applicantDetails.email,
                mobileNumber: response.data.societyDetails?.applicantDetails.mobileNumber,
                relationType: response.data.societyDetails?.applicantDetails.relationType,
                relationName: response.data.societyDetails?.applicantDetails.relationName,
              })

              setCurrentDistrict(response.data.societyDetails.applicantDetails.district)
              setCurrentMandal(response.data.societyDetails.applicantDetails.mandal)
            }
            if (response.data.societyDetails.byeLaws) {
              setbyelawDetails({
                ...byelawDetails,
                quorumSize: Math.round((response.data.societyDetails.memberDetails.length / 2) + 1),
                societyName: response.data.societyDetails.byeLaws.name,
                gender: response.data.societyDetails.byeLaws.gender,
                doorNo: response.data.societyDetails.byeLaws.doorNo,
                street: response.data.societyDetails.byeLaws.street,
                country: response.data.societyDetails.byeLaws.country,
                state: response.data.societyDetails.byeLaws.state,
                district: response.data.societyDetails.byeLaws.district,
                mandal: response.data.societyDetails.byeLaws.mandal,
                villageOrCity: response.data.societyDetails.byeLaws.villageOrCity,
                pinCode: response.data.societyDetails.byeLaws.pinCode,
                email: response.data.societyDetails.byeLaws.pinCode,
                mobileNumber: response.data.societyDetails.byeLaws.mobileNumber,
                membershipConditions: "Yes",
                finance: "Yes",
                auditor: "Yes",
                raisingFunds: "Yes",
                officeBearers: "Yes",
                liabilityConditions: "Yes",
                meetingConditions: "Yes",
                otherMatters: "Yes",
              })
            } else {
              setbyelawDetails({
                ...byelawDetails,
                quorumSize: Math.round((response.data.societyDetails.memberDetails.length / 2) + 1),
              })
            }
            if (response.data.daSociety?.auditorDetails) {
              setauditorDetails({
                ...auditorDetails,
                auditorName: response.data.societyDetails.auditorDetails.auditorName,
                mobileNumber: response.data.societyDetails.auditorDetails.mobileNumber,
                email: response.data.societyDetails.auditorDetails.email,
                doorNo: response.data.societyDetails.auditorDetails.doorNo,
                street: response.data.societyDetails.auditorDetails.street,
                district: response.data.societyDetails.auditorDetails.district,
                mandal: response.data.societyDetails.auditorDetails.mandal,
                villageOrCity: response.data.societyDetails.auditorDetails.villageOrCity,
                pinCode: response.data.societyDetails.auditorDetails.pinCode,
              })
              setCurrentauditorDistrict(response.data.daSociety.auditorDetails.district)
              setCurrentauditorMandal(response.data.daSociety.auditorDetails.mandal)
            }
            if (response.data.societyDetails.documentAttached?.length) {
              response.data.societyDetails.documentAttached.forEach((z: any) => {
                if (z.originalname) {
                  const fileName = z.originalname.split("_")[0]

                  getFileFromUrl(
                    `/downloads/${existingSocietyDetail._id}/${z.originalname}`,
                    fileName
                  ).then((response) => {
                    let inputEle = document.getElementById(fileName) as HTMLInputElement

                    if (inputEle !== null) {
                      const dataTransfer = new DataTransfer()

                      dataTransfer.items.add(response)

                      inputEle.files = dataTransfer.files

                      const newInput = (data: any) => ({
                        ...data,

                        [fileName]: response,
                      })

                      setFile(newInput)
                    }
                  })
                }
              })
            }

            setAddSociety(response.data)
            // if (isPayNowClicked && membersDetails.length > 6) {
            if (isPayNowClicked) {
              let code = 0
              const dis = districtList?.find((x: any) => x.name == data.societyDetails.district)
              if (dis) {
                code = dis.code
              }
              // const memCount = membersDetails.length - 7

              const paymentsData = {
                type: "sra",
                source: "Society",
                deptId: existingSocietyDetail.applicationNumber,
                rmName: existingSocietyDetail.applicantDetails.name,
                rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
                
                mobile: existingSocietyDetail.applicantDetails.mobileNumber,
                email: existingSocietyDetail.applicantDetails.email,
                drNumber: code,
                rf: 500,
                uc: 0,
                oc: 0,
                returnURL: process.env.BACKEND_URL + "/societies/redirectPayment",
              }
              console.log("paymentsData",paymentsData)
              let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
              // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8")?.toString("base64")
              const encodedData = CryptoJS.AES.encrypt(
                JSON.stringify(paymentsData),
                'igrsSecretPhrase'
              ).toString()
              let paymentLink = document.createElement("a")
              paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
              //paymentLink.target = "_blank";

              paymentLink.click()
              setIsPayNowClicked(false)
              setTimeout(function () {
                paymentLink.remove()
              }, 1000)
            } else if (!isPayNowClicked) {
              if (activeTab === 0) {
                ShowAlert(true, "Applicant Details Saved Successfully")
              } else if (activeTab === 1) {
                ShowAlert(true, "Society Details Saved Successfully")
              } else if (activeTab === 2) {
                const remainingMem = 3 - membersDetails.length
                if (membersDetails.length >= 3) {
                  ShowAlert(true, "EC Member Details Saved Successfully")
                } else {
                  ShowAlert(false, `Please add ${remainingMem} more member${remainingMem == 1 ? "" : "s"} `)
                }
              } else if (activeTab === 3) {
                ShowAlert(true, "Bye-Laws Details Saved Successfully")
              }
              if (activeTab < 3) {
                setActiveTab(activeTab + 1)
              }
            } else {
              const remainingMem = 3 - membersDetails.length
              ShowAlert(
                false,
                `Please add ${remainingMem} more member${remainingMem == 1 ? "" : "s"
                } to continue payment`
              )
            }
          } else {
            ShowAlert(false, "details not saved")
          }
        })
        .catch((error) => {
          console.log("error-", error)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: error.message,
            showConfirmButton: false,
            timer: 1500,
          })
        })
    }
  }

  return (
    <>
      <Head>
        <title>E-Registration of Society</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      <div className={styles.RegistrationMain}>
        {locData && locData?.userType && locData?.userType == "user" && (
          <div className="societyRegSec">
            <Container>
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="d-flex align-items-center page-title mb-1">
                    {/* <Image
                      alt="Image"
                      height={20}
                      width={20}
                      src="/assets/back-icon.svg"
                      style={{ cursor: "pointer" }}

                      onClick={() => router.back()
                      }
                    /> */}
                    <div className="pageTitleLeft">

                      <h1>E-Registration of Society</h1>
                    </div>
                    {/* <div className="pageTitleRight">
                    <div className="page-header-btns">
                      <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                        Go Back
                      </a>
                    </div>
                  </div> */}
                  </div>
                </Col>
              </Row>
              <Row>
                <Col lg={7} md={4} xs={12}>
                  <div className={styles.tabContainer} id="tabDiv">
                    {renderTabHeaders()}
                  </div>
                </Col>
              </Row>
            </Container>

            {(existingSocietyDetail?.status == "Incomplete" || isResubmission == "true") &&
              (existingSocietyDetail?.societyStatus != "Approved" ||
                existingSocietyDetail?.societyStatus != "Rejected") && (
                <Container>
                  {activeTab === 0 && (
                    <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
                      <div className="regofAppBg mb-3">
                        <Row>
                          <Col lg={3} md={3} xs={12} >
                            {!TempMemory.OTPRequested ? (
                              <Form.Group>
                                <TableText
                                  label="Enter Aadhaar Number"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <div className="formGroup">
                                  <TableInputText
                                    disabled={TempMemory.AadharVerified}
                                    type={"text"}
                                    maxLength={12}
                                    dot={false}
                                    placeholder="Enter Aadhaar Number"
                                    required={true}
                                    name={"maskedAadhar"}
                                    value={applicantDetails.maskedAadhar}
                                    onChange={(e: any) => {
                                      if (!TempMemory.AadharVerified) {
                                        applicantDetailsChange(e)
                                      }
                                    }}
                                    onKeyPress={true}
                                    onPaste={(e: any) => e.preventDefault()}
                                  />
                                  {!TempMemory.AadharVerified ? (
                                    <div
                                      style={{
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        borderRadius: "2px",
                                      }}
                                      onClick={() => ReqOTP(applicantDetails)}
                                      className="verify btn btn-primary"
                                    >
                                      Get OTP
                                    </div>
                                  ) : null}
                                </div>
                              </Form.Group>
                            ) : (
                              <Form.Group>
                                <TableText label="Enter OTP" required={true} LeftSpace={false} />
                                <div className="formGroup">
                                  <TableInputText
                                    disabled={false}
                                    type="number"
                                    placeholder="Enter OTP Received"
                                    maxLength={6}
                                    required={true}
                                    name={"otpCode"}
                                    value={applicantDetails.otpCode}
                                    onChange={applicantDetailsChange}
                                  />
                                  <div
                                    style={{
                                      display: "flex",
                                      justifyContent: "center",
                                      alignItems: "center",
                                      borderRadius: "2px",
                                    }}
                                    onClick={() => {
                                      ReqDetails(applicantDetails)
                                    }}
                                    className="verify btn btn-primary"
                                  >
                                    Verify
                                  </div>
                                  <div style={{ display: "flex", justifyContent: "flex-end" }}>
                                    <div
                                      style={{
                                        cursor: "pointer",
                                        marginRight: "20px",
                                        color: "blue",
                                        fontSize: "10px",
                                      }}
                                      onClick={() => {
                                        setTempMemory({ ...TempMemory, OTPRequested: false })
                                      }}
                                    >
                                      clear
                                    </div>
                                  </div>
                                </div>
                              </Form.Group>
                            )}
                          </Col>
                          <Col lg={3} md={12} sm={12}>
                            <TableText label="Name of the Applicant" required={false} LeftSpace={false} />
                            <TableInputText
                              type="text"
                              placeholder="Enter Applicant Name"
                              required={true}
                              name="name"
                              value={applicantDetails.name}
                              onChange={() => { }}
                              disabled={true}
                            />
                            <Row className={styles.columnText} style={{ display: "flex" }}>
                              <Col lg={9} md={4} xs={12}>
                                Gender:{applicantDetails.gender}/Age:{applicantDetails.age}
                              </Col>
                            </Row>
                          </Col>
                          <Col lg={3} md={12} sm={12}>
                            <TableText label="Relation Name" required={false} LeftSpace={false} />
                            <Form.Group className="inline">
                              <div className="inline formGroup">
                                <Form.Select name="relationType" onChange={applicantDetailsChange} required value={applicantDetails.relationType}>
                                  <option>Select</option>
                                  {relationtypelist.map((item: any, i: number) => {
                                    return (
                                      <option key={i + 1} value={item}>
                                        {item}
                                      </option>
                                    )
                                  })}
                                  {/* <option>S/O</option>
                          <option>D/O</option>
                          <option>W/O</option>
                          <option>H/O</option> */}
                                </Form.Select>

                                <input
                                  className="form-control"
                                  type="text"
                                  name="relationName"
                                  onChange={() => { }}
                                  value={applicantDetails.relationName}
                                  disabled={true}
                                />
                              </div>
                            </Form.Group>
                          </Col>
                          <Col lg={3} md={12} sm={12}>
                            <TableText label={"Role"} required={false} LeftSpace={false} />

                            <TableInputText
                              type="text"
                              placeholder="Enter Role"
                              required={true}
                              disabled={false}
                              name="role"
                              value={applicantDetails.role}
                              onChange={applicantDetailsChange}
                            />
                            {/* {errors.role && <span style={{ color: "red" }} className={styles.columnText}>{errors.role}</span>} */}
                          </Col>
                        </Row>
                        <div className="formSectionTitle">
                          <h3>Address</h3>
                        </div>

                        <Row>
                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Door No" required={true} LeftSpace={false} />
                            <TableInputText
                              disabled={false}
                              type="text"
                              placeholder="Enter Door No"
                              required={true}
                              name="doorNo"
                              maxLength={50}
                              value={applicantDetails.doorNo}
                              onChange={applicantDetailsChange}
                            />
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Street" required={false} LeftSpace={false} />
                            <TableInputText
                              disabled={false}
                              type="text"
                              placeholder="Enter Street"
                              required={false}
                              name="street"
                              value={applicantDetails.street}
                              maxLength={50}
                              onChange={applicantDetailsChange}
                            />
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="District" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="district"
                              required={true}
                              onChange={(event) => {
                                districtChange(event)
                                applicantDetailsChange(event)
                              }}
                              value={applicantDetails.district}
                            >
                              <option>Select</option>
                              {districtList.map((item: any, i: any) => {
                                return (
                                  <option key={i + 1} value={item.name}>
                                    {item.name}
                                  </option>
                                )
                              })}
                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Mandal" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="mandal"
                              // defaultValue={"Select"}
                              required={true}
                              onChange={(event) => {
                                mandalChange(event)
                                applicantDetailsChange(event)
                              }}
                              value={applicantDetails.mandal}
                            >
                              <option>Select</option>
                              {applicantDetails && (
                                <DynamicMandals
                                  currentDistrict={currentDistrict}
                                  setDetails={() => setApplicantDetails({ ...applicantDetails })}
                                ></DynamicMandals>
                              )}
                            </select>
                          </Col>
                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Village" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="villageOrCity"
                              onChange={applicantDetailsChange}
                              required={true}
                              // defaultValue={"Select"}
                              value={applicantDetails.villageOrCity}
                            >
                              <option>Select</option>
                              {
                                <DynamicVillages
                                  currentDistrict={currentDistrict}
                                  currentMandal={currentMandal}
                                  setDetails={() => setApplicantDetails({ ...applicantDetails })}
                                ></DynamicVillages>
                              }

                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="PIN Code" required={true} LeftSpace={false} />
                            <Form.Control
                              disabled={false}
                              type="text"
                              maxLength={6}
                              placeholder="Enter PIN Code"
                              required={true}
                              name="pinCode"
                              value={applicantDetails.pinCode}
                              onChange={applicantDetailsChange}
                              onKeyPress={onNumberOnlyChange}
                            />
                          </Col>
                        </Row>
                        <div className="regFormBorder"></div>
                        <div className="formSectionTitle">
                          <h3>Contact Details</h3>
                        </div>
                        <Row>
                          {/* <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Landline Number" required={false} LeftSpace={false} />
                            <Form.Control
                              type="number"
                              placeholder="Enter Landline Number"
                              required={false}
                              name={"phone"}
                              value={contactDetails.phone}
                              onChange={contactDetailsChange}
                              onKeyPress={onNumberOnlyChange}
                            />
                          </Col> */}
                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Mobile No" required={true} LeftSpace={false} />
                            <Form.Control
                              type="text"
                              placeholder="Enter Mobile No"
                              required={true}
                              name={"mobileNumber"}
                              autoComplete="off"
                              value={applicantDetails.mobileNumber}
                              onChange={applicantDetailsChange}
                              onKeyPress={onNumberOnlyChange}
                              maxLength={10}
                            />
                          </Col>

                          {/* <Col lg={3} md={4} xs={12} className="mb-3">
                        <TableText label="Fax" required={true} LeftSpace={false} />
                        <Form.Control
                          disabled={false}
                          type="text"
                          placeholder="Enter Fax"
                          required={true}
                          name={"fax"}
                          value={contactDetails.fax}
                          onChange={contactDetailsChange}
                          onKeyPress={onNumberOnlyChange}
                        />
                      </Col> */}

                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Email Address" required={false} LeftSpace={false} />
                            <TableInputText
                              disabled={false}
                              type="email"
                              placeholder="Enter Email Address"
                              required={false}
                              name={"email"}
                              maxLength={40}
                              minLength={15}
                              value={applicantDetails.email}
                              onChange={applicantDetailsChange}
                            />
                          </Col>
                        </Row>
                        <div className="firmSubmitSec">
                          <Row>
                            <Col lg={12} md={12} xs={12}>
                              {(existingSocietyDetail?.status == "Incomplete" || isResubmission == "true") && (
                                <>
                                  <div className="d-flex justify-content-center text-center">
                                    {" "}
                                    <Button type="submit">Save & Next</Button>
                                  </div>
                                </>
                              )}
                            </Col>
                          </Row>
                        </div>
                      </div>

                    </Form>
                  )}

                  {activeTab === 1 && (
                    <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
                      <div className="regofAppBg">
                        <div className="formSectionTitle">
                          <h3>Society Details</h3>
                        </div>

                        <Row>
                          <Col lg={3} md={4} xs={12} >
                            <TableText label="Society Name" required={true} LeftSpace={false} />
                            <TableInputText
                              disabled={true}
                              type="text"
                              placeholder="Enter Society Name"
                              required={true}
                              name={"societyName"}
                              value={existingSocietyDetail?.societyName}
                              onChange={() => { }}
                            />
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="Society Category" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="category"
                              required={true}
                              onChange={societyDetailsChange}
                              value={societyDetails.category}
                            >
                              <option>Select</option>
                              {categorylist.map((item: any, i: number) => {
                                return (
                                  <option key={i + 1} value={item}>
                                    {item}
                                  </option>
                                )
                              })}
                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText
                              label="Date of Annual General Body Meeting"
                              required={true}
                              LeftSpace={false}
                            />
                            <TableInputText
                              disabled={false}
                              type="date"
                              placeholder="Enter General Body Meeting"
                              required={true}
                              name="generalBodyMeeting"
                              value={societyDetails.generalBodyMeeting}
                              onChange={societyDetailsChange}
                            />
                          </Col>
                        </Row>

                        <div className="formSectionTitle">
                          <h3>Contact Details</h3>
                        </div>

                        <Row>
                          {/* <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Landline Number" required={false} LeftSpace={false} />
                          <Form.Control
                            type="text"
                            placeholder="Enter Landline Number"
                            required={false}
                            name={"phone"}
                            value={societyDetails.phone}
                            onChange={societyDetailsChange}
                            onKeyPress={onNumberOnlyChange}
                            maxLength={12}
                          />
                        </Col> */}
                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="Mobile No" required={true} LeftSpace={false} />
                            <Form.Control
                              type="text"
                              placeholder="Enter Mobile No"
                              required={true}
                              name="mobileNumber"
                              autoComplete="off"
                              value={societyDetails.mobileNumber}
                              onChange={societyDetailsChange}
                              onKeyPress={onNumberOnlyChange}
                              maxLength={10}
                            />
                          </Col>

                          {/* <Col lg={3} md={4} xs={12} className="mb-3">
                        <TableText label="Fax" required={true} LeftSpace={false} />
                        <Form.Control
                          disabled={false}
                          type="text"
                          placeholder="Enter Fax"
                          required={true}
                          name={"fax"}
                          value={contactDetails.fax}
                          onChange={contactDetailsChange}
                          onKeyPress={onNumberOnlyChange}
                        />
                      </Col> */}

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="Email Address" required={false} LeftSpace={false} />
                            <TableInputText
                              disabled={false}
                              type="email"
                              placeholder="Enter Email Address"
                              required={false}
                              name="email"
                              maxLength={40}
                              minLength={15}
                              value={societyDetails.email}
                              onChange={societyDetailsChange}
                            />
                          </Col>
                        </Row>
                        <div className="formSectionTitle">
                          <h3>Address of the Society</h3>
                        </div>
                        <Row>
                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="Door No" required={true} LeftSpace={false} />
                            <TableInputText
                              disabled={false}
                              type="text"
                              placeholder="Enter Door No"
                              required={true}
                              name="doorNo"
                              value={societyDetails.doorNo}
                              onChange={societyDetailsChange}
                            />
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="Street" required={false} LeftSpace={false} />
                            <TableInputText
                              disabled={false}
                              type="text"
                              placeholder="Enter Street"
                              required={false}
                              name="street"
                              value={societyDetails.street}
                              onChange={societyDetailsChange}
                            />
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="State" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="state"
                              onChange={() => { }}
                              value={societyDetails.state}
                              disabled={true}
                            >
                              <option>Andhra Pradesh</option>
                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="District" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="district"
                              onChange={() => {
                                // societyDetailsChange(event)
                                // districtsocietyChange(event)
                              }}
                              value={existingSocietyDetail.district}
                              required={true}
                              disabled={true}
                            >
                              <option>Select</option>
                              {districtList &&
                                districtList.length > 0 &&
                                districtList.map((item: any, i: any) => {
                                  return (
                                    <option key={i + 1} value={item.name}>
                                      {item.name}
                                    </option>
                                  )
                                })}
                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="Mandal" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="mandal"
                              onChange={(event) => {
                                societyDetailsChange(event)
                                mandalsocietyChange(event)
                              }}
                              value={societyDetails.mandal}
                              required={true}
                              defaultValue={"Select"}
                            >
                              <option>Select</option>
                              <DynamicMandals
                                currentDistrict={existingSocietyDetail.district}
                                setDetails={() => setSocietyDetails({ ...societyDetails })}
                              ></DynamicMandals>
                            </select>
                          </Col>
                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="Village" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="villageOrCity"
                              onChange={societyDetailsChange}
                              value={societyDetails.villageOrCity}
                              required={true}
                            // defaultValue={"Select"}
                            >
                              <option>Select</option>
                              <DynamicVillages
                                currentDistrict={existingSocietyDetail.district}
                                currentMandal={currentsocietyMandal}
                                setDetails={() => setSocietyDetails({ ...societyDetails })}
                              ></DynamicVillages>
                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText label="PIN Code" required={true} LeftSpace={false} />
                            <Form.Control
                              disabled={false}
                              type="text"
                              maxLength={6}
                              placeholder="Enter PIN Code"
                              required={true}
                              name="pinCode"
                              value={societyDetails.pinCode}
                              onChange={societyDetailsChange}
                              onKeyPress={onNumberOnlyChange}
                            />
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-1">
                            <TableText
                              label="Registration District"
                              required={true}
                              LeftSpace={false}
                            />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="nameOfRegistrationDistrict"
                              onChange={societyDetailsChange}
                              value={existingSocietyDetail.district}
                              required={true}
                              disabled
                            >
                              <option>Select</option>
                              {districtList.map((item: any, i: any) => {
                                return (
                                  <option key={i + 1} value={item.name}>
                                    {item.name}
                                  </option>
                                )
                              })}
                            </select>
                          </Col>
                        </Row>
                        <Row>
                          <Col lg={6} md={4} xs={12} className="mb-1">
                            <TableText label="Aim of the Society" required={true} LeftSpace={false} />
                            <textarea
                              className="form-control textarea"
                              name="aim"
                              maxLength={10000}
                              value={societyDetails.aim}
                              onChange={societyDetailsChange}
                              required
                            ></textarea>
                          </Col>
                          <Col lg={6} md={4} xs={12} className="mb-1">
                            <TableText
                              label="Objective of the Society"
                              required={true}
                              LeftSpace={false}
                            />
                            <textarea
                              className="form-control textarea"
                              name="objective"
                              value={societyDetails.objective}
                              onChange={societyDetailsChange}
                              maxLength={10000}
                              required
                            ></textarea>
                          </Col>
                        </Row>
                        <div className="firmSubmitSec">
                          <Row>
                            <Col lg={12} md={12} xs={12}>
                              {(existingSocietyDetail?.status == "Incomplete" || isResubmission == "true") && (
                                <>
                                  <div className="d-flex justify-content-center text-center py-0 my-0">
                                    {" "}
                                    <Button
                                      className={styles.prev}
                                      onClick={goToPrevTab}
                                      type="button"
                                    >
                                      Back
                                    </Button>
                                    <Button type="submit">Save & Next</Button>
                                  </div>
                                </>
                              )}
                            </Col>
                          </Row>
                        </div>
                      </div>
                    </Form>
                  )}
                  {activeTab === 2 && (
                    <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
                      <div className="regofAppBg mb-3 dahboardProcedureSec">
                        <>
                          <div className="regofAppBg mb-3">
                            <div className="societyMemberDetailsList">
                              <Row className="membersDetailsList">
                                <div className="societyMemberDetailsList">
                                  <Row className="membersDetailsList d-flex align-items-center"></Row>
                                  <Row className="membersDetailsList">
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Member Type"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="memberType"
                                          required={false}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.memberType}
                                        >
                                          <option>Select</option>
                                          {typelist.map((item: any, i: number) => {
                                            return (
                                              <option key={i + 1} value={item}>
                                                {item}
                                              </option>
                                            )
                                          })}
                                        </select>
                                      </Form.Group>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">

                                      {!TempMemorymember.OTPRequested ? (
                                        <Form.Group>
                                          <TableText
                                            label="Enter Aadhaar Number"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <div className="formGroup">
                                            <TableInputText
                                              disabled={TempMemorymember.AadharVerified}
                                              type="text"
                                              maxLength={12}
                                              placeholder="Enter Aadhaar Number"
                                              required={false}
                                              dot={false}
                                              name={"maskedAadhar"}
                                              value={SelectedMemberDetails.maskedAadhar}
                                              onChange={(e: any) => {
                                                if (!TempMemorymember.AadharVerified) {
                                                  membersDetailsChange(e)
                                                }
                                              }}
                                              onKeyPress={true}
                                              onPaste={(e: any) => e.preventDefault()}
                                            />
                                            {!TempMemorymember.AadharVerified ? (
                                              <div
                                                style={{
                                                  display: "flex",
                                                  justifyContent: "center",
                                                  alignItems: "center",
                                                  borderRadius: "2px",
                                                }}
                                                onClick={() => ReqOTP(SelectedMemberDetails)}
                                                className="verify btn btn-primary"
                                              >
                                                Get OTP
                                              </div>
                                            ) : null}
                                          </div>
                                        </Form.Group>
                                      ) : (
                                        <Form.Group>
                                          <TableText
                                            label="Enter OTP"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="formGroup">
                                            <TableInputText
                                              disabled={false}
                                              type="number"
                                              placeholder="Enter OTP Received"
                                              maxLength={6}
                                              required={false}
                                              name={"otpCode"}
                                              value={SelectedMemberDetails.otpCode}
                                              onChange={membersDetailsChange}
                                            />
                                            <div
                                              style={{
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center",
                                                borderRadius: "2px",
                                              }}
                                              onClick={() => {
                                                ReqDetails(SelectedMemberDetails)
                                              }}
                                              className="verify btn btn-primary"
                                            >
                                              Verify
                                            </div>
                                            <div
                                              style={{ display: "flex", justifyContent: "flex-end" }}
                                            >
                                              <div
                                                style={{
                                                  cursor: "pointer",
                                                  marginRight: "20px",
                                                  color: "blue",
                                                  fontSize: "10px",
                                                }}
                                                onClick={() => {
                                                  setTempMemorymember({
                                                    ...TempMemorymember,
                                                    OTPRequested: false,
                                                  })
                                                }}
                                              >
                                                clear
                                              </div>
                                            </div>
                                          </div>
                                        </Form.Group>
                                      )}
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Name of the Member"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <TableInputText
                                          // className="form-control"
                                          name="memberName"
                                          disabled
                                          required={false}
                                          placeholder="Enter Name of the Member"
                                          onChange={() => { }}
                                          value={SelectedMemberDetails.memberName}
                                          type={"text"}
                                        />
                                        <Row className={styles.columnText}>
                                          <Col lg={9} md={4} xs={12}>
                                            Gender:{SelectedMemberDetails.gender}/Age:
                                            {SelectedMemberDetails.age}
                                          </Col>
                                        </Row>
                                      </Form.Group>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group className="inline">
                                        <TableText
                                          label="Relation Name"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <div className="inline formGroup">
                                          <Form.Select
                                            name="relationType"
                                            onChange={(event) => membersDetailsChange(event)}
                                            disabled={false}
                                            required={false}
                                            value={SelectedMemberDetails.relationType}
                                          >
                                            <option>Select</option>
                                            {relationtypelist.map((item: any, i: number) => {
                                              return (
                                                <option key={i + 1} value={item}>
                                                  {item}
                                                </option>
                                              )
                                            })}
                                          </Form.Select>
                                          <input

                                            className="form-control"
                                            type="text"
                                            name="relationName"
                                            onChange={() => { }}
                                            value={SelectedMemberDetails.relationName}
                                            disabled={true}
                                            required={false}
                                          />
                                        </div>
                                      </Form.Group>
                                    </Col>
                                    <Col lg={3} md={2} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Role/Position"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="role"
                                          required={false}
                                          onChange={(event) =>
                                            membersDetailsChange(event)
                                          }
                                          value={SelectedMemberDetails.role}
                                        >
                                          <option>Select</option>
                                          {roleList.map((item: any) => {
                                            return <option value={item}>{item}</option>
                                          })}
                                        </select>
                                      </Form.Group>
                                    </Col>
                                    
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                        <TableText
                                          label="Occupation"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <TableInputText
                                          required={false}
                                          type="text"
                                          name="occupation"
                                          placeholder="Enter Occupation"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.occupation}
                                        />
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      
                                        <TableText
                                          label="Qualification"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <TableInputText
                                          type="text"
                                          required={false}
                                          name="qualification"
                                          placeholder="Enter Qualification"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.qualification}
                                        />
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Date of Joining as a Member"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <input
                                          required={false}
                                          type="date"
                                          className="form-control"
                                          name="joiningDate"
                                          placeholder="DD/MM/YYYY"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.joiningDate}
                                        />
                                      </Form.Group>
                                    </Col>
                                    <div className="formSectionTitle">
                                      <h3>Address</h3>
                                    </div>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="Door No" required={true} LeftSpace={false} />
                                      <TableInputText
                                        disabled={false}
                                        type="text"
                                        placeholder="Enter Door No"
                                        required={false}
                                        name="doorNo"
                                        onChange={(event: any) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.doorNo}
                                      />
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText
                                        label="Street Name"
                                        required={false}
                                        LeftSpace={false}
                                      />
                                      <TableInputText
                                        disabled={false}
                                        type="text"
                                        placeholder="Enter Street Name"
                                        required={false}
                                        name="street"
                                        onChange={(event: any) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.street}
                                      />
                                    </Col>

                                    {/* <Col lg={3} md={3} xs={12} className="mb-3">
                                              <TableText
                                                label="Country"
                                                required={true}
                                                LeftSpace={false}
                                              />
                                              <select style={{ textTransform: 'uppercase' }}
                                                className="form-control"
                                                name="country"
                                                onChange={(event) =>
                                                  membersDetailsChange(event, index)
                                                }
                                                value={SelectedMemberDetails.country}
                                                disabled={true}
                                              >
                                                <option>India</option>
                                              </select>
                                            </Col>

                                            <Col lg={3} md={3} xs={12} className="mb-3">
                                              <TableText
                                                label="State"
                                                required={true}
                                                LeftSpace={false}
                                              />
                                              <select style={{ textTransform: 'uppercase' }}
                                                className="form-control"
                                                name="state"
                                                onChange={(event) =>
                                                  membersDetailsChange(event, index)
                                                }
                                                value={SelectedMemberDetails.state}
                                                disabled={true}
                                              >
                                                <option>Andhra Pradesh</option>
                                              </select>
                                            </Col> */}

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="District" required={true} LeftSpace={false} />
                                      <select style={{ textTransform: 'uppercase' }}
                                        className="form-control"
                                        name="district"
                                        onChange={(event) => {
                                          membersDetailsChange(event)
                                          districtmemberChange(event)
                                        }}
                                        value={SelectedMemberDetails.district}
                                      >
                                        <option>Select</option>
                                        {districtList.map((item: any, i: any) => {
                                          return (
                                            <option key={i + 1} value={item.name}>
                                              {item.name}
                                            </option>
                                          )
                                        })}
                                      </select>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="Mandal" required={true} LeftSpace={false} />
                                      <select style={{ textTransform: 'uppercase' }}
                                        className="form-control"
                                        name="mandal"
                                        id={"mandal"}
                                        placeholder="Mandal"
                                        onChange={(event) => {
                                          membersDetailsChange(event)
                                          mandalmemberChange(event)
                                        }}
                                        value={SelectedMemberDetails.mandal}
                                      // defaultValue={"Select"}
                                      >
                                        <option>Select</option>
                                        {currentmemberDistrict && (
                                          <DynamicMandals
                                            currentDistrict={currentmemberDistrict}
                                            setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                          ></DynamicMandals>
                                        )}</select>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="Village" required={true} LeftSpace={false} />
                                      <select style={{ textTransform: 'uppercase' }}
                                        className="form-control"
                                        name="villageOrCity"
                                        id={"villageOrCity"}
                                        placeholder="Village/City"
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.villageOrCity}
                                      // defaultValue={"Select"}
                                      >
                                        <option>Select</option>
                                        {currentmemberDistrict && currentmemberMandal && <DynamicVillages
                                          currentDistrict={currentmemberDistrict}
                                          currentMandal={currentmemberMandal}
                                          setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                        ></DynamicVillages>}

                                      </select>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="PIN Code" required={true} LeftSpace={false} />
                                      <Form.Control
                                        disabled={false}
                                        type="text"
                                        maxLength={6}
                                        placeholder="Enter PIN Code"
                                        required={false}
                                        name={"pinCode"}
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.pinCode}
                                        onKeyPress={onNumberOnlyChange}
                                      />
                                    </Col>
                                    <div className="formSectionTitle">
                                      <h3>Contact Details</h3>
                                    </div>
                                    {/* <Col lg={3} md={3} xs={12} className="mb-3">
                                              <TableText
                                                label="Landline Number"
                                                required={false}
                                                LeftSpace={false}
                                              />
                                              <Form.Control
                                                disabled={false}
                                                type="text"
                                                maxLength={6}
                                                placeholder="Enter Landline Number"
                                                required={false}
                                                name={"phone"}
                                                onChange={(event) =>
                                                  membersDetailsChange(event, index)
                                                }
                                                value={SelectedMemberDetails.phone}
                                                onKeyPress={onNumberOnlyChange}
                                              />
                                            </Col> */}
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText
                                        label="Mobile Number"
                                        required={true}
                                        LeftSpace={false}
                                      />
                                      <Form.Control
                                        disabled={false}
                                        type="text"
                                        autoComplete="off"
                                        maxLength={10}
                                        placeholder="Enter Mobile Number"
                                        required={false}
                                        name={"mobileNumber"}
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.mobileNumber}
                                        onKeyPress={onNumberOnlyChange}
                                      />
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText
                                        label="Email Address"
                                        required={false}
                                        LeftSpace={false}
                                      />
                                      <Form.Control
                                        disabled={false}
                                        type="text"
                                        placeholder="Enter Email Address"
                                        required={false}
                                        name={"email"}
                                        maxLength={40}
                                        minLength={15}
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.email}
                                      />
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Whether the member is of sound mind?"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="soundMind"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.soundMind === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="soundMind"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.soundMind === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Whether the member is declared to be insolvent or an undischarged insolvent?"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="inSolvent"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.inSolvent === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="inSolvent"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.inSolvent === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Whether the member is convicted of an offense of moral turpitude? "
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="offense"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.offense === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="offense"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.offense === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Whether the member is disqualified for such an appointment by an order of a court?"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="appointment"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.appointment === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="appointment"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.appointment === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                </div>
                              </Row>
                            </div>
                          </div>{" "}
                          {/* </Accordion.Body>
                              </Accordion.Item> */}
                        </>
                        {/* )
                      })
                      } */}
                        <Row>
                          <Col lg={12} md={12} xs={12} className="">
                            <div className="addotherBtnInfo text-center mb-3">
                              {indexmember == -1 && (
                                <div onClick={handleMemberAdd} className="btn btn-primary addPartner">
                                  Add Member
                                </div>
                              )}
                              {indexmember != -1 && (
                                <div
                                  onClick={(index: any) => {
                                    handleMemberUpdate(indexmember)
                                  }}
                                  className="btn btn-primary addPartner mb-3"
                                >
                                  Update Member
                                </div>
                              )}
                            </div>
                          </Col>
                        </Row>
                        <Row>
                          <div className="dashboardRegSec">
                            <Row>
                              {membersDetails && membersDetails?.length > 0 ? (
                                <div ref={refUpdate} className="addedPartnerSec mt-3">
                                  <Row className="mb-4">
                                    <Col lg={12} md={12} xs={12}>
                                      <Table striped bordered className="tableData listData ">
                                        <thead>
                                          <tr>
                                            <th>Type</th>
                                            <th>Aadhaar No</th>
                                            <th>Name of the member</th>
                                            <th>Relation Name</th>
                                            <th>Age/Gender</th>
                                            <th>Role/Position</th>
                                            <th>Occupation</th>
                                            <th>Date of Joining</th>
                                            <th>Address</th>
                                            <th>Contact</th>
                                            <th>Action</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          {membersDetails.map((item: any, i: number) => {
                                            return (
                                              <tr>
                                                <td
                                                  className="text-wrap-table"
                                                  title={item.memberType}
                                                >
                                                  {item.memberType}
                                                </td>

                                                <td className="text-wrap-table" title={item.maskedAadhar}>
                                                  {item.maskedAadhar}
                                                </td>
                                                <td className="text-wrap-table" title={item.memberName}>{item.memberName}</td>
                                                <td className="text-wrap-table" title={item.relationName}>{item.relationName}</td>
                                                <td className="text-wrap-table" title={`${item.age}/${item.gender}`}>{item.age} / {item.gender}</td>
                                                <td className="text-wrap-table" title={item.role}>{item.role}</td>
                                                <td className="text-wrap-table" title={item.occupation}>{item.occupation}</td>
                                                <td className="text-wrap-table" title={item.joiningDate}>{item.joiningDate}</td>
                                                <td className="text-wrap-table"
                                                  title={`${item.doorNo},${item.street},${item.district},${item.mandal},${item.villageOrCity},${item.pinCode}`}>
                                                  {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                                                </td>
                                                <td
                                                  className="text-wrap-table"
                                                  title={item.mobileNumber}
                                                >
                                                  {item.mobileNumber}
                                                </td>
                                                <td>
                                                  {" "}
                                                  <Image
                                                    alt="Image"
                                                    height={15}
                                                    width={15}
                                                    src="/assets/edit.svg"
                                                    style={{ cursor: "pointer" }}
                                                    onClick={() => {
                                                      handleMemberEdit(i)
                                                    }}
                                                  />
                                                  <Image
                                                    alt="Image"
                                                    height={20}
                                                    width={20}
                                                    src="/assets/delete-icon.svg"
                                                    style={{ cursor: "pointer" }}
                                                    onClick={() => {
                                                      handleMemberRemove(i)
                                                    }}
                                                  />
                                                </td>
                                              </tr>
                                            )
                                          })}
                                        </tbody>
                                      </Table>
                                    </Col>
                                  </Row>
                                </div>
                              ) : null}
                            </Row>
                          </div>
                        </Row>
                        {/* </Accordion> */}
                        <div className="firmSubmitSec">
                          <Row>
                            <Col lg={12} md={12} xs={12}>
                              {(existingSocietyDetail?.status == "Incomplete" || isResubmission == "true") && (
                                <>
                                  <div className="d-flex justify-content-center text-center">
                                    {" "}
                                    <Button
                                      className={styles.prev}
                                      onClick={goToPrevTab}
                                      type="button"
                                    >
                                      Back
                                    </Button>
                                    <Button type="submit">Save & Next</Button>
                                  </div>
                                </>
                              )}
                            </Col>
                          </Row>
                        </div>
                      </div>
                    </Form>
                  )}
                  {activeTab === 3 && (
                    <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
                      <>
                        <div className="regofAppBg mb-3">
                          <Row>
                            <Col lg={4} md={4} xs={12} className="mb-3">
                              <TableText
                                label="Name of the Society as mention in the Bye-Laws"
                                required={true}
                                LeftSpace={false}
                              />
                              <TableInputText
                                disabled
                                type="text"
                                placeholder="Enter text here"
                                required={true}
                                name="societyName"
                                value={existingSocietyDetail?.societyName}
                                onChange={() => { }}
                              />
                            </Col>
                          </Row>
                          {/* byelawDetails, byelawsDetailsChange,handlebyelawAdd */}

                          <div className="formSectionTitle">
                            <h3>Address of the Society (as mention in the Bye-Laws)</h3>
                          </div>
                          <Row>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="Door No" required={true} LeftSpace={false} />
                              <TableInputText
                                disabled
                                // data
                                type="text"
                                placeholder="Enter Door No"
                                required={true}
                                name={"doorNo"}
                                value={existingSocietyDetail?.doorNo}
                                onChange={() => { }}
                              />
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="Street" required={false} LeftSpace={false} />
                              <TableInputText
                                disabled
                                type="text"
                                placeholder="Enter Street"
                                required={false}
                                name={"street"}
                                value={existingSocietyDetail?.street}
                                onChange={() => { }}
                              />
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="District" required={true} LeftSpace={false} />
                              <TableInputText
                                name="district"
                                disabled
                                type="text"
                                placeholder="Enter district"
                                required={true}
                                onChange={() => { }}
                                value={existingSocietyDetail?.district}
                              />
                            </Col>

                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="Mandal" required={true} LeftSpace={false} />
                              <TableInputText
                                placeholder="Enter mandal"
                                required={true}
                                name="mandal"
                                // defaultValue={"Select"}
                                type="text"
                                disabled
                                onChange={() => { }}
                                value={existingSocietyDetail?.mandal}
                              />
                            </Col>

                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="Village" required={true} LeftSpace={false} />
                              <TableInputText
                                placeholder="Enter villageOrCity"
                                required={true}
                                type="text"
                                name="villageOrCity"
                                disabled
                                onChange={() => { }}
                                // defaultValue={"Select"}
                                value={existingSocietyDetail?.villageOrCity}
                              />
                            </Col>

                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="PIN Code" required={true} LeftSpace={false} />
                              <TableInputText
                                onChange={() => { }}
                                disabled
                                type="text"
                                maxLength={6}
                                placeholder="Enter PIN Code"
                                required={true}
                                name={"pinCode"}
                                value={existingSocietyDetail?.pinCode}
                              />
                            </Col>
                          </Row>
                          <div className="regFormBorder"></div>
                          <div className="formSectionTitle">
                            <h3>Contact Details</h3>
                          </div>
                          <Row>
                            {/* <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Landline Number" required={false} LeftSpace={false} />
                            <Form.Control
                              type="number"
                              placeholder="Enter Landline Number"
                              required={false}
                              name={"phone"}
                              value={byelawDetails.phone}
                              onChange={byelawsDetailsChange}
                              onKeyPress={onNumberOnlyChange}
                            />
                          </Col> */}
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="Mobile No" required={true} LeftSpace={false} />
                              <TableInputText
                                type="text"
                                placeholder="Enter Mobile No"
                                required={true}
                                disabled
                                name={"mobileNumber"}
                                value={existingSocietyDetail?.mobileNumber}
                                onChange={() => { }}
                              />
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText label="Email Address" required={false} LeftSpace={false} />
                              <TableInputText
                                disabled
                                type="email"
                                placeholder="Enter Email Address"
                                required={false}
                                name={"email"}
                                maxLength={40}
                                minLength={15}
                                value={existingSocietyDetail?.email}
                                onChange={() => { }}
                              />
                            </Col>
                          </Row>
                          <div className="regFormBorder"></div>
                          <Row>
                            <Col lg={9} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Do the Bye-Laws contain the membership conditions (Eligibility, Admission, Withdrawal, Termination)"
                                required={false}
                                LeftSpace={false}
                              />

                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  defaultValue="Yes"
                                  name="membershipConditions"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={byelawsDetailsChange}
                                  checked={byelawDetails.membershipConditions === "Yes"}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  defaultValue="No"
                                  name="membershipConditions"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={byelawsDetailsChange}
                                  checked={byelawDetails.membershipConditions === "No"}
                                />
                              </div>
                            </Col>
                          </Row>
                          <div className="formSectionTitle">
                            <h3>Executive Body</h3>
                          </div>
                          <Row>
                            <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Executive Committee Body meeting conditions (Quorum, Conditions, Responsibilities)"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  defaultValue="Yes"
                                  name="meetingConditions"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={byelawsDetailsChange}
                                  checked={byelawDetails.meetingConditions === "Yes"}
                                />
                                <Form.Check
                                  inline
                                  checked={byelawDetails.meetingConditions === "No"}
                                  label="No"
                                  defaultValue="No"
                                  name="meetingConditions"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={byelawsDetailsChange}
                                />
                              </div>
                            </Col>
                          </Row>
                          <Row>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <TableText
                                label=" Size of the Quorum"
                                required={false}
                                LeftSpace={false}
                              />
                              <TableInputText
                                disabled={true}
                                type="text"
                                placeholder="Enter Quorum Size"
                                required={false}
                                name="quorumSize"
                                value={byelawDetails.quorumSize}
                                onChange={() => { }}
                              />
                            </Col>
                          </Row>
                          <div className="regofAppBg mb-3" style={{ backgroundColor: "#EEEEEE" }}>
                            <div className="formSectionTitle mb-3">
                              <h3>Details of EC Members</h3>
                            </div>
                            <Table
                              striped
                              bordered
                              style={{ width: "100%" }}
                              className="tableData listData"
                            >
                              <thead>
                                <tr>
                                  {tableHeaders2.map((header: any, index: number) => {
                                    return <th key={index + 1}>{header}</th>
                                  })}
                                </tr>
                              </thead>
                              <tbody>
                                {membersDetails.map((form2: any, index: number) => {
                                  return (
                                    <tr key={index + 1}>
                                      {/* <td className="">
                                        <Form.Check
                                          style={{
                                            height: "50%",
                                            marginBottom: "15px",
                                            marginLeft: "10px",
                                          }}
                                          inline
                                          label=""
                                          name="quorum"
                                          type="checkbox"
                                          value={form2.memberName}
                                          className="fom-checkbox"
                                          onChange={changeCheck}
                                          checked={checkedList.includes(form2.memberName)}
                                        />
                                      </td> */}
                                      <td className="text-wrap-table"
                                        title={form2.memberType}>{form2.memberType}</td>
                                      <td className="text-wrap-table"
                                        title={form2.maskedAadhar}>{form2.maskedAadhar}</td>
                                      <td className="text-wrap-table"
                                        title={form2.memberName}>{form2.memberName}</td>
                                      <td className="text-wrap-table" title={form2.relationName}>{form2.relationName}</td>
                                      <td className="text-wrap-table" title={`${form2.age}/${form2.gender}`}>
                                        {form2.age}/{form2.gender}
                                      </td>
                                      <td className="text-wrap-table" title={form2.role}>
                                        {form2.role}
                                      </td>
                                      <td className="text-wrap-table" title={form2.occupation}>{form2.occupation}</td>
                                      <td className="text-wrap-table" title={form2.joiningDate}>{form2.joiningDate}</td>
                                      <td className="text-wrap-table" title={`${form2.doorNo},${form2.street},${form2.district},${form2.mandal},${form2.villageOrCity},${form2.pinCode}`}>

                                        {form2.doorNo},{form2.district},{form2.mandal},
                                        {form2.villageOrCity},{form2.pinCode}
                                      </td>
                                      <td className="text-wrap-table" title={form2.mobileNumber}>{form2.mobileNumber}</td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </Table>

                          </div>

                          <Row>
                            <Col lg={10} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Whether the bye-laws contain the conditions of Office Bearers (Appointment, Election, Removal, Recall, Responsibilites)"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  defaultValue="Yes"
                                  required={true}
                                  name="officeBearers"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={byelawsDetailsChange}
                                  checked={byelawDetails.officeBearers === "Yes"}
                                />

                                <Form.Check
                                  inline
                                  checked={byelawDetails.officeBearers === "No"}
                                  label="No"
                                  defaultValue="No"
                                  name="officeBearers"
                                  required={true}
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={byelawsDetailsChange}
                                />
                              </div>
                            </Col>
                          </Row>

                          <Row>
                            <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Whether the bye-laws contain the details of finance ?"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  required={true}
                                  name="finance"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={(event: any) => byelawsDetailsChange(event)}
                                  defaultValue="Yes"
                                  checked={byelawDetails.finance === "Yes"}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  defaultValue="No"
                                  name="finance"
                                  required={true}
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={(event: any) => byelawsDetailsChange(event)}
                                  checked={byelawDetails.finance === "No"}
                                />
                              </div>
                            </Col>
                          </Row>
                          <Row>
                            <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Whether the bye-laws contain the details of the auditor ?"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  value="Yes"
                                  name="auditor"
                                  type="radio"
                                  className="fom-checkbox"
                                  // onChange={byelawsDetailsChange}
                                  checked={displayOption === "display"}
                                  onChange={() => setDisplayOption("display")}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  value="No"
                                  name="auditor"
                                  type="radio"
                                  className="fom-checkbox"
                                  checked={displayOption === "not-display"}
                                  onChange={() => setDisplayOption("not-display")}
                                />
                              </div>
                            </Col>
                          </Row>
                          {displayOption === "display" && (
                            <div>
                              <Row className="mb-3">
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Name of the Auditor"
                                    LeftSpace={false}
                                    required={true}
                                  />
                                  <TableInputText
                                    type={"text"}
                                    placeholder={"Enter Name of the Auditor"}
                                    required={true}
                                    value={auditorDetails.auditorName}
                                    onChange={auditorDetailsChange}
                                    name="auditorName"
                                  ></TableInputText>
                                </Col>
                                <Col lg={3} md={12} sm={12} className="mb-3">
                                  <TableText label={"Mobile No"} required={true} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Mobile No"
                                    maxLength={10}
                                    required={true}
                                    name="mobileNumber"
                                    value={auditorDetails.mobileNumber}
                                    onChange={auditorDetailsChange}
                                  />
                                  {errors.mobileNumber && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.mobileNumber}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={12} sm={12} className="mb-3">
                                  <TableText
                                    label={"Email Address"}
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Email Address"
                                    required={false}
                                    name="email"
                                    maxLength={40}
                                    minLength={15}
                                    value={auditorDetails.email}
                                    onChange={auditorDetailsChange}
                                  />
                                  {errors.email && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.email}
                                    </span>
                                  )}
                                </Col>{" "}
                              </Row>
                              <div className="formSectionTitle">
                                <h3>Address</h3>
                              </div>
                              <Row>
                                <Col lg={3} md={12} sm={12} className="mb-3">
                                  {" "}
                                  <TableText label={"Door No"} required={true} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Door No"
                                    required={true}
                                    name="doorNo"
                                    value={auditorDetails.doorNo}
                                    onChange={auditorDetailsChange}
                                  />
                                  {errors.doorNo && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.doorNo}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={12} sm={12} className="mb-3">
                                  <TableText label={"Street"} required={false} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Street"
                                    required={false}
                                    name="street"
                                    value={auditorDetails.street}
                                    onChange={auditorDetailsChange}
                                  />
                                  {errors.Street && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.Street}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={4} xs={12} className="mb-3">
                                  <TableText label="District" required={true} LeftSpace={false} />
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="district"
                                    onChange={(event) => {
                                      districtauditorChange(event)
                                      auditorDetailsChange(event)
                                    }}
                                    value={auditorDetails.district}
                                  >
                                    <option>Select</option>
                                    {districtList.map((item: any, i: any) => {
                                      return (
                                        <option key={i + 1} value={item.name}>
                                          {item.name}
                                        </option>
                                      )
                                    })}
                                  </select>
                                </Col>

                                <Col lg={3} md={4} xs={12} className="mb-3">
                                  <TableText label="Mandal" required={true} LeftSpace={false} />
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="mandal"
                                    defaultValue={"Select"}
                                    onChange={(event) => {
                                      mandalauditorChange(event)
                                      auditorDetailsChange(event)
                                    }}
                                    value={auditorDetails.mandal}
                                  >
                                    <option>Select</option>
                                    <DynamicMandals
                                      currentDistrict={currentauditorDistrict}
                                      setDetails={() => setauditorDetails({ ...auditorDetails })}
                                    ></DynamicMandals>
                                  </select>
                                </Col>

                                <Col lg={3} md={4} xs={12} className="mb-3">
                                  <TableText label="Village" required={true} LeftSpace={false} />
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="villageOrCity"
                                    onChange={auditorDetailsChange}
                                    defaultValue={"Select"}
                                    value={auditorDetails.villageOrCity}
                                  >
                                    <option>Select</option>
                                    <DynamicVillages
                                      currentDistrict={currentauditorDistrict}
                                      currentMandal={currentauditorMandal}
                                      setDetails={() => setauditorDetails({ ...auditorDetails })}
                                    ></DynamicVillages>
                                  </select>
                                </Col>
                                <Col lg={3} md={12} sm={12} className="mb-3">
                                  {" "}
                                  <TableText label={"Pin Code"} required={true} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Pin Code"
                                    required={true}
                                    name="pinCode"
                                    maxLength={6}
                                    value={auditorDetails.pinCode}
                                    onChange={auditorDetailsChange}
                                  />
                                  {errors.pinCode && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.pinCode}
                                    </span>
                                  )}
                                </Col>
                              </Row>
                            </div>
                          )}
                          {displayOption === "not-display" && <div></div>}
                          <Row>
                            <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Whether the bye-laws contain the conditions for raising of the funds?"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  defaultValue="Yes"
                                  name="raisingFunds"
                                  type="radio"
                                  required={true}
                                  className="fom-checkbox"
                                  onChange={(event: any) => byelawsDetailsChange(event)}
                                  checked={byelawDetails.raisingFunds === "Yes"}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  defaultValue="No"
                                  required={true}
                                  name="raisingFunds"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={(event: any) => byelawsDetailsChange(event)}
                                  checked={byelawDetails.raisingFunds === "No"}
                                />
                              </div>
                            </Col>
                          </Row>
                          <Row>
                            <Col lg={10} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Whether the bye-laws contain the conditions for liabilities of EC members in financial matters and exchange of debts ?"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  defaultValue="Yes"
                                  required={true}
                                  name="liabilityConditions"
                                  type="radio"
                                  className="fom-checkbox"
                                  onChange={(event: any) => byelawsDetailsChange(event)}
                                  checked={byelawDetails.liabilityConditions === "Yes" ? true : false}
                                />
                                {/* {console.log("data",byelawDetails)} */}
                                <Form.Check
                                  inline
                                  label="No"
                                  defaultValue="No"
                                  name="liabilityConditions"
                                  type="radio"
                                  required={true}
                                  className="fom-checkbox"
                                  onChange={(event: any) => byelawsDetailsChange(event)}
                                  checked={byelawDetails.liabilityConditions === "No" ? true : false}
                                />
                              </div>
                            </Col>
                          </Row>
                          <Row>
                            {/* <pre>{JSON.stringify(byelawDetails,2,null)}</pre> */}
                            <Col lg={9} md={3} xs={12} style={{ display: "flex" }}>
                              <TableText
                                label="Whether the bye-laws contain the other matters like settlement of internal disputes or dissolution of society ?"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  disabled={false}
                                  type="radio"
                                  required={true}
                                  name="otherMatters"
                                  onChange={(event) => byelawsDetailsChange(event)}
                                  defaultValue="Yes"
                                  checked={byelawDetails.otherMatters === "Yes"}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  disabled={false}
                                  type="radio"
                                  required={true}
                                  name="otherMatters"
                                  onChange={(event) => byelawsDetailsChange(event)}
                                  defaultValue="No"
                                  checked={byelawDetails.otherMatters === "No"}
                                />
                              </div>
                            </Col>
                          </Row>
                        </div>

                        <div className="regofAppBg my-3">
                          <div className="d-flex justify-content-between align-items-center page-title mb-3">
                            <div className="pageTitleLeft">
                              <h1>
                                Upload Society Related Documents-(All Uploaded Documents should be in
                                PDF format only upto 6MB )
                              </h1>
                            </div>
                          </div>
                          <Row>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText
                                label={"Memorandum of Association"}
                                required={true}
                                LeftSpace={false}
                              />
                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  required={true}
                                  name="memorandum"
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText label={"Bye - Laws "} required={true} LeftSpace={false} />
                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  name="byeLaws"
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  required={true}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText
                                label={"ID Proofs of EC Members "}
                                required={true}
                                LeftSpace={false}
                              />
                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  name="idProofs"
                                  ref={inputRef}
                                  required={true}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText
                                label={"Self Signed Declaration of EC Members "}
                                required={true}
                                LeftSpace={false}
                              />
                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  name="selfSignedDeclaration"
                                  ref={inputRef}
                                  required={true}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText
                                label={"Affidavit  /  Lease Agreement "}
                                required={true}
                                LeftSpace={false}
                              />
                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  name="affidavit"
                                  required={true}
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col>
                            <Col lg={3} md={12} sm={12} className="my-2">
                              <TableText
                                label={"Affidavit by Auditor"}
                                required={true}
                                LeftSpace={false}
                              />
                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  required={true}
                                  name="affidavitByAuditor"
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col>
                          </Row>
                        </div>
                        <div className="firmSubmitSec">
                          <Row>
                            <Col lg={12} md={12} xs={12}>
                              {(existingSocietyDetail?.status == "Incomplete" || isResubmission == "true") && (
                                <>
                                  <div className="d-flex justify-content-center text-center">
                                    {" "}
                                    <Button
                                      className={styles.prev}
                                      onClick={goToPrevTab}
                                      type="button"
                                    >
                                      Back
                                    </Button>
                                    <Button type="submit">Save</Button>
                                    <Button
                                      variant="primary"
                                      type="submit"
                                      onClick={() => setIsPayNowClicked(true)
                                      }
                                    >
                                      Pay now
                                    </Button>
                                  </div>
                                </>
                              )}
                            </Col>
                          </Row>
                        </div>
                      </>
                    </Form>
                  )}
                </Container>
                // </Form>
              )}
            {(existingSocietyDetail?.status != "Incomplete" && isResubmission == "false") &&
              (existingSocietyDetail?.societyStatus != "Approved" ||
                existingSocietyDetail?.societyStatus != "Rejected") && (
                <Col lg={12} md={12} xs={12}>
                  <div className="d-flex justify-content-between pagesubmitSecTitle mb-3">
                    <div className="ms-2">
                      <h2>
                        Your application was submitted.{" "}
                        <a href="/societies" style={{ color: "blue" }}>
                          click here
                        </a>{" "}
                        to check application status
                      </h2>
                    </div>
                  </div>
                </Col>
              )}
          </div>)}
        {(!locData?.userType || locData?.userType != "user") && (

          <div className="societyRegSec">

            <Container>

              <Row>

                <Col lg={12} md={12} xs={12}>

                  <div className="d-flex justify-content-between page-title mb-2" style={{ paddingTop: "17px" }}>

                    <div className="pageTitleLeft">

                      <h1>Unauthorized page</h1>

                    </div>

                  </div>

                </Col>

              </Row>

            </Container>

          </div>

        )}
      </div>
    </>
  )
}
