import React, { useEffect, useState } from "react"
import Head from "next/head"
import { Container, Row, Col, Accordion, Button, Modal } from "react-bootstrap"
import router, { Router } from "next/router"
import { Route } from "react-router"
import { routes } from "@/router/routes"
import CryptoJS from "crypto-js"
const SocietyDashboard = () => {
  useEffect(() => {
    require("bootstrap/dist/js/bootstrap.bundle.min.js")
  }, [])
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showProceedModal, setShowProceedModal] = useState(false);
  const [locData, setLocData] = useState<any>({})
  const handleClosePaymentModal = () => {
    setShowPaymentModal(false);
  };
  const handleCloseProceedModal = () => {
    setShowProceedModal(false);
  };
  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLocData(data)
    }
  }, [])
  return (
    <>
      <Head>
        <title>E-Registration of Societies</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>
      {locData && locData?.userType && locData?.userType == "user" && (
      <div className="societyRegSec">
        <Container>
          <Row>
            <Col lg={12} md={12} xs={12}>
              <div className="d-flex justify-content-between page-title mb-2">
                <div className="pageTitleLeft">
                  <h1>E-Registration of Societies</h1>
                </div>
              </div>
            </Col>
          </Row>
        </Container>

        <div className="dashboardRegSec">
          <Container>
            <Row className="dashboardTopList justify-items-center">
              <Col lg={3} md={3} xs={12} className="mb-4 dashboardFirm">
                <div className="dashboardChangesInfo d-flex align-items-center">
                  <div className="dashboardFirmImg">
                    <img src="/assets/firm-reg-icon.jpg" alt="Firm Registration" />
                  </div>
                  <div className="dashboardFirmRight">
                    <h6>Society Registration</h6>
                    <div className="d-flex justify-content-between">
                      <p className="mrg">
                        Fee - <strong>500/-</strong>
                      </p>
                    </div>
                  </div>
                </div>
              </Col>

              <Col lg={3} md={3} xs={12} className="mb-4 dashboardCertified">
                <div className="dashboardChangesInfo d-flex align-items-center">
                  <div className="dashboardFirmImg">
                    <img src="/assets/certified-icon.jpg" alt="Certified" />
                  </div>
                  <div className="dashboardFirmRight">
                    <h6>Certified Copy of ByeLaw</h6>
                    <div className="d-flex justify-content-between">
                      <p className="mrg">
                        Fee - <strong>100/-</strong>
                      </p>
                    </div>
                    <div className="d-flex justify-content-between">
                      <p className="mrg">
                        User Charges - <strong>100/-</strong>
                      </p>
                    </div>
                  </div>
                </div>
              </Col>

              <Col lg={3} md={3} xs={12} className="mb-4 dashboardAddress">
                <div className="dashboardChangesInfo d-flex align-items-center">
                  <div className="dashboardFirmImg">
                    <img src="/assets/address-change-icon.jpg" alt="Certified" />
                  </div>
                  <div className="dashboardFirmRight">
                    <h6>Certified Copy of Society</h6>
                    <div className="d-flex justify-content-between">
                      <p className="mrg">
                        Fee - <strong>100/-</strong>
                      </p>
                    </div>
                    <div className="d-flex justify-content-between">
                      <p className="mrg">
                        User Charges - <strong>100/-</strong>
                      </p>
                    </div>
                  </div>
                </div>
              </Col>

              <Col lg={3} md={3} xs={12} className="mb-4 dashboardReconstitution">
                <div className="dashboardChangesInfo d-flex align-items-center">
                  <div className="dashboardFirmImg">
                    <img src="/assets/reconstitution-icon.jpg" alt="Reconstitution" />
                  </div>
                  <div className="dashboardFirmRight">
                    <h6>Filling Of Amendment</h6>
                    <div className="d-flex justify-content-between">
                      <p className="mrg">
                        Fee - <strong>300/-</strong> (per change)
                      </p>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>

        <div className="dahboardProcedureSec">
          <Container>
            <Row>
              <Col lg={4} md={6} xs={12} className="p-1">
                <div className="dashboardInfologin">
                  <h6> E-Registration of Society (Online Application Form)</h6>

                  <div className="panelDesc">
                    <p>
                      {/* href="/societies/details" */}
                      <a onClick={() => { setShowPaymentModal(true) }} style={{ cursor: "pointer" }}>
                        <strong>Click here for Online Application Form</strong>
                      </a>
                    </p>
                  </div>
                </div>
                <Modal show={showPaymentModal} onHide={handleClosePaymentModal} style={{ paddingTop: "5%" }}>
                  <Modal.Header closeButton>
                    <Modal.Title>
                      Check List
                    </Modal.Title>
                  </Modal.Header>
                  <Modal.Body className="text-start">
                    <ul>
                      <li><p>Aadhaar Numbers of All Members</p></li>
                      <li><p>Lease Agreement/Rental Agreement/Legal Affidavit incase of own property</p></li>
                      <li><p>Self Signed Declaration of Members</p></li>
                      <li><p>Memorandum</p></li>
                      <li><p>Bye Laws</p></li>
                      <li><p>ID Proofs</p></li>
                      <li><p>Affidavit By Auditor</p></li>
                    </ul>
                  </Modal.Body>
                  <Modal.Footer>
                    <div style={{ alignItems: "flex-end" }}>
                      <Button variant="primary" onClick={() => { router.push('/societies/details') }}>
                        Proceed
                      </Button>
                      <Button variant="secondary" className="ms-2" onClick={() => { setShowPaymentModal(false) }}>
                        Cancel
                      </Button>
                    </div>

                  </Modal.Footer>
                </Modal>

              </Col>
              <Col lg={4} md={6} xs={12} className="p-1">
                <div className="dashboardInfologin">
                  <h6>Status of Application</h6>
                  <div className="panelDesc">
                    <p>
                      <a style={{ cursor: "pointer" }} onClick={() => { router.push('/societies') }}>
                        <strong>Click here for Status of the Application</strong>
                      </a>
                    </p>
                  </div>
                </div>
              </Col>
              <Col lg={4} md={6} xs={12} className="p-1">
                <div className="dashboardInfologin">
                  <h6> Download of Registration Certificate</h6>
                  <div className="panelDesc">
                    <p>
                      <a href="/societies/downloadCertificate">
                        <strong>Click here to download the Certificate</strong>
                      </a>
                    </p>
                  </div></div>
              </Col>
              <Col lg={8} md={6} xs={12} className="p-1">
                <div className="dashboardInfologin">
                  <h6>Filing of Amendment/Annual Returns Etc</h6>
                  <div className="panelDesc">
                    <p className="p-0 m-0">
                      <a onClick={() => { setShowProceedModal(true) }} style={{ cursor: "pointer" }}>
                        <strong>Click here for filing the Amendments</strong>
                      </a>
                    </p>

                    <p>
                      This service can be availed by any society who wants to amendment bye
                      law's or rules. Required document should be uploaded. Department after verification can approve or
                      reject the request.
                    </p>

                    <h6>Documents Needed :</h6>

                    <div className="mb-3">
                      <ol>
                        <li>
                          Online Application from applicant along with mandatory resolutions
                        </li>
                     
                        <li>
                          The approval of the same shall be within 3 working days.
                        </li>
                      </ol>
                    </div>
                  </div>
                  <Modal show={showProceedModal} onHide={handleCloseProceedModal} style={{ paddingTop: "5%" }}>
                    <Modal.Header closeButton>
                      <Modal.Title>
                        Check List
                      </Modal.Title>
                    </Modal.Header>
                    <Modal.Body className="text-start">
                      <ul>
                        <li><p>Aadhaar Numbers of All Members</p></li>
                        <li><p>Lease Agreement/Rental Agreement/Legal Affidavit incase of own property</p></li>
                        <li><p>Self Signed Declaration of Members</p></li>
                        <li><p>Memorandum</p></li>
                        <li><p>Bye Laws</p></li>
                        <li><p>ID Proofs</p></li>
                        <li><p>Affidavit By Auditor</p></li>
                        <li><p>Declaration</p></li>
                        <li><p>Supporting Documents</p></li>
                      </ul>
                    </Modal.Body>
                    <Modal.Footer>

                      <div style={{ alignItems: "flex-end" }}>
                        <Button variant="primary" onClick={() => { router.push('/listofAmendment') }}>
                          Proceed
                        </Button>
                        <Button variant="secondary" className="ms-2" onClick={() => { setShowProceedModal(false) }}>
                          Cancel
                        </Button>
                      </div>

                    </Modal.Footer>
                  </Modal></div></Col>
              <Col lg={4} md={6} xs={12}>
                <Row>
                  <Col lg={12} md={6} xs={12} className="p-1">
                    <div className="dashboardInfologin">
                      <h6>Certified Copy of Bye-laws of Societies</h6>
                      <div className="panelDesc">
                        <p className="p-0 m-0">
                          <a href="/societies/downloadByLawCertificate">
                            <strong>Click here for the Certified Copy of Bye-laws</strong>
                          </a>
                        </p>

                        <p className="p-0 m-0">
                          <strong>Description :</strong> Any person can get the certified copy of
                          Bye-Laws of Registered society through the facility
                        </p>

                        <h6>Required Documents :</h6>

                        <div className="mb-3">
                          <ol>
                            <li>Online Application</li>
                          </ol>
                        </div>

                        <p>
                          <strong>Approval Authority :</strong> Registrar General of Societies
                          (Commissioner & IG){" "}
                          <a href="/societies/details">
                            <strong>Click here</strong>
                          </a>
                        </p>
                      </div></div></Col>
                  <Col lg={12} md={6} xs={12} className="p-1">
                    <div className="dashboardInfologin">
                      <h6>Model MOA & Bye-laws</h6>
                      <div className="panelDesc">
                        <p>
                          <a href="/societies/details">
                            <strong>Click here for Model MOA & Bye-laws</strong>
                          </a>
                        </p>
                      </div>
                    </div>
                  </Col></Row>
              </Col>
            </Row>
          </Container>
        </div >
      </div >)}
      {(!locData?.userType || locData?.userType != "user") && (
        <div className="societyRegSec">
          <Container >
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title" style={{paddingTop:"17px"}}>
                  <div className="pageTitleLeft ">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}

export default SocietyDashboard
