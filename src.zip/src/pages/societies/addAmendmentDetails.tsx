import React, { useEffect, useRef, useState } from 'react'
import { Row, Col, Form, Container, Button } from 'react-bootstrap'
import styles from "@/styles/pages/Forms.module.scss"
import TableInputText from '@/components/TableInputText'
import TableText from '@/components/TableText'
import CryptoJS from 'crypto-js'
import { CallingAxios, KeepLoggedIn, ShowMessagePopup } from '@/GenericFunctions'
import { UseSaveDataEntrySocietyDetails } from '@/axios'
import DynamicMandals from './dynamicMandals'
import DynamicVillages from './dynamicCities'
import instance from '@/redux/api'
import { LoadingAction } from '@/redux/commonSlice'
import { store } from '@/redux/store'
interface AmendmentProps {
  reqsearchdata: any
  selectedRequest: any
  setReqSearchData: any
  setIsView: any
  setIsError: any
  setErrorMessage: any
}
const AddAmendmentDetails = ({
  reqsearchdata,
  selectedRequest,
  setReqSearchData,
  setIsView,
  setIsError,
  setErrorMessage,
}: AmendmentProps) => {
  const [checkedList, setCheckedList] = useState<string[]>([])
  const Loading = (value: boolean) => { store.dispatch(LoadingAction({ enable: value })) }
  const [isCheckSoc, setIsCheckSoc] = useState<boolean>(false)
  const [selectedOption, setSelectedOption] = useState<string>("")
  const [file, setFile] = useState<any>({})
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [locData, setLocData] = useState<any>({})
  const [token, setToken] = useState<string>("")
  const [districtList, setDistricts] = useState<any>([])
  const [societyDetails, setSocietyDetails] = useState<any>({
    societyName: "",
    category: "",
    aim: "",
    objective: "",
    newAim: "",
    newObjective: "",
    newNameDateEffect: "",
    societyNewName: "",
  })
  useEffect(() => {
    const isResubmit = localStorage.getItem("isResubmission")
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLocData(data)
      setToken(data.token)
    }
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)
      })
      .catch(() => {
        Loading(false)
      })
  }, [])

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if (fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])) {
      // throw Error("Invalid File");
      ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
      e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if (fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])) {
      if (!regex) {
        ShowMessagePopup(false, "Please upload proper file name");
        e.target.value = "";
      }
    }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }
  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  const societyDetailsChange = (e: any) => {
    setSocietyDetails({ ...societyDetails, [e.target.name]: e.target.value })
    console.log("society deatils", societyDetails)
  }
  const handleOptionChange = (event: any) => {
    setSelectedOption(event.target.value)
    // setIsCheckSoc(false)
    setSocietyDetails({
      societyName: selectedRequest[`societyFields`].societyName,
      category: "",
      aim: "",
      objective: "",
      newAim: "",
      newObjective: "",
      joiningofnewmember: "",
      membersagreedwithbyelaws: "",
      joiningofnewmemberapprovedbyQuorum: "",

      newNameDateEffect: "",
      societyNewName: "",
      street: "",
      annualmeeting: "",
      venue: "",
      memberattended: "",
      governingbody: "",
      newDate: "",
      memoradumByelaws: "",
      doorNo: "",
      district: selectedRequest[`societyFields`].district,
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      majority: "",
      acceptorapprove: "",
      majority1: "",
      acceptorapprove1: ""
    })
  }
  let message
  if (selectedOption === "With in the district") {
    message = (
      <div className=" page-title mb-3">
        <div className="formSectionTitle ms-2">
          <h3>Enter New Address</h3>
        </div>
        <Row>
          <Col lg={3} md={4} xs={12} >
            <TableText label="Door No" required={true} LeftSpace={false} />
            <TableInputText
              disabled={false}
              type="text"
              placeholder="Enter Door No"
              required={true}
              name={"doorNo"}
              value={societyDetails.doorNo}
              onChange={societyDetailsChange}
            />
          </Col>

          <Col lg={3} md={4} xs={12} >
            <TableText label="Street" required={true} LeftSpace={false} />
            <TableInputText
              disabled={false}
              type="text"
              placeholder="Enter Street"
              required={true}
              name={"street"}
              value={societyDetails.street}
              onChange={societyDetailsChange}
            />
          </Col>

          <Col lg={3} md={4} xs={12} >
            <TableText label="District" required={true} LeftSpace={false} />
            <select style={{ textTransform: 'uppercase' }}
              className="form-control"
              name="district"
              onChange={() => { }}
              value={societyDetails.district}
              required={true}
              disabled={true}
            >
              <option>Select</option>
              {districtList.map((item: any, i: any) => {
                return (
                  <option key={i + 1} value={item.name}>
                    {item.name}
                  </option>
                )
              })}
            </select>
          </Col>

          <Col lg={3} md={4} xs={12} >
            <TableText label="Mandal" required={true} LeftSpace={false} />
            <select style={{ textTransform: 'uppercase' }}
              className="form-control"
              name="mandal"
              onChange={(event) => {
                societyDetailsChange(event)
              }}
              value={societyDetails.mandal}
              required={true}
              defaultValue={"Select"}
            >
              <option>Select</option>
              <DynamicMandals currentDistrict={societyDetails.district}></DynamicMandals>
            </select>
          </Col>

          <Col lg={3} md={4} xs={12} className="mb-3">
            <TableText label="Village" required={true} LeftSpace={false} />
            <select style={{ textTransform: 'uppercase' }}
              className="form-control"
              name="villageOrCity"
              onChange={societyDetailsChange}
              value={societyDetails.villageOrCity}
              required={true}
              defaultValue={"Select"}
            >
              <option>Select</option>
              <DynamicVillages
                currentDistrict={societyDetails.district}
                currentMandal={societyDetails.mandal}
              ></DynamicVillages>
            </select>
          </Col>

          <Col lg={3} md={4} xs={12} className="mb-3">
            <TableText label="PIN Code" required={true} LeftSpace={false} />
            <Form.Control
              disabled={false}
              type="text"
              maxLength={6}
              placeholder="Enter PIN Code"
              required={true}
              name={"pinCode"}
              value={societyDetails.pinCode}
              onChange={societyDetailsChange}
              onKeyPress={onNumberOnlyChange}
            />
          </Col>
        </Row>
      </div>
    )
  } else if (selectedOption === "Outside the district") {
    message = (
      <div className="panelDesc formsec">
        <Row>
          <Col lg={12} md={12} xs={12}>
            <div className="regofAppBg mb-3 ">
              <div className="formsec">
                <Row className="">
                  <Col lg={3} md={3} xs={12} className="mb-3 ">
                    <Form.Group>
                        <Form.Label>Select Distrcit</Form.Label>
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="district"
                        onChange={societyDetailsChange}
                        value={societyDetails.district}
                        required={true}
                        disabled={false}
                      >
                        <option>Select</option>
                        {districtList.map((item: any, i: any) => {
                          return (
                            <option key={i + 1} value={item.name}>
                              {item.name}
                            </option>
                          )
                        })}
                      </select>

                    </Form.Group>
                  </Col>
                </Row>
                <div className=" page-title mb-3">
                  <div className="formSectionTitle">
                    <h3>Enter New Address</h3>
                  </div>
                  <Row className="mt-2">
                    <Col lg={3} md={3} xs={12} >
                      <TableText label="Door No" required={true} LeftSpace={false} />
                      <TableInputText
                        type="text"
                        placeholder="Enter Door No"
                        name="doorNo"
                        required
                        onChange={societyDetailsChange}
                        value={societyDetails.doorNo}

                      />
                   </Col>

                    <Col lg={3} md={3} xs={12} >
                      <TableText label="Street" LeftSpace={false} required={false} />
                      <TableInputText
                        type="text"
                        placeholder="Enter Street"
                        name="street"
                        required

                        value={societyDetails.street}
                        onChange={societyDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} >
                      <TableText label="District" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="district"
                        onChange={() => { }}
                        value={societyDetails.district}
                        required={true}
                        disabled={true}
                      >
                        <option>Select</option>
                        {districtList.map((item: any, i: any) => {
                          return (
                            <option key={i + 1} value={item.name}>
                              {item.name}
                            </option>
                          )
                        })}
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} >
                      <TableText label="Mandal" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="mandal"
                        onChange={(event) => {
                          societyDetailsChange(event)
                        }}
                        value={societyDetails.mandal}
                        required={true}
                        defaultValue={"Select"}
                      >
                        <option>Select</option>
                        <DynamicMandals currentDistrict={societyDetails.district}></DynamicMandals>
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Village" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="villageOrCity"
                        onChange={societyDetailsChange}
                        value={societyDetails.villageOrCity}
                        required={true}
                        defaultValue={"Select"}
                      >
                        <option>Select</option>
                        <DynamicVillages
                          currentDistrict={societyDetails.district}
                          currentMandal={societyDetails.mandal}
                        ></DynamicVillages>
                      </select>
                    </Col>

                    <Col lg={3} md={3} xs={12} className="mb-3">
                      <TableText label="Pin Code" required={true} LeftSpace={false} />
                      <TableInputText
                        type="text"
                        placeholder="Enter Pin Code"
                        name="pinCode"
                        required
                        onChange={societyDetailsChange}
                        // value={pin}
                        maxLength={6}
                        value={societyDetails.pinCode}
                      />
                      {/* {pinErrorMessage && <p style={{ color: 'red' }}>{pinErrorMessage}</p>} */}
                    </Col>
                  </Row>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </div>
    )
  }
  const changeCheck = (e: React.ChangeEvent<HTMLInputElement>) => {
    const checkedValue = e.target.value
    const isChecked = e.target.checked

    if (isChecked) {
      if (
        checkedValue == "Change in the name of the society" ||
        checkedValue == "Change in the aims and objectives of the society" ||
        checkedValue == "Amendment of Memorandum and Bye-laws"
      ) {
        let disabledCheckboxes = [
          "Amalgamation of the society",
          "Winding up of the society",
          "Dissolution and winding up of the society",
          "Change of place of Registered Society Inside/Outside the District",
          "Filing of list of members",
        ]
        setCheckedList((prevCheckedList) => [...prevCheckedList, checkedValue])
        setCheckedList((prevCheckedList) =>
          prevCheckedList.filter((element) => !disabledCheckboxes.includes(element))
        )
      }

      if (
        checkedValue == "Amalgamation of the society" ||
        checkedValue == "Winding up of the society" ||
        checkedValue == "Dissolution and winding up of the society" ||
        checkedValue == "Change of place of Registered Society Inside/Outside the District" ||
        checkedValue == "Filing of list of members"
      ) {
        setCheckedList((prevCheckedList) => [...prevCheckedList, checkedValue])
        setCheckedList((prevCheckedList) =>
          prevCheckedList.filter((value) => value == checkedValue)
        )
      }
      // console.log("checkedlist", checkedList)
    } else {
      setCheckedList((prevCheckedList) => prevCheckedList.filter((value) => value !== checkedValue))
      //   setUncheckedList((prevUncheckedList) => [...prevUncheckedList, checkedValue]);
      //   console.log("uncheked",unchecked)
    }
  }
  const validateInputs = () => {
    let society = { ...societyDetails }
    if (checkedList &&
      checkedList.length > 0 &&
      checkedList.some((x: string) => x == "Change in the name of the society")) {
      if (!society.societyNewName) {
        return ShowMessagePopup(false, 'Please Enter Society New Name')
      }
      if (society.majority != "Yes") {
        return ShowMessagePopup(false, 'Please select validate option for majority of quorum members')
      }
      if (society.acceptorapprove != "Yes") {
        return ShowMessagePopup(false, 'Please select validate option for quorum')
      }
      if (!society.newNameDateEffect) {
        return ShowMessagePopup(false, 'Please Enter the new Name Date Effect')
      }
    }
  }
  const file2Base64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      if (reader && reader != null && file) {
        reader.readAsDataURL(file)
        reader.onload = () => resolve(reader.result?.toString() || "")
        reader.onerror = (error) => reject(error)
      }
      else {
        resolve("")
      }
    })
  }
  const handlesubmit = async (e: any) => {
    e.preventDefault()
    // if (validateInputs()) {
    const data = {
      // applicantDetails: selectedRequest["applicantFields"],

      societyDetails: societyDetails,
    }
    const newData = new FormData()
    newData.append("id", selectedRequest["applicantFields"].id)
    newData.append("applicantDetails[aadharNumber]", btoa(selectedRequest["applicantFields"].aadharNumber))
    newData.append("applicantDetails[applicationNumber]", selectedRequest["applicantFields"].applicantNumber)
    newData.append("applicantDetails[name]", selectedRequest["applicantFields"].applicantName)
    newData.append("applicantDetails[doorNo]", selectedRequest["applicantFields"].doorNo)
    newData.append("applicantDetails[street]", selectedRequest["applicantFields"].street)
    newData.append("applicantDetails[age]", selectedRequest["applicantFields"].age)
    newData.append("applicantDetails[gender]", selectedRequest["applicantFields"].applicantGender)
    newData.append("applicantDetails[country]", "India")
    newData.append("applicantDetails[state]", "Andhra Pradesh")
    newData.append("applicantDetails[district]", selectedRequest["applicantFields"].district)
    newData.append("applicantDetails[mandal]", selectedRequest["applicantFields"].mandal)
    newData.append("applicantDetails[villageOrCity]", selectedRequest["applicantFields"].villageOrCity)
    newData.append("applicantDetails[pinCode]", selectedRequest["applicantFields"].pinCode)
    newData.append("applicantDetails[mobileNumber]", selectedRequest["applicantFields"].mobileNumber)
    newData.append("applicantDetails[relationType]", selectedRequest["applicantFields"].relationType)
    newData.append("applicantDetails[relationName]", selectedRequest["applicantFields"].relationName)
    newData.append(
      "status",
      "Approved"
    )
    if (data.societyDetails?.district != "") {
      newData.append("doorNo", data.societyDetails.doorNo)
      newData.append("street", data.societyDetails.street)
      newData.append("district", data.societyDetails.district)
      newData.append("mandal", data.societyDetails.mandal)
      newData.append("villageOrCity", data.societyDetails.villageOrCity)
      newData.append("state", "Andhra Pradesh")
      newData.append("country", "India")
    }
    if (data.societyDetails?.newAim != "") {
      newData.append("aim", data.societyDetails.newAim)
      newData.append("objective", data.societyDetails.newObjective)

    }
    if (data.societyDetails?.societyNewName != "") {
      newData.append("societyName", data.societyDetails.societyNewName)
      newData.append("newNameDateEffect", data.societyDetails.newNameDateEffect)
    }
    if (file.byeLaws) {
      newData.append("byeLaws", file.byeLaws)
    }
    Object.keys(file).forEach(async (value: any, key: any) => {
      newData.append(key, value)
    })
    if (file.moa) {
      newData.append("moa", file.moa)
    }
    if (file.declaration) {
      newData.append("declaration", file.declaration)
    }
    if (file.supportingDoc) {
      newData.append("supportingDoc", file.supportingDoc)
    }
    if (file.selfSignedDeclaration) {
      newData.append("selfSignedDeclaration", file.selfSignedDeclaration)
    }
    if (checkedList &&
      checkedList.length > 0 &&
      checkedList.some((x: string) => x == "Change in the name of the society")) {
      newData.append("isNameChange", "true")
    }
    if (checkedList &&
      checkedList.length > 0 &&
      checkedList.some((x: string) => x == "Change in the aims and objectives of the society")) {
      newData.append("isAimChange", "true")
    }
    if (checkedList &&
      checkedList.length > 0 &&
      checkedList.some((x: string) => x == "Amendment of Memorandum and Bye-laws")) {
      newData.append("isMemorandumChange", "true")
    }
    if (
      checkedList &&
      checkedList.length > 0 &&
      checkedList.some(
        (x: string) =>
          x == "Change of place of Registered Society Inside/Outside the District"
      )) {
      newData.append("isAddressChange", "true")
    }
    Object.keys(file).forEach(async (value: any, key: any) => {
      newData.append(key, value)
    })
    let keys = Object.keys(file)
    let values: any = Object.values(file)
    let object: any = {}
    newData.forEach((value, key) => (object[key] = value))
    if (file.moa) {
      object.moa = await file2Base64(file?.moa)
    }
    if (file.byeLaws) {
      object.byeLaws = await file2Base64(file?.byeLaws)
    }
    if (file.declaration) {
      object.declaration = await file2Base64(file?.declaration)
    }
    if (file.supportingDoc) {
      object.supportingDoc = await file2Base64(file?.supportingDoc)
    }
    if (file.selfSignedDeclaration) {
      object.selfSignedDeclaration = await file2Base64(file?.selfSignedDeclaration)
    }
    let i = 0
    for await (let item of values) {
      object[keys[i]] = await file2Base64(item)
      i++
    }

    localStorage.setItem("AmendmentData", JSON.stringify(object))
    let result = await CallingAxios(UseSaveDataEntrySocietyDetails(newData, token))
    console.log("result", result)
    // debugger
    if (result.success) {
      ShowMessagePopup(true, "Society Saved SuccessFully", "")
      setCheckedList([])
    } else {
      console.log("result", result)
      ShowMessagePopup(false, "not saved", "")
    }




  }
  return (
    <div>
      <div className={styles.RegistrationMain}>
        <div className="societyRegSec">
          <Container className="formsec ">
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between align-items-center page-title mb-3">
                  <div className="pageTitleLeft">
                    <h1>Amendment of Society (Under Sections:8,9,10,21,24,26)</h1>
                  </div>
                  {/* <div className="pageTitleRight">
                      <div className="page-header-btns">
                        <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                          Go Back
                        </a>
                      </div>
                    </div> */}
                </div>
              </Col>
            </Row>
            <div className={styles.AmendmentDetails}>
              <h3>Amendment Details</h3>
            </div>
            <Row>
              <div className={styles.sectionContainer}>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionItems}>
                    <h5 className={styles.sectionAct}>Under Section 6(3),8,21</h5>
                  </div>
                </Col>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionDetailItems}>
                    <Row>
                      <Col lg={12} md={12} xs={12} className="py-1">
                        <Form.Check
                          inline
                          label="Change in the name of the society.(Section 6(3))"
                          type="checkbox"
                          className="fom-checkbox"
                          checked={
                            checkedList && checkedList.length > 0
                              ? checkedList.some(
                                (x: any) => x == "Change in the name of the society"
                              )
                              : false
                          }
                          value="Change in the name of the society"
                          // disabled={checkboxes[0].disabled}
                          onChange={(e: any) => changeCheck(e)}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={12} md={12} xs={12} className="py-1">
                        <Form.Check
                          inline
                          label="Change in the aims and objectives of the society.(Section 21)"
                          type="checkbox"
                          className="fom-checkbox"
                          value="Change in the aims and objectives of the society"
                          checked={
                            checkedList && checkedList.length > 0
                              ? checkedList.some(
                                (x: any) =>
                                  x == "Change in the aims and objectives of the society"
                              )
                              : false
                          }
                          // disabled={checkboxes[1].disabled}
                          onChange={(e: any) => changeCheck(e)}
                        />
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={12} md={12} xs={12} className="py-1">
                        <Form.Check
                          inline
                          label="Amalgamation of the society.(Section 21)"
                          type="checkbox"
                          className="fom-checkbox"
                          value="Amalgamation of the society"
                          checked={
                            checkedList && checkedList.length > 0
                              ? checkedList.some((x: any) => x == "Amalgamation of the society")
                              : false
                          }
                          // disabled={checkboxes[2].disabled}
                          onChange={(e: any) => changeCheck(e)}
                        />
                      </Col>
                    </Row>
                    <Row>
                      <Col lg={12} md={12} xs={12} className="py-1">
                        <Form.Check
                          inline
                          label="Amendment of Memorandum and Bye-laws.(Section 8)"
                          type="checkbox"
                          className="fom-checkbox"
                          value="Amendment of Memorandum and Bye-laws"
                          checked={
                            checkedList && checkedList.length > 0
                              ? checkedList.some(
                                (x: any) => x == "Amendment of Memorandum and Bye-laws"
                              )
                              : false
                          }
                          // disabled={checkboxes[4].disabled}
                          onChange={(e: any) => changeCheck(e)}
                        />
                      </Col>
                    </Row>
                  </div>
                </Col>
                <hr />
              </div>
            </Row>
            <Row>
              <div className={styles.sectionContainer}>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionItems}>
                    <h5 className={styles.sectionAct}>Under Section 9</h5>
                  </div>
                </Col>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionDetailItems}>
                    {/* <Row>
                        <Col lg={12} md={12} xs={12}>
                          <Form.Check
                            inline
                            label="Filling of Annual list"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Filling of Annual list"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some((x: any) => x == "Filling of Annual list")
                                : false
                            }
                            // disabled={checkboxes[5].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row> */}
                    <Row>
                      <Col lg={12} md={12} xs={12}>
                        <Form.Check
                          inline
                          label="Filing of list of members(Section 9)"
                          type="checkbox"
                          className="fom-checkbox"
                          value="Filing of list of members"
                          checked={
                            checkedList && checkedList.length > 0
                              ? checkedList.some((x: any) => x == "Filing of list of members")
                              : false
                          }
                          // disabled={checkboxes[5].disabled}
                          onChange={(e: any) => changeCheck(e)}
                        />
                      </Col>
                    </Row>
                  </div>
                </Col>
                <hr />
              </div>
            </Row>

            <Row>
              <div className={styles.sectionContainer}>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionItems}>
                    <h5 className={styles.sectionAct}>Under Section 10</h5>
                  </div>
                </Col>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionDetailItems}>
                    <Row>
                      <Col lg={12} md={12} xs={12}>
                        <Form.Check
                          inline
                          label="Change of place of Registered Society Inside/Outside the District.(Section 10)"
                          type="checkbox"
                          className="fom-checkbox"
                          value="Change of place of Registered Society Inside/Outside the District"
                          checked={
                            checkedList && checkedList.length > 0
                              ? checkedList.some(
                                (x: any) =>
                                  x ==
                                  "Change of place of Registered Society Inside/Outside the District"
                              )
                              : false
                          }
                          //  disabled={checkboxes[6].disabled}

                          onChange={(e: any) => changeCheck(e)}
                        />
                      </Col>
                    </Row>
                  </div>
                </Col>
                <hr />
              </div>
            </Row>

            <Row>
              <div className={styles.sectionContainer}>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionItems}>
                    <h5 className={styles.sectionAct}>Under Section 24</h5>
                  </div>
                </Col>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionDetailItems}>
                    <Row>

                      <Col lg={12} md={12} xs={12}>
                        <Form.Check
                          inline
                          label="Dissolution of the Society.(Section 24)"
                          type="checkbox"
                          className="fom-checkbox"
                          value="Dissolution and winding up of the society"

                          checked={
                            checkedList && checkedList.length > 0
                              ? checkedList.some(
                                (x: any) => x == "Dissolution and winding up of the society"
                              )
                              : false
                          }
                          // disabled={checkboxes[7].disabled}
                          onChange={(e: any) => changeCheck(e)}
                        />
                      </Col>
                    </Row>
                  </div>
                </Col>
                <hr />
              </div>
            </Row>

            <Row>
              <div className={styles.sectionContainer}>
                <Col lg={6} md={6} xs={6}>
                  <div className={styles.sectionItems}>
                    <h5 className={styles.sectionAct}>Under Section 26</h5>
                  </div>
                </Col>

              </div>
            </Row>
            <hr />

            {/* <Row>
                <Col lg={12} md={12} xs={12} style={{ textAlign: "center" }}>
                  <Button onClick={() => handlesubmit()}>Continue</Button>
                </Col>
              </Row> */}
            {checkedList && checkedList.length > 0
              && checkedList.some(
                (x: any) => x == "Change in the name of the society"
              ) ? <>
              <div className="uploadFirmList my-1">
                <h3>Society Name Change(Section 6(3))</h3>
              </div>
              <Row>
                <Col lg={3} md={4} xs={12} className="mb-1">
                  <TableText label="Society Name" required={true} LeftSpace={false} />
                  <TableInputText
                    disabled={true}
                    type="text"
                    placeholder="Enter Society Name"
                    required={true}
                    name="societyName"
                    value={selectedRequest[`societyFields`]?.societyName}
                    onChange={() => { }}
                  />
                </Col>
                <Col lg={3} md={4} xs={12} className="mb-1">
                  <TableText label="New Society Name" required={true} LeftSpace={false} />
                  <TableInputText

                    type="text"
                    placeholder="Enter Society Name"
                    required={true}
                    name="societyNewName"
                    value={societyDetails.societyNewName}
                    onChange={societyDetailsChange}
                  />
                </Col>
                <Col lg={3} md={12} sm={12} className="my-2">
                  <TableText
                    label={"New Name Date of Effect "}
                    required={true}
                    LeftSpace={false}
                  />
                  <Form.Control
                    type="date"
                    placeholder="Enter Name Date of Effect"
                    name="newNameDateEffect"
                    onChange={societyDetailsChange}
                    value={societyDetails.newNameDateEffect}
                    className="durationTo"
                  />

                </Col>
              </Row>
              <Row>
                <Col lg={3} md={3} xs={12} >
                  <TableText label="Declaration" required={true} LeftSpace={false} />

                  <div className="firmFile">
                    <Form.Control
                      type="file"
                      required={true}
                      name="declaration"
                      ref={inputRef}
                      onChange={handleFileChange}
                      accept="application/pdf"
                    />
                  </div>
                </Col>

                <Col lg={3} md={3} xs={12} >
                  <TableText label="Supporting Document" required={true} LeftSpace={false} />

                  <div className="firmFile">
                    <Form.Control
                      required={true}
                      type="file"
                      name="supportingDoc"
                      ref={inputRef}
                      onChange={handleFileChange}
                      accept="application/pdf"
                    />
                  </div>
                </Col>
                <Col lg={3} md={3} xs={12} >
                  <TableText label="MOA" required={true} LeftSpace={false} />

                  <div className="firmFile">
                    <Form.Control
                      required={true}
                      type="file"
                      name="moa"
                      ref={inputRef}
                      onChange={handleFileChange}
                      accept="application/pdf"
                    />
                  </div>
                </Col>
              </Row></>
              : null
            }
            {checkedList && checkedList.length > 0
              && checkedList.some(
                (x: any) => x == "Change of place of Registered Society Inside/Outside the District"
              ) ?  <div className="regofAppBg mb-3">
              <div className="uploadFirmList my-1">
                <h3>Change of place of Society(Section 10)</h3>
              </div>
              <div className="firmDuration">
                <Form.Check
                  inline
                  label=" With in the district"
                  value="With in the district"
                  checked={selectedOption === "With in the district"}
                  onChange={handleOptionChange}
                  name="atwill"
                  type="radio"
                  className="fom-checkbox fw-bold small text-sm"
                />
                <Form.Check
                  inline
                  label="Outside the district"
                  value="Outside the district"
                  name="atwill"
                  type="radio"
                  checked={selectedOption === "Outside the district"}
                  onChange={handleOptionChange}
                  className="fom-checkbox fw-bold small text-sm"
                />
              </div>
              {message && <p>{message}</p>}
              <div className="uploadFirmList my-1">
                <h3>Documents</h3>
              </div>
              <Col lg={3} md={12} sm={12} className="my-2">
                <TableText
                  label={"Affidavit  /  Lease Agreement "}
                  required={true}
                  LeftSpace={false}
                />
                <div className="firmFile">
                  <Form.Control
                    type="file"
                    name="affidavit"
                    required={true}
                    ref={inputRef}
                    onChange={handleFileChange}
                    accept="application/pdf"
                  />
                </div>
              </Col>
            </div>
              : null}

            {checkedList && checkedList.length > 0
              && checkedList.some(
                (x: any) => x == "Change in the aims and objectives of the society"
              ) ? <>

              <div className="uploadFirmList my-1">
                <h3>aim and objective Change</h3>
              </div>
              <Row>
                <Col lg={3} md={4} xs={12} className="mb-1">
                  <TableText label="Society Name" required={true} LeftSpace={false} />
                  <TableInputText
                    disabled={true}
                    type="text"
                    placeholder="Enter Society Name"
                    required={true}
                    name="societyName"
                    value={selectedRequest[`societyFields`]?.societyName}
                    onChange={() => { }}
                  />
                </Col>
                <Col lg={3} md={4} xs={12} className="mb-1">
                  <TableText label="Aim" required={true} LeftSpace={false} />
                  <TableInputText

                    type="text"
                    placeholder="Enter Aim"
                    required={true}
                    name="aim"
                    disabled
                    value={selectedRequest[`societyFields`]?.aim}
                    onChange={societyDetailsChange}
                  />
                </Col>
                <Col lg={3} md={4} xs={12} className="mb-1">
                  <TableText label="Objective" required={true} LeftSpace={false} />
                  <TableInputText
                    type="text"
                    placeholder="Enter Objective"
                    required={true}
                    disabled
                    name="objective"
                    value={selectedRequest[`societyFields`]?.objective}
                    onChange={societyDetailsChange}
                  />
                </Col>
              </Row>
              <Row className=" my-1">
                <Col lg={6} md={12} sm={12}>
                  <TableText label={"New Aim"} required={true} LeftSpace={false} />
                  <textarea
                    className="form-control textarea"
                    maxLength={10000}
                    placeholder="Enter New Aim  "
                    required={true}
                    name="newAim"
                    value={societyDetails.newAim}
                    onChange={societyDetailsChange}
                  ></textarea>
                  {/* {errors.aim && <span style={{ color: "red" }} className={styles.columnText}>{errors.aim}</span>} */}
                </Col>
                <Col lg={6} md={12} sm={12}>
                  <TableText label={"New Objective"} required={true} LeftSpace={false} />
                  <textarea
                    className="form-control textarea"
                    placeholder="Enter New Objective"
                    required={true}
                    name="newObjective"
                    maxLength={10000}
                    value={societyDetails.newObjective}
                    onChange={societyDetailsChange}
                  ></textarea>
                </Col>
              </Row>
              <Row>
                <Col lg={3} md={3} xs={12} >
                  <TableText label="Declaration" required={true} LeftSpace={false} />

                  <div className="firmFile">
                    <Form.Control
                      type="file"
                      required={true}
                      name="declaration"
                      ref={inputRef}
                      onChange={handleFileChange}
                      accept="application/pdf"
                    />
                  </div>
                </Col>

                <Col lg={3} md={3} xs={12} >
                  <TableText label="Supporting Document" required={true} LeftSpace={false} />

                  <div className="firmFile">
                    <Form.Control
                      required={true}
                      type="file"
                      name="supportingDoc"
                      ref={inputRef}
                      onChange={handleFileChange}
                      accept="application/pdf"
                    />
                  </div>
                </Col>
                <Col lg={3} md={3} xs={12} >
                  <TableText label="MOA" required={true} LeftSpace={false} />

                  <div className="firmFile">
                    <Form.Control
                      required={true}
                      type="file"
                      name="moa"
                      ref={inputRef}
                      onChange={handleFileChange}
                      accept="application/pdf"
                    />
                  </div>
                </Col>
              </Row></>
              : null
            }

            {checkedList.length > 0 ?
              <div className="firmSubmitSec mt-3">
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <>
                      <div className="d-flex justify-content-center text-center">
                        {" "}
                        <Button onClick={(e: any) => { handlesubmit(e) }}>Save</Button>
                        {/* <Button onClick={handleSubmit}>Save</Button> */}
                      </div>
                    </>
                  </Col>
                </Row>
              </div> : null}

          </Container>
        </div>
      </div>
    </div>
  )
}

export default AddAmendmentDetails