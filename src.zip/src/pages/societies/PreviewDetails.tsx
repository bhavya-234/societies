import { useState, useEffect } from "react"
import PDFMerger from "pdf-merger-js/browser"
import instance from "@/redux/api"

const PreviewDetails = (props: any) => {
  const { documentAttachedList, id } = props
  const [mergedPdfUrl, setMergedPdfUrl] = useState<any>()

  useEffect(() => {
    const render = async () => {
      const merger = new PDFMerger()
      for (const document of documentAttachedList) {
        let fileName = document?.originalname
        let apiUrl = `/downloads/${id}/${fileName}`
        await instance.get(apiUrl, { responseType: "arraybuffer" }).then((res) => {
          const file = window.URL.createObjectURL(new Blob([res.data], { type: "application/pdf" }))
          merger.add(file)
        })
      }
      const mergedPdf: Blob = await merger.saveAsBlob()
      const fileUrl: String = URL.createObjectURL(mergedPdf)
      return setMergedPdfUrl(fileUrl)
    }
    render().catch((err) => {
      throw err
    })
    ;() => setMergedPdfUrl({})
  }, [documentAttachedList, setMergedPdfUrl])

  return (
    <>
      {!mergedPdfUrl ? (
        <div>Loading</div>
      ) : (
        <iframe
          className="document-attached-file"
          src={`${mergedPdfUrl}`}
          title="pdf-viewer"
          width="100%s"
        />
      )}
    </>
  )
}
export default PreviewDetails
