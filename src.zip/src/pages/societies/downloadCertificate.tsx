import React, { useState, useEffect } from "react"
import Head from "next/head"
import { Container, Col, Row, Button, Table } from "react-bootstrap"
import instance from "@/redux/api"
import JsBarcode from "jsbarcode"
import { downloadSocietyCertificate, getDeptSignature, getSocietyDetails } from "@/axios"
import api from "@/pages/api/api"
import { PopupAction } from "@/redux/commonSlice"
import { useAppDispatch } from "@/hooks/reduxHooks"
import CryptoJS from "crypto-js"
import Pdf from "react-to-pdf"
import { DateFormator, Loading } from "@/GenericFunctions"
import { PDFDocument, StandardFonts } from "pdf-lib"
const DownloadCertificate = () => {
  const [img, setImg] = useState("")
  const [selectedRequest, setSelectedRequest] = useState<any>({})
  const [districts, setDistricts] = useState<any>([])
  const [locData, setLocData] = useState<any>({})
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [isView, setIsView] = useState<boolean>(false)
  const [isAlreadyDownloaded, setIsAlreadyDownloaded] = useState<boolean>(false)
  const [ispaymentSuccess, setIsPaymentSuccess] = useState<boolean>(false)
  const [signature, setSignature] = useState<string>("")
  const [fullName, setFullName] = useState<string>("")
  const [date, setDate] = useState<any>("")
  let ref = React.useRef<HTMLDivElement | null>(null)
  let btnref = React.useRef<HTMLButtonElement | null>(null)
  const dispatch = useAppDispatch()
  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }
  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if(data&data?.token){
    setLocData(data)
    setLoggedInAadhar(data.aadharNumber)
    instance.get("/getDistricts").then((response) => {
      setDistricts(response.data)
    })
    getSocietyDetails(data.applicationId, data.token).then((response) => {
      if (response?.success) {
        if (response.data.daSociety.status == "Approved") {
          setSelectedRequest(response.data.daSociety)
        }
        else if (response.data.daSociety.historyDetails?.some((x) => x.status == "Approved")) {
          setSelectedRequest(response.data.daSociety.historyDetails?.find((x) => x.status == "Approved"))
        }
        const date = response.data.daSociety.processingHistory?.find((x) => x.status == "Approved")
        if (date) {
          setDate(DateFormator(date.applicationProcessedDate, "dd/mm/yyyy"))
        }
        if (response.data.daSociety.approvedRejectedById) {
          getDeptSignature(response.data.daSociety.approvedRejectedById, data.token)
            .then((res) => {
              if (res.success && res.data) {
                setSignature("data:image/jpeg;base64, " + res.data.signature)
                console.log("signa", signature)
                setFullName(res.data.fullName)
                setImg("data:image/jpeg;base64 ," + res.data.signature)
                Loading(false)
              }
            })
            .catch(() => {
              Loading(false)
              console.log("error")
            })
        }
        else {
          Loading(false)
        }
        JsBarcode("#barcode", response.data.daSociety.applicationNumber, {
          displayValue: false,
        })
        if (response.data.daSociety.status == "Approved" && response.data.daSociety.isdownload) {
          setIsAlreadyDownloaded(true)
        } else {
          setIsAlreadyDownloaded(false)
        }
      }
    }).catch(() => {
      Loading(false)
    })
  }
  }, [])

  const docLink = async (name: any, index: number, path: any, id: any) => {
    let url = ""

    url = `/downloads/${id}/${name}`

    if (path.split("/")[2] == 0) {

      url = `/downloads/${path.split("/")[2]}/${name}`

    }
    const res = await api.get(url, { responseType: "arraybuffer" })

    const pdfDoc = await PDFDocument.load(res.data);
    const pages = pdfDoc.getPages();
    for await (let page of pages) {
    const firstPage = page;
    let image;
    await fetch(img).then((res) => res.arrayBuffer().then(r => image = r))
    const jpgImage = await pdfDoc.embedJpg(image)
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const { width, height } = firstPage.getSize();
    firstPage.drawImage(jpgImage, {
      x: width - 160,
      y: height - 800,
      width: 90,
      height: 70,
      opacity: 0.75,
    });
    firstPage.drawText(date,{
      x: width - 150,
      y: height - 812,
      font,
      size:12
      
    })
    }
    const pdfBytes = await pdfDoc.save();
    const bytes = new Uint8Array(pdfBytes);
    const docUrl = URL.createObjectURL(
      new Blob([bytes], { type: "application/pdf" })
    );

    var link = document.createElement("a")
    link.href = docUrl
    link.setAttribute("download", `${name}.pdf`)
    document.body.appendChild(link)
    link.click()
    link.remove()
    
  }
  const loadDocs = async (data: any) => {

    let list: any = []
    if (data?.documentAttached?.length > 0) {
      let i = 0
      for await (let document of data.documentAttached) {
        await docLink(document?.originalname, i, document?.path, data._id)
        i++
      }
    }
  }
  useEffect(() => {
    if (selectedRequest?.status == "Approved") {
      let data1: any = localStorage.getItem("isdownload")
      if (data1) {
        let data: any = localStorage.getItem("FASPLoginDetails")
        if (data && data != "" && process.env.SECRET_KEY) {
          let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
          data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
        }
        api
          .get("/getPaymentDetails/" + data.applicationNumber, {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${data.token}`,
            },
          })
          .then((response: any) => {
            if (!response || !response.data || !response.data.success) {
              localStorage.removeItem("isdownload")
              setIsPaymentSuccess(false)
            } else {
              if (
                response.data.data.paymentDetails.transactionStatus == "Success" &&
                !response.data.data.paymentDetails.isUtilized &&
                btnref.current
              ) {
                localStorage.setItem("download", "true")
                btnref.current.click()
                localStorage.removeItem("isdownload")
              } else {
                localStorage.removeItem("isdownload")
                setIsPaymentSuccess(false)
              }
            }
          })
          .catch((error) => {
            localStorage.removeItem("isdownload")
            setIsPaymentSuccess(false)
          })
      }
    }
  }, [selectedRequest])
  const PaymentLink = () => {
    let code = 0
    const dis = districts?.find((x: { name: string }) => x.name == selectedRequest.district)
    if (dis) {
      code = dis.code
    }
    localStorage.setItem("isdownload", "true")
    const paymentsData = {
      type: "sra",
      source: "Society",
      deptId: selectedRequest.applicationNumber,
      rmName: selectedRequest.applicantDetails.name,
      rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
      mobile: selectedRequest.applicantDetails.mobileNumber,
      email: selectedRequest.applicantDetails.email,
      drNumber: code,
      rf: 100,
      uc: 100,
      oc: 0,
      returnURL: process.env.BACKEND_URL + "/societies/redirectcertificate",
    }
    let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
    // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
    const encodedData = CryptoJS.AES.encrypt(
      JSON.stringify(paymentsData),
      'igrsSecretPhrase'
    ).toString()
    console.log("ENCODED VALUE IS ", encodedData)
    let paymentLink = document.createElement("a")
    paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
    paymentLink.click()
    setTimeout(function () {
      paymentLink.remove()
    }, 1000)
  }
  const options = {
    orientation: "p",
    unit: "mm",
    format: [400, 480],
  }
  return (
    <>
      <Head>
        <title>Acknowledgement of Registration of Society</title>
        <link rel="icon" href="/registration-stamp-icon.ico" />
      </Head>
      {locData && locData?.userType && locData?.userType == "user" && (
        <>
          {selectedRequest.status == "Approved" && img != '' ? (
            <>
              <Pdf
                targetRef={ref}
                filename={`${selectedRequest.applicationNumber}.pdf`}
                options={options}
              >
                {({ toPdf }: any) => (
                  <div className="text-center">
                    <Button
                      id="downloadClick"
                      ref={btnref}
                      className="ms-3"
                      variant="primary"
                      onClick={async () => {
                        const data = localStorage.getItem("download")

                        if (data == "true") {
                          await loadDocs(selectedRequest)
                          toPdf()
                          downloadSocietyCertificate(
                            { amount: 300 },
                            locData.applicationId,
                            locData.token
                          )
                          ShowAlert(true, "Your certificate is downloaded successfully")
                          localStorage.removeItem("download")
                        } else if (!isAlreadyDownloaded) {
                          await loadDocs(selectedRequest)
                          toPdf()
                          downloadSocietyCertificate(
                            { amount: 0 },
                            locData.applicationId,
                            locData.token
                          )
                          ShowAlert(true, "Your certificate is downloaded successfully")
                          setIsAlreadyDownloaded(true)
                        } else {
                          PaymentLink()
                        }
                      }}
                    >
                      Download Certificate
                    </Button>
                  </div>
                )}
              </Pdf>
              <div className="note requiredData mb-3" style={{ paddingLeft: "30%" }}>
                <p>Note:- Free Download of Certified Copy of the Document is allowed only Once.
                </p>
              </div>
            </>
          ) :
            <div className="societyRegSec">
              <Container>
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <div className="d-flex justify-content-center page-title mb-2">
                      <div className="pageTitleLeft">
                        <h1>Application is not yet approved</h1>
                      </div>
                    </div>
                  </Col>
                </Row>
              </Container>
            </div>}
          <div
            style={{
              position: "absolute",
              left: "-999em",
              right: "0",
              margin: "auto",
              width: "100%",
            }}
            ref={ref}
            className="societyRegSec"
            id="viewSocietyCerticate"
          >
            <div className="viewCertificatePage">
              <div className="pageWrapper">
                <div className="viewCerticateSec">
                  <Container>
                    <div id="insideData">
                      <div className="certificateHeader">
                        <div className="certificateHeaderLogo">
                          <img
                            src="/assets/Andhra_Pradesh_Official_Logo.jpg"
                            alt="Andhra_Pradesh_Official_Logo.jpg"
                            title=""
                          />
                        </div>
                        <h1>
                          GOVERNMENT OF ANDHRA PRADESH REGISTRATION AND STAMPS DEPARTMENT THE
                          REGISTRAR OF SOCIETIES <span>{selectedRequest.district}</span>
                        </h1>
                      </div>

                      <div className="certificateReg">
                        <Row className="d-flex justify-content-between align-items-center">
                          <Col md={{ span: 2, offset: 1 }}></Col>
                          <Col lg={5} md={5} xs={12}>
                            <div className="certificateTitle text-center">
                              <h2>CERTIFICATE OF REGISTRATION</h2>
                              <h6>
                                ( No: {selectedRequest.registrationNumber} of{" "}
                                {selectedRequest.registrationYear} )
                              </h6>
                            </div>
                          </Col>
                          <Col lg={4} md={4} xs={12}>
                            <div className="certificateInfo">
                              <h6>Application No </h6>
                              <img id="barcode" />
                              <h5>{selectedRequest.applicationNumber}</h5>
                              <h6>Date: {DateFormator(selectedRequest.createdAt, "dd/mm/yyyy")}</h6>
                            </div>
                          </Col>
                        </Row>
                      </div>

                      <div className="certificateHereInfo">
                        <p>
                          I hereby certify that <b>{selectedRequest.societyName}'</b>,{" "}
                          <b>
                            {selectedRequest.doorNo}
                            {selectedRequest.street && <span> / {selectedRequest.street}</span>}
                            {selectedRequest.villageCity && (
                              <span> / {selectedRequest.villageCity}</span>
                            )}
                            {selectedRequest.mandal && <span> / {selectedRequest.mandal}</span>}
                            {selectedRequest.district && <span> / {selectedRequest.district}</span>}
                            {selectedRequest.state && <span> / {selectedRequest.state}</span>}
                            {selectedRequest.country && <span> / {selectedRequest.country}</span>}
                            {selectedRequest.pinCode && <span> / {selectedRequest.pinCode}</span>}
                          </b>{" "}
                          on this day registered under the Andhra Pradesh Societies Registration
                          Act., 2001
                        </p>
                      </div>

                      <div className="certifyLogoSec">
                        <Row className="d-flex justify-content-between align-items-center">
                          <Col lg={6} md={6} xs={12}>
                            <div className="certifyLogoInfo text-center">
                              <div className="certifyLogoImgSec">
                                <img src="/assets/soc_logo.png" alt="soc_logo.png" />
                                <h6>{selectedRequest.district}</h6>
                              </div>
                              <h6>Date: {date}</h6>
                            </div>
                          </Col>
                          <Col lg={6} md={6} xs={12}>
                            <div className="certifySignInfo">
                              <h6>Certified By</h6>
                              <div className="certifySignImg">
                                <img src={signature} alt="signImg.png" />
                              </div>
                              <h6>Name: {fullName}</h6>
                              <h6>Designation: DISTRICT REGISTRAR</h6>
                              <h6>District:{selectedRequest.district}</h6>
                            </div>
                          </Col>
                        </Row>
                      </div>

                      <div className="certifyMaintainSec text-center">
                        <h3>(Maintained Under Section 3 of Societies Registration Act, 2001)</h3>
                      </div>

                      <Table striped bordered className="certifiyTable">
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>Society Registration Number:</td>
                            <td>
                              No: {selectedRequest.registrationNumber} of{" "}
                              {selectedRequest.registrationYear}
                            </td>
                          </tr>

                          <tr>
                            <td>2</td>
                            <td>Name of the Society:</td>
                            <td>{selectedRequest.societyName}</td>
                          </tr>

                          <tr>
                            <td>3</td>
                            <td>Society Category:</td>
                            <td>{selectedRequest.category}</td>
                          </tr>

                          <tr>
                            <td>4</td>
                            <td>Society Address:</td>
                            <td>
                              {" "}
                              {`${selectedRequest.doorNo}/${selectedRequest.street}/${selectedRequest.villageCity}/${selectedRequest.mandal}/${selectedRequest.district}/${selectedRequest.state}/${selectedRequest.country}`}
                            </td>
                          </tr>
                        </tbody>
                      </Table>

                      <div className="certifyMaintainSec text-center">
                        <h3>EC Member Details</h3>
                      </div>

                      <Table striped bordered className="certifiyTable">
                        <thead>
                          <tr>
                            <th>S.No</th>
                            <th>Name of the office Bearers & S/O, W/O, D/O</th>
                            <th>Designation of their local standing in the Society</th>
                            <th>Occupation</th>
                            <th>Residential Address</th>
                          </tr>
                        </thead>

                        {selectedRequest.memberDetails &&
                          selectedRequest.memberDetails.length > 0 ? (
                          <tbody>
                            {selectedRequest.memberDetails.map((item: any, i: number) => {
                              return (
                                <> {
                                  item.status != "InActive" ?
                                    <tr key={i + 1}>
                                      <td className="text-center">{i + 1}</td>
                                      <td>{`${item.memberName},${item.relationType} ${item.relationName}`}</td>
                                      <td>{item.role}</td>
                                      <td className="text-center">{item.occupation}</td>
                                      <td>
                                        {`${item.doorNo}/${item.street}/${item.villageOrCity}/${item.mandal}/${item.district}/${item.state}/${item.country}`}
                                      </td>
                                    </tr> : null}</>
                              )
                            })}
                          </tbody>
                        ) : (
                          <tbody>
                            <tr>
                              <td colSpan={6}>No Members Found</td>
                            </tr>
                          </tbody>
                        )}
                      </Table>

                      <div className="certifyMaintainSec text-center">
                        <h3>Document Details</h3>
                      </div>

                      <Table striped bordered className="certifiyTable">
                        <thead>
                          <tr>
                            <th>Document Type</th>
                            <th>Document Name</th>
                          </tr>
                        </thead>

                        {selectedRequest?.documentAttached?.length > 0 ? (
                          <tbody>
                            {selectedRequest?.documentAttached?.map(
                              (document: any, index: number) => {
                                const appName = document?.originalname

                                const appSplit = appName.split("_")
                                let appSplitVal = appSplit[0]
                                let appSplitValdata = appSplit[1]
                                let appType = ""
                                let validFileExtensions = ["resigned", "death", "terminated", "selfSignedDeclaration", "committeeResolution", "firstNotice", "secondNotice", "thirdNotice"];
                                if (appSplitVal == "idProofs") {
                                  appType = "Id Proofs"
                                }

                                if (appSplitVal == "memorandum") {
                                  appType = "Memorandum"
                                }

                                if (appSplitVal == "byeLaws") {
                                  appType = "ByeLaws"
                                }

                                if (appSplitVal == "affidavit") {
                                  appType = "Lease Deed or Affidavit"
                                }
                                if (appSplitVal == "moa") {
                                  appType = "MOA"
                                }
                                if (appSplitVal == "affidavitByAuditor") {
                                  appType = "Affidavit By Auditor"
                                }

                                if (appSplitVal == "selfSignedDeclaration") {
                                  appType = "Self signed declaration"
                                }
                                if (appSplitVal == "declaration") {
                                  appType = "declaration"
                                }
                                if (appSplitVal == "propertyDisposal") {
                                  appType = "property Disposal"
                                }

                                if (appSplitVal == "supportingDoc") {
                                  appType = "supporting Document"
                                }
                                if (appSplitVal == "minutesOfMeeting") {
                                  appType = "minutes Of Meeting"
                                }
                                if (appSplitValdata == "committeeResolution") {
                                  appType = "Resolution of Committee"
                                }
                                if (appSplitValdata == "firstNotice") {
                                  appType = "Notice 1"
                                }

                                if (appSplitValdata == "secondNotice") {
                                  appType = "Notice 2"
                                }
                                if (appSplitValdata == "thirdNotice") {
                                  appType = "Notice 3"
                                }
                                if (appSplitValdata == "resigned") {
                                  appType = "Resigned"
                                }
                                if (appSplitValdata == "death") {
                                  appType = "Death"
                                }
                                if (appSplitValdata == "terminated") {
                                  appType = "Terminated"
                                }
                                if (appSplitValdata == "selfSignedDeclaration") {
                                  appType = "Self Signed Declaration"
                                }
                                return (
                                  <tr key={index + 1}>
                                    <td>{appType}</td>
                                    <td>{document?.originalname}</td>
                                  </tr>
                                )
                              }
                            )}
                          </tbody>
                        ) : (
                          <tbody>
                            <tr>
                              <td colSpan={6}>No Documents Found</td>
                            </tr>
                          </tbody>
                        )}
                      </Table>
                    </div>
                  </Container>
                </div>
              </div>
            </div>
          </div>

          {selectedRequest.status == "Incomplete" && (
            <div className="applicationPendingSec">
              <Row className="d-flex justify-content-between align-items-center">
                <Col lg={12} md={12} xs={12}>
                  <div className="certificateHeader text-center">
                    <h3>Your application is not yet submitted </h3>
                  </div>
                </Col>
              </Row>
            </div>
          )}
          {selectedRequest.status != "Approved" && selectedRequest.status != "Incomplete" && (
            <div className="applicationPendingSec">
              <Container>
                <Row className="d-flex justify-content-between align-items-center">
                  <Col lg={12} md={12} xs={12}>
                    <div className="certificateHeader text-center">
                      <h3>Your application is pending </h3>
                    </div>
                  </Col>
                </Row>
              </Container>
            </div>
          )}
        </>
      )}
      {(!locData?.userType || locData?.userType != "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}

export default DownloadCertificate
