import { useState, useEffect } from "react"
import Head from "next/head"
import { useRouter } from "next/router"
import { Container, Col, Row, Table, Button, Form, Modal } from "react-bootstrap"
import api from "@/pages/api/api"
import Swal from "sweetalert2"
import styles from "@/styles/components/Table.module.scss"
import { DefaceTransactionDetails, getDeptSignature, getSocietyDetails, updateSocietyDetails, VerifyTransactionDetails } from "@/axios"
import { useAppDispatch } from "@/hooks/reduxHooks"
import { PopupAction } from "@/redux/commonSlice"
import { get } from "lodash"
import RegistrationofSocietyCertificate from "./RegistrationofSocietyCertificate"
import ViewHistory from "./viewHistory"
import CryptoJS from "crypto-js"
import PreviewDetails from "./PreviewDetails"
import { DateFormator, Loading, ShowMessagePopup } from "@/GenericFunctions"
import AddAmendmentDetails from "./addAmendmentDetails"

interface ViewDetailsProps {
  reqsearchdata: any
  selectedRequest: any
  setReqSearchData: any
  setIsView: any
  setIsError: any
  setErrorMessage: any
}

const ViewDetails = ({
  reqsearchdata,
  selectedRequest,
  setReqSearchData,
  setIsView,
  setIsError,
  setErrorMessage,
}: ViewDetailsProps) => {
  const [locData, setLocData] = useState<any>({})

  const [firmPartners, setFirmPartners] = useState<any>([])
  const [firmProcessing, setFirmProcessing] = useState<any>([])
  const [isTransVerified, SetIsTransVerified] = useState<boolean>(false)
  const [isTransDefaced, setIsTransDefaced] = useState<boolean>(false)
  const [transactionDetails, setTransactionDetails] = useState<any>({})
  const [userType, setUserType] = useState<string>("")
  const [district, setdistrict] = useState<string>()
  const [role, setRole] = useState<string>("")
  const [token, setToken] = useState<string>("")
  const [isViewCertificate, setIsViewCertificate] = useState<boolean>(false)
  
  const [isViewAmendments, setIsViewAmendments] = useState<boolean>(false)
  
  const [isViewHistory, setViewHistory] = useState<boolean>(false)
  const [existingSocietyDetails, setExistingSocietyDetails] = useState<any>({})
  const [isPreview, setIsPreview] = useState<boolean>(false)
  // const [showAmendments, setshowAmendments] = useState(false);
  // const handleAmendmentsModal = () => {
  //   setshowAmendments(false)
  // }
  const router = useRouter()
  const dispatch = useAppDispatch()
  useEffect(() => {
    if (!isViewHistory) {
      loadDocs()
    }
  }, [isViewHistory])
  useEffect(() => {
    if (!isPreview) {
      loadDocs()
      document.body.classList.remove(
        "viewCertificate",
        "viewCertificatePage",
        "previewForm",
        "bg-salmon",
        "viewCerticate",
        "viewCerticatePage",
        "previewFormPage"
      )
    }
  }, [isPreview])
  // const accepted = async (e: any) => {
  //   e.preventDefault()
  //   const newData = new FormData()
  //   newData.append("formType", "Accept")
  //   newData.append("id", selectedRequest.applicantFields.applicantNumber)
  //   updateSocietyDetails(selectedRequest.applicantFields._id, token, newData)
  //     .then((response: any) => {
  //       ShowMessagePopup(true, "Accepted and forwarded to DR")
  //       router.push('/societies')
  //     })
  //     .catch((error) => {
  //       console.log("error-", error)
  //       setIsError(true)
  //       setErrorMessage(error.message)
  //       Swal.fire({
  //         icon: "error",
  //         title: "Error!",
  //         text: error.message,
  //         showConfirmButton: false,
  //         timer: 1500,
  //       })
  //     })
  // }
  useEffect(() => {
    console.log("selected request", selectedRequest)
    loadDocs()
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data?.token != "") {
      setLocData(data)
      if (data.userType != "user") {
        api
          .get("/getPaymentDetails/" + selectedRequest.applicantFields.applicantNumber, {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${data.token}`,
            },
          })
          .then((response: any) => {
            if (!response || !response.data || !response.data.success) {
              console.log("error-", response.data.message)
              console.log(response.data.message)
              setIsError(true)
              setErrorMessage(response.data.message)
              Swal.fire({
                icon: "error",
                title: "Error!",
                text: response.data.message,
                showConfirmButton: false,
                timer: 1500,
              })
            } else {
              console.log("new district check", response.data.data.paymentDetails)

              setTransactionDetails(response.data.data.paymentDetails)
              if (response.data.data.paymentDetails?.isUtilized) {
                // if (response.data.data.paymentDetails?.isUtilized &&selectedRequest[`societyFields`].district==response.data.data?.paymentDetails?.district){
                SetIsTransVerified(true)
                setIsTransDefaced(true)
              }
            }
          })
          .catch((error) => {
            console.log("error-", error)
            console.log(error.message)

            // setErrorMessage(error.message)
            // setIsError(true)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: error.message,
              showConfirmButton: false,
              timer: 1500,
            })
          })
      }
    }
  }, [])
  console.log("selected request", selectedRequest)

  useEffect(() => {

    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data?.token != "") {
      setLocData(data)
      console.log("locdata", locData)
      setdistrict(data.district)
      console.log(district)
      setUserType(data.userType)
      setRole(data.role)
      setToken(data.token)
      getSocietyDetails(selectedRequest.applicantFields.id, data.token).then((response) => {
        setExistingSocietyDetails(response.data?.daSociety)
        Loading(false)
      }
      )
    }
    // const processingData = [
    //   {
    //     designation: `DLF-AS-GUN-ADMIN`,
    //     status: `Forwarded BY DLS`,
    //     remarks: `Madam, I Verified Found Correct and Submitted for Approval`,
    //     attachments: `N/A`,
    //     applicationTakenDate: `04/02/2023 10:41:06`,
    //     applicationProcessedDate: `04/02/2023 10:41:06`,
    //   },
    // ]
    // setFirmProcessing(processingData)
  }, [])

  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }

  const verifyTransacDetails = async () => {
    let result: any = await VerifyTransactionDetails({
      deptTransactionID: btoa(transactionDetails?.departmentTransID),
    })
    if (result.status && result.status === "Success") {
      ShowAlert(true, "Transaction details are verified Successfully")
      SetIsTransVerified(true)
    } else {
      ShowAlert(false, get(result, "message", "Tansaction details verification Failed"))
    }
  }
  const defaceTransacDetails = async () => {
    let result: any = await DefaceTransactionDetails({
      deptTransactionID: btoa(transactionDetails.departmentTransID),
    })
    if (result.status && result.status === "Success") {
      api
        .post("/confirmDephaseTransaction/" + transactionDetails.departmentTransID, null, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
        })
        .then((response: any) => {
          if (!response || !response.data || !response.data.success) {
            console.log("error-", response.data.message)
            console.log(response.data.message)
            setIsError(true)
            setErrorMessage(response.data.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: response.data.message,
              showConfirmButton: false,
              timer: 1500,
            })
          } else {
            setIsTransDefaced(true)
            Swal.fire({
              icon: "success",
              title: "Success!",
              text: "Succesfully Defaced",
              showConfirmButton: false,
              timer: 1500,
            })
          }
        })
        .catch((error) => {
          console.log("error-", error)
          console.log(error.message)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: error.message,
            showConfirmButton: false,
            timer: 1500,
          })
        })
    } else {
      ShowAlert(false, get(result, "message", "Tansaction deface Failed"))
    }
  }
  const docLink = async (name: any, index: number, path: any) => {
    let url = ""
    // `/downloads/${selectedRequest.firmFields.firmId}/${name}`
    url = `/downloads/${selectedRequest.applicantFields.id}/${name}`
    if (path.split("/")[2] == 0) {
      url = `/downloads/${path.split("/")[2]}/${name}`
    }
    const res = await api.get(url, { responseType: "arraybuffer" })
    const urls = window.URL.createObjectURL(new Blob([res.data], { type: "application/pdf" }))
    var link: any = document.getElementById(`docFile${index}`)
    if (link) {
      link.href = urls
    }
  }
  const loadDocs = async () => {
    if (selectedRequest?.documentAttached?.length > 0) {
      selectedRequest?.documentAttached.forEach(async (document: any, index: number) => {
        await docLink(document?.originalname, index, document?.path)
      })
    }
  }
  const handleSubmit = (e) => {
    e.preventDefault()

    const remarks: any = document.getElementById("remarks")

    const actionTaken: any = document.getElementById("actionTaken")

    let remarksData: any = {

      id: selectedRequest.applicantFields.id,

      remarks: remarks.value,

    }

    // @Vejan make the changes

    if (role == "DR" && process.env.SECRET_KEY) {

      remarksData.status = actionTaken.value

      const enc = CryptoJS.AES.encrypt(

        JSON.stringify(remarksData),

        process.env.SECRET_KEY

      ).toString()

      if (actionTaken.value == "Approved") {

        let data: any = localStorage.getItem("FASPLoginDetails")

        if (data && data != "") {

          let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)

          data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))

        }

        if (data) {

          getDeptSignature(data.deptUserId, data.token)

            .then((res) => {

              if (res.success && res.data && (!res.data.signature || res.data.signature == "")) {

                ShowMessagePopup(

                  false,

                  "Please upload your signature on the Profile tab",

                  ""

                )

                return

              } else if (res.success) {

                api

                  .post(

                    "/societies/remarks",

                    { remark: enc },

                    {
                      headers: {
                        Accept: "application/json",
                        Authorization: `Bearer ${token}`,
                      },
                    }
                  )
                  .then((response: any) => {
                    if (!response || !response.data || !response.data.success) {
                      console.log("error-", response.data.message)
                      console.log(response.data.message)
                      setIsError(true)
                      setErrorMessage(response.data.message)
                      Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: response.data.message,
                        showConfirmButton: false,
                        timer: 1500,
                      })
                    } else {
                      Swal.fire({
                        icon: "success",
                        title: "Success!",
                        text:
                          role == "DR"
                            ? `Application successfully ${actionTaken.value}`
                            : "Application successfully Forwarded",
                        showConfirmButton: false,
                        timer: 1500,
                      })
                      setTimeout(() => {
                        setIsView(false)
                      }, 1500)
                    }
                  })
                  .catch((error: any) => {
                    console.log("error-", error)
                    console.log(error.message)
                    setIsError(true)
                    setErrorMessage(error.message)
                    Swal.fire({
                      icon: "error",
                      title: "Error!",
                      text: error.message,
                      showConfirmButton: false,
                      timer: 1500,
                    })
                  })
              }
            })
            .catch(() => {
              console.log("error")
            })
        }
      } else {
        api
          .post(
            "/societies/remarks",
            { remark: enc },
            {
              headers: {
                Accept: "application/json",
                Authorization: `Bearer ${token}`,
              },
            }
          )
          .then((response: any) => {
            if (!response || !response.data || !response.data.success) {
              console.log("error-", response.data.message)
              console.log(response.data.message)
              setIsError(true)
              setErrorMessage(response.data.message)
              Swal.fire({
                icon: "error",
                title: "Error!",
                text: response.data.message,
                showConfirmButton: false,
                timer: 1500,
              })
            } else {
              Swal.fire({
                icon: "success",
                title: "Success!",
                text:
                  role == "DR"
                    ? `Application successfully ${actionTaken.value}`
                    : "Application successfully Forwarded",
                showConfirmButton: false,
                timer: 1500,
              })
              setTimeout(() => {
                setIsView(false)
              }, 1500)
            }
          })
          .catch((error: any) => {
            console.log("error-", error)
            console.log(error.message)
            setIsError(true)
            setErrorMessage(error.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: error.message,
              showConfirmButton: false,
              timer: 1500,
            })
          })
      }
    } else
      if (role == "IG" && process.env.SECRET_KEY) {

        remarksData.status = actionTaken.value
        const enc = CryptoJS.AES.encrypt(

          JSON.stringify(remarksData),

          process.env.SECRET_KEY

        ).toString()

        if (actionTaken.value == "AcceptedByHA") {

          let data: any = localStorage.getItem("FASPLoginDetails")

          if (data && data != "") {

            let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)

            data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))

          }

          if (data) {
            getDeptSignature(data.deptUserId, data.token)

              .then((res) => {

                if (res.success && res.data && (!res.data.signature || res.data.signature == "")) {

                  ShowMessagePopup(

                    false,

                    "Please upload your signature on the Profile tab",

                    ""

                  )

                  return

                } else if (res.success) {

                  api

                    .post(

                      "/societies/remarks",

                      { remark: enc },

                      {
                        headers: {
                          Accept: "application/json",
                          Authorization: `Bearer ${token}`,
                        },
                      },

                    )
                    .then((response: any) => {
                      if (!response || !response.data || !response.data.success) {
                        console.log("error-", response.data.message)
                        console.log(response.data.message)
                        setIsError(true)
                        setErrorMessage(response.data.message)
                        Swal.fire({
                          icon: "error",
                          title: "Error!",
                          text: response.data.message,
                          showConfirmButton: false,
                          timer: 1500,
                        })
                      } else {
                        Swal.fire({
                          icon: "success",
                          title: "Success!",
                          text:
                            role == "IG"
                              ? `Application successfully ${actionTaken.value} and forwarded to DR`
                              : "Application successfully forwarded",
                          showConfirmButton: false,
                          timer: 1500,
                        })
                        setTimeout(() => {
                          setIsView(false)
                        }, 1500)
                      }
                    })
                    .catch((error: any) => {
                      console.log("error-", error)
                      console.log(error.message)
                      setIsError(true)
                      setErrorMessage(error.message)
                      Swal.fire({
                        icon: "error",
                        title: "Error!",
                        text: error.message,
                        showConfirmButton: false,
                        timer: 1500,
                      })
                    })
                }
              })
              .catch(() => {
                console.log("error")
              })
          }
        } else {
          api
            .post(
              "/societies/remarks",
              { remark: enc },
              {
                headers: {
                  Accept: "application/json",
                  Authorization: `Bearer ${token}`,
                },
              }
            )
            .then((response: any) => {
              if (!response || !response.data || !response.data.success) {
                console.log("error-", response.data.message)
                console.log(response.data.message)
                setIsError(true)
                setErrorMessage(response.data.message)
                Swal.fire({
                  icon: "error",
                  title: "Error!",
                  text: response.data.message,
                  showConfirmButton: false,
                  timer: 1500,
                })
              } else {
                Swal.fire({
                  icon: "success",
                  title: "Success!",
                  text:
                    role == "IG"
                      ? `Application successfully ${actionTaken.value}`
                      : "Application successfully Forwarded",
                  showConfirmButton: false,
                  timer: 1500,
                })
                setTimeout(() => {
                  setIsView(false)
                }, 1500)
              }
            })
            .catch((error: any) => {
              console.log("error-", error)
              console.log(error.message)
              setIsError(true)
              setErrorMessage(error.message)
              Swal.fire({
                icon: "error",
                title: "Error!",
                text: error.message,
                showConfirmButton: false,
                timer: 1500,
              })
            })
        }
      }

      else if (process.env.SECRET_KEY) {
        const enc = CryptoJS.AES.encrypt(
          JSON.stringify(remarksData),
          process.env.SECRET_KEY
        ).toString()
        api
          .post(
            "/societies/remarks",
            { remark: enc },
            {
              headers: {
                Accept: "application/json",
                Authorization: `Bearer ${token}`,
              },
            }
          )
          .then((response: any) => {
            if (!response || !response.data || !response.data.success) {
              console.log("error-", response.data.message)
              console.log(response.data.message)
              setIsError(true)
              setErrorMessage(response.data.message)
              Swal.fire({
                icon: "error",
                title: "Error!",
                text: response.data.message,
                showConfirmButton: false,
                timer: 1500,
              })
            } else {
              Swal.fire({
                icon: "success",
                title: "Success!",
                text:
                  role == "DR"

                    ? `Application successfully ${actionTaken.value}`

                    : "Application successfully Forwarded",

                showConfirmButton: false,

                timer: 1500,

              })

              setTimeout(() => {

                setIsView(false)

              }, 1500)

            }

          })

          .catch((error: any) => {

            console.log("error-", error)

            console.log(error.message)

            setIsError(true)

            setErrorMessage(error.message)

            Swal.fire({

              icon: "error",

              title: "Error!",

              text: error.message,

              showConfirmButton: false,

              timer: 1500,

            })

          })
      }
  }
  return (

    <>
      {!isViewCertificate && !isViewHistory && selectedRequest && !isViewAmendments && (

        <>
          <Head>
            <title>Registration of Society</title>
            <link rel="icon" href="/igrsfavicon.ico" />
          </Head>
          {locData && locData?.userType && locData?.userType != "user" && (
            <div className="societyRegSec report" >
              <Container>
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <div className="d-flex justify-content-between align-items-center page-title mb-3">
                      <div className="pageTitleLeft">
                        <h1>Registration of Society</h1>
                      </div>
                      {/* {userType == "dept" &&
                        <div className="pageTitleRight">
                          <div className="page-header-btns">
                            <a className="btn btn-secondary new-user" onClick={() =>{ setIsViewAmendments(true)}}>
                              Add Amendments
                            </a>
                          </div>
                        </div>} */}
                      <div className="pageTitleRight">
                        <div className="page-header-btns">
                          <a className="btn btn-secondary new-user" onClick={() => setIsView(false)}>
                            Go Back
                          </a>
                        </div>
                      </div>
                    </div>
                  </Col>
                </Row>
              </Container>

              <div className="dataPrevSec">
                <Form className="formsec" onSubmit={handleSubmit}>
                  <Container>
                    {/* {selectedRequest && selectedRequest[`userFields`] && (
                    <Row>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <div className="form-group">
                          <label className="form-label">User ID</label>
                          <div className="valuePrev">{selectedRequest[`userFields`].userId}</div>
                        </div>
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <div className="form-group">
                          <label className="form-label">Portal User Name</label>
                          <div className="valuePrev">
                            {selectedRequest[`userFields`].portaluserName}
                          </div>
                        </div>
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <div className="form-group">
                          <label className="form-label">Operator Name</label>
                          <div className="valuePrev">
                            {selectedRequest[`userFields`].operatorName}
                          </div>
                        </div>
                      </Col>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <div className="form-group">
                          <label className="form-label">Mobile No</label>
                          <div className="valuePrev">{selectedRequest[`userFields`].mobileNumber}</div>
                        </div>
                      </Col>
                    </Row>
                  )} */}
                    <Row>
                      <Col lg={12} md={12} xs={12}>
                        <div className="regofAppBg mb-3">
                          {selectedRequest && selectedRequest[`applicantFields`] && (
                            <div className="firmApplicationSec">
                              <div className="formSectionTitle">
                                <h3>Applicant Details</h3>
                              </div>

                              <Row>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Application Number</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`applicantFields`].applicantNumber}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Name</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`applicantFields`].applicantName}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={2} md={4} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Email ID</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`applicantFields`].emailId}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={2} md={3} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Gender</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`applicantFields`].applicantGender}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={2} md={4} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Mobile No</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`applicantFields`].mobileNumber}
                                    </div>
                                  </div>
                                </Col>
                              </Row>

                              <Row>
                                <Col lg={12} md={4} xs={12}>
                                  <div className="form-group">
                                    <label className="form-label">Address</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`addressFields`].doorNo}
                                      {selectedRequest[`addressFields`].street && (
                                        <span> / {selectedRequest[`addressFields`].street}</span>
                                      )}
                                      {selectedRequest[`addressFields`].villageCity && (
                                        <span> / {selectedRequest[`addressFields`].villageCity}</span>
                                      )}
                                      {selectedRequest[`addressFields`].mandal && (
                                        <span> / {selectedRequest[`addressFields`].mandal}</span>
                                      )}
                                      {selectedRequest[`addressFields`].district && (
                                        <span> / {selectedRequest[`addressFields`].district}</span>
                                      )}
                                      {selectedRequest[`addressFields`].state && (
                                        <span> / {selectedRequest[`addressFields`].state}</span>
                                      )}
                                      {selectedRequest[`addressFields`].country && (
                                        <span> / {selectedRequest[`addressFields`].country}</span>
                                      )}
                                      {selectedRequest[`addressFields`].pinCode && (
                                        <span> / {selectedRequest[`addressFields`].pinCode}</span>
                                      )}
                                    </div>
                                  </div>
                                </Col>


                              </Row>
                            </div>
                          )}
                        </div>
                        <div className="regofAppBg mb-3">
                          {selectedRequest && selectedRequest[`societyFields`] && (
                            <div className="firmApplicationSec">
                              <div className="formSectionTitle">
                                <h3>Society Details</h3>
                              </div>

                              <Row>
                                <Col lg={3} md={4} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Society Name</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`societyFields`].societyName}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={3} md={4} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Society Category</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`societyFields`].category}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={2} md={4} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">General Body Meeting</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`societyFields`].generalBodyMeeting}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={2} md={4} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Aim</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`societyFields`].aim}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={2} md={4} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Objective</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`societyFields`].objective}
                                    </div>
                                  </div>
                                </Col>
                                <Col lg={12} md={12} xs={12} className="mb-3">
                                  <div className="form-group">
                                    <label className="form-label">Address</label>
                                    <div className="valuePrev">
                                      {selectedRequest[`societyFields`].doorNo}
                                      {selectedRequest[`societyFields`].street && (
                                        <span> / {selectedRequest[`societyFields`].street}</span>
                                      )}
                                      {selectedRequest[`societyFields`].villageCity && (
                                        <span> / {selectedRequest[`societyFields`].villageCity}</span>
                                      )}
                                      {selectedRequest[`societyFields`].mandal && (
                                        <span> / {selectedRequest[`societyFields`].mandal}</span>
                                      )}
                                      {selectedRequest[`societyFields`].district && (
                                        <span> / {selectedRequest[`societyFields`].district}</span>
                                      )}
                                      {selectedRequest[`societyFields`].state && (
                                        <span> / {selectedRequest[`societyFields`].state}</span>
                                      )}
                                      {selectedRequest[`addressFields`].country && (
                                        <span> / {selectedRequest[`addressFields`].country}</span>
                                      )}
                                      {selectedRequest[`societyFields`].pinCode && (
                                        <span> / {selectedRequest[`societyFields`].pinCode}</span>
                                      )}

                                    </div>
                                  </div>
                                </Col>
                              </Row>
                            </div>
                          )}
                        </div>
                        {existingSocietyDetails?.isAmalgamChange == true ? <>
                          <div className="regofAppBg mb-3">

                            {selectedRequest && selectedRequest[`incomingSocietyFields`]?.length > 0 && (
                              <div className="firmApplicationSec">
                                <div className="formSectionTitle">
                                  <h3>Incoming Society Details</h3>
                                </div>
                                {selectedRequest &&
                                  selectedRequest[`incomingSocietyFields`].length > 0 && (


                                    selectedRequest[`incomingSocietyFields`].map(
                                      (item: any, i: number) => {
                                        return (

                                          <Row>
                                            <Col lg={3} md={4} xs={12} className="mb-3">
                                              <div className="form-group">
                                                <label className="form-label">Society Name</label>
                                                <div className="valuePrev">
                                                  {item.incomingSocietyDetails.societyName}
                                                </div>
                                              </div>
                                            </Col>
                                            <Col lg={3} md={4} xs={12} className="mb-3">
                                              <div className="form-group">
                                                <label className="form-label">Reason For Amalgam</label>
                                                <div className="valuePrev">
                                                  {item.incomingSocietyDetails.reasonForAmalgam}
                                                </div>
                                              </div>
                                            </Col>
                                            <Col lg={2} md={4} xs={12} className="mb-3">
                                              <div className="form-group">
                                                <label className="form-label">Aim</label>
                                                <div className="valuePrev">
                                                  {item.incomingSocietyDetails.aim}
                                                </div>
                                              </div>
                                            </Col>
                                            <Col lg={2} md={4} xs={12} className="mb-3">
                                              <div className="form-group">
                                                <label className="form-label">Objective</label>
                                                <div className="valuePrev">
                                                  {item.incomingSocietyDetails.objective}
                                                </div>
                                              </div>
                                            </Col>

                                            <Col lg={12} md={12} xs={12} className="mb-3">
                                              <div className="form-group">
                                                <label className="form-label">Address</label>
                                                <div className="valuePrev">
                                                  {item.incomingSocietyDetails.doorNo}
                                                  {item.incomingSocietyDetails.street && (
                                                    <span> / {item.incomingSocietyDetails.street}</span>
                                                  )}
                                                  {item.incomingSocietyDetails.villageCity && (
                                                    <span> / {item.incomingSocietyDetails.villageCity}</span>
                                                  )}
                                                  {item.incomingSocietyDetails.mandal && (
                                                    <span> / {item.incomingSocietyDetails.mandal}</span>
                                                  )}
                                                  {item.incomingSocietyDetails.district && (
                                                    <span> / {item.incomingSocietyDetails.district}</span>
                                                  )}
                                                  {item.incomingSocietyDetails.state && (
                                                    <span> / {item.incomingSocietyDetails.state}</span>
                                                  )}
                                                  {item.incomingSocietyDetails.country && (
                                                    <span> / {item.incomingSocietyDetails.country}</span>
                                                  )}
                                                  {item.incomingSocietyDetails.pinCode && (
                                                    <span> / {item.incomingSocietyDetails.pinCode}</span>
                                                  )}

                                                </div>
                                              </div>
                                            </Col>
                                          </Row>)
                                      })
                                  )}
                              </div>
                            )}
                          </div>

                        </> : null}
                        <div className="firmPartnerSec tableSec mb-3">
                          <div className="formSectionTitle">
                            <h3>EC Member Details</h3>
                          </div>
                          <Row>
                            <Col lg={12} md={12} xs={12}>
                              <Table striped bordered className="tableData listData">
                                <thead>
                                  <tr>
                                    {/* <th className="siNo text-center">SI No</th> */}
                                    <th>Name</th>
                                    <th>Age</th>
                                    <th>Role</th>
                                    <th>Address</th>
                                  </tr>
                                </thead>
                                {selectedRequest && selectedRequest[`memberDetails`].length > 0 ? (
                                  <tbody>
                                    {selectedRequest &&
                                      selectedRequest[`memberDetails`].map((item: any, i: number) => {
                                        return (
                                          <> {
                                            item.status != "InActive" ?
                                              <tr key={i + 1}>
                                                {/* <td className="siNo text-center">{i + 1}</td> */}
                                                <td >{item.memberName}</td>
                                                <td >{item.age}</td>
                                                <td>{item.role}</td>
                                                <td>

                                                  {item.doorNo}
                                                  {item.street && <span> / {item.street}</span>}
                                                  {item.villageCity && <span> / {item.villageCity}</span>}
                                                  {item.mandal && <span> / {item.mandal}</span>}
                                                  {item.district && <span> / {item.district}</span>}
                                                  {item.state && <span> / {item.state}</span>}
                                                  {item.country && <span> / {item.country}</span>}
                                                  {item.pinCode && <span> / {item.pinCode}</span>}
                                                </td>
                                              </tr> : null}</>
                                        )
                                      })}
                                  </tbody>
                                ) : (
                                  <tbody>
                                    <tr>
                                      <td colSpan={6}>No Members Found</td>
                                    </tr>
                                  </tbody>
                                )}
                              </Table>
                            </Col>
                          </Row>
                        </div>

                        {/* {userType != "user" && (
                    <div className="firmPartnerSec tableSec mb-3">
                      <div className="formSectionTitle">
                        <h3>Applicant Message History</h3>
                      </div>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <Table striped bordered className="tableData listData">
                            <thead>
                              <tr>
                                <th className="siNo text-center">SI No</th>
                                <th>Number</th>
                                <th>Message</th>
                                <th>Sent Date</th>
                              </tr>
                            </thead>

                            {selectedRequest[`messageToApplicant`].length > 0 ? (
                              <tbody>
                                {selectedRequest[`messageToApplicant`].map((item, i) => {
                                  return (
                                    <tr key={i + 1}>
                                      <td className="siNo text-center">{i + 1}</td>
                                      <td>{item.number}</td>
                                      <td>{item.message}</td>
                                      <td>{item.sentDate}</td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            ) : (
                              <tbody>
                                <tr>
                                  <td colSpan={6}>No Data Found</td>
                                </tr>
                              </tbody>
                            )}
                          </Table>
                        </Col>
                      </Row>
                    </div>
                  )} */}
                        {/* {userType == "dept" && selectedRequest.applicantFields.status != "Approved" && (
                    <div className="uploadFirmList mb-4">
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <h3>Message to Applicant</h3>
                        </Col>
                      </Row>
                      <div className="regofAppBg">
                        <Row className="align-items-center applicantMessage">
                          <Col lg={3} md={4} xs={12} className="mb-2">
                            <label className="form-label">
                              Message to Applicant <span>*</span>
                            </label>
                            <p>
                              (Please use this option to inform applicant in case of any
                              clarification required for your office)
                            </p>
                          </Col>
                          <Col lg={5} md={4} xs={12} className="mb-3">
                            <textarea
                              className="form-control textarea"
                              name="applicantMessage"
                              id="applicantMessage"
                            // required
                            ></textarea>
                          </Col>
                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <Button variant="primary" onClick={sendSms}>
                              Send SMS
                            </Button>
                          </Col>
                        </Row>
                      </div>
                    </div>
                  )} */}
                      </Col>
                      {/* <Col lg={6} md={6} xs={6}>
                      <div className="firmApplicationSec mb-3">
                        <div className="formSectionTitle mb-3">
                          <h3 className="documents-attached-title">Documents Attached</h3>
                        </div>
                        <div id="document-attached-list"></div>
                        <ul className="document-attached-list">
                          <li key={1}>
                            <PreviewDetails
                              documentAttachedList={selectedRequest?.documentAttached}
                              id={selectedRequest?.applicantFields?.id}
                            />
                          </li>
                        </ul>
                      </div>
                    </Col> */}

                    </Row>
                    <div className="firmApplicationSec mb-3">
                      <div className="formSectionTitle mb-3">
                        <h3>Documents Attached</h3>
                      </div>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <ul>
                            {selectedRequest &&
                              selectedRequest?.documentAttached &&
                              selectedRequest?.documentAttached?.map(
                                (document: any, index: number) => {
                                  return (
                                    <li key={index + 1}>
                                      <a id={`docFile${index}`} target="_blank">
                                        {document?.originalname}
                                      </a>
                                    </li>
                                  )
                                }
                              )}
                          </ul>
                        </Col>
                      </Row>
                    </div>
                    {userType && (
                      <div className="firmPartnerSec tableSec mb-3">
                        <div className="formSectionTitle">
                          <h3>Processing History</h3>
                        </div>
                        <Row>
                          <Col lg={12} md={12} xs={12}>
                            <Table striped bordered className="tableData listData">
                              <thead>
                                <tr>
                                  {/* <th className="siNo text-center">SI No</th> */}
                                  <th>Designation</th>
                                  <th>Status</th>
                                  <th>Remarks</th>
                                  <th>Application Type</th>
                                  <th>Application taken Date</th>
                                  <th>Application Processed Date</th>
                                </tr>
                              </thead>

                              {selectedRequest &&
                                selectedRequest[`processingHistory`].length > 0 ? (
                                <tbody>
                                  {selectedRequest[`processingHistory`].map(
                                    (item: any, i: number) => {
                                      return (

                                        <tr key={i + 1}>
                                          {/* <td className="siNo text-center">{i + 1}</td> */}
                                          <td>{item.designation}</td>
                                          <td>{item.status}</td>
                                          <td>{item.remarks}</td>
                                          <td>
                                            {(selectedRequest.isAimChange == true || selectedRequest.isNameChange == true
                                              || selectedRequest.isAddressChange == true ||
                                              selectedRequest.isAmalgamChange == true ||
                                              selectedRequest.isSocietyDissolved == true ||
                                              selectedRequest.isSocietyWinding == true ||
                                              selectedRequest.isMemorandumChange == true ||
                                              selectedRequest.isFiling == true) ?
                                              <>
                                                {selectedRequest.isAimChange == true && "Aim and Objective Change"}
                                                {selectedRequest.isNameChange == true && "Name Change"}
                                                {selectedRequest.isAddressChange == true && "Address Change"}
                                                {selectedRequest.isAmalgamChange == true && "Amalgamation"}
                                                {selectedRequest.isSocietyDissolved == true && "Dissolution"}
                                                {selectedRequest.isSocietyWinding == true && "Winding Society"}
                                                {selectedRequest.isMemorandumChange == true && "Memorandum and Bye-laws"}
                                                {selectedRequest.isFiling == true && "Filing of List of Members"}
                                              </> : "Society Registration"}
                                          </td>
                                          <td>{DateFormator(item.applicationTakenDate, "dd/mm/yyyy")}</td>
                                          <td>{DateFormator(item.applicationProcessedDate, "dd/mm/yyyy")}</td>
                                        </tr>
                                      )
                                    }
                                  )}
                                </tbody>
                              ) : (
                                <tbody>
                                  <tr>
                                    <td colSpan={6}>No Data Found</td>
                                  </tr>
                                </tbody>
                              )}
                            </Table>
                          </Col>
                        </Row>
                      </div>
                    )}
                    {userType == "dept" &&
                      selectedRequest &&
                      selectedRequest.applicantFields.status != "Approved" &&
                      selectedRequest.applicantFields.status != "Rejected" &&
                      (role == "DR" ||
                        (role != "DR" && selectedRequest.applicantFields.status != "Forwarded")) &&
                      // selectedRequest.applicantFields.status == "Forwarded"&&
                      (<div className="uploadFirmList mb-4">
                        <Row>
                          <Col lg={12} md={12} xs={12}>
                            <h3>Officer Recommendations</h3>
                          </Col>
                        </Row>
                        <div className="regofAppBg">
                          {userType == "dept" && role != "DR" && role != "IG" &&
                            selectedRequest.applicantFields.status != "Forwarded" &&
                            selectedRequest.applicantFields.status != "Approved" &&
                            selectedRequest.applicantFields.status != "AppealedToHA" && !isTransVerified && (
                              <Row>
                                <Col lg={12} md={12} xs={12} className="text-center mb-3">
                                  <Button
                                    variant="primary"
                                    onClick={() => {
                                      verifyTransacDetails()
                                    }}
                                  >
                                    Verify Transaction
                                  </Button>
                                </Col>
                              </Row>
                            )}
                          {userType == "dept" && role == "DR" &&
                            selectedRequest.applicantFields.status != "Approved" &&
                            selectedRequest.applicantFields.status != "AcceptedByHA" &&
                            !isTransDefaced && (
                              <Row>
                                <Col lg={12} md={12} xs={12} className="text-center mb-3">
                                  <Button variant="primary" onClick={() => defaceTransacDetails()}>
                                    Deface Transaction
                                  </Button>
                                </Col>
                              </Row>
                            )}
                          {isTransDefaced && role == "DR"
                            &&
                            selectedRequest.applicantFields.status != "Approved" &&
                            selectedRequest.applicantFields.status != "AppealedToHA" &&
                            selectedRequest.applicantFields.status != "Rejected" &&
                            (
                              <Row className="align-items-center">
                                <Col lg={3} md={4} xs={12} className="mb-2">
                                  <label className="form-label">
                                    Action Taken <span>*</span>
                                  </label>
                                </Col>
                                <Col lg={5} md={4} xs={12} className="mb-3">
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="actionTaken"
                                    id="actionTaken"
                                    required
                                  >
                                    <option hidden>Select</option>
                                    <option value="Approved">Approved</option>
                                    {selectedRequest.applicantFields.status != "AcceptedByHA" ?
                                      <option value="Rejected">Rejected</option> : null}
                                  </select>
                                </Col>
                              </Row>
                            )}

                          {role == "IG"
                            &&
                            selectedRequest.applicantFields.status != "Approved" &&
                            selectedRequest.applicantFields.status != "AcceptedByHA" &&
                            selectedRequest.applicantFields.status != "Rejected" &&
                            (<>
                              <Row className="align-items-center">
                                <Col lg={3} md={4} xs={12} className="mb-2">
                                  <label className="form-label">
                                    Action Taken <span>*</span>
                                  </label>
                                </Col>
                                <Col lg={5} md={4} xs={12} className="mb-3">
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="actionTaken"
                                    id="actionTaken"
                                    required
                                  >
                                    <option hidden>Select</option>
                                    <option value="AcceptedByHA">Approved/Accepted</option>
                                    <option value="Rejected">Rejected</option>
                                  </select>
                                </Col>
                              </Row>
                              <Row className="align-items-center">
                                <Col lg={3} md={4} xs={12} className="mb-2">
                                  <label className="form-label">
                                    Remarks <span>*</span>
                                  </label>
                                </Col>
                                <Col lg={5} md={4} xs={12} className="mb-3">
                                  <textarea
                                    className="form-control textarea"
                                    name="remarks"
                                    id="remarks"
                                    required
                                  ></textarea>
                                </Col>
                              </Row></>
                            )}
                          {userType == "dept" &&
                            selectedRequest.applicantFields.status != "Rejected" &&
                            selectedRequest.applicantFields.status != "Approved" &&
                            selectedRequest.applicantFields.status != "AppealedToHA" &&
                            ((role == "DR" && isTransDefaced) ||
                              (role != "DR" && role != "IG" &&
                                isTransVerified &&
                                selectedRequest.applicantFields.status != "Forwarded")) && (
                              // ((role == "DR" && isTransDefaced) ||
                              //   (role != "DR" && isTransVerified)) && (
                              <Row className="align-items-center">
                                <Col lg={3} md={4} xs={12} className="mb-2">
                                  <label className="form-label">
                                    Remarks <span>*</span>
                                  </label>
                                </Col>
                                <Col lg={5} md={4} xs={12} className="mb-3">
                                  <textarea
                                    className="form-control textarea"
                                    name="remarks"
                                    id="remarks"
                                    required
                                  ></textarea>
                                </Col>
                              </Row>
                            )}
                        </div>
                      </div>
                      )}
                    {userType == "dept" &&
                      selectedRequest &&
                      selectedRequest.applicantFields.status != "Rejected" &&
                      selectedRequest.applicantFields.status == "Approved" && (
                        <Row>
                          <Col lg={12} md={12} xs={12} className="text-center">
                            <Button variant="primary" onClick={() => setIsViewCertificate(true)}>
                              View Certificate
                            </Button>
                          </Col>
                        </Row>
                      )}
                    {userType == "dept" &&
                      selectedRequest &&
                      selectedRequest.applicantFields.status != "Rejected" &&
                      selectedRequest.applicantFields.status != "Approved" &&
                      selectedRequest.applicantFields.status != "Forwarded" &&
                      selectedRequest.applicantFields.status != "AppealedToHA" &&
                      isTransVerified &&
                      role != "DR" && role != "IG" && (
                        <Row>
                          <Col lg={12} md={12} xs={12} className="text-center">
                            <Button variant="primary" type="submit">
                              Forward
                            </Button>
                          </Col>
                        </Row>
                      )}
                    {userType == "dept" &&
                      selectedRequest &&
                      selectedRequest.applicantFields.status != "Rejected" &&
                      (selectedRequest.applicantFields.status == "Forwarded" || selectedRequest.applicantFields.status == "AcceptedByHA") &&
                      selectedRequest.applicantFields.status != "Approved" &&

                      role == "DR" &&
                      isTransDefaced && (
                        <Row>
                          <Col lg={12} md={12} xs={12} className="text-center">
                            <Button variant="primary" type="submit">
                              Submit
                            </Button>
                          </Col>
                        </Row>
                      )}
                    {userType == "dept" &&
                      selectedRequest &&
                      selectedRequest.applicantFields.status != "Rejected" &&
                      selectedRequest.applicantFields.status == "AppealedToHA" &&
                      selectedRequest.applicantFields.status != "Approved" &&
                      role == "IG" &&
                      isTransDefaced && (
                        <Row>
                          <Col lg={12} md={12} xs={12} className="text-center">
                            <Button variant="primary" type="submit">
                              Submit
                            </Button>
                          </Col>
                        </Row>
                      )}


                    {userType == "dept" &&
                      selectedRequest &&
                      selectedRequest.historyDetails?.length > 0 && (
                        <Row>
                          <Col lg={12} md={12} xs={12} className="text-center mt-2">
                            <Button variant="primary" onClick={() => setViewHistory(true)}>
                              View History
                            </Button>
                          </Col>
                        </Row>
                      )}
                  
                  </Container>
                </Form>
              </div>
            </div>)}
          {(!locData?.userType || locData?.userType == "user") && (
            <div className="societyRegSec">
              <Container>
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <div className="d-flex justify-content-between page-title mb-2">
                      <div className="pageTitleLeft">
                        <h1>Unauthorized page</h1>
                      </div>
                    </div>
                  </Col>
                </Row>
              </Container>
            </div>
          )}
        </>
      )}

      {isViewCertificate && (
        <RegistrationofSocietyCertificate
          reqsearchdata={reqsearchdata}
          selectedRequest={selectedRequest}
          setReqSearchData={setReqSearchData}
          setIsView={setIsView}
          setIsError={setIsError}
          setErrorMessage={setErrorMessage}
        />
      )}
      {isViewAmendments && (
        <AddAmendmentDetails
          reqsearchdata={reqsearchdata}
          selectedRequest={selectedRequest}
          setReqSearchData={setReqSearchData}
          setIsView={setIsView}
          setIsError={setIsError}
          setErrorMessage={setErrorMessage}
        />
      )}
      {isViewHistory && selectedRequest.historyDetails?.length > 0 && (
        <ViewHistory
          reqsearchdata={reqsearchdata}
          selectedRequest={
            selectedRequest &&
            selectedRequest.historyDetails[selectedRequest.historyDetails.length - 1]
          }
          setReqSearchData={setReqSearchData}
          setIsView={setIsView}
          setIsError={setIsError}
          setErrorMessage={setErrorMessage}
          appId={existingSocietyDetails._id}
          setViewHistory={setViewHistory}
        />
      )}

    </>
  )
}

export default ViewDetails
