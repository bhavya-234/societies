import React, { useState, useEffect } from "react"
import Head from "next/head"
import { Container, Col, Row, Table } from "react-bootstrap"
import ViewDetails from "./viewDetails"
import JsBarcode from "jsbarcode"
import CryptoJS from "crypto-js"
import { DateFormator } from "@/GenericFunctions"
import { getDeptSignature } from "@/axios"

interface RegistrationSocietyProps {
  reqsearchdata: any
  selectedRequest: any
  setReqSearchData: any
  setIsView: any
  setIsError: any
  setErrorMessage: any
}

const RegistrationofSocietyCertificate = ({
  reqsearchdata,
  selectedRequest,
  setReqSearchData,
  setIsView,
  setIsError,
  setErrorMessage,
}: RegistrationSocietyProps) => {
  const [isGoBack, setIsGoBack] = useState(false)

  const [fullName, setFullName] = useState("")
  const [signature, setSignature] = useState<string>("")
  const [date, setDate] = useState<string>("")
  const current = new Date()
  // const date = `${current.getDate()}/${current.getMonth() + 1}/${current.getFullYear()}`
  const [locData, setLocData] = useState<any>({})
  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLocData(data)
    }
  }, [])

  // useEffect(() => {
  //   document.body.classList.add("viewCertificatePage")


  // if (selectedRequest && selectedRequest[`applicantFields`]) {
  //   JsBarcode("#barcode", selectedRequest[`applicantFields`].applicantNumber, {
  //     displayValue: false,
  //   })
  // }
  useEffect(() => {

    const date =

      selectedRequest.processingHistory &&

      selectedRequest.processingHistory?.find((x: any) => x.status == "Approved")

    if (date && date.applicationProcessedDate) {

      setDate(DateFormator(date.applicationProcessedDate, "dd/mm/yyyy"))

    }

    let data: any = localStorage.getItem("FASPLoginDetails")

    if (data && data != "" && process.env.SECRET_KEY) {

      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)

      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))

    }

    if (data && data.token) {

      setLocData(data)

    }

    if (data) {

      getDeptSignature(selectedRequest[`societyFields`].deptId, data.token)

        .then((res: any) => {

          if (res.success && res.data) {

            setSignature("data:image/jpg;base64, " + res.data.signature)

            setFullName(res.data.fullName)

          }

        })

        .catch(() => {

          console.log("error")

        })

    }
    document.body.classList.add("viewCertificatePage")
    if (selectedRequest && selectedRequest[`applicantFields`]) {
      setTimeout(() => {
        JsBarcode("#barcode", selectedRequest[`applicantFields`].applicantNumber, {
          displayValue: false,
        })
      }, 200);
    }
    return () => {

      document.body.classList.remove(

        "viewCertificate",

        "bg-salmon",

        "viewCerticate",

        "viewCerticatePage"

      )

    }

  }, [])
  const handleBack = () => {
    setIsGoBack(true)
    document.body.classList.remove("viewCertificatePage")
  }

  return (
    <>
      {locData && locData?.userType && locData?.userType != "user" && (
        <>
          {!isGoBack && selectedRequest && (
            <>
              <Head>
                <title>Acknowledgement of Registration of Society</title>
                <link rel="icon" href="/registration-stamp-icon.ico" />
              </Head>
              <div className="societyRegSec viewCerticateSec">
                <Container>
                  <div className="certificateHeader">
                    <div className="certificateHeaderLogo">
                      <img
                        src="/assets/Andhra_Pradesh_Official_Logo.jpg"
                        alt="Andhra_Pradesh_Official_Logo.jpg"
                        title=""
                      />
                    </div>
                    <h1>
                      GOVERNMENT OF ANDHRA PRADESH REGISTRATION AND STAMPS DEPARTMENT THE REGISTRAR
                      OF SOCIETIES <span>{selectedRequest[`addressFields`].district}</span>
                    </h1>
                  </div>

                  <div className="certificateReg">
                    <Row className="d-flex justify-content-between align-items-center">
                      <Col md={{ span: 2, offset: 1 }}></Col>
                      <Col lg={5} md={5} xs={12}>
                        <div className="certificateTitle text-center">
                          <h2>CERTIFICATE OF REGISTRATION</h2>
                          <h6>
                            ( No: {selectedRequest[`societyFields`].registrationNumber} of{" "}
                            {selectedRequest[`societyFields`].registrationYear} )
                          </h6>
                        </div>
                      </Col>
                      <Col lg={4} md={4} xs={12}>
                        <div className="certificateInfo">
                          <h6>Application No </h6>
                          <img id="barcode" />
                          <h5>{selectedRequest[`applicantFields`].applicantNumber}</h5>
                          <h6>Date: {date}</h6>
                        </div>
                      </Col>
                    </Row>
                  </div>

                  <div className="certificateHereInfo">
                    <p>
                      I hereby certify that <b>{selectedRequest[`societyFields`].societyName}</b>,{" "}
                      <b>
                        {selectedRequest[`addressFields`].doorNo}
                        {selectedRequest[`addressFields`].street && (
                          <span> / {selectedRequest[`addressFields`].street}</span>
                        )}
                        {selectedRequest[`addressFields`].villageCity && (
                          <span> / {selectedRequest[`addressFields`].villageCity}</span>
                        )}
                        {selectedRequest[`addressFields`].mandal && (
                          <span> / {selectedRequest[`addressFields`].mandal}</span>
                        )}
                        {selectedRequest[`addressFields`].district && (
                          <span> / {selectedRequest[`addressFields`].district}</span>
                        )}
                        {selectedRequest[`addressFields`].state && (
                          <span> / {selectedRequest[`addressFields`].state}</span>
                        )}
                        {selectedRequest[`addressFields`].country && (
                          <span> / {selectedRequest[`addressFields`].country}</span>
                        )}
                        {selectedRequest[`addressFields`].pinCode && (
                          <span> / {selectedRequest[`addressFields`].pinCode}</span>
                        )}
                      </b>{" "}
                      on this day registered under the Andhra Pradesh Societies Registration Act.,
                      2001
                    </p>
                  </div>

                  <div className="certifyLogoSec">
                    <Row className="d-flex justify-content-between align-items-center">
                      <Col lg={6} md={6} xs={12}>
                        <div className="certifyLogoInfo text-center">
                          <div className="certifyLogoImgSec">
                            <img src="/assets/soc_logo.png" alt="soc_logo.png" />
                            <h6>{selectedRequest[`addressFields`].district}</h6>
                          </div>
                          <h6>Date: {date}</h6>
                        </div>
                      </Col>
                      <Col lg={6} md={6} xs={12}>
                        <div className="certifySignInfo">
                          <h6>Certified By</h6>
                          <div className="certifySignImg">
                            <img src={signature} alt="signImg.png" />
                          </div>
                          <h6>Name: {fullName}</h6>
                          <h6>Designation: DISTRICT REGISTRAR</h6>
                          <h6>District:{selectedRequest[`addressFields`].district}</h6>
                        </div>
                      </Col>
                    </Row>
                  </div>

                  <div className="certifyMaintainSec text-center">
                    <h3>(Maintained Under Section 3 of Societies Registration Act, 2001)</h3>
                  </div>

                  <Table striped bordered className="certifiyTable">
                    <tbody>
                      <tr>
                        <td>1</td>
                        <td>Society Registration Number:</td>
                        <td>
                          No: {selectedRequest[`societyFields`].registrationNumber} of{" "}
                          {selectedRequest[`societyFields`].registrationYear}
                        </td>
                      </tr>

                      <tr>
                        <td>2</td>
                        <td>Name of the Society:</td>
                        <td>{selectedRequest[`societyFields`].societyName}</td>
                      </tr>

                      <tr>
                        <td>3</td>
                        <td>Society Category:</td>
                        <td>{selectedRequest[`societyFields`].category}</td>
                      </tr>

                      <tr>
                        <td>4</td>
                        <td>Society Address:</td>
                        <td>
                          {" "}
                          {`${selectedRequest[`addressFields`].doorNo}/${selectedRequest[`addressFields`].street
                            }/${selectedRequest[`addressFields`].villageCity}/${selectedRequest[`addressFields`].mandal
                            }/${selectedRequest[`addressFields`].district}/${selectedRequest[`addressFields`].state
                            }/${selectedRequest[`addressFields`].country}`}
                        </td>
                      </tr>
                    </tbody>
                  </Table>

                  <div className="certifyMaintainSec text-center">
                    <h3>EC Member Details</h3>
                  </div>

                  <Table striped bordered className="certifiyTable">
                    <thead>
                      <tr>
                        <th>S.No</th>
                        <th>Name of the office Bearers & S/O, W/O, D/O</th>
                        <th>Designation of their local standing in the Society</th>
                        <th>Occupation</th>
                        <th>Residential Address</th>
                      </tr>
                    </thead>

                    {selectedRequest[`memberDetails`].length > 0 ? (
                      <tbody>

                        {selectedRequest[`memberDetails`].map((item: any, i: number) => {
                          return (
                            <> {
                              item.status != "InActive" ?
                            <tr key={i + 1}>
                              <td className="text-center">{i + 1}</td>
                              <td>{`${item.memberName}, ${item.relationType},${item.relationName}`}</td>
                              <td>{item.role}</td>
                              <td className="text-center">{item.occupation}</td>
                              <td>
                                {`${item.doorNo}/${item.street}/${item.villageOrCity}/${item.mandal}/${item.district}/${item.state}/${item.country}/${item.pinCode}`}
                              </td>
                            </tr>:null}</>
                          )
                        })}
                      </tbody>
                    ) : (
                      <tbody>
                        <tr>
                          <td colSpan={6}>No Members Found</td>
                        </tr>
                      </tbody>
                    )}
                  </Table>

                  <div className="certifyMaintainSec text-center">
                    <h3>Document Details</h3>
                  </div>

                  <Table striped bordered className="certifiyTable">
                    <thead>
                      <tr>
                        <th>Document Type</th>
                        <th>Document Name</th>
                      </tr>
                    </thead>

                    {selectedRequest?.documentAttached?.length > 0 ? (
                      <tbody>
                        {selectedRequest?.documentAttached?.map((document: any, index: number) => {
                          const appName = document?.originalname
                          const appSplit = appName.split("_")
                          let validFileExtensions = ["resigned", "death", "committeeResolution", "firstNotice", "secondNotice", "thirdNotice", "terminated", "selfSignedDeclaration"];
                          let appSplitVal = appSplit[0]
                          let appSplitValdata = appSplit[1]
                          let appType = ""
                          if (appSplitVal == "idProofs") {
                            appType = "Id Proofs"
                          }

                          if (appSplitVal == "memorandum") {
                            appType = "Memorandum"
                          }

                          if (appSplitVal == "byeLaws") {
                            appType = "ByeLaws"
                          }

                          if (appSplitVal == "affidavit") {
                            appType = "Lease Deed or Affidavit"
                          }
                          if (appSplitVal == "moa") {
                            appType = "MOA"
                          }
                          if (appSplitVal == "affidavitByAuditor") {
                            appType = "Affidavit By Auditor"
                          }

                          if (appSplitVal == "selfSignedDeclaration") {
                            appType = "Self signed declaration"
                          }
                          if (appSplitVal == "declaration") {
                            appType = "declaration"
                          }
                          if (appSplitVal == "propertyDisposal") {
                            appType = "property Disposal"
                          }

                          if (appSplitVal == "supportingDoc") {
                            appType = "supporting Document"
                          }
                          if (appSplitVal == "minutesOfMeeting") {
                            appType = "minutes Of Meeting"
                          }
                          if (appSplitValdata == "committeeResolution") {
                            appType = "Resolution of Committee"
                          }
                          if (appSplitValdata == "firstNotice") {
                            appType = "Notice 1"
                          }

                          if (appSplitValdata == "secondNotice") {
                            appType = "Notice 2"
                          }
                          if (appSplitValdata == "thirdNotice") {
                            appType = "Notice 3"
                          }
                          if (appSplitValdata == "resigned") {
                            appType = "Resigned"
                          }
                          if (appSplitValdata == "death") {
                            appType = "Death"
                          }
                          if (appSplitValdata == "terminated") {
                            appType = "Terminated"
                          }
                          if (appSplitValdata == "selfSignedDeclaration") {
                            appType = "Self Signed Declaration"
                          }
                          return (
                            <tr key={index + 1}>
                              <td>{appType}</td>
                              <td>{document?.originalname}</td>
                            </tr>
                          )
                        })}
                      </tbody>
                    ) : (
                      <tbody>
                        <tr>
                          <td colSpan={6}>No Documents Found</td>
                        </tr>
                      </tbody>
                    )}
                  </Table>

                  <div className="certificateBtnSec">
                    <Row>
                      <Col lg={12} md={12} xs={12}>
                        <div className="d-flex justify-content-center text-center">
                          <button className="btn btn-primary showPayment" onClick={handleBack}>
                            Back
                          </button>
                        </div>
                      </Col>
                    </Row>
                  </div>
                </Container>
              </div>
            </>
          )}
          {isGoBack && (
            <ViewDetails
              reqsearchdata={reqsearchdata}
              selectedRequest={selectedRequest}
              setReqSearchData={setReqSearchData}
              setIsView={setIsView}
              setIsError={setIsError}
              setErrorMessage={setErrorMessage}
            />
          )}
        </>
      )}
      {(!locData?.userType || locData?.userType == "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}

export default RegistrationofSocietyCertificate
