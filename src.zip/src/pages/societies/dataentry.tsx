import { KeepLoggedIn, ShowMessagePopup } from "@/GenericFunctions"
import {
  UseGetAadharDetails,
  UseSaveDataEntrySocietyDetails,
  useGetDistrictList,
  useGetMandalList,
  useGetVillagelList,
} from "@/axios"
import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import { useAppDispatch } from "@/hooks/reduxHooks"
import {
  IAAdditionalDetailsModel,
  IApplicationDetailsModel,
  IByLawsDetailsModel,
  IExistingMemberDetailsModel,
  ISocitiesDetailsModel,
} from "@/models/societyTypes"
import instance from "@/redux/api"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { store } from "@/redux/store"
import styles from "@/styles/pages/Forms.module.scss"
import CryptoJS, { AES } from "crypto-js"
import Head from "next/head"
import Image from "next/image"
import { useRouter } from "next/router"
import React, { useEffect, useRef, useState } from "react"
import { Button, Col, Container, Form, Row, Table } from "react-bootstrap"
import TableDropdownSRO from "@/components/TableDropdownSRO"
import { showText } from "pdf-lib"

export default function dataentry() {
  const [isResubmission, setIsResubmission] = useState<string>("false")
  const [districtList, setDistricts] = useState<any>([])
  const [token, setToken] = useState<string>("")
  const [LoginDetails, setLoginDetails] = useState<any>({})
  const [currentVillage, setCurrentVillage] = useState<any>([])
  const [currentMandal, setCurrentMandal] = useState<any>([])
  const [currentsocietyVillage, setCurrentsocietyVillage] = useState<any>([])
  const [currentsocietyMandal, setCurrentsocietyMandal] = useState<any>([])
  const [currentmemberVillage, setCurrentmemberVillage] = useState<any>([])
  const [currentmemberMandal, setCurrentmemberMandal] = useState<any>([])
  const [currentauditorVillage, setCurrentauditorVillage] = useState<any>([])
  const [currentauditorMandal, setCurrentauditorMandal] = useState<any>([])

  const [errors, setErrors] = useState<any>({})
  const router = useRouter()
  const dispatch = useAppDispatch()
  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }
  const [locData, setLocData] = useState<any>({})
  const [historyDetails, sethistoryDetails] = useState<any>([

  ])

  const [additionalDetails, setAdditionalDetails] = useState<IAAdditionalDetailsModel>({
    submissionResponse: "",
    applicationProcessedDate: "",
    registrationYear: "",
  })
  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }

  const [roleList] = useState<any>([
    "President",
    "Vice President",
    "Secretary",
    "Joint Secretary",
    "Treasurer",
    "Member",
  ])
  const [typelist] = useState<any>(["Individual", "Corporate"])
  const [relationtypelist] = useState<any>(["S/O", "D/O", "W/O", "H/O"])

  const [categorylist] = useState<any>([
    "Promotion of Art",
    "Fine Art",
    "Charity",
    "Crafts",
    "Religion",
    "Sports",
    "Literature",
    "Culture",
    "Science",
    "Political Education",
    "Philosophy",
    "Public Purpose",
  ])
  const [applicantDetails, setApplicantDetails] = useState<IApplicationDetailsModel>({
    maskedAadhar: "",
    aadharNumber: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    applicationNumber: "",
    name: "",
    relationType: "",
    relationName: "",
    role: "",
    gender: "",
    age: "",
    doorNo: "",
    street: "",
    country: "",
    state: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    email: "",
    mobileNumber: "",
  })



  const [societyDetails, setSocietyDetails] = useState<any>({
    societyName: "",
    category: "",
    generalBodyMeeting: "",
    registrationNumber: "",
    registrationYear: "",
    doorNo: "",
    street: "",
    state: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    aim: "",
    objective: "",
    mobileNumber: "",
    email: "",
    applicationProcessedDate: "",
    nameOfRegistrationDistrict: "",
    // memberDetails:[],
    // applicantDetails:{},

  })
  const [byelawDetails, setbyelawDetails] = useState<IByLawsDetailsModel | any>({
    maskedAadhar: "",
    societyName: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    relationType: "",
    doorNo: "",
    street: "",
    state: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    quorumSize: "",
    memberName: "",
    memberType: "",
    aadharNumber: "",
    relationName: "",
    joiningDate: "",
    qualification: "",
    occupation: "",
    role: "",
    mobileNumber: "",
    email: "",
    // phone: "",
    membershipConditions: "",
    finance: "",
    auditor: "",
    raisingFunds: "",
    officeBearers: "",
    liabilityConditions: "",
    meetingConditions: "",
    otherMatters: "",
  })
  const [auditorDetails, setauditorDetails] = useState<IByLawsDetailsModel | any>({
    auditorName: "",
    mobileNumber: "",
    email: "",
    doorNo: "",
    Street: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
  })


  const auditorDetailsChange = (e: any) => {
    let TempDetails: IByLawsDetailsModel = { ...auditorDetails }
    let AddName = e.target.name
    let AddValue = e.target.value
    if (AddName == "district") {
      setCurrentauditorMandal([])
      setCurrentauditorVillage([])
      GetMandalList(AddValue, "auditor")
    }
    if (AddName == "mandal") {
      setCurrentauditorVillage([])
      GetVillageList(AddValue, TempDetails.district, "auditor")
    }
    setauditorDetails({ ...TempDetails, [AddName]: AddValue })
  }
  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  const ageCalculator = (dateOfBirth: any) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    let month_diff = Date.now() - dob.getTime()
    let age_dt = new Date(month_diff)
    let year = age_dt.getUTCFullYear()
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }
  const additonalDetailsChange = (e: any) => {
    let tempDetails: IAAdditionalDetailsModel = { ...additionalDetails }
    let AddName = e.target.name
    let AddValue = e.target.value
    setAdditionalDetails({ ...tempDetails, [AddName]: AddValue })
  }
  useEffect(() => {
    const isResubmit = localStorage.getItem("isResubmission")
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLocData(data)
      if ((data.userType === "dept" && data.district !== undefined) || data.district !== "") {
        applicantDetailsChange({ target: { name: "district", value: data.district } })
        societyDetailsChange({ target: { name: "district", value: data.district } })
        auditorDetailsChange({ target: { name: "district", value: data.district } })
      }
    }
    if (isResubmit == "true") {
      setIsResubmission("true")
    } else {
      setIsResubmission("false")
    }
    let LoginData = KeepLoggedIn()
    if (LoginData) {
      setLoginDetails(LoginData)
      GetDistrictList(LoginData.token)
    }
    return () => {
      localStorage.removeItem("isResubmission")
    }
  }, [])


  const [indexmember, setindexmember] = useState<any>(-1)
  const [membersDetails, setMembersDetails] = useState<any>([
  ])
  const validateForm = () => {
    const errors: any = {}
    const byelawDet = { ...byelawDetails }
    const auditorDet = { ...auditorDetails }
    const societyDet = { ...societyDetails }
    const applicantDet = { ...applicantDetails }
    const memberDet = [{ ...membersDetails }]
    let nameRegex = /^[a-zA-Z ]{2,50}$/
    if (membersDetails.length <= 0) {
      return ShowMessagePopup(false, "Please add atleast 1 member to the society")
    }
    if (!societyDet.societyName) {
      ShowAlert(false, "Please Enter Society Name")
    }
    if (!societyDet.generalBodyMeeting) {
      ShowAlert(false, "Please Select General Body Meeting Date")
    }
    if (societyDetails?.applicationProcessedDate === "" ||
      societyDetails?.applicationProcessedDate === undefined) {
      ShowAlert(false, "Please Enter Registration Date")
    }
    if (!societyDet.villageOrCity) {
      ShowAlert(false, "Please Select Village Name")
    }
    if (!societyDet.mandal) {
      ShowAlert(false, "Please Select Mandal")
    }
    if (!societyDet.district) {
      ShowAlert(false, "Please Select District")
    }
    if (!societyDet.pinCode) {
      ShowAlert(false, "Please Enter Pincode")
    }
    if (!societyDet.street) {
      ShowAlert(false, "Please Enter Street")
    }
    if (!societyDet.doorNo) {
      ShowAlert(false, "Please Enter DoorNo")
    }
    if (
      additionalDetails?.submissionResponse === ""
    ) {
      console.log(additionalDetails, "additionalDetails")
      return ShowMessagePopup(false, "Please enter Application Submission Details to Proceed")
    }

    if (!societyDet.registrationNumber) {
      return ShowMessagePopup(false, "Please enter registration Number")
    }
    if (!byelawDetails.quorumSize) {
      return ShowMessagePopup(false, "Please enter Quorum Size")
    }
    if (!societyDet.registrationYear) {
      return ShowMessagePopup(false, "Please enter registration Year")
    }
    return true
  }

  const [file, setFile] = useState<any>([])
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [SelectedMemberDetails, setSelectedMemberDetails] =
    useState<any>({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })

  const handleMemberUpdate = (index: any) => {
    let object: any = { ...SelectedMemberDetails }
    if (
      object.aadharNumber == "" ||
      object.relationType == "" ||
      object.gender == "" ||
      object.memberType == "" ||
      object.age == "" ||
      object.doorNo == "" ||
      object.district == "" ||
      object.mandal == "" ||
      object.villageOrCity == "" ||
      object.pinCode == "" ||
      object.relationName == "" ||
      object.mobileNumber == "" ||
      object.joiningDate == "" ||
      object.role == "" ||
      object.qualification == "" ||
      object.occupation == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for Updated Member", "")
    } else if (object.soundMind !== "Yes") {
      return ShowMessagePopup(false, "Please select validate option for soundMind", "")
    } else if (object.inSolvent !== "No") {
      return ShowMessagePopup(false, "Please select validate option for insolvent", "")
    }
    else if (object.offense !== "No") {
      return ShowMessagePopup(false, "Please select validate option for offense", "")
    } else if (object.appointment !== "No") {
      return ShowMessagePopup(false, "Please select validate option for appointment", "")
    } else if (!object.memberType) {
      return ShowMessagePopup(false, "Please select member type", "")
    } else if (!object.mandal) {
      return ShowMessagePopup(false, "Please select mandal", "")
    } else if (!object.villageOrCity) {
      return ShowMessagePopup(false, "Please select village or city", "")
    }

    let Details: any[] = [...membersDetails]
    Details.splice(index, 1, object)
    setMembersDetails([...Details])
    console.log("index", index)
    setSelectedMemberDetails({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, " Member Updated Successfully", "")
    setindexmember(-1)
  }
  const handleMemberAdd = () => {
    // 
    let object: any = { ...SelectedMemberDetails }
    if (
      object.gender == "" ||
      object.age == "" ||
      object.district == "" ||
      object.memberName == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for Updated Member", "")
    }
    let Details: any[] = [...membersDetails]
    Details.push(object)
    setMembersDetails(Details)
    setSelectedMemberDetails({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, "New Member Added Successfully", "")
  }
  const ref = useRef(null)
  const refUpdate = useRef(null)
  const refDelete = useRef(null)
  const CallingAxios = async (myFunction: any) => {
    Loading(true)
    let result = await myFunction
    Loading(false)
    return result
  }
  const GetDistrictList = async (token: any) => {
    let result = await CallingAxios(useGetDistrictList(token))
    if (result.success) {
      setDistricts(result.data)
    }
  }

  const GetMandalList = async (district: string, saveto: string) => {
    let result = await CallingAxios(
      useGetMandalList({ districtName: district }, LoginDetails.token)
    )
    if (result.success) {
      switch (saveto) {
        case "applicant":
          setCurrentMandal(result.data)
          break
        case "members":
          setCurrentmemberMandal(result.data)
          break
        case "society":
          setCurrentsocietyMandal(result.data)
          break
        case "auditor":
          setCurrentauditorMandal(result.data)
          break

        default:
          break
      }
    }
  }

  const GetVillageList = async (mandal: string, district: string, saveto: string) => {
    let result = await CallingAxios(
      useGetVillagelList({ districtName: district, mandalName: mandal }, LoginDetails.token)
    )
    if (result.success) {
      switch (saveto) {
        case "applicant":
          setCurrentVillage(result.data)
          break
        case "members":
          setCurrentmemberVillage(result.data)
          break
        case "society":
          setCurrentsocietyVillage(result.data)
          break
        case "auditor":
          setCurrentauditorVillage(result.data)
          break
        default:
          break
      }
    }
  }
  const [displayOption, setDisplayOption] = useState("display")
  const applicantDetailsChange = (e: any) => {
    let TempDetails: IApplicationDetailsModel = { ...applicantDetails }
    let AddName = e.target.name
    let AddValue = e.target.value
    if (AddName == "district") {
      setCurrentMandal([])
      setCurrentVillage([])
      GetMandalList(AddValue, "applicant")
    }
    if (AddName == "mandal") {
      setCurrentVillage([])
      GetVillageList(AddValue, applicantDetails.district, "applicant")
    }
    console.log({ ...TempDetails, [AddName]: AddValue }, "changedFormData")
    setApplicantDetails({ ...TempDetails, [AddName]: AddValue })
  }
  const membersDetailsChange = (e: any) => {
    let tempDetails: any = { ...SelectedMemberDetails }
    let AddName = e.target.name
    let AddValue = e.target.value
    if (AddName == "district") {
      setCurrentmemberMandal([])
      setCurrentmemberVillage([])
      GetMandalList(AddValue, "members")
    }
    if (AddName == "mandal") {
      setCurrentmemberVillage([])
      GetVillageList(AddValue, tempDetails.district, "members")
    }
    setSelectedMemberDetails({ ...tempDetails, [AddName]: AddValue })
  }
  const societyDetailsChange = (e: any) => {
    let TempDetails: ISocitiesDetailsModel = { ...societyDetails }
    let AddName = e.target.name
    let AddValue = e.target.value
    if (AddName == "district") {
      setCurrentsocietyMandal([])
      setCurrentsocietyVillage([])
      GetMandalList(AddValue, "society")
    }
    if (AddName == "mandal") {
      setCurrentsocietyVillage([])
      GetVillageList(AddValue, TempDetails.district, "society")
    }
    setSocietyDetails({ ...TempDetails, [AddName]: AddValue })
  }

  const byelawsDetailsChange = (e: any) => {
    const data = (data: any) => ({ ...data, [e.target.name]: e.target.value })

    setbyelawDetails(data)
  }
  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if (fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])) {
      ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
      e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if (fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])) {
      if (!regex) {
        ShowMessagePopup(false, "Please upload proper file name");
        e.target.value = "";
      }
    }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  const handleMemberRemove = (index: number) => {
    let data: any = [...membersDetails]
    data.splice(index, 1)
    setMembersDetails(data)
  }
  const handleMemberEdit = (index: number) => {
    Loading(true)
    setTimeout(() => {
      setCurrentmemberMandal(membersDetails[index].mandal)
      setindexmember(index)

      setSelectedMemberDetails(membersDetails[index])

      console.log("membersDetails[index]", membersDetails[index])
      Loading(false)
    }, 800);

  }

  const handleSubmit = async (e: any) => {
    e.preventDefault()

    if (validateForm()) {

      const {
        idProofs,
        memorandum,
        byeLaws,
        affidavit,
        affidavitByAuditor,
        selfSignedDeclaration,
      } = file

      const idProofsDoc = idProofs

      const memorandumDoc = memorandum

      const affidavitByAuditorDoc = affidavitByAuditor

      const affidavitDoc = affidavit
      const byeLawsDoc = byeLaws
      const selfDoc = selfSignedDeclaration

      const data: any = {
        applicantDetails: applicantDetails,
        societyDetails: societyDetails,
        idProofs: idProofs,
        byelawDetails: byelawDetails,
        auditorDetails: auditorDetails,
        memorandum: memorandum,
        affidavitByAuditor: affidavitByAuditor,
        byeLaws: byeLaws,
        affidavit: affidavit,
        selfSignedDeclaration: selfSignedDeclaration,
        membersDetails: [...membersDetails.filter((x: any) => x.memberName.trim())],
      }
      const newData = new FormData()

      newData.append("registrationNumber", societyDetails.registrationNumber)
      newData.append("applicantDetails[aadharNumber]", data.applicantDetails.aadharNumber)
      newData.append("applicantDetails[name]", data.applicantDetails.name)
      newData.append("applicantDetails[relationType]", data.applicantDetails.relationType)
      newData.append("applicantDetails[age]", data.applicantDetails.age)
      newData.append("applicantDetails[role]", data.applicantDetails.role)
      newData.append("applicantDetails[relationName]", data.applicantDetails.relationName)
      newData.append("applicantDetails[gender]", data.applicantDetails.gender)
      newData.append("applicantDetails[doorNo]", data.applicantDetails.doorNo)
      newData.append("applicantDetails[street]", data.applicantDetails.street)
      newData.append("applicantDetails[country]", "India")
      newData.append("applicantDetails[state]", "Andhra Pradesh")
      newData.append("applicantDetails[district]", data.applicantDetails.district)
      newData.append("applicantDetails[mandal]", data.applicantDetails.mandal)
      newData.append("applicantDetails[villageOrCity]", data.applicantDetails.villageOrCity)
      newData.append("applicantDetails[pinCode]", data.applicantDetails.pinCode)
      newData.append("applicantDetails[mobileNumber]", data.applicantDetails.mobileNumber)
      newData.append("applicantDetails[email]", data.applicantDetails.email)
      newData.append("isRegistration", "Yes")
      newData.append("isnewData", "true")
      newData.append("auditorDetails[auditorName]", data.auditorDetails.auditorName)
      newData.append("auditorDetails[email]", data.auditorDetails.email)
      newData.append("auditorDetails[mobileNumber]", data.auditorDetails.mobileNumber)
      newData.append("auditorDetails[doorNo]", data.auditorDetails.doorNo)
      newData.append("auditorDetails[street]", data.auditorDetails.street)
      newData.append("auditorDetails[district]", data.auditorDetails.district)
      newData.append("auditorDetails[mandal]", data.auditorDetails.mandal)
      newData.append("auditorDetails[villageOrCity]", data.auditorDetails.villageOrCity)
      newData.append("auditorDetails[pinCode]", data.auditorDetails.pinCode)
      newData.append("societyName", societyDetails.societyName)
      newData.append("category", data.societyDetails.category)
      newData.append("generalBodyMeeting", data.societyDetails.generalBodyMeeting)
      newData.append("aim", data.societyDetails.aim)
      newData.append("objective", data.societyDetails.objective)
      newData.append("doorNo", data.societyDetails.doorNo)
      newData.append("street", data.societyDetails.street)
      newData.append("country", "India")
      newData.append("state", "Andhra Pradesh")
      newData.append("district", societyDetails.district)
      newData.append("mandal", data.societyDetails.mandal)
      newData.append("villageOrCity", data.societyDetails.villageOrCity)
      newData.append("pinCode", data.societyDetails.pinCode)
      newData.append(
        "status",
        additionalDetails?.submissionResponse === "Yes" ? "Approved" : "Rejected"
      )
      newData.append("applicationProcessedDate", societyDetails?.applicationProcessedDate)
      newData.append("registrationYear", societyDetails?.registrationYear)
      // console.log("registrationYear",societyDetails?.applicationProcessedDate.getFullYear())
      newData.append("mobileNumber", data.societyDetails.mobileNumber)
      newData.append("email", data.societyDetails.email)
      newData.append("byeLaws[societyName]", societyDetails.societyName)
      newData.append("byeLaws[quorumSize]", data.byelawDetails.quorumSize)
      newData.append("byeLaws[doorNo]", societyDetails.doorNo)
      newData.append("byeLaws[street]", societyDetails.street)
      newData.append("byeLaws[country]", "India")
      newData.append("byeLaws[state]", "Andhra Pradesh")
      newData.append("byeLaws[district]", societyDetails.district)
      newData.append("byeLaws[mandal]", societyDetails.mandal)
      newData.append("byeLaws[villageOrCity]", societyDetails.villageOrCity)
      newData.append("byeLaws[pinCode]", societyDetails.pinCode)
      newData.append("byeLaws[mobileNumber]", societyDetails.mobileNumber)
      newData.append("byeLaws[membershipConditions]", data.byelawDetails.membershipConditions)
      newData.append("byeLaws[finance]", data.byelawDetails.finance)
      newData.append("byeLaws[auditor]", "Yes")
      newData.append("byeLaws[email]", societyDetails.email)
      newData.append("byeLaws[raisingFunds]", data.byelawDetails.raisingFunds)
      newData.append("byeLaws[officeBearers]", data.byelawDetails.officeBearers)
      newData.append("byeLaws[liabilityConditions]", data.byelawDetails.liabilityConditions)
      newData.append("byeLaws[meetingConditions]", data.byelawDetails.meetingConditions)
      newData.append("byeLaws[otherMatters]", data.byelawDetails.otherMatters)
      newData.append("idProofs", idProofsDoc)
      newData.append("memorandum", memorandumDoc)
      newData.append("byeLaws", byeLawsDoc)
      newData.append("affidavitByAuditor", affidavitByAuditorDoc)
      newData.append("affidavit", affidavitDoc)
      newData.append("selfSignedDeclaration", selfDoc)
      for (let j = 0; j < data.membersDetails.length; j++) {
        if (data.membersDetails[j].joiningDate) {
          newData.append("memberDetails[" + j + "][email]", data.membersDetails[j].email ? data.membersDetails[j].email : "")
          newData.append(
            "memberDetails[" + j + "][mobileNumber]",
            data.membersDetails[j].mobileNumber
          )
          newData.append(
            "memberDetails[" + j + "][qualification]",
            data.membersDetails[j].qualification
          )
          newData.append(
            "memberDetails[" + j + "][joiningDate]",
            data.membersDetails[j].joiningDate
          )
          newData.append("memberDetails[" + j + "][memberType]", data.membersDetails[j].memberType)
          newData.append(
            "memberDetails[" + j + "][aadharNumber]",
            data.membersDetails[j].aadharNumber
          )
          newData.append("memberDetails[" + j + "][memberName]", data.membersDetails[j].memberName)
          newData.append(
            "memberDetails[" + j + "][relationName]",
            data.membersDetails[j].relationName
          )
          newData.append(
            "memberDetails[" + j + "][relationType]",
            data.membersDetails[j].relationType
          )
          newData.append("memberDetails[" + j + "][occupation]", data.membersDetails[j].occupation)
          newData.append("memberDetails[" + j + "][age]", data.membersDetails[j].age)
          newData.append("memberDetails[" + j + "][gender]", data.membersDetails[j].gender)
          newData.append("memberDetails[" + j + "][role]", data.membersDetails[j].role)
          newData.append("memberDetails[" + j + "][status]", "Active")
          newData.append("memberDetails[" + j + "][doorNo]", data.membersDetails[j].doorNo)
          newData.append("memberDetails[" + j + "][street]", data.membersDetails[j].street)
          newData.append("memberDetails[" + j + "][country]", "India")
          newData.append("memberDetails[" + j + "][state]", "Andhra Pradesh")
          newData.append("memberDetails[" + j + "][district]", data.membersDetails[j].district)
          newData.append("memberDetails[" + j + "][mandal]", data.membersDetails[j].mandal)
          newData.append("memberDetails[" + j + "][soundMind]", data.membersDetails[j].soundMind)
          newData.append("memberDetails[" + j + "][inSolvent]", data.membersDetails[j].inSolvent)
          newData.append("memberDetails[" + j + "][offense]", data.membersDetails[j].offense)
          newData.append("memberDetails[" + j + "][appointment]", data.membersDetails[j].appointment)
          newData.append(
            "memberDetails[" + j + "][villageOrCity]",
            data.membersDetails[j].villageOrCity
          )
          newData.append("memberDetails[" + j + "][pinCode]", data.membersDetails[j].pinCode)
        }
      }
      let Result = await CallingAxios(UseSaveDataEntrySocietyDetails(newData, token))
      if (Result.success) {
        ShowMessagePopup(true, "Society Saved SuccessFully", "/report")
      } else {
        console.log(Result)
        ShowMessagePopup(false, Result.message.message, "")
      }


    }
  }

  return (
    <>
      <Head>
        <title>E-Registration of Society</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      <div className={styles.RegistrationMain}>
        {locData && locData?.userType && locData?.userType != "user" && (
          <div className="societyRegSec">
            <Container>
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="d-flex align-items-center page-title mb-1">

                    <div className="pageTitleLeft">

                      <h1>E-Registration of Society</h1>
                    </div>

                  </div>
                </Col>
              </Row>

              <Form className={`formsec ${styles.RegistrationInput}`} autoComplete="off">
                <div className="regofAppBg mb-3">
                  <div className="formSectionTitle">
                    <h3>Applicant Details</h3>
                  </div>
                  <Row>
                    <Col lg={3} md={3} xs={12} >
                      <Form.Group>
                        <TableText
                          label="Enter Aadhaar Number"
                          required={false}
                          LeftSpace={false}
                        />
                        <div className="formGroup">
                          <TableInputText
                            type={"text"}
                            maxLength={12}
                            dot={false}
                            placeholder="Enter Aadhaar Number"
                            required={false}
                            name={"aadharNumber"}
                            value={applicantDetails.aadharNumber}
                            onChange={(e: any) => {
                              applicantDetailsChange(e)
                            }}
                            onKeyPress={true}
                            onPaste={(e: any) => e.preventDefault()}
                          />

                        </div>
                      </Form.Group>

                    </Col>
                    <Col lg={3} md={12} sm={12}>
                      <TableText label="Name of the Applicant" required={false} LeftSpace={false} />
                      <TableInputText
                        type="text"
                        placeholder="Enter Applicant Name"
                        required={false}
                        name="name"
                        value={applicantDetails.name}
                        onChange={(e: any) => {
                          applicantDetailsChange(e)
                        }}
                      />

                    </Col>


                    <Col lg={3} md={3} xs={12} className="mb-3">
                      <TableText label="Gender" required={false} LeftSpace={false} />
                      <TableDropdownSRO
                        keyName={"label"}
                        required={false}
                        options={[
                          { label: "Male", value: "Male" },
                          { label: "Female", value: "Female" },
                          { label: "Others", value: "Others" },
                        ]}
                        name={"gender"}
                        value={applicantDetails.gender}
                        onChange={applicantDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={12} sm={12}>
                      <TableText label="Age" required={false} LeftSpace={false} />
                      <TableInputText
                        type="number"
                        placeholder="Enter age"
                        required={false}
                        name="age"
                        value={applicantDetails.age}
                        onChange={(e: any) => {
                          applicantDetailsChange(e)
                        }}
                      />
                    </Col>
                    <Col lg={3} md={12} sm={12}>
                      <TableText label="Relation Name" required={false} LeftSpace={false} />
                      <Form.Group className="inline">
                        <div className="inline formGroup">
                          <Form.Select name="relationType" onChange={applicantDetailsChange} required value={applicantDetails.relationType}>
                            <option>Select</option>
                            {relationtypelist.map((item: any, i: number) => {
                              return (
                                <option key={i + 1} value={item}>
                                  {item}
                                </option>
                              )
                            })}

                          </Form.Select>
                          <input
                            className="form-control"
                            type="text"
                            name="relationName"
                            onChange={(e: any) => {
                              applicantDetailsChange(e)
                            }}
                            required={false}
                            value={applicantDetails.relationName}
                          />
                        </div>
                      </Form.Group>
                    </Col>
                    <Col lg={3} md={12} sm={12}>
                      <TableText label={"Role"} required={false} LeftSpace={false} />

                      <TableInputText
                        type="text"
                        placeholder="Enter Role"
                        required={false}
                        disabled={false}
                        name="role"
                        value={applicantDetails.role}
                        onChange={applicantDetailsChange}
                      />
                    </Col>
                  </Row>
                  <div className="formSectionTitle">
                    <h3>Address</h3>
                  </div>

                  <Row>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Door No" required={false} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Door No"
                        required={false}
                        name="doorNo"
                        maxLength={50}
                        value={applicantDetails.doorNo}
                        onChange={applicantDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Street" required={false} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Street"
                        required={false}
                        name="street"
                        value={applicantDetails.street}
                        maxLength={50}
                        onChange={applicantDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="District" required={false} LeftSpace={false} />
                      <TableDropdownSRO
                        keyName={"name"}
                        required={false}
                        options={districtList}
                        name={"district"}
                        value={applicantDetails.district}
                        onChange={applicantDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Mandal" required={false} LeftSpace={false} />
                      <TableDropdownSRO
                        keyName={"mandalName"}
                        required={false}
                        options={currentMandal}
                        name={"mandal"}
                        value={applicantDetails.mandal}
                        onChange={applicantDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Village/City" required={false} LeftSpace={false} />
                      <TableDropdownSRO
                        keyName="villageName"
                        required={false}
                        options={currentVillage}
                        name={"villageOrCity"}
                        value={applicantDetails.villageOrCity}
                        onChange={applicantDetailsChange}
                      />
                    </Col>


                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="PIN Code" required={false} LeftSpace={false} />
                      <Form.Control
                        disabled={false}
                        type="text"
                        maxLength={6}
                        placeholder="Enter PIN Code"
                        required={false}
                        name="pinCode"
                        value={applicantDetails.pinCode}
                        onChange={applicantDetailsChange}
                        onKeyPress={onNumberOnlyChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Mobile No" required={false} LeftSpace={false} />
                      <Form.Control
                        type="text"
                        placeholder="Enter Mobile No"
                        required={false}
                        name={"mobileNumber"}
                        autoComplete="off"
                        value={applicantDetails.mobileNumber}
                        onChange={applicantDetailsChange}
                        onKeyPress={onNumberOnlyChange}
                        maxLength={10}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Email Address" required={false} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="email"
                        placeholder="Enter Email Address"
                        required={false}
                        name={"email"}
                        maxLength={40}
                        minLength={15}
                        value={applicantDetails.email}
                        onChange={applicantDetailsChange}
                      />
                    </Col>
                  </Row>



                </div>

                <div className="regofAppBg mb-3">
                  <div className="formSectionTitle">
                    <h3>Society Details</h3>
                  </div>

                  <Row>

                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText
                        label="Society Name"
                        required={true}
                        LeftSpace={false}
                      />
                        <div className="formGroup">
                              <input
                                className="form-control"
                                type="text"
                                maxLength={50}
                                required={true}
                                placeholder="Society Name"
                                name="societyName"
                                value={societyDetails.societyName}
                                onChange={societyDetailsChange}
                              />
                            </div>
                      {/* <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Society Name"
                        required={true}
                        name="societyName"
                        value={societyDetails.societyName}
                        onChange={societyDetailsChange}
                      /> */}
                    </Col>
                  
                    {/* <Col lg={3} md={12} sm={12}>
                      <TableText label="Application Number" required={true} LeftSpace={false} />
                      <TableInputText
                        type="number"
                        placeholder="Enter application Number"
                        required={true}
                        name="applicationNumber"
                        value={applicantDetails.applicationNumber}
                        onChange={(e: any) => {
                          applicantDetailsChange(e)
                        }}
                      />
                    </Col> */}
                    <Col lg={3} md={12} sm={12}>
                      <TableText label="society Register No" required={true} LeftSpace={false} />
                      <TableInputText
                        type="number"
                        placeholder="Enter society Register No"
                        required={true}
                        name="registrationNumber"
                        value={societyDetails.registrationNumber}
                        onChange={(e: any) => {
                          societyDetailsChange(e)
                        }}
                      />
                    </Col>
                    <Col lg={3} md={3} xs={3}>
                      <TableText label="Registration Year" required={true} LeftSpace={false} />
                      <TableInputText
                        type="number"
                        maxLength={4}
                        placeholder="Enter Registration Year"
                        required={true}
                        dot={false}
                        name={"registrationYear"}
                        value={societyDetails.registrationYear}
                        onChange={societyDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText label="Society Category" required={false} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="category"
                        required={false}
                        onChange={societyDetailsChange}
                        value={societyDetails.category}
                      >
                        <option>Select</option>
                        {categorylist.map((item: any, i: number) => {
                          return (
                            <option key={i + 1} value={item}>
                              {item}
                            </option>
                          )
                        })}
                      </select>
                    </Col>
                    <Col lg={3} md={3} xs={3}>
                      <TableText label="Date Of Registration" required={true} LeftSpace={false} />
                      <Form.Control
                        type="date"
                        required={true}
                        placeholder="DD/MM/YYYY"
                        name="applicationProcessedDate"
                        value={societyDetails.applicationProcessedDate}
                        onChange={societyDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText
                        label="Date of Annual General Body Meeting"
                        required={true}
                        LeftSpace={false}
                      />
                      <TableInputText
                        disabled={false}
                        type="date"
                        placeholder="Enter General Body Meeting"
                        required={true}
                        name="generalBodyMeeting"
                        value={societyDetails.generalBodyMeeting}
                        onChange={societyDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText label="Mobile No" required={false} LeftSpace={false} />
                      <Form.Control
                        type="text"
                        placeholder="Enter Mobile No"
                        required={false}
                        name="mobileNumber"
                        autoComplete="off"
                        value={societyDetails.mobileNumber}
                        onChange={societyDetailsChange}
                        onKeyPress={onNumberOnlyChange}
                        maxLength={10}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText label="Email Address" required={false} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="email"
                        placeholder="Enter Email Address"
                        required={false}
                        name="email"
                        maxLength={40}
                        minLength={15}
                        value={societyDetails.email}
                        onChange={societyDetailsChange}
                      />
                    </Col>
                  </Row>
                  <div className="formSectionTitle">
                    <h3>Address of the Society</h3>
                  </div>
                  <Row>
                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText label="Door No" required={true} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Door No"
                        required={true}
                        name="doorNo"
                        value={societyDetails.doorNo}
                        onChange={societyDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText label="Street" required={true} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Street"
                        required={true}
                        name="street"
                        value={societyDetails.street}
                        onChange={societyDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText label="State" required={false} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="state"
                        onChange={() => { }}
                        value={societyDetails.state}
                        disabled={true}
                      >
                        <option>Andhra Pradesh</option>
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="District" required={true} LeftSpace={false} />
                      <TableDropdownSRO
                        keyName={"name"}
                        required={true}
                        options={districtList}
                        name={"district"}
                        value={societyDetails.district}
                        onChange={societyDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Mandal" required={true} LeftSpace={false} />
                      <TableDropdownSRO
                        keyName={"mandalName"}
                        required={true}
                        options={currentsocietyMandal}
                        name={"mandal"}
                        value={societyDetails.mandal}
                        onChange={societyDetailsChange}
                      />
                    </Col>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Village/City" required={true} LeftSpace={false} />
                      <TableDropdownSRO
                        keyName="villageName"
                        required={true}
                        options={currentsocietyVillage}
                        name={"villageOrCity"}
                        value={societyDetails.villageOrCity}
                        onChange={societyDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-1">
                      <TableText label="PIN Code" required={true} LeftSpace={false} />
                      <Form.Control
                        disabled={false}
                        type="text"
                        maxLength={6}
                        placeholder="Enter PIN Code"
                        required={true}
                        name="pinCode"
                        value={societyDetails.pinCode}
                        onChange={societyDetailsChange}
                        onKeyPress={onNumberOnlyChange}
                      />
                    </Col>


                  </Row>
                  <Row>
                    <Col lg={6} md={4} xs={12} className="mb-1">
                      <TableText label="Aim of the Society" required={false} LeftSpace={false} />
                      <textarea
                        className="form-control textarea"
                        name="aim"
                        maxLength={10000}
                        value={societyDetails.aim}
                        onChange={societyDetailsChange}
                        required
                      ></textarea>
                    </Col>
                    <Col lg={6} md={4} xs={12} className="mb-1">
                      <TableText
                        label="Objective of the Society"
                        required={true}
                        LeftSpace={false}
                      />
                      <textarea
                        className="form-control textarea"
                        name="objective"
                        value={societyDetails.objective}
                        onChange={societyDetailsChange}
                        maxLength={10000}
                        required
                      ></textarea>
                    </Col>
                  </Row>

                </div>
                <div className="regofAppBg mb-3 dahboardProcedureSec">
                  <div className="formSectionTitle">
                    <h3>EC Member Details</h3>
                  </div>
                  <>
                    <div className="regofAppBg mb-3">
                      <div className="societyMemberDetailsList">
                        <Row className="membersDetailsList">
                          <div className="societyMemberDetailsList">

                            <Row className="membersDetailsList d-flex align-items-center"></Row>
                            <Row className="membersDetailsList">
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <Form.Group>
                                  <TableText
                                    label="Member Type"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="memberType"
                                    required={false}
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.memberType}
                                  >
                                    <option>Select</option>
                                    {typelist.map((item: any, i: number) => {
                                      return (
                                        <option key={i + 1} value={item}>
                                          {item}
                                        </option>
                                      )
                                    })}
                                  </select>
                                </Form.Group>
                              </Col>

                              <Col lg={3} md={3} xs={12} className="mb-3">

                                <Form.Group>
                                  <TableText
                                    label="Enter Aadhaar Number"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="formGroup">
                                    <TableInputText
                                      type="text"
                                      maxLength={12}
                                      placeholder="Enter Aadhaar Number"
                                      required={false}
                                      dot={false}
                                      name={"aadharNumber"}
                                      value={SelectedMemberDetails.aadharNumber}
                                      onChange={(e: any) => {
                                        membersDetailsChange(e)
                                      }}
                                      onKeyPress={true}
                                      onPaste={(e: any) => e.preventDefault()}
                                    />

                                  </div>
                                </Form.Group>

                              </Col>

                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <Form.Group>
                                  <TableText
                                    label="Name of the Member"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    name="memberName"
                                    required={false}
                                    placeholder="Enter Name of the Member"
                                    onChange={(e: any) => {
                                      membersDetailsChange(e)
                                    }}
                                    value={SelectedMemberDetails.memberName}
                                    type={"text"}
                                  />


                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText label="Gender" required={true} LeftSpace={false} />
                                <TableDropdownSRO
                                  keyName={"label"}
                                  required={false}
                                  options={[
                                    { label: "Male", value: "Male" },
                                    { label: "Female", value: "Female" },
                                    { label: "Others", value: "Others" },
                                  ]}
                                  name={"gender"}
                                  value={SelectedMemberDetails.gender}
                                  onChange={(e: any) => {
                                    membersDetailsChange(e)
                                  }}
                                />
                              </Col>


                              <Col lg={3} md={12} sm={12}>
                                <TableText label="Age" required={true} LeftSpace={false} />
                                <TableInputText
                                  type="number"
                                  placeholder="Enter age"
                                  required={false}
                                  name="age"
                                  value={SelectedMemberDetails.age}
                                  onChange={(e: any) => {
                                    membersDetailsChange(e)
                                  }}
                                />

                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <Form.Group className="inline">
                                  <TableText
                                    label="Relation Name"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="inline formGroup">
                                    <Form.Select
                                      name="relationType"
                                      onChange={(event) => membersDetailsChange(event)}
                                      disabled={false}
                                      required={false}
                                      value={SelectedMemberDetails.relationType}
                                    >
                                      <option>Select</option>
                                      {relationtypelist.map((item: any, i: number) => {
                                        return (
                                          <option key={i + 1} value={item}>
                                            {item}
                                          </option>
                                        )
                                      })}
                                    </Form.Select>
                                    <input

                                      className="form-control"
                                      type="text"
                                      name="relationName"
                                      onChange={(e: any) => {
                                        membersDetailsChange(e)
                                      }}
                                      value={SelectedMemberDetails.relationName}
                                      required={false}
                                    />
                                  </div>
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={2} xs={12} className="mb-3">
                                <Form.Group>
                                  <TableText
                                    label="Role/Position"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <select style={{ textTransform: 'uppercase' }}
                                    className="form-control"
                                    name="role"
                                    required={false}
                                    onChange={(event) =>
                                      membersDetailsChange(event)
                                    }
                                    value={SelectedMemberDetails.role}
                                  >
                                    <option>Select</option>
                                    {roleList.map((item: any) => {
                                      return <option value={item}>{item}</option>
                                    })}
                                  </select>
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <Form.Group>
                                  <TableText
                                    label="Occupation"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    required={false}
                                    type="text"
                                    name="occupation"
                                    placeholder="Enter Occupation"
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.occupation}
                                  />
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <Form.Group>
                                  <TableText
                                    label="Qualification"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    type="text"
                                    required={false}
                                    name="qualification"
                                    placeholder="Enter Qualification"
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.qualification}
                                  />
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <Form.Group>
                                  <TableText
                                    label="Date of Joining as a Member"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <input
                                    required={false}
                                    type="date"
                                    className="form-control"
                                    name="joiningDate"
                                    placeholder="DD/MM/YYYY"
                                    onChange={(event) => membersDetailsChange(event)}
                                    value={SelectedMemberDetails.joiningDate}
                                  />
                                </Form.Group>
                              </Col>
                              <div className="formSectionTitle">
                                <h3>Address</h3>
                              </div>

                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText label="Door No" required={false} LeftSpace={false} />
                                <TableInputText
                                  disabled={false}
                                  type="text"
                                  placeholder="Enter Door No"
                                  required={false}
                                  name="doorNo"
                                  onChange={(event: any) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.doorNo}
                                />
                              </Col>

                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText
                                  label="Street Name"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <TableInputText
                                  disabled={false}
                                  type="text"
                                  placeholder="Enter Street Name"
                                  required={false}
                                  name="street"
                                  onChange={(event: any) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.street}
                                />
                              </Col>


                              <Col lg={3} md={4} xs={12} className="mb-3">
                                <TableText label="District" required={true} LeftSpace={false} />
                                <TableDropdownSRO
                                  keyName={"name"}
                                  required={false}
                                  options={districtList}
                                  name={"district"}
                                  value={SelectedMemberDetails.district}
                                  onChange={membersDetailsChange}
                                />
                              </Col>
                              <Col lg={3} md={4} xs={12} className="mb-3">
                                <TableText label="Mandal" required={false} LeftSpace={false} />
                                <TableDropdownSRO
                                  keyName={"mandalName"}
                                  required={false}
                                  options={currentmemberMandal}
                                  name={"mandal"}
                                  value={SelectedMemberDetails.mandal}
                                  onChange={membersDetailsChange}
                                />
                              </Col>
                              <Col lg={3} md={4} xs={12} className="mb-3">
                                <TableText label="Village/City" required={false} LeftSpace={false} />
                                <TableDropdownSRO
                                  keyName="villageName"
                                  required={false}
                                  options={currentmemberVillage}
                                  name={"villageOrCity"}
                                  value={SelectedMemberDetails.villageOrCity}
                                  onChange={membersDetailsChange}
                                />
                              </Col>

                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText label="PIN Code" required={false} LeftSpace={false} />
                                <Form.Control
                                  disabled={false}
                                  type="text"
                                  maxLength={6}
                                  placeholder="Enter PIN Code"
                                  required={false}
                                  name={"pinCode"}
                                  onChange={(event) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.pinCode}
                                  onKeyPress={onNumberOnlyChange}
                                />
                              </Col>

                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText
                                  label="Email"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <Form.Control
                                  disabled={false}
                                  type="email"
                                  autoComplete="off"
                                  placeholder="Enter Email Id"
                                  required={false}
                                  name={"email"}
                                  onChange={(event) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.email}
                                />
                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText
                                  label="Mobile Number"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <Form.Control
                                  disabled={false}
                                  type="text"
                                  autoComplete="off"
                                  maxLength={10}
                                  placeholder="Enter Mobile Number"
                                  required={false}
                                  name={"mobileNumber"}
                                  onChange={(event) => membersDetailsChange(event)}
                                  value={SelectedMemberDetails.mobileNumber}
                                  onKeyPress={onNumberOnlyChange}
                                />
                              </Col>

                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is of sound mind?"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="soundMind"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="Yes"
                                      checked={SelectedMemberDetails.soundMind === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="soundMind"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="No"
                                      checked={SelectedMemberDetails.soundMind === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is declared to be insolvent or an undischarged insolvent?"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="inSolvent"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="Yes"
                                      checked={SelectedMemberDetails.inSolvent === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="inSolvent"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="No"
                                      checked={SelectedMemberDetails.inSolvent === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is convicted of an offense of moral turpitude? "
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="offense"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="Yes"
                                      checked={SelectedMemberDetails.offense === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="offense"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="No"
                                      checked={SelectedMemberDetails.offense === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col>
                                <div className="mb-3 d-flex">
                                  <TableText
                                    label="Whether the member is disqualified for such an appointment by an order of a court?"
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <div className="firmChangeList px-4">
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="appointment"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="Yes"
                                      checked={SelectedMemberDetails.appointment === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      disabled={false}
                                      type="radio"
                                      required={false}
                                      name="appointment"
                                      onChange={(event) => membersDetailsChange(event)}
                                      defaultValue="No"
                                      checked={SelectedMemberDetails.appointment === "No"}
                                    />
                                  </div>
                                </div>
                              </Col>
                            </Row>
                          </div>
                        </Row>
                      </div>
                    </div>{" "}

                  </>

                  <Row>
                    <Col lg={12} md={12} xs={12} className="">
                      <div className="addotherBtnInfo text-center mb-3">
                        {indexmember == -1 && (
                          <div onClick={handleMemberAdd} className="btn btn-primary addPartner">
                            Add Member
                          </div>
                        )}
                        {/* {indexmember != -1 && (
                          <div
                            onClick={(index: any) => {
                              handleMemberUpdate(indexmember)
                            }}
                            className="btn btn-primary addPartner mb-3"
                          >
                            Update Member
                          </div>
                        )} */}
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <div className="dashboardRegSec">
                      <Row>
                        {membersDetails && membersDetails?.length > 0 ? (
                          <div ref={refUpdate} className="addedPartnerSec mt-3">
                            <Row className="mb-4">
                              <Col lg={12} md={12} xs={12}>
                                <Table striped bordered className="tableData listData ">
                                  <thead>
                                    <tr>
                                      <th>Type</th>
                                      <th>Aadhaar No</th>
                                      <th>Name of the member</th>
                                      <th>Relation Name</th>
                                      <th>Age/Gender</th>
                                      <th>Role/Position</th>
                                      <th>Occupation</th>
                                      <th>Date of Joining</th>
                                      <th>Address</th>
                                      <th>Contact</th>
                                      <th>Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {membersDetails.map((item: any, i: number) => {
                                      return (
                                        <tr>
                                          <td className="text-center">
                                            {item.memberType}
                                          </td>
                                          <td className="text-center">
                                            {item.aadharNumber}
                                          </td>
                                          <td className="text-center">{item.memberName}</td>
                                          <td className="text-center">{item.relationName}</td>
                                          <td className="text-center">{item.age} / {item.gender}</td>
                                          <td className="text-center">{item.role}</td>
                                          <td className="text-center">{item.occupation}</td>
                                          <td className="text-center">{item.joiningDate}</td>
                                          <td className="text-center">
                                            {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                                          </td>
                                          <td className="text-center"
                                          >
                                            {item.mobileNumber}
                                          </td>
                                          <td>
                                            {" "}
                                            {/* <Image
                                              alt="Image"
                                              height={15}
                                              width={15}
                                              src="/assets/edit.svg"
                                              style={{ cursor: "pointer" }}
                                              onClick={() => {
                                                handleMemberEdit(i)
                                              }}
                                            /> */}
                                            <Image
                                              alt="Image"
                                              height={20}
                                              width={20}
                                              src="/assets/delete-icon.svg"
                                              style={{ cursor: "pointer" }}
                                              onClick={() => {
                                                handleMemberRemove(i)
                                              }}
                                            />
                                          </td>
                                        </tr>
                                      )
                                    })}
                                  </tbody>
                                </Table>
                              </Col>
                            </Row>
                          </div>
                        ) : null}
                      </Row>
                    </div>
                  </Row>

                </div>

                <div className="regofAppBg mb-3">
                  <div className="formSectionTitle">
                    <h3>ByeLaw Details</h3>
                  </div>
                  <Row>
                    <Col lg={9} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Do the Bye-Laws contain the membership conditions (Eligibility, Admission, Withdrawal, Termination)"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">
                        <Form.Check
                          inline
                          label="Yes"
                          defaultValue="Yes"
                          name="membershipConditions"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawsDetailsChange}
                          checked={byelawDetails.membershipConditions === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          defaultValue="No"
                          name="membershipConditions"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawsDetailsChange}
                          checked={byelawDetails.membershipConditions === "No"}
                        />
                      </div>
                    </Col>
                  </Row>
                  <div className="formSectionTitle">
                    <h3>Executive Body</h3>
                  </div>
                  <Row>
                    <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Executive Committee Body meeting conditions (Quorum, Conditions, Responsibilities)"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">
                        <Form.Check
                          inline
                          label="Yes"
                          defaultValue="Yes"
                          name="meetingConditions"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawsDetailsChange}
                          checked={byelawDetails.meetingConditions === "Yes"}
                        />
                        <Form.Check
                          inline
                          checked={byelawDetails.meetingConditions === "No"}
                          label="No"
                          defaultValue="No"
                          name="meetingConditions"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawsDetailsChange}
                        />
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText
                        label=" Size of the Quorum"
                        required={true}
                        LeftSpace={false}
                      />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Quorum Size"
                        required={true}
                        name="quorumSize"
                        value={byelawDetails.quorumSize}
                        onChange={byelawsDetailsChange}
                      />
                    </Col>
                  </Row>


                  <Row>
                    <Col lg={10} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Whether the bye-laws contain the conditions of Office Bearers (Appointment, Election, Removal, Recall, Responsibilites)"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">
                        <Form.Check
                          inline
                          label="Yes"
                          defaultValue="Yes"
                          required={false}
                          name="officeBearers"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawsDetailsChange}
                          checked={byelawDetails.officeBearers === "Yes"}
                        />

                        <Form.Check
                          inline
                          checked={byelawDetails.officeBearers === "No"}
                          label="No"
                          defaultValue="No"
                          name="officeBearers"
                          required={false}
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawsDetailsChange}
                        />
                      </div>
                    </Col>
                  </Row>

                  <Row>
                    <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Whether the bye-laws contain the details of finance ?"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">
                        <Form.Check
                          inline
                          label="Yes"
                          required={false}
                          name="finance"
                          type="radio"
                          className="fom-checkbox"
                          onChange={(event: any) => byelawsDetailsChange(event)}
                          defaultValue="Yes"
                          checked={byelawDetails.finance === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          defaultValue="No"
                          name="finance"
                          required={false}
                          type="radio"
                          className="fom-checkbox"
                          onChange={(event: any) => byelawsDetailsChange(event)}
                          checked={byelawDetails.finance === "No"}
                        />
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Whether the bye-laws contain the details of the auditor ?"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="auditor"
                          type="radio"
                          className="fom-checkbox"
                          checked={displayOption === "display"}
                          onChange={() => setDisplayOption("display")}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="auditor"
                          type="radio"
                          className="fom-checkbox"
                          checked={displayOption === "not-display"}
                          onChange={() => setDisplayOption("not-display")}
                        />
                      </div>
                    </Col>
                  </Row>
                  {displayOption === "display" && (
                    <div>
                      <Row className="mb-3">
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <TableText
                            label="Name of the Auditor"
                            LeftSpace={false}
                            required={false}
                          />
                          <TableInputText
                            type={"text"}
                            placeholder={"Enter Name of the Auditor"}
                            required={false}
                            value={auditorDetails.auditorName}
                            onChange={auditorDetailsChange}
                            name="auditorName"
                          ></TableInputText>
                        </Col>
                        <Col lg={3} md={12} sm={12} className="mb-3">
                          <TableText label={"Mobile No"} required={false} LeftSpace={false} />
                          <TableInputText
                            type="text"
                            placeholder="Enter Mobile No"
                            maxLength={10}
                            required={false}
                            name="mobileNumber"
                            value={auditorDetails.mobileNumber}
                            onChange={auditorDetailsChange}
                          />
                          {errors.mobileNumber && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.mobileNumber}
                            </span>
                          )}
                        </Col>
                        <Col lg={3} md={12} sm={12} className="mb-3">
                          <TableText
                            label={"Email Address"}
                            required={false}
                            LeftSpace={false}
                          />
                          <TableInputText
                            type="text"
                            placeholder="Enter Email Address"
                            required={false}
                            name="email"
                            maxLength={40}
                            minLength={15}
                            value={auditorDetails.email}
                            onChange={auditorDetailsChange}
                          />
                          {errors.email && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.email}
                            </span>
                          )}
                        </Col>{" "}
                      </Row>
                      <div className="formSectionTitle">
                        <h3>Address</h3>
                      </div>
                      <Row>
                        <Col lg={3} md={12} sm={12} className="mb-3">
                          {" "}
                          <TableText label={"Door No"} required={false} LeftSpace={false} />
                          <TableInputText
                            type="text"
                            placeholder="Enter Door No"
                            required={false}
                            name="doorNo"
                            value={auditorDetails.doorNo}
                            onChange={auditorDetailsChange}
                          />
                          {errors.doorNo && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.doorNo}
                            </span>
                          )}
                        </Col>
                        <Col lg={3} md={12} sm={12} className="mb-3">
                          <TableText label={"Street"} required={false} LeftSpace={false} />
                          <TableInputText
                            type="text"
                            placeholder="Street"
                            required={false}
                            name="street"
                            value={auditorDetails.street}
                            onChange={auditorDetailsChange}
                          />
                          {errors.Street && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.Street}
                            </span>
                          )}
                        </Col>
                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="District" required={false} LeftSpace={false} />
                          <TableDropdownSRO
                            keyName={"name"}
                            required={false}
                            options={districtList}
                            name={"district"}
                            value={auditorDetails.district}
                            onChange={auditorDetailsChange}
                          />
                        </Col>
                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Mandal" required={false} LeftSpace={false} />
                          <TableDropdownSRO
                            keyName={"mandalName"}
                            required={false}
                            options={currentauditorMandal}
                            name={"mandal"}
                            value={auditorDetails.mandal}
                            onChange={auditorDetailsChange}
                          />
                        </Col>
                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Village/City" required={false} LeftSpace={false} />
                          <TableDropdownSRO
                            keyName="villageName"
                            required={false}
                            options={currentauditorVillage}
                            name={"villageOrCity"}
                            value={auditorDetails.villageOrCity}
                            onChange={auditorDetailsChange}
                          />
                        </Col>
                        <Col lg={3} md={12} sm={12} className="mb-3">
                          {" "}
                          <TableText label={"Pin Code"} required={false} LeftSpace={false} />
                          <TableInputText
                            type="text"
                            placeholder="Enter Pin Code"
                            required={false}
                            name="pinCode"
                            maxLength={6}
                            value={auditorDetails.pinCode}
                            onChange={auditorDetailsChange}
                          />
                          {errors.pinCode && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.pinCode}
                            </span>
                          )}
                        </Col>
                      </Row>
                    </div>
                  )}
                  {displayOption === "not-display" && <div></div>}
                  <Row>
                    <Col lg={8} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Whether the bye-laws contain the conditions for raising of the funds?"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">

                        <Form.Check
                          inline
                          label="Yes"
                          defaultValue="Yes"
                          name="raisingFunds"
                          type="radio"
                          required={false}
                          className="fom-checkbox"
                          onChange={(event: any) => byelawsDetailsChange(event)}
                          checked={byelawDetails.raisingFunds === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          defaultValue="No"
                          required={false}
                          name="raisingFunds"
                          type="radio"
                          className="fom-checkbox"
                          onChange={(event: any) => byelawsDetailsChange(event)}
                          checked={byelawDetails.raisingFunds === "No"}
                        />
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={10} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Whether the bye-laws contain the conditions for liabilities of EC members in financial matters and exchange of debts ?"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">
                        <Form.Check
                          inline
                          label="Yes"
                          defaultValue="Yes"
                          required={false}
                          name="liabilityConditions"
                          type="radio"
                          className="fom-checkbox"
                          onChange={(event: any) => byelawsDetailsChange(event)}
                          checked={byelawDetails.liabilityConditions === "Yes" ? true : false}
                        />
                        {/* {console.log("data",byelawDetails)} */}
                        <Form.Check
                          inline
                          label="No"
                          defaultValue="No"
                          name="liabilityConditions"
                          type="radio"
                          required={false}
                          className="fom-checkbox"
                          onChange={(event: any) => byelawsDetailsChange(event)}
                          checked={byelawDetails.liabilityConditions === "No" ? true : false}
                        />
                      </div>
                    </Col>
                  </Row>
                  <Row>
                    {/* <pre>{JSON.stringify(byelawDetails,2,null)}</pre> */}
                    <Col lg={9} md={3} xs={12} style={{ display: "flex" }}>
                      <TableText
                        label="Whether the bye-laws contain the other matters like settlement of internal disputes or dissolution of society ?"
                        required={false}
                        LeftSpace={false}
                      />
                      <div className="firmChangeList px-4">
                        <Form.Check
                          inline
                          label="Yes"
                          disabled={false}
                          type="radio"
                          required={false}
                          name="otherMatters"
                          onChange={(event) => byelawsDetailsChange(event)}
                          defaultValue="Yes"
                          checked={byelawDetails.otherMatters === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          disabled={false}
                          type="radio"
                          required={false}
                          name="otherMatters"
                          onChange={(event) => byelawsDetailsChange(event)}
                          defaultValue="No"
                          checked={byelawDetails.otherMatters === "No"}
                        />
                      </div>
                    </Col>
                  </Row>
                </div>

                <div className="uploadFirmList appDocList mb-4">

                  <Row>
                    <Col lg={12} md={12} xs={12}>
                      <h3>
                        Upload Society Related Documents-(All Uploaded Documents should be in
                        PDF format only upto 6MB )
                      </h3>
                    </Col>
                  </Row>
                  <div className=" firmFileStep1">
                    <Row>
                      <Col lg={3} md={12} sm={12} className="my-2">

                        <TableText
                          label={"Memorandum of Association"}
                          required={false}
                          LeftSpace={false}
                        />
                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            required={false}
                            name="memorandum"
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                      <Col lg={3} md={12} sm={12} className="my-2">
                        <TableText label={"Bye - Laws "} required={false} LeftSpace={false} />
                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="byeLaws"
                            ref={inputRef}
                            onChange={handleFileChange}
                            required={false}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                      <Col lg={3} md={12} sm={12} className="my-2">
                        <TableText
                          label={"ID Proofs of EC Members "}
                          required={false}
                          LeftSpace={false}
                        />
                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="idProofs"
                            ref={inputRef}
                            required={false}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                      <Col lg={3} md={12} sm={12} className="my-2">
                        <TableText
                          label={"Self Signed Declaration of EC Members "}
                          required={false}
                          LeftSpace={false}
                        />
                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="selfSignedDeclaration"
                            ref={inputRef}
                            required={false}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                      <Col lg={3} md={12} sm={12} className="my-2">
                        <TableText
                          label={"Affidavit  /  Lease Agreement "}
                          required={false}
                          LeftSpace={false}
                        />
                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="affidavit"
                            required={false}
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                      <Col lg={3} md={12} sm={12} className="my-2">
                        <TableText
                          label={"Affidavit by Auditor"}
                          required={false}
                          LeftSpace={false}
                        />
                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            required={false}
                            name="affidavitByAuditor"
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                    </Row>
                  </div>
                </div>

                <div className="uploadFirmList appDocList mb-4">
                  <Row>
                    <Col lg={12} md={12} xs={12}>
                      <h3>Application Submission</h3>
                    </Col>
                  </Row>

                  <div className="firmFileStep1">
                    <Row className="my-2">
                      <Col lg={4} md={4} xs={4} className="d-flex align-items-center">
                        <TableText label="Do you want to Accept this Application" required={true} LeftSpace={false} />
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="submissionResponse"
                          type="radio"
                          className="fom-checkbox mx-3 "
                          defaultChecked={additionalDetails.submissionResponse === "Yes"}
                          onChange={(e: any) => additonalDetailsChange(e)}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="submissionResponse"
                          type="radio"
                          className="fom-checkbox "
                          defaultChecked={additionalDetails.submissionResponse === "No"}
                          onChange={(e: any) => additonalDetailsChange(e)}
                        />
                      </Col>
                      {/* <Col lg={3} md={3} xs={3}>
                        <TableText label="Application Processed Date" required={true} LeftSpace={false} />
                        <Form.Control
                          type="date"
                          required={true}
                          placeholder="DD/MM/YYYY"
                          name="applicationProcessedDate"
                          value={additionalDetails.applicationProcessedDate}
                          onChange={additonalDetailsChange}
                        />
                      </Col> */}
                      {/* <Col lg={3} md={3} xs={3}>
                        <TableText label="Registration Year" required={true} LeftSpace={false} />
                        <TableInputText
                          type="number"
                          maxLength={4}
                          placeholder="Enter Registration Year"
                          required={true}
                          dot={false}
                          name={"registrationYear"}
                          value={additionalDetails.registrationYear}
                          onChange={additonalDetailsChange}
                        />
                      </Col> */}
                    </Row>


                  </div>
                </div>

                <div className="firmSubmitSec">
                  <Row>
                    <Col lg={12} md={12} xs={12}>
                      <>
                        <div className="d-flex justify-content-center text-center">
                          {" "}
                          <Button onClick={handleSubmit}>Save</Button>
                          {/* <Button onClick={handleSubmit}>Save</Button> */}
                        </div>
                      </>
                    </Col>
                  </Row>
                </div>
              </Form>
            </Container>
          </div>)}
        {(!locData?.userType || locData?.userType == "user") && (

          <div className="societyRegSec">

            <Container>

              <Row>

                <Col lg={12} md={12} xs={12}>

                  <div className="d-flex justify-content-between page-title mb-2" style={{ paddingTop: "17px" }}>

                    <div className="pageTitleLeft">

                      <h1>Unauthorized page</h1>

                    </div>

                  </div>

                </Col>

              </Row>

            </Container>

          </div>

        )}
      </div>
    </>
  )
}



