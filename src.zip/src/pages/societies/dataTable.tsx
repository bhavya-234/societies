import moment from "moment"
import { useEffect, useState } from "react"
import { Container, Col, Row, Table, Button } from "react-bootstrap"
import Search from "./search"
import CryptoJS from "crypto-js"
import DepartmentTab from "../../components/Tabs"
import Swal from "sweetalert2"
import api from "../api/api"
import { updateSocietyDetails } from "@/axios"
import { ShowMessagePopup } from "@/GenericFunctions"
import { useRouter } from "next/router"
interface DataTableProps {
  requests: any
  reqsearchdata: any
  setReqSearchData: any
  handleView: any
  isTableView: any
  setIsTableView: any
  isSearchView: any
  apiResponsetoFirmDataMapper: any
  setIsError: any
  setErrorMessage: any
}

const dataTable = ({
  requests,
  reqsearchdata,
  setReqSearchData,
  handleView,
  isTableView,
  setIsTableView,
  isSearchView,
  apiResponsetoFirmDataMapper,
  setIsError,
  setErrorMessage,
}: DataTableProps) => {
  const [storeData, setStoreData] = useState<any>({})
  const [token, setToken] = useState<string>("")
  const router = useRouter()
  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if(data&&data?.token){
    setStoreData(data)
    setToken(data.token)}
  }, [])
  const appealed = async (e: any) => {
    e.preventDefault()
    const newData = new FormData()
    newData.append("formType", "Appeal")
    newData.append("id", storeData.applicationId)

    updateSocietyDetails(storeData._id, token, newData)
      .then((response: any) => {
        ShowMessagePopup(true, "Successfully Appealed to Higher Authority")
        router.push('/')
      })
      .catch((error) => {
        console.log("error-", error)
        setIsError(true)
        setErrorMessage(error.message)
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: error.message,
          showConfirmButton: false,
          timer: 1500,
        })
      })
  }
  return (
    <div className="firmReqsList">
      {storeData?.userType != "user" ? <DepartmentTab active={1} /> : null}
      {isSearchView ? (
        <Search
          requests={requests}
          reqsearchdata={reqsearchdata}
          setReqSearchData={setReqSearchData}
          apiResponsetoFirmDataMapper={apiResponsetoFirmDataMapper}
          setIsTableView={setIsTableView}
          setIsError={setIsError}
          setErrorMessage={setErrorMessage}
        />
      ) : (
        <Container />
      )}

      {isTableView ? (
        <Container>
          <Row>
            <Col>
              {storeData.role == "IG" ?
                <>
                  <Table striped bordered className="tableData listData tabledatadata">
                    <thead>
                      <tr>
                        <th className="siNo text-center">SNo</th>
                        <th >Application No</th>
                        <th>Society Name</th>
                        <th>District Name</th>
                        <th>Application Date</th>
                        <th>Application Type</th>
                        <th>Status</th>
                        <th>Remarks</th>
                      </tr>
                    </thead>
                    {reqsearchdata && reqsearchdata.length > 0 ? (
                      <tbody>
                        {reqsearchdata.map((item: any, i: number) => {
                          return (
                            <tr key={i + 1}>
                              <td className="text-center">{i + 1}</td>
                              <td>
                                {(item["applicantFields"].status == "AppealedToHA"||
                                item["applicantFields"].status =="AcceptedByHA") ? (
                                  <a
                                    onClick={() => handleView(item["userFields"].userId)}
                                    className="viewData"
                                  >
                                    {item["applicantFields"].applicantNumber}
                                  </a>
                                ) : null}
                              </td>
                              <td >{item["societyFields"].societyName}</td>
                              <td>{item["addressFields"].district}</td>
                              <td>{moment(item["societyFields"]?.createdAt).format("DD/MM/YYYY")}</td>
                              {(item.isAimChange == true || item.isNameChange == true
                                || item.isAddressChange == true ||
                                item.isAmalgamChange == true ||
                                item.isSocietyDissolved == true ||
                                item.isSocietyWinding == true ||
                                item.isMemorandumChange == true ||
                                item.isFiling == true) ?
                                <td>
                                  {item.isAimChange == true && "Aim and Objective Change"} 
                                  {item.isNameChange == true && "Name Change"}
                                  {item.isAddressChange == true && "Address Change"}
                                  {item.isAmalgamChange == true && "Amalgamation"}
                                  {item.isSocietyDissolved == true && "Dissolution"}
                                  {item.isSocietyWinding == true && "Winding Society"}
                                  {item.isMemorandumChange == true && "Memorandum and Bye-laws"}
                                  {item.isFiling == true && "Filing of List of Members"}

                                </td> : <td>Society Registration</td>}
                              <td>{item["applicantFields"].status}</td>

                              {(item["applicantFields"].status == "AppealedToHA"||
                              item["applicantFields"].status =="AcceptedByHA") && item["processingHistory"].length > 0 ? (
                                <td>
                                  {item["processingHistory"][item.processingHistory.length - 1].remarks}
                                </td>
                              ) : <td>{""}</td>}
                            </tr>
                          )
                        })}
                      </tbody>
                    ) : (
                      <tbody>
                        <tr>
                          <td colSpan={7}>No Data Found</td>
                        </tr>
                      </tbody>
                    )}
                  </Table>
                </>
                :
                <Table striped bordered className="tableData listData tabledatadata">
                  <thead>
                    <tr>
                      <th className="siNo text-center">SNo</th>
                      <th >Application No</th>
                      <th>Society Name</th>
                      <th>District Name</th>
                      <th>Application Date</th>
                      <th>Application Type</th>
                      <th>Status</th>
                      <th>Remarks</th>
                    </tr>
                  </thead>

                  {reqsearchdata && reqsearchdata.length > 0 ? (
                    <tbody>
                      {reqsearchdata.map((item: any, i: number) => {
                        return (
                          <tr key={i + 1}>
                            <td className="text-center">{i + 1}</td>
                            <td>
                              {item["applicantFields"].status == "Incomplete" ? (
                                item["applicantFields"].applicantNumber
                              ) : item["applicantFields"].status != "Forwarded" &&
                                item["applicantFields"].status != "Approved" &&
                                item["applicantFields"].status != "Rejected" &&
                                item["applicantFields"].status != "AcceptedByHA" &&
                                storeData?.role == "DR" ? (
                                item["applicantFields"].applicantNumber
                              ) : item["applicantFields"].status != "Incomplete" ? (
                                <a
                                  onClick={() => handleView(item["userFields"].userId)}
                                  className="viewData"
                                >
                                  {item["applicantFields"].applicantNumber}
                                </a>
                              ) : null}
                              {/* {item["applicantFields"].status == "Incomplete" &&
                              item["applicantFields"].applicantNumber}
                            {item["applicantFields"].status != "Incomplete" && (
                              <a
                                onClick={() => handleView(item["userFields"].userId)}
                                className="viewData"
                              >
                                {item["applicantFields"].applicantNumber}
                              </a>
                            )} */}
                            </td>
                            <td>{item["societyFields"].societyName}</td>
                            <td>{item["addressFields"].district}</td>
                            <td>{moment(item["societyFields"]?.createdAt).format("DD/MM/YYYY")}</td>
                            {(item.isAimChange == true || item.isNameChange == true
                              || item.isAddressChange == true ||
                              item.isAmalgamChange == true ||
                              item.isSocietyDissolved == true ||
                              item.isSocietyWinding == true ||
                              item.isMemorandumChange == true ||
                              item.isFiling == true) ?
                              <td>
                                  {item.isAimChange == true && "Aim and Objective Change"}
                                  {item.isNameChange == true && "Name Change"}
                                  {item.isAddressChange == true && "Address Change"}
                                  {item.isAmalgamChange == true && "Amalgamation"}
                                  {item.isSocietyDissolved == true && "Dissolution"}
                                  {item.isSocietyWinding == true && "Winding Society"}
                                  {item.isMemorandumChange == true && "Memorandum and Bye-laws"}
                                  {item.isFiling == true && "Filing of List of Members"}

                                </td>: <td>Society Registration</td>}
                            <td>{item["applicantFields"].status}</td>

                            {(item["applicantFields"].status == "Forwarded" || item["applicantFields"].status == "Approved" || item["applicantFields"].status == "Rejected") && item["processingHistory"].length > 0 ? (
                              <td>
                                {item["processingHistory"][item.processingHistory.length - 1].remarks}
                              </td>
                            ) : (
                              <td>{""}</td>
                            )}
                          </tr>
                        )
                      })}
                    </tbody>
                  ) : (
                    <tbody>
                      <tr>
                        <td colSpan={7}>No Data Found</td>
                      </tr>
                    </tbody>
                  )}
                </Table>}
              {storeData?.userType == "user" &&
              
                reqsearchdata &&
                reqsearchdata.length > 0 &&
                reqsearchdata[0]["applicantFields"].status == "Rejected" &&
                !reqsearchdata[0]?.processingHistory?.some((x) => x.status == "Approved") &&
                reqsearchdata[0]?.isAddressChange==false&& reqsearchdata[0]?.isAmalgamChange==false&&
                reqsearchdata[0]?.isAimChange==false&& reqsearchdata[0]?.isMemorandumChange==false&&
                reqsearchdata[0]?.isNameChange==false&& reqsearchdata[0]?.isSocietyWinding==false&&
                reqsearchdata[0]?.isSocietyDissolved==false&& reqsearchdata[0]?.isFiling==false&&
                (
                  <Col lg={12} md={12} xs={12}>
                    <div className="d-flex justify-content-between pagesubmitSecTitle mb-3 p-5 pt-3">
                      <div className="ms-2">
                        <h2>
                          <a
                            href="/societies/details"
                            onClick={() => localStorage.setItem("isResubmission", "true")}
                            style={{ color: "blue" }}
                          >
                            click here
                          </a>{" "}
                          to resubmit form
                        </h2>
                      </div>
                      <div>
                        <Button onClick={appealed}>
                          Appeal to Higher Authority
                        </Button>
                      </div>
                    </div>
                  </Col>
                )}
            </Col>
          </Row>
        </Container>
      ) : (
        <Container />
      )}
    </div>
  )
}

export default dataTable
