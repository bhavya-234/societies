import Head from "next/head"
import { useState, useEffect } from "react"
import PageHeader from "./pageHeader"
import DataTable from "./dataTable"
import ViewDetails from "./viewDetails"
import { useAppSelector, useAppDispatch } from "@/redux/hooks"
import Swal from "sweetalert2"
import { getSocietyDetails, getSocietyDetailsdata } from "@/axios"
import CryptoJS from "crypto-js"
import api from "../api/api"
import { Loading } from "@/GenericFunctions"

export default function Societies() {
  const [isAdding, setIsAdding] = useState<boolean>(false)
  const [requests, setRequests] = useState<any>([])
  const [reqsearchdata, setReqSearchData] = useState<any>([])
  const [selectedRequest, setSelectedRequest] = useState<any>(null)
  const [isView, setIsView] = useState<boolean>(false)
  const [isSearchView, setIsSearchView] = useState<boolean>(false)
  const [isTableView, setIsTableView] = useState<boolean>(false)
  const [isError, setIsError] = useState<boolean>(false)
  const [errorMessage, setErrorMessage] = useState<string>("")

  const dispatch = useAppDispatch()
  const [SelectedformTypekey, setSelectedformTypekey] = useState<number>(1)
  let initialLoginDetails = useAppSelector((state) => state.login.loginDetails)
  const [isAuthenticated, setIsAuthenticated] = useState<any>(null)
  const [savedLoginDetails, setSavedLoginDetails] = useState<any>(null)
  const [LoginDetails, setLoginDetails] = useState<any>(initialLoginDetails)

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if(data&&data?.token){
    setSavedLoginDetails(data)}
  }, [initialLoginDetails])
  useEffect(() => {
    if(!isView){

    
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if(data&&data?.token){
    if (data != null && data.userType === "user") {
      getSocietyDetails(data.applicationId, data.token)
        .then((response: any) => {
          Loading(false)
          if (!response || !response.success) {
            // console.log("error-", response.data.message)
            // console.log(response.data.message)
            setIsError(true)
            setErrorMessage(response.data.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: response.data.message,
              showConfirmButton: false,
              timer: 1500,
            })
          }

          if (response.data.daSociety) {
            response.data.dasocieties = [response.data.daSociety]
          }

          console.log("RESPONSE IS ", response)

          const firmRegData: any = []
          for (let i = 0; i < response.data.dasocieties.length; i++) {
            firmRegData.push(apiResponsetoFirmDataMapper(response.data.dasocieties[i], i + 1))
          }
          setRequests(firmRegData)
          setReqSearchData(firmRegData)
        })
        .catch((error) => {
          Loading(false)
          // console.log("error-", error)
          // console.log(error.message)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: error.message,
            showConfirmButton: false,
            timer: 1500,
          })
        })
      setIsTableView(true)
    } else if (data.role == "IG") {
      Loading(true)
      getSocietyDetailsdata(data.token)
        .then((response: any) => {
          Loading(false)
          if (!response || !response.success) {
           
            console.log("error-", response.data.message)
            console.log(response.data.message)
            setIsError(true)
            setErrorMessage(response.data.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: "success",
              showConfirmButton: false,
              timer: 1500,
            })
          }
          else {

            response.data.dasocieties = response.data

            console.log("RESPONSE IS ", response)

            const firmRegData: any = []
            for (let i = 0; i < response.data.dasocieties.length; i++) {
              firmRegData.push(apiResponsetoFirmDataMapper(response.data.dasocieties[i], i + 1))
            }
            setRequests(firmRegData)
            setReqSearchData(firmRegData)
          }
        })
        .catch((error) => {
          Loading(false)
          console.log("error-", error)
          console.log(error.message)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: "error",
            showConfirmButton: false,
            timer: 1500,
          })
        })
      setIsTableView(true)
      // setIsSearchView(true)
    }
    else {
      setIsSearchView(true)
    }}
  }
  }, [isView])
  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if(data&&data?.token){
    if (data != null && data.userType === "user") {
      getSocietyDetails(data.applicationId, data.token)
        .then((response: any) => {
          Loading(false)
          if (!response || !response.success) {
            // console.log("error-", response.data.message)
            // console.log(response.data.message)
            setIsError(true)
            setErrorMessage(response.data.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: response.data.message,
              showConfirmButton: false,
              timer: 1500,
            })
          }

          if (response.data.daSociety) {
            response.data.dasocieties = [response.data.daSociety]
          }

          console.log("RESPONSE IS ", response)

          const firmRegData: any = []
          for (let i = 0; i < response.data.dasocieties.length; i++) {
            firmRegData.push(apiResponsetoFirmDataMapper(response.data.dasocieties[i], i + 1))
          }
          setRequests(firmRegData)
          setReqSearchData(firmRegData)
        })
        .catch((error) => {
          Loading(false)
          // console.log("error-", error)
          // console.log(error.message)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: error.message,
            showConfirmButton: false,
            timer: 1500,
          })
        })
      setIsTableView(true)
    } else if (data.role == "IG") {
      Loading(true)
      getSocietyDetailsdata(data.token)
        .then((response: any) => {
          Loading(false)
          if (!response || !response.success) {
           
            console.log("error-", response.data.message)
            console.log(response.data.message)
            setIsError(true)
            setErrorMessage(response.data.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: "success",
              showConfirmButton: false,
              timer: 1500,
            })
          }
          else {

            response.data.dasocieties = response.data

            console.log("RESPONSE IS ", response)

            const firmRegData: any = []
            for (let i = 0; i < response.data.dasocieties.length; i++) {
              firmRegData.push(apiResponsetoFirmDataMapper(response.data.dasocieties[i], i + 1))
            }
            setRequests(firmRegData)
            setReqSearchData(firmRegData)
          }
        })
        .catch((error) => {
          Loading(false)
          console.log("error-", error)
          console.log(error.message)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: "error",
            showConfirmButton: false,
            timer: 1500,
          })
        })
      setIsTableView(true)
      // setIsSearchView(true)
    }
    else {
      setIsSearchView(true)
    }}
  }, [])

  const handleView = (id: string | number) => {
    const [request] = reqsearchdata.filter((request: any) => request["userFields"].userId === id)
    setSelectedRequest(request)
    setIsView(true)
  }

  const apiResponsetoFirmDataMapper = (societyData: any, ind: number) => {
    return {
      userFields: { userId: ind, portaluserName: "Test", operatorName: "N/A", mobileNo: "N/A" },
      applicantFields: {
        id: societyData._id,
        applicantNumber: societyData.applicationNumber,
        applicantName: societyData.applicantDetails?.name,
        applicantSurname: societyData.applicantDetails?.surname,
        applicantGender: societyData.applicantDetails?.gender,
        status: societyData.status,
        mandal:societyData.applicantDetails?.mandal,
        villageOrCity:societyData.applicantDetails?.villageOrCity,
        societyStatus: societyData.societyStatus,
        emailId: societyData.applicantDetails?.email,
        mobileNumber: societyData.applicantDetails?.mobileNumber,
        relationType: societyData.applicantDetails?.relationType,
        relationName: societyData.applicantDetails?.relationName,
        pinCode: societyData.applicantDetails?.pinCode,
        street:societyData.applicantDetails?.street,
        doorNo:societyData.applicantDetails?.doorNo,
        age:societyData.applicantDetails?.age,
        district:societyData.applicantDetails?.district,
      },
      addressFields: {
        doorNo: societyData.doorNo,
        street: societyData.street,
        country: "INDIA",
        state: societyData.state,
        district: societyData.district,
        mandal: societyData.mandal,
        villageCity: societyData.villageOrCity,
        pinCode: societyData.pinCode,
      },
      contactFields: {
        contactPhone: societyData.contactDetails?.phone,
        contactMobile: societyData?.mobileNumber,
        fax: societyData.contactDetails?.fax,
        emailId: societyData?.email,
        deliveryType: societyData.contactDetails?.deliveryType,
      },
      societyFields: {
        deptId: societyData.approvedRejectedById,
        aim: societyData.aim,
        objective: societyData.objective,
        societyName: societyData.societyName,
        registrationNumber: societyData.registrationNumber,
        registrationYear: societyData.registrationYear,
        societyId: societyData._id,
        category: societyData.category,
        doorNo: societyData.doorNo,
        generalBodyMeeting: societyData.generalBodyMeeting,
        street: societyData.street,
        state: societyData.state,
        district: societyData.district,
        mandal: societyData.mandal,
        villageOrCity: societyData.villageOrCity,
        pinCode: societyData.pinCode,
        nameOfRegistrationDistrict: societyData.nameOfRegistrationDistrict,
        createdAt: societyData.createdAt,
      },
      
      incomingSocietyFields:societyData.incomingSocietyAmalgamDetails,
      processingHistory: societyData.processingHistory,
      messageToApplicant: societyData.messageToApplicant,
      documentAttached: societyData.documentAttached,
      memberDetails: societyData.memberDetails,
      incomingmemberDetails:societyData.incomingmemberDetails,
      historyDetails: societyData.historyDetails,
      isAimChange: societyData.isAimChange,
      isNameChange: societyData.isNameChange,
      isAddressChange: societyData.isAddressChange,
      isFiling: societyData.isFiling,
      isMemorandumChange: societyData.isMemorandumChange,
      isSocietyWinding: societyData.isSocietyWinding,
      isAmalgamChange: societyData.isAmalgamChange,
      isSocietyDissolved: societyData.isSocietyDissolved,
    }
  }

  return (
    <>
      <Head>
        <title>Registration Societies Requests</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      <div className="firmReqSec">
        {!isAdding && !isView && (
          <>
            <PageHeader setIsAdding={setIsAdding} />
            <DataTable
              requests={requests}
              reqsearchdata={reqsearchdata}
              setReqSearchData={setReqSearchData}
              handleView={handleView}
              apiResponsetoFirmDataMapper={apiResponsetoFirmDataMapper}
              isTableView={isTableView}
              isSearchView={isSearchView}
              setIsTableView={setIsTableView}
              setIsError={setIsError}
              setErrorMessage={setErrorMessage}
            />
          </>
        )}
        {/* {isAdding && (
          <Details requests={requests} setRequests={setRequests} setIsAdding={setIsAdding} />
        )} */}

        {isView && (
          <ViewDetails
            reqsearchdata={reqsearchdata}
            selectedRequest={selectedRequest}
            setReqSearchData={setReqSearchData}
            setIsView={setIsView}
            setIsError={setIsError}
            setErrorMessage={setErrorMessage}
          />
        )}
      </div>
    </>
  )
}
