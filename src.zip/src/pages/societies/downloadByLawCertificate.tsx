import React, { useState, useEffect } from "react"
import Head from "next/head"
import { Container, Col, Row, Button } from "react-bootstrap"
import instance from "@/redux/api"
import { downloadByeLawCertificate, getDeptSignature, getSocietyDetails } from "@/axios"
import api from "@/pages/api/api"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { useAppDispatch } from "@/hooks/reduxHooks"
import CryptoJS from "crypto-js"
import { store } from "@/redux/store"
import { PDFDocument, StandardFonts } from "pdf-lib"
import { DateFormator } from "@/GenericFunctions"

const DownloadByLawCertificate = () => {
  const [selectedRequest, setSelectedRequest] = useState<any>({})
  const [districts, setDistricts] = useState<any>([])
  const [locData, setLocData] = useState<any>({})
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [isView, setIsView] = useState<boolean>(false)
  const [isAlreadyDownloaded, setIsAlreadyDownloaded] = useState<boolean>(false)
  const [ispaymentSuccess, setIsPaymentSuccess] = useState<boolean>(false)
  const [img, setImg] = useState("")
  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }

  let ref = React.useRef<HTMLDivElement | null>(null)
  let btnref = React.useRef<HTMLButtonElement | null>(null)
  const dispatch = useAppDispatch()
  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }
  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setLocData(data)
    setLoggedInAadhar(data.aadharNumber)
    Loading(true)
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)
        getSocietyDetails(data.applicationId, data.token)
          .then((response) => {
            if (response?.success) {
              setSelectedRequest(response.data.daSociety)
              if (
                response.data.daSociety.status != "Incomplete" &&
                response.data.daSociety.isdownload
              ) {
                setIsAlreadyDownloaded(true)
              } else {
                setIsAlreadyDownloaded(false)
              }
            }
            Loading(false)
          })
          .catch(() => {
            Loading(false)
          })
      })
      .catch(() => {
        Loading(false)
      })
    getSocietyDetails(data.applicationId, data.token).then((response) => {
      if (response?.success) {
        if (response.data.daSociety.approvedRejectedById) {
          getDeptSignature(response.data.daSociety.approvedRejectedById, data.token)
            .then((res) => {
              if (res.success && res.data) {
                setImg("data:image/jpg;base64, " + res.data.signature)
              }
            })
            .catch(() => {
              Loading(false)
              console.log("error")
            })
        }
      }
    })
  }, [])
  useEffect(() => {
    if (Object.keys(selectedRequest).length) {
      let data1: any = localStorage.getItem("isdownloadByeLaw")
      if (data1) {
        let data: any = localStorage.getItem("FASPLoginDetails")
        if (data && data != "" && process.env.SECRET_KEY) {
          let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
          data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
        }
        api
          .get("/getPaymentDetails/" + data.applicationNumber, {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${data.token}`,
            },
          })
          .then((response: any) => {
            if (!response || !response.data || !response.data.success) {
              localStorage.removeItem("isdownloadByeLaw")
              setIsPaymentSuccess(false)
            } else {
              if (
                response.data.data.paymentDetails.transactionStatus == "Success" &&
                btnref.current
              ) {
                localStorage.setItem("downloadByeLaw", "true")
                btnref.current.click()
                localStorage.removeItem("isdownloadByeLaw")
              } else {
                localStorage.removeItem("isdownloadByeLaw")
                setIsPaymentSuccess(false)
              }
            }
          })
          .catch((error) => {
            localStorage.removeItem("isdownloadByeLaw")
            setIsPaymentSuccess(false)
          })
      }
    }
  }, [selectedRequest])

  const PaymentLink = () => {
    let code = 0
    const dis = districts?.find((x: { name: string }) => x.name == selectedRequest.district)
    if (dis) {
      code = dis.code
    }
    localStorage.setItem("isdownloadByeLaw", "true")
    const paymentsData = {
      type: "sra",
      source: "Society",
      deptId: selectedRequest.applicationNumber,
      rmName: selectedRequest.applicantDetails?.name,
      rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
      mobile: selectedRequest.applicantDetails?.mobileNumber,
      email: selectedRequest.applicantDetails?.email,
      drNumber: code,
      rf: 100,
      uc: 100,
      oc: 0,
      returnURL: process.env.BACKEND_URL + "/societies/redirectbylawcertificate",
    }
    let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
    // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
    const encodedData = CryptoJS.AES.encrypt(
      JSON.stringify(paymentsData),
      'igrsSecretPhrase'
    ).toString()
    console.log("ENCODED VALUE IS ", encodedData)
    let paymentLink = document.createElement("a")
    paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
    paymentLink.click()
    setTimeout(function () {
      paymentLink.remove()
    }, 1000)
  }
  const fetchFile = () => {
    const url = `/downloads/${selectedRequest._id}/${selectedRequest.byeLawDocLink}`

    instance.get(url, { responseType: "arraybuffer" }).then(async (res) => {
      const pdfDoc = await PDFDocument.load(res.data);
      const pages = pdfDoc.getPages();
      let data = selectedRequest.processingHistory?.find((x) => x.status == "Approved")
      let date =  (DateFormator(selectedRequest.createdAt, "dd/mm/yyyy"))
      if (data) {
        date = (DateFormator(data.applicationProcessedDate, "dd/mm/yyyy"))
      }
      for await (let page of pages) {
        const firstPage = page;
        let image;
        await fetch(img).then((res) => res.arrayBuffer().then(r => image = r))
        const jpgImage = await pdfDoc.embedJpg(image)
        const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
        const { width, height } = firstPage.getSize();
        firstPage.drawImage(jpgImage, {
          x: width - 160,
          y: height - 800,
          width: 90,
          height: 70,
          opacity: 0.75,
        });
        firstPage.drawText(date, {
          x: width - 150,
          y: height - 812,
          font,
          size: 12

        })
      }
      const pdfBytes = await pdfDoc.save();
      const bytes = new Uint8Array(pdfBytes);
      const docUrl = URL.createObjectURL(
        new Blob([bytes], { type: "application/pdf" })
      );

      var link = document.createElement("a")
      link.href = docUrl
      link.setAttribute("download", `byelaws.pdf`)
      document.body.appendChild(link)
      link.click()
      link.remove()

    })
  }
  return (
    <>
      <Head>
        <title>Acknowledgement of Registration of Society</title>
        <link rel="icon" href="/registration-stamp-icon.ico" />
      </Head>
      {locData && locData?.userType && locData?.userType == "user" && (
        <>
          {selectedRequest.status != "Incomplete" && (
            <div className="text-center">
              <Button
                id="downloadClick"
                ref={btnref}
                className="ms-3"
                variant="primary"
                onClick={() => {
                  const data = localStorage.getItem("downloadByeLaw")
                  if (data == "true") {
                    fetchFile()
                    downloadByeLawCertificate({ amount: 300 }, locData.applicationId, locData.token)
                    ShowAlert(true, "Your certificate is downloaded successfully")
                    localStorage.removeItem("downloadByeLaw")
                  } else {
                    PaymentLink()
                  }
                }}
              >
                Download Copy of Bye-Laws
              </Button>
            </div>
          )}

          {selectedRequest.status == "Incomplete" && (
            <div className="certifyLogoSec">
              <Row className="d-flex justify-content-between align-items-center">
                <Col lg={12} md={12} xs={12}>
                  <div className="certifyLogoInfo text-center">
                    <h3>Your application is not yet submitted </h3>
                  </div>
                </Col>
              </Row>
            </div>
          )}
        </>
      )}
      {(!locData?.userType || locData?.userType != "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}

export default DownloadByLawCertificate
