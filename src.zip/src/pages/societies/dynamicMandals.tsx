import React, { useState } from "react"
import instance from "@/redux/api"
import { store } from "@/redux/store"
import { LoadingAction } from "@/redux/commonSlice"

interface DynamicMandals {
  currentDistrict: any
  setDetails?: () => void
}

export default function DynamicMandals({ currentDistrict, setDetails }: DynamicMandals) {
  console.log(currentDistrict)
  const [mandalList, setMandalList] = useState([])
  let data = {
    districtName: currentDistrict,
  }
  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }
  React.useEffect(() => {
    if (currentDistrict && currentDistrict != null) {
      Loading(true)
      instance
        .post("/getDistrictsMandals", data)
        .then((response) => {
          const mList = response.data.map((item: { mandalName: string }) => {
            return item.mandalName
          })
          setMandalList(mList)
          Loading(false)
          setDetails && setDetails()
        })
        .catch(() => {
          Loading(false)
        })
    } else {
      setMandalList([])
    }
  }, [currentDistrict])

  return (
    <>
      {mandalList &&
        mandalList.length > 0 &&
        mandalList.map((mandal: any, i: number) => {
          return (
            <option key={mandal + i} value={mandal}>
              {mandal}
            </option>
          )
        })}
    </>
  )
}
