import React, { useState, ChangeEvent, useRef, useEffect } from "react"
import Swal from "sweetalert2"
import Head from "next/head"
import { useRouter } from "next/router"
import instance from "@/redux/api"
import styles from "@/styles/pages/Forms.module.scss"
import { Container, Col, Row, Form, Button, Table } from "react-bootstrap"
import DynamicMandals from "./dynamicMandals"
import DynamicVillages from "./dynamicCities"
import {
  getSocietyDetails,
  updateSocietyDetails,
  UseGetAadharDetails,
  UseGetAadharOTP,
} from "@/axios"
import { useAppDispatch } from "@/hooks/reduxHooks"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { get } from "lodash"
import { store } from "@/redux/store"
import TableText from "@/components/TableText"
import TableInputText from "@/components/TableInputText"
import CryptoJS from "crypto-js"
import { IApplicationDetailsSMModel, IContactDetailsModel } from "@/models/societyTypes"

export default function SocietiesAmendment() {
  const [addSociety, setAddSociety] = useState<string>("")
  const [isError, setIsError] = useState<boolean>(false)
  const [errorMessage, setErrorMessage] = useState<string>("")
  const [districtList, setDistricts] = useState<any>([])
  const [token, setToken] = useState<string>("")
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [isPayNowClicked, setIsPayNowClicked] = useState<boolean>(false)
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const [aadhaarUserResponse, setAadhaarUserResponse] = useState<any>({})
  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  const [currentDistrict, setCurrentDistrict] = useState<string>("")
  const [currentMandal, setCurrentMandal] = useState<string>("")
  const [changeFirm, setChangeFirm] = useState<string[]>([])

  const router = useRouter()
  const dispatch = useAppDispatch()
  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message,redirectOnSuccess:"/login" }))
  }
  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }

  const [roleList] = useState<string[]>([
    "President",
    "Vice President",
    "Secretary",
    "Joint Secretary",
    "Treasurer",
    "Member",
  ])
  const [applicantDetails, setApplicantDetails] = useState<IApplicationDetailsSMModel>({
    maskedAadhar: "",
    aadharNumber: "",
    otpStatus: "",
    otpVerified: "",
    otpCode: "",
    applicationNumber: "",
    name: "",
    gender: "",
    doorNo: "",
    street: "",
    country: "",
    state: "",
    applicantDistrict: "",
    applicantMandal: "",
    applicantVillageOrCity: "",
    pinCode: "",
  })

  const [societyDetails, setSocietyDetails] = useState<any>({
    societyName: "",
    newNameEffectDate: "",
  })

  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid && event.key != "Backspace") {
      event.preventDefault()
      return
    }
  }
  const generateApplicantOtp = async () => {
    if (applicantDetails.aadharNumber && applicantDetails.aadharNumber.length == 12) {
      Loading(true)
      let result = await UseGetAadharOTP(btoa(applicantDetails.aadharNumber))
      Loading(false)
      if (result && result.status === "Success") {
        ShowAlert(true, "OTP Sent to Aadhaar Registered Mobile Number")
        setSentOTP(true)
        setAadhaarOTPResponse(result)
        let data = { ...applicantDetails }
        data["otpStatus"] = "1"
        setApplicantDetails(data)
      } else {
        ShowAlert(false, get(result, "message", "Aadhaar API failed"))
        setAadhaarOTPResponse({})
        let data = { ...applicantDetails }
        data["otpStatus"] = "2"
        setApplicantDetails(data)
      }
    } else {
      ShowAlert(false, "Kindly enter valid Aadhar number")
    }
  }

  const verifyApplicantOtp = async () => {
    if (applicantDetails.otpCode) {
      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(applicantDetails.aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: applicantDetails.otpCode,
      })
      Loading(false)
      if (result.status && result.status === "Success") {
        let data = { ...applicantDetails }
        data["name"] = result.userInfo.name
        data["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        data["country"] = result.userInfo.country
        data["state"] = result.userInfo.state
        data["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data["street"] = result.userInfo.street
        data["applicantDistrict"] = result.userInfo.dist.toUpperCase()
        data["pinCode"] = result.userInfo.pc
        data["otpVerified"] = "true"

        setApplicantDetails(data)
        setCurrentDistrict(result.userInfo.dist.toUpperCase())
      } else {
        let data = { ...applicantDetails }
        data["otpVerified"] = "false"
        setApplicantDetails(data)
        ShowAlert(false, get(result, "message", "Aadhaar API Failed"))
      }
    }
  }

  const generateOtp = async (index: string | number) => {
    if (membersDetails[index].aadharNumber && membersDetails[index].aadharNumber.length == 12) {
      Loading(true)
      let result = await UseGetAadharOTP(btoa(membersDetails[index].aadharNumber))
      Loading(false)
      if (result && result.status === "Success") {
        ShowAlert(true, "OTP Sent to Aadhaar Registered Mobile Number")
        setSentOTP(true)
        setAadhaarOTPResponse(result)
        let data: any = [...membersDetails]
        data[index]["otpStatus"] = "1"
        setMembersDetails(data)
      } else {
        ShowAlert(false, get(result, "message", "Aadhaar API failed"))
        setAadhaarOTPResponse({})
        let data: any = [...membersDetails]
        data[index]["otpStatus"] = "2"
        setMembersDetails(data)
      }
      // const newInput = () => ({ ...membersDetails, ["otpStatus"]: "1" })
      // membersDetails[index].otpCode = ""
      // setApplicantDetails(newInput)
    } else {
      ShowAlert(false, "Kindly enter valid Aadhar number")
    }
  }

  const ageCalculator = (dateOfBirth: string) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    //calculate month difference from current date in time
    let month_diff = Date.now() - dob.getTime()

    //convert the calculated difference in date format
    let age_dt = new Date(month_diff)

    //extract year from date
    let year = age_dt.getUTCFullYear()

    //now calculate the age of the user
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }

  const verifyOtp = async (index: string | number) => {
    if (membersDetails[index].otpCode) {
      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(membersDetails[index].aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: membersDetails[index].otpCode,
      })
      Loading(false)
      if (result.status && result.status === "Success") {
        let data: any = [...membersDetails]
        data[index]["memberName"] = result.userInfo.name
        data[index]["fatherOrHusbandName"] = result.userInfo.co.split(":").pop().trim()
        data[index]["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        data[index]["age"] = ageCalculator(result.userInfo.dob)
        data[index]["country"] = result.userInfo.country
        data[index]["state"] = result.userInfo.state
        data[index]["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data[index]["street"] = result.userInfo.street
        data[index]["district"] = result.userInfo.dist.toUpperCase()
        data[index]["pinCode"] = result.userInfo.pc
        data[index]["otpVerified"] = "true"

        setMembersDetails(data)
      } else {
        let data: any = [...membersDetails]
        data[index]["otpVerified"] = "false"
        setMembersDetails(data)
        ShowAlert(false, get(result, "message", "Aadhaar API Failed"))
      }
    }
  }

  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setToken(data.token)
    setLoggedInAadhar(data.aadharNumber)
    setApplicantDetails({
      ...applicantDetails,
      applicationNumber: data.applicationNumber,
    })
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)

        getSocietyDetails(data.applicationId, data.token)
          .then((response) => {
            if (response?.success) {
              setExistingSocietyDetail(response.data.daSociety)
              if (response.data.daSociety.memberDetails?.length) {
                setMembersDetails([...response.data.daSociety.memberDetails])
              }
              if (response.data.daSociety.applicantDetails) {
                setApplicantDetails({
                  ...applicantDetails,
                  applicationNumber: data.applicationNumber,
                })
              }
            }
            Loading(false)
          })
          .catch(() => {
            Loading(false)
          })
        Loading(false)
      })
      .catch(() => {
        Loading(false)
      })
  }, [])
  const [contactDetails, setContactDetails] = useState<IContactDetailsModel>({
    mobileNumber: "",
    email: "",
    phone: "",
    fax: "",
    deliveryType: "",
  })

  const [membersDetails, setMembersDetails] = useState<any>([])
  const [newMembersDetails, setNewMembersDetails] = useState<any>([])

  const [file, setFile] = useState<any>([])
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [isCheckNation, setIsCheckNation] = useState<boolean>(false)
  const [FormErrors, setFormErrors] = useState<any>({})
  const [isCheckFirm, setIsCheckFirm] = useState<boolean>(false)

  const checkFirmDB = (e: any) => {
    e.preventDefault()
    const errors: any = {}

    let ob: any = {
      societyName: societyDetails.societyName.trim(),
      district: existingSocietyDetail.district,
    }
    if (
      !societyDetails.societyName ||
      societyDetails.societyName.trim().length < 4 ||
      societyDetails.societyName.trim().length > 20
    ) {
      errors["societyName"] = "*Society Name should contain 4 - 20 characters."
    } else {
      let obj: any = {
        registrationName: societyDetails.societyName.trim(),
      }
      instance
        .post("checkAvailability", obj)
        .then((response: any) => {
          if (response.data.success == false) {
            ShowAlert(false, response.data.message)
            setIsCheckNation(false)
          }
          if (response.data.success == true) {
            instance
              .post("societies/check", ob)
              .then((response: any) => {
                if (
                  response.data.message == "Society already exists!" &&
                  response.data.success == false
                ) {
                  ShowAlert(false, response.data.message)
                }
                if (
                  response.data.message == "Society is available to register" &&
                  response.data.success == true
                ) {
                  ShowAlert(true, response.data.message)
                  setIsCheckFirm(true)
                } else {
                  setIsCheckFirm(false)
                }
              })
              .catch((error) => {
                if (error.message == "Request failed with status code 400") {
                  ShowAlert(false, "Society Name is Mandatory")
                }
              })
          } else {
            setIsCheckNation(false)
          }
          Loading(false)
        })
        .catch((error) => {
          if (error.message == "Request failed with status code 400") {
            ShowAlert(false, "Society Name & District is Mandatory")
          }
        })
    }
    setFormErrors({ ...errors })
  }
  const handleMemberAdd = () => {
    setNewMembersDetails([
      ...newMembersDetails,
      {
        maskedAadhar: "",
        aadharNumber: "",
        otpStatus: "",
        otpVerified: "",
        otpCode: "",
        memberName: "",
        gender: "",
        fatherOrHusbandName: "",
        age: "",
        occupation: "",
        role: "",
        doorNo: "",
        street: "",
        country: "",
        state: "",
        district: "",
        mandal: "",
        villageOrCity: "",
        pinCode: "",
      },
    ])
  }

  const handleUploadClick = () => {
    inputRef.current?.click()
  }

  const countryList = ["India"]
  const stateList = ["Andhra Pradesh"]

  const genderList = ["Female", "Male", "Other"]

  const [applicantMandals, setApplicantMandals] = useState([])
  const [applicantCities, setApplicantCities] = useState([])

  const [societyMandals, setSocietyMandals] = useState([])
  const [societyCities, setSocietyCities] = useState([])

  // useEffect(() => {
  //   console.log('mounted');
  //   return () => console.log('unmounting...');
  // }, [currentDistrict,currentMandal])

  const applicantDetailsChange = (e: any) => {
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        e.target.value.length > 0 &&
        e.target.value.length > applicantDetails.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          applicantDetails.aadharNumber.substring(0, startpos) +
          applicantDetails.aadharNumber.substring(
            startpos + 1,
            applicantDetails.aadharNumber.length
          )
      }
      setApplicantDetails({
        ...applicantDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? applicantDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
      setApplicantDetails(newInput)
    }
  }

  const districtChange = (e: any, _index?: number) => {
    // if(e.target.name == 'applicantDistrict'){
    //   setApplicantMandals([])
    //   setApplicantCities([])

    setCurrentDistrict(e.target.value)
    console.log(currentDistrict)
    setCurrentMandal("")
    // }
  }

  const mandalChange = (e: any, _index?: number) => {
    setCurrentMandal(e.target.value)
  }
  const contactDetailsChange = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setContactDetails(newInput)
  }

  const societyDetailsChange = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setSocietyDetails(newInput)
  }

  const membersDetailsChange = (e: any, index: number) => {
    if (e.target.name == "maskedAadhar") {
      let data: any = [...newMembersDetails]
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (e.target.value.length > 0 && e.target.value.length > data[index].aadharNumber.length) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          data[index].aadharNumber.substring(0, startpos) +
          data[index].aadharNumber.substring(startpos + 1, data[index].aadharNumber.length)
      }
      const det: any = {
        ...data[index],
        maskedAadhar: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? data[index].aadharNumber + newNo : aadharNo,
      }
      data.splice(index, 1, det)

      setNewMembersDetails(data)
    } else {
      let data = [...newMembersDetails]
      const det = { ...data[index], [e.target.name]: e.target.value }
      data.splice(index, 1, det)
      setNewMembersDetails(data)
    }
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const files: any = e.target.files
    if (!files) {
      return
    } else if (files && files[0]) {
      const newInput = (data: any) => ({ ...data, [e.target.name]: files[0] })
      setFile(newInput)
    }
  }

  const handleMemberRemove = (index: number) => {
    let data: any = [...newMembersDetails]
    delete data[index]
    let memList: any = []
    data.forEach((x: any) => {
      if (x) {
        memList.push(x)
      }
    })
    setNewMembersDetails(memList)
  }
  const [deletedMemCount, setDeletedMemCount] = useState(0)
  const handleDeleteMemberRemove = (index: number) => {
    setDeletedMemCount(deletedMemCount + 1)
    let data = [...membersDetails]
    delete data[index]
    let memList: any = []
    data.forEach((x: any) => {
      if (x) {
        memList.push(x)
      }
    })
    setMembersDetails(memList)
  }
  const handleSubmit = async (e: any) => {
    e.preventDefault()

    const {
      applicationForm,
      memorandumAndByeLaws,
      membershipDeed,
      affidavit,
      selfSignedDeclaration,
    } = file

    const appDoc = applicationForm

    const memorandumAndByeLawsDoc = memorandumAndByeLaws

    const partnerDoc = membershipDeed

    const affidavitDoc = affidavit

    const selfDoc = selfSignedDeclaration

    const data = {
      applicantDetails: applicantDetails,
      contactDetails: contactDetails,
      societyDetails: societyDetails,
      applicationForm: applicationForm,
      memorandumAndByeLaws: memorandumAndByeLawsDoc,
      membershipDeed: membershipDeed,
      affidavit: affidavit,
      selfSignedDeclaration: selfSignedDeclaration,
      membersDetails: [
        ...membersDetails.filter((x: any) => x.memberName.trim()),
        ...newMembersDetails.filter((x: any) => x.memberName.trim()),
      ],
    }

    const newData = new FormData()
    newData.append("applicantDetails[aadharNumber]", btoa(data.applicantDetails.aadharNumber))
    newData.append("applicantDetails[applicationNumber]", existingSocietyDetail.applicationNumber)
    newData.append("applicantDetails[name]", data.applicantDetails.name)
    newData.append("applicantDetails[gender]", data.applicantDetails.gender)
    newData.append("applicantDetails[doorNo]", data.applicantDetails.doorNo)
    newData.append("applicantDetails[street]", data.applicantDetails.street)
    newData.append("applicantDetails[country]", "India")
    newData.append("applicantDetails[state]", "Andhra Pradesh")
    newData.append("applicantDetails[district]", data.applicantDetails.applicantDistrict)
    newData.append("applicantDetails[mandal]", data.applicantDetails.applicantMandal)
    newData.append("applicantDetails[villageOrCity]", data.applicantDetails.applicantVillageOrCity)
    newData.append("applicantDetails[pinCode]", data.applicantDetails.pinCode)
    // newData.append("contactDetails[mobileNumber]", data.contactDetails.mobileNumber)
    // newData.append("contactDetails[email]", data.contactDetails.email)
    // newData.append("contactDetails[phone]", data.contactDetails.phone)
    // newData.append("contactDetails[fax]", data.contactDetails.fax)
    // newData.append("contactDetails[deliveryType]", data.contactDetails.deliveryType)
    // newData.append("processingHistory[0][designation]", "DR-GUN-Admin")
    // newData.append("processingHistory[0][status]", "ALL")
    // newData.append("processingHistory[0][remarks]", "none")
    // newData.append("processingHistory[0][attachements]", "")
    // newData.append("processingHistory[0][applicationTakenDate]", "12/12/2022")
    // newData.append("processingHistory[0][applicationProcessedDate]", "30/12/2022")
    // newData.append("category", data.societyDetails.category)
    // newData.append("generalBodyMeeting", data.societyDetails.generalBodyMeeting)

    // newData.append("doorNo", data.societyDetails.doorNo)
    // newData.append("street", data.societyDetails.street)
    // newData.append("country", "India")
    // newData.append("state", "Andhra Pradesh")
    // newData.append("district", data.societyDetails.district)
    // newData.append("mandal", data.societyDetails.mandal)
    // newData.append("villageOrCity", data.societyDetails.villageOrCity)
    // newData.append("pinCode", data.societyDetails.pinCode)
    newData.append("applicationForm", appDoc)
    newData.append("memorandumAndByeLaws", memorandumAndByeLawsDoc)
    newData.append("membershipDeed", partnerDoc)
    newData.append("affidavit", affidavitDoc)
    newData.append("selfSignedDeclaration", selfDoc)
    if (isCheckFirm && changeFirm.some((x) => x == "Society Name Change")) {
      newData.append("changeName", "true")
      newData.append("societyName", data.societyDetails.societyName)
    } else {
      newData.append("changeName", "false")
    }
    if (changeFirm.some((x) => x == "Add/Delete Member")) {
      newData.append("changeMember", "true")
      for (let j = 0; j < data.membersDetails.length; j++) {
        newData.append(
          "membersDetails[" + j + "][aadharNumber]",
          btoa(data.membersDetails[j].aadharNumber)
        )
        newData.append("membersDetails[" + j + "][memberName]", data.membersDetails[j].memberName)
        newData.append("membersDetails[" + j + "][gender]", data.membersDetails[j].gender)
        newData.append(
          "membersDetails[" + j + "][fatherOrHusbandName]",
          data.membersDetails[j].fatherOrHusbandName
        )
        newData.append("membersDetails[" + j + "][age]", data.membersDetails[j].age)
        newData.append("membersDetails[" + j + "][occupation]", data.membersDetails[j].occupation)
        newData.append("membersDetails[" + j + "][role]", data.membersDetails[j].role)
        newData.append("membersDetails[" + j + "][doorNo]", data.membersDetails[j].doorNo)
        newData.append("membersDetails[" + j + "][street]", data.membersDetails[j].street)
        newData.append("membersDetails[" + j + "][country]", "India")
        newData.append("membersDetails[" + j + "][state]", "Andhra Pradesh")
        newData.append("membersDetails[" + j + "][district]", data.membersDetails[j].district)
        newData.append("membersDetails[" + j + "][mandal]", data.membersDetails[j].mandal)
        newData.append(
          "membersDetails[" + j + "][villageOrCity]",
          data.membersDetails[j].villageOrCity
        )
        newData.append("membersDetails[" + j + "][pinCode]", data.membersDetails[j].pinCode)
      }
    } else {
      newData.append("changeMember", "false")
    }
    if (changeFirm.some((x: string) => x == "Dissolve Society")) {
      newData.append("societyDissolved", "true")
    } else {
      newData.append("societyDissolved", "false")
    }

    updateSocietyDetails(existingSocietyDetail._id, token, newData)
      .then((response: any) => {
        console.log(response)
        setAddSociety(response.data)
        if (isPayNowClicked && data.membersDetails.length > 6) {
          let code = 0
          const dis = districtList?.find(
            (x: { name: string }) => x.name == existingSocietyDetail.district
          )
          if (dis) {
            code = dis.code
          }
          let amount = 0
          if (isCheckFirm && changeFirm.some((x: string) => x == "Society Name Change")) {
            amount = 100
          }
          if (deletedMemCount > 0) {
            amount = amount + deletedMemCount * 100
          }
          if (newMembersDetails.length) {
            amount = amount + newMembersDetails.length * 100
          }
          if (changeFirm.some((x) => x == "Dissolve Society")) {
            amount = 100
          }

          const paymentsData = {
            type: "sra",
            source: "Society",
            deptId: existingSocietyDetail.applicationNumber,
            rmName: existingSocietyDetail.applicantDetails.name,
            rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
            mobile: existingSocietyDetail.contactDetails.mobileNumber,
            email: existingSocietyDetail.contactDetails.email,
            drNumber: code,
            rf: amount,
            uc: 0,
            oc: 0,
            returnURL: process.env.PAYMENT_CALLBACK_URL + "/societies/paymentSuccess",
          }
          let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
          // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
          const encodedData = CryptoJS.AES.encrypt(
            JSON.stringify(paymentsData),
            'igrsSecretPhrase'
          ).toString()
          console.log("ENCODED VALUE IS ", encodedData)
          let paymentLink = document.createElement("a")
          paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
          //paymentLink.target = "_blank";
          paymentLink.click()
          setIsPayNowClicked(false)
          setTimeout(function () {
            paymentLink.remove()
          }, 1000)
        } else {
          const remainingMem = 7 - data.membersDetails.length
          ShowAlert(
            false,
            `Please add ${remainingMem} more member${
              remainingMem == 1 ? "" : "s"
            } to continue payment`
          )
        }
      })
      .catch((error) => {
        console.log("error-", error)
        console.log(error.message)
        setIsError(true)
        setErrorMessage(error.message)
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: error.message,
          showConfirmButton: false,
          timer: 1500,
        })
      })
  }

  return (
    <>
      <Head>
        <title>Amendment of Society</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      <div className={styles.RegistrationMain}>
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between align-items-center page-title mb-3">
                  <div className="pageTitleLeft">
                    <h1>Amendment of Society</h1>
                  </div>
                  {/* <div className="pageTitleRight">
                    <div className="page-header-btns">
                      <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                        Go Back
                      </a>
                    </div>
                  </div> */}
                </div>
              </Col>
            </Row>
          </Container>

          {existingSocietyDetail.status == "Approved" && (
            <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit}>
              <Container>
                <div className="regofAppBg mb-3">
                  <div className="formSectionTitle mb-3">
                    <h3>Applicant Details</h3>
                  </div>

                  <Row>
                    <Col lg={3} md={3} xs={12} className="mb-3">
                      <TableText label="Aadhaar Number" required={true} LeftSpace={false} />
                      <div className="formGroup">
                        {(!applicantDetails.otpStatus ||
                          applicantDetails.otpStatus == "2" ||
                          applicantDetails.otpVerified == "true") && (
                          <div>
                            <input
                              className="form-control"
                              type="text"
                              placeholder="Enter Aadhaar Number"
                              name="maskedAadhar"
                              required={true}
                              disabled={applicantDetails.otpVerified == "true"}
                              onChange={(event) => applicantDetailsChange(event)}
                              value={applicantDetails.maskedAadhar}
                              onKeyPress={onNumberOnlyChange}
                              maxLength={12}
                              onPaste={(e) => e.preventDefault()}
                            />
                            {!applicantDetails.otpStatus && (
                              <button
                                className="verify btn btn-primary"
                                onClick={() => generateApplicantOtp()}
                              >
                                Get OTP
                              </button>
                            )}
                          </div>
                        )}
                        {applicantDetails.otpStatus == "1" &&
                          applicantDetails.otpVerified != "true" && (
                            <div>
                              <Form.Control
                                type="text"
                                placeholder="Enter OTP"
                                name="otpCode"
                                required
                                onChange={(event) => applicantDetailsChange(event)}
                                value={applicantDetails.otpCode}
                                onKeyPress={onNumberOnlyChange}
                              />
                              <button
                                className="verify btn btn-primary"
                                onClick={() => verifyApplicantOtp()}
                              >
                                Verify
                              </button>
                            </div>
                          )}
                      </div>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Application Number" required={true} LeftSpace={false} />
                      <TableInputText
                        disabled={true}
                        type="text"
                        placeholder="Application Number"
                        required={true}
                        name={"applicationNumber"}
                        value={applicantDetails.applicationNumber}
                        onChange={applicantDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Name" required={true} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Name"
                        required={true}
                        name={"name"}
                        value={applicantDetails.name}
                        onChange={applicantDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Gender" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="gender"
                        defaultValue={applicantDetails.gender}
                        onChange={applicantDetailsChange}
                        value={applicantDetails.gender}
                      >
                        <option>Select</option>
                        {genderList.map((item: any, i: number) => {
                          return (
                            <option key={i + 1} value={item}>
                              {item}
                            </option>
                          )
                        })}
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Door No" required={true} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Door No"
                        required={true}
                        name={"doorNo"}
                        value={applicantDetails.doorNo}
                        onChange={applicantDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Street" required={true} LeftSpace={false} />
                      <TableInputText
                        disabled={false}
                        type="text"
                        placeholder="Enter Street"
                        required={true}
                        name={"street"}
                        value={applicantDetails.street}
                        onChange={applicantDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Country" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="country"
                        onChange={applicantDetailsChange}
                        value={applicantDetails.country}
                        disabled={true}
                      >
                        <option>India</option>
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="State" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="state"
                        onChange={applicantDetailsChange}
                        value={applicantDetails.state}
                        disabled={true}
                      >
                        <option>Andhra Pradesh</option>
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="District" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="applicantDistrict"
                        onChange={(event) => {
                          districtChange(event)
                          applicantDetailsChange(event)
                        }}
                        value={applicantDetails.applicantDistrict}
                      >
                        <option>Select</option>
                        {districtList.map((item: any, i: number) => {
                          return (
                            <option key={i + 1} value={item.name}>
                              {item.name}
                            </option>
                          )
                        })}
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Mandal" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="applicantMandal"
                        defaultValue={"Select"}
                        onChange={(event) => {
                          mandalChange(event)
                          applicantDetailsChange(event)
                        }}
                        value={applicantDetails.applicantMandal}
                      >
                        <option>Select</option>
                        <DynamicMandals currentDistrict={currentDistrict}></DynamicMandals>
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="VillageOrCity" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="applicantVillageOrCity"
                        onChange={applicantDetailsChange}
                        defaultValue={"Select"}
                        value={applicantDetails.applicantVillageOrCity}
                      >
                        <option>Select</option>
                        <DynamicVillages
                          currentDistrict={currentDistrict}
                          currentMandal={currentMandal}
                        ></DynamicVillages>
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="PIN Code" required={true} LeftSpace={false} />
                      <Form.Control
                        disabled={false}
                        type="text"
                        maxLength={6}
                        placeholder="Enter PIN Code"
                        required={true}
                        name={"pinCode"}
                        value={applicantDetails.pinCode}
                        onChange={applicantDetailsChange}
                        onKeyPress={onNumberOnlyChange}
                      />
                    </Col>
                  </Row>
                </div>

                <div className="firmChangeboxes mb-3">
                  <div className="formSectionTitle">
                    <h3>
                      Please Select Type of Change in Society<span>*</span>
                    </h3>
                  </div>

                  <Row>
                    <Col lg={12} md={12} xs={12}>
                      <div className="firmChangeList">
                        <Form.Check
                          inline
                          label="Society Name Change"
                          value="Society Name Change"
                          name="changeFirm"
                          type="checkbox"
                          className="fom-checkbox"
                          checked={changeFirm.some((x) => x == "Society Name Change")}
                          onChange={(e) => {
                            if (e.target.checked) {
                              let change:any = []
                              if (changeFirm.some((x) => x == "Add/Delete Member")) {
                                change.push("Add/Delete Member")
                              }
                              setChangeFirm([...change, e.target.value])
                            } else {
                              let change:any = []
                              if (changeFirm.some((x) => x == "Add/Delete Member")) {
                                change.push("Add/Delete Member")
                              }
                              setChangeFirm([...change])
                            }
                          }}
                        />
                        <Form.Check
                          inline
                          label="Add/Delete Member"
                          value="Add/Delete Member"
                          name="changeFirm"
                          type="checkbox"
                          className="fom-checkbox"
                          checked={changeFirm.some((x) => x == "Add/Delete Member")}
                          onChange={(e) => {
                            if (e.target.checked) {
                              let change:any = []
                              if (changeFirm.some((x) => x == "Society Name Change")) {
                                change.push("Society Name Change")
                              }
                              setChangeFirm([...change, e.target.value])
                            } else {
                              let change:any = []
                              if (changeFirm.some((x) => x == "Society Name Change")) {
                                change.push("Society Name Change")
                              }
                              setChangeFirm([...change])
                            }
                          }}
                        />
                        <Form.Check
                          inline
                          label="Dissolve Society"
                          value="Dissolve Society"
                          name="changeFirm"
                          type="checkbox"
                          className="fom-checkbox"
                          checked={changeFirm.some((x) => x == "Dissolve Society")}
                          onChange={(e) => {
                            let change:any = []
                            if (e.target.checked) {
                              change.push("Dissolve Society")
                              setChangeFirm([...change])
                            } else {
                              setChangeFirm([])
                            }
                          }}
                        />
                      </div>
                    </Col>
                  </Row>
                </div>

                {changeFirm.some((x) => x == "Society Name Change") && (
                  <div className="FirmSecNew mb-3">
                    <div className="uploadFirmList">
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <h3>Society Name Change</h3>
                        </Col>
                      </Row>
                    </div>

                    <div className="regofAppBg">
                      <Row>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <Form.Group>
                            <TableText label="New Name" required={true} LeftSpace={false} />
                            <div className="formGroup">
                              <input
                                className="form-control"
                                type="text"
                                maxLength={50}
                                required={true}
                                placeholder="Enter New Name"
                                name="societyName"
                                onChange={societyDetailsChange}
                                value={societyDetails.societyName}
                              />
                              <div
                                onClick={checkFirmDB}
                                className="Check Society Availability verify btn btn-primary"
                              >
                                Check Availability
                              </div>
                            </div>
                          </Form.Group>
                        </Col>
                      </Row>
                    </div>
                  </div>
                )}

                {changeFirm.some((x) => x == "Add/Delete Member") && (
                  <div className="currentPartnerSec mb-3">
                    <div className="formSectionTitle mb-3">
                      <h3>Current EC Member Details</h3>
                    </div>

                    <div className="currentPartnersTable">
                      <Row className="mb-4">
                        <Col lg={12} md={12} xs={12}>
                          <Table striped bordered className="tableData">
                            <thead>
                              <tr>
                                <th>S.No</th>
                                <th>Member Name</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Role</th>
                                <th>Delete</th>
                              </tr>
                            </thead>
                            <tbody>
                              {membersDetails.map((item: any, i: number) => {
                                return (
                                  <tr>
                                    <td>{i + 1}</td>
                                    <td>{item.memberName}</td>
                                    <td>{item.age}</td>
                                    <td>{item.gender}</td>
                                    <td>{item.role}</td>
                                    <td>
                                      <Button onClick={() => handleDeleteMemberRemove(i)}>
                                        Delete
                                      </Button>
                                    </td>
                                  </tr>
                                )
                              })}
                            </tbody>
                          </Table>
                        </Col>
                      </Row>
                    </div>
                  </div>
                )}

                {changeFirm.some((x) => x == "Add/Delete Member") &&
                  newMembersDetails.map((form: any, index: number) => {
                    return (
                      <>
                        <div className="regofAppBg mb-3" key={index}>
                          <Row className="membersDetailsList d-flex align-items-center mb-3">
                            <Col className="">
                              <div className="formSectionTitle">
                                <h3>{`Member ${index + 1}`}</h3>
                              </div>
                            </Col>
                            <Col className="text-end">
                              <div
                                onClick={() => handleMemberRemove(index)}
                                className="btn btn-secondary addPartner"
                              >
                                Remove
                              </div>
                            </Col>
                          </Row>
                          <Row>
                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <Form.Group>
                                <TableText
                                  label="Aadhaar Number"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <div className="formGroup">
                                  {(!form.otpStatus ||
                                    form.otpStatus == "2" ||
                                    form.otpVerified == "true") && (
                                    <div>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter Aadhaar Number"
                                        name="maskedAadhar"
                                        required={true}
                                        disabled={form.otpVerified == "true"}
                                        onChange={(event) => membersDetailsChange(event, index)}
                                        value={form.maskedAadhar}
                                        maxLength={12}
                                        onKeyPress={onNumberOnlyChange}
                                        onPaste={(e) => e.preventDefault()}
                                      />
                                      {!form.otpStatus && (
                                        <button
                                          className="verify btn btn-primary"
                                          onClick={() => generateOtp(index)}
                                        >
                                          Get OTP
                                        </button>
                                      )}
                                    </div>
                                  )}
                                  {form.otpStatus == "1" && form.otpVerified != "true" && (
                                    <div>
                                      <Form.Control
                                        type="text"
                                        placeholder="Enter OTP"
                                        name="otpCode"
                                        required
                                        onChange={(event) => membersDetailsChange(event, index)}
                                        value={form.otpCode}
                                        onKeyPress={onNumberOnlyChange}
                                      />
                                      <button
                                        className="verify btn btn-primary"
                                        onClick={() => verifyOtp(index)}
                                      >
                                        Verify
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </Form.Group>
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <Form.Group>
                                <TableText label="Name" required={true} LeftSpace={false} />
                                <input
                                  className="form-control"
                                  name="memberName"
                                  required={true}
                                  placeholder="Enter Name"
                                  onChange={(event) => membersDetailsChange(event, index)}
                                  value={form.memberName}
                                />
                              </Form.Group>
                            </Col>
                            <Col lg={2} md={2} xs={12} className="mb-3">
                              <Form.Group>
                                <TableText
                                  label="Father / Husband Name"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <input
                                  className="form-control"
                                  name="fatherOrHusbandName"
                                  required={true}
                                  placeholder="Enter Father / Husband Name"
                                  onChange={(event) => membersDetailsChange(event, index)}
                                  value={form.fatherOrHusbandName}
                                />
                              </Form.Group>
                            </Col>
                            <Col lg={2} md={2} xs={12} className="mb-3">
                              <Form.Group>
                                <TableText label="Gender" required={true} LeftSpace={false} />
                                <select style={{ textTransform: 'uppercase' }}
                                  className="form-control"
                                  name="gender"
                                  required={true}
                                  onChange={(event) => membersDetailsChange(event, index)}
                                  value={form.gender}
                                >
                                  <option>Select</option>
                                  {genderList.map((item: any, i: number) => {
                                    return (
                                      <option key={i + 1} value={item}>
                                        {item}
                                      </option>
                                    )
                                  })}
                                </select>
                              </Form.Group>
                            </Col>

                            <Col lg={2} md={2} xs={12} className="mb-3">
                              <Form.Group>
                                <TableText label="Age" required={true} LeftSpace={false} />
                                <input
                                  className="form-control"
                                  name="age"
                                  required={true}
                                  placeholder="Enter Age"
                                  onChange={(event) => membersDetailsChange(event, index)}
                                  value={form.age}
                                  onKeyPress={onNumberOnlyChange}
                                  type="text"
                                />
                              </Form.Group>
                            </Col>
                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <Form.Group>
                                <TableText label="Occupation" required={true} LeftSpace={false} />
                                <input
                                  required={true}
                                  className="form-control"
                                  name="occupation"
                                  placeholder="Enter Occupation"
                                  onChange={(event) => membersDetailsChange(event, index)}
                                  value={form.occupation}
                                />
                              </Form.Group>
                            </Col>

                            <Col lg={3} md={2} xs={12} className="mb-3">
                              <Form.Group>
                                <TableText label="Role" required={true} LeftSpace={false} />
                                <select style={{ textTransform: 'uppercase' }}
                                  className="form-control"
                                  name="role"
                                  required={true}
                                  onChange={(event) => membersDetailsChange(event, index)}
                                  value={form.role}
                                >
                                  <option>Select</option>
                                  {roleList.map((item: any, i: number) => {
                                    return (
                                      <option key={i + 1} value={item}>
                                        {item}
                                      </option>
                                    )
                                  })}
                                </select>
                              </Form.Group>
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="Door No" required={true} LeftSpace={false} />
                              <TableInputText
                                disabled={false}
                                type="text"
                                placeholder="Enter Door No"
                                required={true}
                                name={"doorNo"}
                                onChange={(event: any) => membersDetailsChange(event, index)}
                                value={form.doorNo}
                              />
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="Street" required={true} LeftSpace={false} />
                              <TableInputText
                                disabled={false}
                                type="text"
                                placeholder="Enter Street"
                                required={true}
                                name={"street"}
                                onChange={(event: any) => membersDetailsChange(event, index)}
                                value={form.street}
                              />
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="Country" required={true} LeftSpace={false} />
                              <select style={{ textTransform: 'uppercase' }}
                                className="form-control"
                                name="country"
                                onChange={(event: any) => membersDetailsChange(event, index)}
                                value={form.country}
                                disabled={true}
                              >
                                <option>India</option>
                              </select>
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="State" required={true} LeftSpace={false} />
                              <select style={{ textTransform: 'uppercase' }}
                                className="form-control"
                                name="state"
                                onChange={(event: any) => membersDetailsChange(event, index)}
                                value={form.state}
                                disabled={true}
                              >
                                <option>Andhra Pradesh</option>
                              </select>
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="District" required={true} LeftSpace={false} />
                              <select style={{ textTransform: 'uppercase' }}
                                className="form-control"
                                name="district"
                                onChange={(event) => membersDetailsChange(event, index)}
                                value={form.district}
                              >
                                <option>Select</option>
                                {districtList.map((item: any, i: number) => {
                                  return (
                                    <option key={i + 1} value={item.name}>
                                      {item.name}
                                    </option>
                                  )
                                })}
                              </select>
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="Mandal" required={true} LeftSpace={false} />
                              <select style={{ textTransform: 'uppercase' }}
                                className="form-control"
                                name="mandal"
                                id={`mandal${index}`}
                                placeholder="Mandal"
                                onChange={(event: any) => membersDetailsChange(event, index)}
                                value={form.mandal}
                                defaultValue={"Select"}
                              >
                                <option>Select</option>
                                <DynamicMandals currentDistrict={form.district}></DynamicMandals>
                              </select>
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="VillageOrCity" required={true} LeftSpace={false} />
                              <select style={{ textTransform: 'uppercase' }}
                                className="form-control"
                                name="villageOrCity"
                                id={`villageOrCity${index}`}
                                placeholder="Village/City"
                                onChange={(event: any) => membersDetailsChange(event, index)}
                                value={form.villageOrCity}
                                defaultValue={"Select"}
                              >
                                <option>Select</option>
                                <DynamicVillages
                                  currentDistrict={form.district}
                                  currentMandal={form.mandal}
                                ></DynamicVillages>
                              </select>
                            </Col>

                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <TableText label="PIN Code" required={true} LeftSpace={false} />
                              <Form.Control
                                disabled={false}
                                type="text"
                                maxLength={6}
                                placeholder="Enter PIN Code"
                                required={true}
                                name={"pinCode"}
                                onChange={(event: any) => membersDetailsChange(event, index)}
                                value={form.pinCode}
                                onKeyPress={onNumberOnlyChange}
                              />
                            </Col>
                          </Row>
                        </div>
                      </>
                    )
                  })}

                {changeFirm.some((x) => x == "Add/Delete Member") && (
                  <Row>
                    <Col lg={12} md={12} xs={12} className="mb-4">
                      <div className="addotherBtnInfo text-center">
                        <div onClick={handleMemberAdd} className="btn btn-primary addPartner">
                          Add Member
                        </div>
                      </div>
                    </Col>
                  </Row>
                )}

                <div className="uploadFirmList appDocList mb-4">
                  <Row>
                    <Col lg={12} md={12} xs={12}>
                      <h3>
                        Upload Society Related Documents-(All Uploaded Documents should be in PDF
                        format only upto 5MB )
                      </h3>
                    </Col>
                  </Row>

                  <div className="firmFileStep1">
                    <Row>
                      <Col lg={2} md={4} xs={12}>
                        <div className="firmFile">
                          <Form.Group controlId="formFile">
                            <Form.Label>
                              Application Form <span>*</span> :{" "}
                            </Form.Label>
                            <Form.Control
                              type="file"
                              id="applicationForm"
                              name="applicationForm"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </Form.Group>
                        </div>
                      </Col>

                      <Col lg={2} md={4} xs={12}>
                        <div className="firmFile">
                          <Form.Group controlId="formFile">
                            <Form.Label>
                              Memorandum and ByeLaws <span>*</span> :{" "}
                            </Form.Label>
                            <Form.Control
                              type="file"
                              id="memorandumAndByeLaws"
                              name="memorandumAndByeLaws"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </Form.Group>
                        </div>
                      </Col>

                      <Col lg={2} md={4} xs={12}>
                        <div className="firmFile">
                          <Form.Group controlId="formFile">
                            <Form.Label>
                              Membership Deed <span>*</span> :{" "}
                            </Form.Label>
                            <Form.Control
                              type="file"
                              id="membershipDeed"
                              name="membershipDeed"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </Form.Group>
                        </div>
                      </Col>

                      <Col lg={2} md={6} xs={12}>
                        <div className="firmFile">
                          <Form.Group controlId="formFile">
                            <Form.Label>
                              Lease Deed or Affidavit <span>*</span> :{" "}
                            </Form.Label>
                            <Form.Control
                              type="file"
                              id="affidavit"
                              name="affidavit"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </Form.Group>
                        </div>
                      </Col>

                      <Col lg={2} md={4} xs={12}>
                        <div className="firmFile">
                          <Form.Group controlId="formFile">
                            <Form.Label>
                              Self Signed Declaration <span>*</span> :{" "}
                              <a
                                href="/assets/downloads/Societies-Self-Signed-Certificate.pdf"
                                target="_blank"
                              >
                                <img src="/assets/pdf_symbol.jpg" />
                              </a>
                            </Form.Label>
                            <Form.Control
                              type="file"
                              id="selfSignedDeclaration"
                              name="selfSignedDeclaration"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </Form.Group>
                        </div>
                      </Col>
                    </Row>
                  </div>
                </div>

                <Row>
                  <Col lg={12} md={12} xs={12} className="text-center">
                    <Button
                      variant="primary"
                      type="submit"
                      onClick={() => setIsPayNowClicked(true)}
                    >
                      Pay now
                    </Button>
                  </Col>
                </Row>
              </Container>
            </Form>
          )}
          {existingSocietyDetail.status == "Incomplete" && (
            <Col lg={12} md={12} xs={12}>
              <div className="d-flex justify-content-between pagesubmitSecTitle mb-3">
                <div className="ms-2">
                  <h2>
                    Your application is pending.{" "}
                    <a href="/societies" style={{ color: "blue" }}>
                      click here
                    </a>{" "}
                    to check application status
                  </h2>
                </div>
              </div>
            </Col>
          )}

          {existingSocietyDetail.status != "Incomplete" &&
            existingSocietyDetail.status != "Approved" &&
            existingSocietyDetail.status != "Rejected" && (
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between pagesubmitSecTitle mb-3">
                  <div className="ms-2">
                    <h2>
                      Your application was submitted.{" "}
                      <a href="/societies" style={{ color: "blue" }}>
                        click here
                      </a>{" "}
                      to check application status
                    </h2>
                  </div>
                </div>
              </Col>
            )}
        </div>
      </div>
    </>
  )
}
