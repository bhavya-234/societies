import { useState, useEffect } from "react"
import Head from "next/head"
import { useRouter } from "next/router"
import { Container, Col, Row, Table, Form } from "react-bootstrap"
import api from "@/pages/api/api"
import Swal from "sweetalert2"
import { DefaceTransactionDetails, getSocietyDetails, VerifyTransactionDetails } from "@/axios"
import { useAppDispatch } from "@/hooks/reduxHooks"
import { PopupAction } from "@/redux/commonSlice"
import { get } from "lodash"
import instance from "@/redux/api"
import CryptoJS from "crypto-js"
import { DateFormator, Loading } from "@/GenericFunctions"

interface ViewHistoryProps {
  reqsearchdata: any
  selectedRequest: any
  setReqSearchData: any
  setIsView: any
  setIsError: any
  setErrorMessage: any
  appId: string
  setViewHistory: any
}

const ViewHistory = ({
  reqsearchdata,
  selectedRequest,
  setReqSearchData,
  setIsView,
  setIsError,
  setErrorMessage,
  appId,
  setViewHistory,
}: ViewHistoryProps) => {
  const router = useRouter()
  const dispatch = useAppDispatch()

  const [firmPartners, setFirmPartners] = useState<any>([])
  const [firmProcessing, setFirmProcessing] = useState<any>([])
  const [isTransVerified, SetIsTransVerified] = useState<boolean>(false)
  const [isTransDefaced, setIsTransDefaced] = useState<boolean>(false)
  const [transactionDetails, setTransactionDetails] = useState<any>({})
  const [userType, setUserType] = useState<string>("")
  const [role, setRole] = useState<string>("")
  const [token, setToken] = useState<string>("")
  const [isViewCertificate, setIsViewCertificate] = useState<boolean>(false)
  const [existingSocietyDetails, setExistingSocietyDetails] = useState<any>({})
  const [locData, setLocData] = useState<any>({})

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
     if(data&&data?.token!=""){
    if (data.role == "DR") {
    
      api
        .get("/getPaymentDetails/" + selectedRequest.applicationNumber, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${data.token}`,
          },
        })
        .then((response: any) => {
          if (!response || !response.data || !response.data.success) {
            console.log("error-", response.data.message)
            console.log(response.data.message)
            setIsError(true)
            loadDocs(response.data.daSociety)
            setErrorMessage(response.data.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: response.data.message,
              showConfirmButton: false,
              timer: 1500,
            })
          } else {
            setTransactionDetails(response.data.data.paymentDetails)
            if (response.data.data.paymentDetails.isUtilized) {              
              // if (response.data.data.paymentDetails?.isUtilized &&selectedRequest[`societyFields`].district==response.data.data?.paymentDetails?.district){              
              SetIsTransVerified(true)
              setIsTransDefaced(true)
            }
          }
        })
        .catch((error) => {
          console.log("error-", error)
          console.log(error.message)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: error.message,
            showConfirmButton: false,
            timer: 1500,
          })
        })
    }}
  }, [])

  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data?.token) {
    setLocData(data)  
    setUserType(data.userType)
    setRole(data.role)
    setToken(data.token)
    getSocietyDetails(appId, data.token).then((response) => {
      loadDocs(response.data.daSociety)
      setExistingSocietyDetails(response.data.daSociety)
      Loading(false)
    })
    // const processingData = [
    //   {
    //     designation: `DLF-AS-GUN-ADMIN`,
    //     status: `Forwarded BY DLS`,
    //     remarks: `Madam, I Verified Found Correct and Submitted for Approval`,
    //     attachments: `N/A`,
    //     applicationTakenDate: `04/02/2023 10:41:06`,
    //     applicationProcessedDate: `04/02/2023 10:41:06`,
    //   },
    // ]
    // setFirmProcessing(processingData)
  }
  }, [])

  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }

  const verifyTransacDetails = async () => {
    let result: any = await VerifyTransactionDetails({
      deptTransactionID: btoa(transactionDetails.departmentTransID),
    })
    if (result.status && result.status === "Success") {
      ShowAlert(true, "Tansaction details are verified Successfully")
      SetIsTransVerified(true)
    } else {
      ShowAlert(false, get(result, "message", "Tansaction details verification Failed"))
    }
  }

  const defaceTransacDetails = async () => {
    let result: any = await DefaceTransactionDetails({
      deptTransactionID: btoa(transactionDetails.departmentTransID),
    })
    if (result.status && result.status === "Success") {
      api
        .post("/confirmDephaseTransaction/" + transactionDetails.departmentTransID, null, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
        })
        .then((response: any) => {
          if (!response || !response.data || !response.data.success) {
            console.log("error-", response.data.message)
            console.log(response.data.message)
            setIsError(true)
            setErrorMessage(response.data.message)
            Swal.fire({
              icon: "error",
              title: "Error!",
              text: response.data.message,
              showConfirmButton: false,
              timer: 1500,
            })
          } else {
            setIsTransDefaced(true)
            Swal.fire({
              icon: "success",
              title: "Success!",
              text: "Succesfully Defaced",
              showConfirmButton: false,
              timer: 1500,
            })
          }
        })
        .catch((error) => {
          console.log("error-", error)
          console.log(error.message)
          setIsError(true)
          setErrorMessage(error.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: error.message,
            showConfirmButton: false,
            timer: 1500,
          })
        })
    } else {
      ShowAlert(false, get(result, "message", "Tansaction deface Failed"))
    }
  }

  // const docLink = async (name: string, index: number) => {
  //   const url = `/downloads/${selectedRequest.applicantFields.id}/${name}`
  //   instance.get(url, { responseType: "arraybuffer" }).then((res) => {
  //     const url = window.URL.createObjectURL(new Blob([res.data], { type: "application/pdf" }))
  //     var link: any = document.getElementById(`docFile${index}`)
  //     if (link) {
  //       link.href = url
  //     }
  //   })
  // }
  const docLink = async (name: any, index: number, path: any,id:any) => {
    let url = ""
    // `/downloads/${selectedRequest.firmFields.firmId}/${name}`
    url = `/downloads/${id}/${name}`
    if (path.split("/")[2] == 0) {
      url = `/downloads/${path.split("/")[2]}/${name}`
    }
    const res = await api.get(url, { responseType: "arraybuffer" })
    const urls = window.URL.createObjectURL(new Blob([res.data], { type: "application/pdf" }))
    var link: any = document.getElementById(`docFile${index}`)
    if (link) {
      link.href = urls
    }
  }
  const loadDocs = async (data:any) => {
    if (selectedRequest?.documentAttached?.length > 0) {
      selectedRequest?.documentAttached.forEach(async (document: any, index: number) => {
        await docLink(document?.originalname, index, document?.path,data._id)
      })
    }
  }
  const handleSubmit = (e: any) => {
    e.preventDefault()
    const remarks: any = document.getElementById("remarks")
    const actionTaken: any = document.getElementById("actionTaken")
    let remarksData: any = {
      remarks: remarks.value,
    }
    if (role == "DR") {
      remarksData.status = actionTaken.value
    }

    api
      .put("/societies/remarks/" + selectedRequest.societyFields.societyId, remarksData, {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response: any) => {
        if (!response || !response.data || !response.data.success) {
          console.log("error-", response.data.message)
          console.log(response.data.message)
          setIsError(true)
          setErrorMessage(response.data.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: response.data.message,
            showConfirmButton: false,
            timer: 1500,
          })
        } else {
          Swal.fire({
            icon: "success",
            title: "Success!",
            text: "Succesfully Added Remarks",
            showConfirmButton: false,
            timer: 1500,
          })
          setTimeout(() => {
            setIsView(false)
          }, 1500)
        }
      })
      .catch((error) => {
        console.log("error-", error)
        console.log(error.message)
        setIsError(true)
        setErrorMessage(error.message)
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: error.message,
          showConfirmButton: false,
          timer: 1500,
        })
      })
  }

  const sendSms = (e: any) => {
    e.preventDefault()
    const applicantMessage: any = document.getElementById("applicantMessage")
    let smsdata: any = {
      message: applicantMessage.value,
    }
    api
      .put("/societies/sendSMS/" + selectedRequest.societyFields.societyId, smsdata, {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response: any) => {
        if (!response || !response.data || !response.data.success) {
          console.log("error-", response.data.message)
          console.log(response.data.message)
          setIsError(true)
          setErrorMessage(response.data.message)
          Swal.fire({
            icon: "error",
            title: "Error!",
            text: response.data.message,
            showConfirmButton: false,
            timer: 1500,
          })
        } else {
          Swal.fire({
            icon: "success",
            title: "Success!",
            text: "SMS Sent Succesfully",
            showConfirmButton: false,
            timer: 1500,
          })
        }
      })
      .catch((error) => {
        console.log("error-", error)
        console.log(error.message)
        setIsError(true)
        setErrorMessage(error.message)
        Swal.fire({
          icon: "error",
          title: "Error!",
          text: error.message,
          showConfirmButton: false,
          timer: 1500,
        })
      })
  }

  return (
    <>
      {!isViewCertificate && (
        <>
          <Head>
            <title>Registration of Society</title>
            <link rel="icon" href="/igrsfavicon.ico" />
          </Head>
          {locData && locData?.userType && locData?.userType != "user" && (
            <div className="societyRegSec">
              <Container>
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <div className="d-flex justify-content-between align-items-center page-title mb-3">
                      <div className="pageTitleLeft">
                        <h1>Registration of Society</h1>
                      </div>
                      <div className="pageTitleRight">
                        <div className="page-header-btns">
                          <a
                            className="btn btn-secondary new-user"
                            onClick={() => setViewHistory(false)}
                          >
                            Go Back
                          </a>
                        </div>
                      </div>
                    </div>
                  </Col>
                </Row>
              </Container>

              <div className="dataPrevSec">
                <Form className="formsec" onSubmit={handleSubmit}>
                  <Container>
                    {/* {selectedRequest[`userFields1`] && (
                      <Row>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <div className="form-group">
                            <label className="form-label">User ID</label>
                            <div className="valuePrev">{selectedRequest[`userFields`].userId}</div>
                          </div>
                        </Col>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <div className="form-group">
                            <label className="form-label">Portal User Name</label>
                            <div className="valuePrev">
                              {selectedRequest[`userFields`].portaluserName}
                            </div>
                          </div>
                        </Col>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <div className="form-group">
                            <label className="form-label">Operator Name</label>
                            <div className="valuePrev">
                              {selectedRequest[`userFields`].operatorName}
                            </div>
                          </div>
                        </Col>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <div className="form-group">
                            <label className="form-label">Mobile No</label>
                            <div className="valuePrev">
                              {selectedRequest[`userFields`].mobileNo}
                            </div>
                          </div>
                        </Col>
                      </Row>
                    )} */}

                    <div className="regofAppBg mb-3">
                      {selectedRequest[`applicantDetails`] && (
                        <div className="firmApplicationSec">
                          <div className="formSectionTitle">
                            <h3>Applicant Details</h3>
                          </div>

                          <Row>
                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Application Number</label>
                                <div className="valuePrev">{selectedRequest.applicationNumber}</div>
                              </div>
                            </Col>
                            <Col lg={3} md={3} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Name</label>
                                <div className="valuePrev">
                                  {selectedRequest[`applicantDetails`].name}
                                </div>
                              </div>
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Email ID</label>
                                <div className="valuePrev">
                                  {selectedRequest[`applicantDetails`].email}
                                </div>
                              </div>
                            </Col>
                            <Col lg={2} md={3} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Gender</label>
                                <div className="valuePrev">
                                  {selectedRequest[`applicantDetails`].gender}
                                </div>
                              </div>
                            </Col>
                          </Row>

                          <Row>
                          <Col lg={3} md={4} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Mobile No</label>
                                <div className="valuePrev">
                                  {selectedRequest[`applicantDetails`].mobileNumber}
                                </div>
                              </div>
                            </Col>
                            <Col lg={9} md={4} xs={12}>
                              <div className="form-group">
                                <label className="form-label">Address</label>
                                <div className="valuePrev">
                                  {selectedRequest[`applicantDetails`].doorNo}
                                  {selectedRequest[`applicantDetails`].street && (
                                    <span> / {selectedRequest[`applicantDetails`].street}</span>
                                  )}
                                  {selectedRequest[`applicantDetails`].villageCity && (
                                    <span>
                                      {" "}
                                      / {selectedRequest[`applicantDetails`].villageCity}
                                    </span>
                                  )}
                                  {selectedRequest[`applicantDetails`].mandal && (
                                    <span> / {selectedRequest[`applicantDetails`].mandal}</span>
                                  )}
                                  {selectedRequest[`applicantDetails`].district && (
                                    <span> / {selectedRequest[`applicantDetails`].district}</span>
                                  )}
                                  {selectedRequest[`applicantDetails`].state && (
                                    <span> / {selectedRequest[`applicantDetails`].state}</span>
                                  )}
                                  {selectedRequest[`applicantDetails`].country && (
                                    <span> / {selectedRequest[`applicantDetails`].country}</span>
                                  )}
                                  {selectedRequest[`applicantDetails`].pinCode && (
                                    <span> / {selectedRequest[`applicantDetails`].pinCode}</span>
                                  )}
                                </div>
                              </div>
                            </Col>

                            {/* <Col lg={3} md={4} xs={12} className="mb-3">
                            <div className="form-group">
                              <label className="form-label">Landline Phone No</label>
                              <div className="valuePrev">
                                {selectedRequest[`contactDetails`].contactPhone}
                              </div>
                            </div>
                          </Col> */}
                           
                            {/* <Col lg={2} md={4} xs={12} className="mb-3">
                            <div className="form-group">
                              <label className="form-label">Fax</label>
                              <div className="valuePrev">
                                {selectedRequest[`contactDetails`].fax}
                              </div>
                            </div>
                          </Col> */}
                          </Row>
                        </div>
                      )}
                    </div>
                    <div className="regofAppBg mb-3">
                      {selectedRequest && (
                        <div className="firmApplicationSec">
                          <div className="formSectionTitle">
                            <h3>Society Details</h3>
                          </div>

                          <Row>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Society Name</label>
                                <div className="valuePrev">{selectedRequest.societyName}</div>
                              </div>
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Society Category</label>
                                <div className="valuePrev">{selectedRequest.category}</div>
                              </div>
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Aim</label>
                                <div className="valuePrev">{selectedRequest.aim}</div>
                              </div>
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Objective</label>
                                <div className="valuePrev">{selectedRequest.objective}</div>
                              </div>
                            </Col>
                            <Col lg={3} md={4} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">General Body Meeting</label>
                                <div className="valuePrev">
                                  {selectedRequest.generalBodyMeeting}
                                </div>
                              </div>
                            </Col>

                            <Col lg={9} md={12} xs={12} className="mb-3">
                              <div className="form-group">
                                <label className="form-label">Address</label>
                                <div className="valuePrev">
                                  {selectedRequest.doorNo}
                                  {selectedRequest.street && (
                                    <span> / {selectedRequest.street}</span>
                                  )}
                                  {selectedRequest.villageCity && (
                                    <span> / {selectedRequest.villageCity}</span>
                                  )}
                                  {selectedRequest.mandal && (
                                    <span> / {selectedRequest.mandal}</span>
                                  )}
                                  {selectedRequest.district && (
                                    <span> / {selectedRequest.district}</span>
                                  )}
                                  {selectedRequest.state && <span> / {selectedRequest.state}</span>}
                                  {selectedRequest.country && (
                                    <span> / {selectedRequest.country}</span>
                                  )}
                                  {selectedRequest.pinCode && (
                                    <span> / {selectedRequest.pinCode}</span>
                                  )}
                                </div>
                              </div>
                            </Col>
                          </Row>
                        </div>
                      )}
                    </div>

                    <div className="firmPartnerSec tableSec mb-3">
                      <div className="formSectionTitle">
                        <h3>EC Member Details</h3>
                      </div>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <Table striped bordered className="tableData listData">
                            <thead>
                              <tr>
                                {/* <th className="siNo text-center">SI No</th> */}
                                <th>Name</th>
                                <th>Age</th>
                                <th>Role</th>
                                <th>Address</th>
                              </tr>
                            </thead>

                            {selectedRequest[`memberDetails`].length > 0 ? (
                              <tbody>
                                {selectedRequest[`memberDetails`].map((item: any, i: number) => {
                                  return (
                                   
                                    <tr key={i + 1}>
                                      {/* <td className="siNo text-center">{i + 1}</td> */}
                                      <td>{item.memberName}</td>
                                      <td>{item.age}</td>
                                      <td>{item.role}</td>
                                      <td>
                                        {item.doorNo}
                                        {item.street && <span> / {item.street}</span>}
                                        {item.villageCity && <span> / {item.villageCity}</span>}
                                        {item.mandal && <span> / {item.mandal}</span>}
                                        {item.district && <span> / {item.district}</span>}
                                        {item.state && <span> / {item.state}</span>}
                                        {item.country && <span> / {item.country}</span>}
                                        {item.pinCode && <span> / {item.pinCode}</span>}
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            ) : (
                              <tbody>
                                <tr>
                                  <td colSpan={6}>No Members Found</td>
                                </tr>
                              </tbody>
                            )}
                          </Table>
                        </Col>
                      </Row>
                    </div>
                    <div className="firmApplicationSec mb-3">
                      <div className="formSectionTitle mb-3">
                        <h3>Documents Attached</h3>
                      </div>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <ul>
                            {selectedRequest.documentAttached.length > 0 &&
                              selectedRequest?.documentAttached &&
                              selectedRequest?.documentAttached?.map(
                                (document: any, index: number) => {
                                  return (
                                    <li key={index + 1}>
                                      <a id={`docFile${index}`} target="_blank">
                                        {document?.originalname}
                                      </a>
                                    </li>
                                  )
                                }
                              )}
                          </ul>
                        </Col>
                      </Row>
                    </div>
                    {/* <div className="firmApplicationSec mb-3">
                      <div className="formSectionTitle mb-3">
                        <h3>Documents Attached</h3>
                      </div>

                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <ul>
                            {selectedRequest?.documentAttached?.map(
                              (document: any, index: number) => {
                                return (
                                  <li key={index + 1}>
                                    <a
                                      id={`docFile${index}`}
                                      onClick={() => docLink(document?.originalname, index)}
                                      target="_blank"
                                    >
                                      {document?.originalname}
                                    </a>
                                  </li>
                                )
                              }
                            )}
                          </ul>
                        </Col>
                      </Row>
                    </div> */}

                    {userType != "user" && (
                      <div className="firmPartnerSec tableSec mb-3">
                        <div className="formSectionTitle">
                          <h3>Processing History</h3>
                        </div>
                        <Row>
                          <Col lg={12} md={12} xs={12}>
                            <Table striped bordered className="tableData listData">
                              <thead>
                                <tr>
                                  {/* <th className="siNo text-center">SI No</th> */}
                                  <th>Designation</th>
                                  <th>Status</th>
                                  <th>Remarks</th>
                                  <th>Application Type</th>
                                  <th>Application taken Date</th>
                                  <th>Application Processed Date</th>
                                </tr>
                              </thead>

                              {selectedRequest[`processingHistory`].length > 0 ? (
                                <tbody>
                                  {selectedRequest[`processingHistory`].map(
                                    (item: any, i: number) => {
                                      return (
                                        <tr key={i + 1}>
                                          {/* <td className="siNo text-center">{i + 1}</td> */}
                                          <td>{item.designation}</td>
                                          <td>{item.status}</td>
                                          <td>{item.remarks}</td>
                                          <td>
                                            {(selectedRequest.isAimChange == true || selectedRequest.isNameChange == true
                                              || selectedRequest.isAddressChange == true ||
                                              selectedRequest.isAmalgamChange == true ||
                                              selectedRequest.isSocietyDissolved == true ||
                                              selectedRequest.isSocietyWinding == true ||
                                              selectedRequest.isMemorandumChange == true ||
                                              selectedRequest.isFiling == true) ?
                                              <>
                                                {selectedRequest.isAimChange == true && "Aim and Objective Change"}
                                                {selectedRequest.isNameChange == true && "Name Change"}
                                                {selectedRequest.isAddressChange == true && "Address Change"}
                                                {selectedRequest.isAmalgamChange == true && "Amalgamation"}
                                                {selectedRequest.isSocietyDissolved == true && "Dissolution"}
                                                {selectedRequest.isSocietyWinding == true && "Winding Society"}
                                                {selectedRequest.isMemorandumChange == true && "Memorandum and Bye-laws"}
                                                {selectedRequest.isFiling == true && "Filing of List of Members"}
                                              </> : "Society Registration"}
                                          </td>
                                          <td>{DateFormator(item.applicationTakenDate, "dd/mm/yyyy")}</td>
                                          <td>{DateFormator(item.applicationProcessedDate, "dd/mm/yyyy")}</td>
                                        </tr>
                                      )
                                    }
                                  )}
                                </tbody>
                              ) : (
                                <tbody>
                                  <tr>
                                    <td colSpan={6}>No Data Found</td>
                                  </tr>
                                </tbody>
                              )}
                            </Table>
                          </Col>
                        </Row>
                      </div>
                    )}

                    {/* {userType != "user" && (
                      <div className="firmPartnerSec tableSec mb-3">
                        <div className="formSectionTitle">
                          <h3>Applicant Message History</h3>
                        </div>
                        <Row>
                          <Col lg={12} md={12} xs={12}>
                            <Table striped bordered className="tableData listData">
                              <thead>
                                <tr>
                                  <th className="siNo text-center">SI No</th>
                                  <th>Number</th>
                                  <th>Message</th>
                                  <th>Sent Date</th>
                                </tr>
                              </thead>

                              {selectedRequest[`messageToApplicant`].length > 0 ? (
                                <tbody>
                                  {selectedRequest[`messageToApplicant`].map(
                                    (item: any, i: number) => {
                                      return (
                                        <tr key={i + 1}>
                                          <td className="siNo text-center">{i + 1}</td>
                                          <td>{item.number}</td>
                                          <td>{item.message}</td>
                                          <td>{item.sentDate}</td>
                                        </tr>
                                      )
                                    }
                                  )}
                                </tbody>
                              ) : (
                                <tbody>
                                  <tr>
                                    <td colSpan={6}>No Data Found</td>
                                  </tr>
                                </tbody>
                              )}
                            </Table>
                          </Col>
                        </Row>
                      </div>
                    )} */}
                  </Container>
                </Form>
              </div>
            </div>
          )}
          {(!locData?.userType || locData?.userType == "user") && (
            <div className="societyRegSec">
              <Container>
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <div className="d-flex justify-content-between page-title mb-2">
                      <div className="pageTitleLeft">
                        <h1>Unauthorized page</h1>
                      </div>
                    </div>
                  </Col>
                </Row>
              </Container>
            </div>
          )}
        </>
      )}
    </>
  )
}

export default ViewHistory
