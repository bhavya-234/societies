import { useState, useEffect, useRef } from "react"
import Head from "next/head"
import api from "@/pages/api/api"
import { useRouter } from "next/router"
import CryptoJS from "crypto-js"
import { store } from "@/redux/store"
import { useAppDispatch, useAppSelector } from "@/redux/hooks"
import { SaveDocumentDetails } from "@/redux/formSlice"
import { Button, Col, Container, Row, Table } from "react-bootstrap"

import Pdf from "react-to-pdf"
import { getSocietyDetails } from "@/axios"
import { listeners } from "process"
import { Loading } from "@/GenericFunctions"

const PaymentSuccess = () => {
  const router = useRouter()
  let ref = useRef<HTMLDivElement | null>(null)

  let btnref = useRef<HTMLButtonElement | null>(null)
  const [locData, setLocData] = useState<any>({})
  const [isSuccess, setIsSuccess] = useState<boolean>(false)
  const [isFailure, setIsFailure] = useState<boolean>(false)
  const [paymentDetails, setPaymentDetails] = useState<any>({})
  const [token, setToken] = useState<string>("")

  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }


    setToken(data.token)
    getSocietyDetails(data.applicationId, data.token).then((response) => {
      setExistingSocietyDetail(response.data?.daSociety)
      Loading(false)
    })
  }, [])
  useEffect(() => {
    document.body.classList.add("paymentSuccessPage")
    return () => {
      document.body.classList.remove(
        "paymentPage",
        "previewForm",
        "bg-salmon",
        "viewCerticate",
        "viewCerticatePage"
      )

    }

  }, [])
  const options = {

    orientation: "p",

    unit: "mm",

    scale: 1,

    format: [400, 253],

  }
  const RedirectToSearch = () => {
    router.push("/societies")
  }

  const dispatch = useAppDispatch()
  // let Documentsoption: any = useAppSelector((state) => state.form.DocumentDetails)
  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")

    if (data && data != "" && process.env.SECRET_KEY) {

      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)

      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))

    }

    if (data && data.token) {

      setLocData(data)

      api

        .get("/getPaymentDetails/" + data.applicationNumber, {

          headers: {

            Accept: "application/json",

            Authorization: `Bearer ${data.token}`,

          },

        })

        .then((response: any) => {


          if (!response || !response.data || !response.data.success) {
            Loading(false)
            setIsFailure(true)

          } else {

            if (

              response.data.data.paymentDetails.transactionStatus == "Success" &&

              !response.data.data.paymentDetails.isUtilized

            ) {
              if ((existingSocietyDetail?.historyDetails?.length > 0 && existingSocietyDetail?.historyDetails?.some((x: any) => x.status == "Approved")) ||
                (existingSocietyDetail?.processingHistory?.length > 0 && existingSocietyDetail?.processingHistory?.some((x: any) => x.status == "Approved"))
              ) {
                setIsSuccess(true)
                setPaymentDetails(response.data.data.paymentDetails)
                let data: any = localStorage.getItem("FASPLoginDetails")

                if (data && data != "" && process.env.SECRET_KEY) {

                  let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)

                  data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))

                }

                if (data && data.token) {

                  setLocData(data)

                  let AmendmentData: any = localStorage.getItem("AmendmentData")
                  const file = (e: any) => { e.target.files; }

                  if (AmendmentData) {

                    AmendmentData = JSON.parse(AmendmentData)

                    let formData = new FormData()
                    let fileNamesSplit = file.name.split('_');
                    let validFileExtensions = ["resigned", "death", "terminated", "selfSignedDeclaration", "committeeResolution", "firstNotice", "secondNotice", "thirdNotice"];

                    Object.keys(AmendmentData).forEach((key: any) => {

                      if (

                        key == "selfSignedDeclaration" ||

                        key == "affidavit" ||
                        key == "moa" ||
                        key == "supportingDoc" ||
                        validFileExtensions.includes(key.split('_')[1]) ||
                        key == "declaration" ||
                        key == "propertyDisposal" ||
                        key == "minutesOfMeeting" ||
                        key == "idProofs" ||
                        key == "affidavitByAuditor" ||
                        key == "memorandum" ||
                        key == "byeLaws"

                      ) {

                        let pos = AmendmentData[key].indexOf(";base64,")

                        let type = AmendmentData[key].substring(5, pos)

                        let b64 = AmendmentData[key].substr(pos + 8)



                        // decode base64

                        let imageContent = atob(b64)



                        // create an ArrayBuffer and a view (as unsigned 8-bit)

                        let buffer = new ArrayBuffer(imageContent.length)

                        let view = new Uint8Array(buffer)



                        // fill the view, using the decoded base64

                        for (let n = 0; n < imageContent.length; n++) {

                          view[n] = imageContent.charCodeAt(n)

                        }



                        // convert ArrayBuffer to Blob

                        formData.append(key, new Blob([buffer], { type: type }))

                      } else {

                        formData.append(key, AmendmentData[key])

                      }

                    })

                    let myHeader = {
                      headers: {
                        Authorization: `Bearer ${data.token}`,
                      },
                    }
                    api
                      .post("/societies/update", formData, myHeader)

                      .then((res) => {

                        setPaymentDetails(response.data.data.paymentDetails)

                        store.dispatch(SaveDocumentDetails(null))

                        const formData1 = new FormData()

                        formData1.append("formType", "payment")

                        formData1.append("id", data.applicationId)

                        api

                          .post("/societies/update", formData1, myHeader)

                          .then((res) => {

                            getSocietyDetails(data.applicationId, data.token).then((response) => {
                              setExistingSocietyDetail(response.data?.daSociety)
                              Loading(false)
                            })
                          })

                          .catch((e) => {
                            Loading(false)
                            console.log("Error while saving")

                          })

                      })

                      .catch((e) => {
                        Loading(false)
                        console.log("Error while saving")

                      })

                  } else {
                    Loading(false)
                    const formData1 = new FormData()

                    formData1.append("formType", "payment")

                    formData1.append("id", data.applicationId)

                    let myHeader = {

                      headers: {

                        Authorization: `Bearer ${data.token}`,

                      },

                    }

                    api

                      .post("/societies/update", formData1, myHeader)

                      .then((res) => { })

                      .catch((e) => {

                        console.log("Error while saving")

                      })

                  }
                  // console.log("AmendmentData", AmendmentData)

                }
                else {
                  // setIsSuccess(true)
                  setIsFailure(true)
                }

              } else if (response.data.data.paymentDetails.totalAmount === 500) {
                setIsSuccess(true)
                setPaymentDetails(response.data.data.paymentDetails)
                let data: any = localStorage.getItem("FASPLoginDetails")

                if (data && data != "" && process.env.SECRET_KEY) {

                  let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)

                  data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))

                }

                if (data && data.token) {

                  setLocData(data)

                  let AmendmentData: any = localStorage.getItem("AmendmentData")
                  const file = (e: any) => { e.target.files; }

                  if (AmendmentData) {

                    AmendmentData = JSON.parse(AmendmentData)

                    let formData = new FormData()
                    let fileNamesSplit = file.name.split('_');
                    let validFileExtensions = ["resigned", "death", "terminated", "selfSignedDeclaration", "committeeResolution", "firstNotice", "secondNotice", "thirdNotice"];

                    Object.keys(AmendmentData).forEach((key: any) => {

                      if (

                        key == "selfSignedDeclaration" ||

                        key == "affidavit" ||
                        key == "moa" ||
                        key == "supportingDoc" ||
                        validFileExtensions.includes(key.split('_')[1]) ||
                        key == "declaration" ||
                        key == "propertyDisposal" ||
                        key == "minutesOfMeeting" ||
                        key == "idProofs" ||
                        key == "affidavitByAuditor" ||
                        key == "memorandum" ||
                        key == "byeLaws"

                      ) {

                        let pos = AmendmentData[key].indexOf(";base64,")

                        let type = AmendmentData[key].substring(5, pos)

                        let b64 = AmendmentData[key].substr(pos + 8)



                        // decode base64

                        let imageContent = atob(b64)



                        // create an ArrayBuffer and a view (as unsigned 8-bit)

                        let buffer = new ArrayBuffer(imageContent.length)

                        let view = new Uint8Array(buffer)



                        // fill the view, using the decoded base64

                        for (let n = 0; n < imageContent.length; n++) {

                          view[n] = imageContent.charCodeAt(n)

                        }



                        // convert ArrayBuffer to Blob

                        formData.append(key, new Blob([buffer], { type: type }))

                      } else {

                        formData.append(key, AmendmentData[key])

                      }

                    })

                    let myHeader = {
                      headers: {
                        Authorization: `Bearer ${data.token}`,
                      },
                    }
                    api
                      .post("/societies/update", formData, myHeader)

                      .then((res) => {

                        setPaymentDetails(response.data.data.paymentDetails)

                        store.dispatch(SaveDocumentDetails(null))

                        const formData1 = new FormData()

                        formData1.append("formType", "payment")

                        formData1.append("id", data.applicationId)

                        api

                          .post("/societies/update", formData1, myHeader)

                          .then((res) => {

                            getSocietyDetails(data.applicationId, data.token).then((response) => {
                              setExistingSocietyDetail(response.data?.daSociety)
                              Loading(false)
                            })
                          })

                          .catch((e) => {
                            Loading(false)
                            console.log("Error while saving")

                          })

                      })

                      .catch((e) => {
                        Loading(false)
                        console.log("Error while saving")

                      })

                  } else {
                    Loading(false)
                    const formData1 = new FormData()

                    formData1.append("formType", "payment")

                    formData1.append("id", data.applicationId)

                    let myHeader = {

                      headers: {

                        Authorization: `Bearer ${data.token}`,

                      },

                    }

                    api

                      .post("/societies/update", formData1, myHeader)

                      .then((res) => { })

                      .catch((e) => {

                        console.log("Error while saving")

                      })

                  }
                  // console.log("AmendmentData", AmendmentData)

                }
                else {
                  // setIsSuccess(true)
                  setIsFailure(true)
                }
              } else {
                setIsFailure(true)
              }

            }
          }
        })

        .catch((error) => {
          Loading(false)
          setIsFailure(true)

        })

    }

  }, [])


  return (
    <>
      <Head>
        <title>Successfully Completed Registration! -  Societies</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      {locData && locData?.userType && locData?.userType == "user" && (

        <div className="paymentpageSec">

          <div className="societyRegSec">

            <Container>

              <div className="regFieldsMain text-center">



                {isSuccess && (

                  <div className="paymentSuccess" ref={ref}>
                    <div className="paymentPageHeader">

                      <Col lg={12} md={12} xs={12} style={{ margin: "0 auto" }}>

                        <div className="d-flex align-items-center justify-content-center">

                          <div style={{ textAlign: "center" }}>

                            <img

                              src="
                              assets/header-logo.svg"

                              title="REGISTRATION & STAMPS DEPARTMENT"

                              alt="REGISTRATION & STAMPS DEPARTMENT"

                              style={{ width: "400px" }}

                            />

                          </div>

                        </div>

                      </Col>

                    </div>



                    <div className="formSectionTitle">

                      <h2>Societies Registration</h2>

                      <h6>* * * * * * * *</h6>

                      <h4>* * * * * * Acknowledgement Receipt * * * * * *</h4>

                    </div>

                    <Table bordered className="paymentTable">

                      <tbody className="tableBody">

                        <tr>

                          <td>

                            <b>Application Number</b>

                          </td>

                          <td>:</td>

                          <td>{paymentDetails.applicationNumber}</td>

                        </tr>
                        <tr>

                          <td>

                            <b>Society Name</b>

                          </td>

                          <td>:</td>

                          <td>{existingSocietyDetail.societyName}</td>

                        </tr>
                        <tr>

                          <td>

                            <b>Application Type</b>

                          </td>
                          <td>:</td>
                          {(existingSocietyDetail.isAimChange == true || existingSocietyDetail.isNameChange == true
                            || existingSocietyDetail.isAddressChange == true ||
                            existingSocietyDetail.isAmalgamChange == true ||
                            existingSocietyDetail.isSocietyDissolved == true ||
                            existingSocietyDetail.isSocietyWinding == true ||
                            existingSocietyDetail.isMemorandumChange == true ||
                            existingSocietyDetail.isFiling == true) ?
                            <td>
                              {existingSocietyDetail.isAimChange == true && "Aim and Objective Change"}
                              {existingSocietyDetail.isNameChange == true && "Name Change"}
                              {existingSocietyDetail.isAddressChange == true && "Address Change"}
                              {existingSocietyDetail.isAmalgamChange == true && "Amalgamation"}
                              {existingSocietyDetail.isSocietyDissolved == true && "Dissolution"}
                              {existingSocietyDetail.isSocietyWinding == true && "Winding Society"}
                              {existingSocietyDetail.isMemorandumChange == true && "Memorandum and Bye-laws"}
                              {existingSocietyDetail.isFiling == true && "Filing of List of Members"}
                            </td> : <td>Society Registration</td>}
                        </tr>
                        <tr>

                          <td>

                            <b>Department Transaction ID</b>

                          </td>

                          <td>:</td>

                          <td>{paymentDetails.departmentTransID}</td>

                        </tr>

                        <tr>

                          <td>

                            <b>Amount</b>

                          </td>

                          <td>:</td>

                          <td>{paymentDetails.totalAmount}</td>

                        </tr>

                        <tr>

                          <td>

                            <b>Mode of the Payment</b>

                          </td>

                          <td>:</td>

                          <td>{paymentDetails.paymentMode}</td>

                        </tr>

                      </tbody>

                    </Table>

                  </div>

                )}

                {isFailure && (

                  <div className="paymentFailed">

                    <div className="paymentPageHeader">

                      <Col lg={12} md={12} xs={12} style={{ margin: "0 auto" }}>

                        <div className="d-flex align-items-center justify-content-center">

                          <div style={{ textAlign: "center" }}>

                            <img

                              src="/assets/header-logo.svg"

                              title="REGISTRATION & STAMPS DEPARTMENT"

                              alt="REGISTRATION & STAMPS DEPARTMENT"

                              style={{ width: "400px" }}

                            />

                          </div>

                        </div>

                      </Col>

                    </div>

                    <div className="formSectionTitle">

                      <h3>Your Payment is failed!</h3>

                    </div>

                  </div>

                )}

                {(isSuccess || isFailure) && (

                  <div className="d-flex justify-content-center paymentpagebtns">

                    <a className="btn btn-primary new-user mt-3" href="/societies">

                      Ok

                    </a>

                    {isSuccess && (

                      <div className="">

                        <Pdf targetRef={ref} filename={`PaymentSuccess.pdf`} options={options}>

                          {({ toPdf }: any) => (

                            <div className="text-center">

                              <Button

                                className="btn btn-primary new-user ms-3 mt-3"

                                id="downloadClick"

                                ref={btnref}

                                variant="primary"

                                onClick={() => {

                                  toPdf()

                                }}

                              >

                                Print

                              </Button>

                            </div>

                          )}

                        </Pdf>

                      </div>

                    )}

                  </div>

                )}

              </div>

            </Container>

          </div>

        </div>

      )}


      {(locData?.userType != "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}
export default PaymentSuccess
