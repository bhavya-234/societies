import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import React, { useEffect, useRef, useState } from "react"
import { Col, Container, Form, Row } from "react-bootstrap"
import styles from "@/styles/components/Table.module.scss"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { useAppDispatch } from "@/hooks/reduxHooks"
import CryptoJS, { AES } from "crypto-js"
import { useRouter } from "next/router"
import DynamicVillages from "./societies/dynamicCities"
import DynamicMandals from "./societies/dynamicMandals"
import instance from "@/redux/api"
import {
  UseGetAadharDetails,
  UseGetAadharOTP,
  getSocietyDetails,
  updateSocietyDetails,
} from "@/axios"
import { store } from "@/redux/store"
import Swal from "sweetalert2"
import { get } from "lodash"
import { ShowMessagePopup } from "@/GenericFunctions"
import {
  ISApplicantDetailModel,
  ISFillingListOfMembersSocietyDetailsModel,
  RequestTypeDetailsModel,
  WindingDetailsModel,
} from "@/models/types"

interface DetailProps {
  checklistwinding?: any
}
const WindingSociety = ({ checklistwinding }: DetailProps) => {
  const router = useRouter()
  const dispatch = useAppDispatch()
  const [checklist, setChecklist] = useState<any>(checklistwinding);
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [file, setFile] = useState<any>([])
  const [errors, setErrors] = useState<any>({})
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false)
  const [addSociety, setAddSociety] = useState<string>("")
  const [isError, setIsError] = useState<boolean>(false)
  const [errorMessage, setErrorMessage] = useState<string>("")
  const [districtList, setDistricts] = useState<any>([])
  const [token, setToken] = useState<string>("")
  const [membersDetails, setMembersDetails] = useState<any>([])
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [isPayNowClicked, setIsPayNowClicked] = useState<boolean>(false)
  const [display, setdisplay] = useState<boolean>(false)
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const [aadhaarUserResponse, setAadhaarUserResponse] = useState<any>({})
  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  const [currentDistrict, setCurrentDistrict] = useState<string>("")
  const [TempMemory, setTempMemory] = useState<any>({ OTPRequested: false, AadharVerified: false })

  const [currentMandal, setCurrentMandal] = useState<string>("")
  const tableHeaders: string[] = [
    "Type",
    "Aadhaar No ",
    "Name of the Member",
    "Relation Name",
    "Age / Gender",
    "Role/Position",
    "Occupation",
    "Date of Joining",
    "Address",
    "Contact Details",
  ]
  const [applicantDetails, setApplicantDetails] = useState<ISApplicantDetailModel>({
    aadharNumber: "",
    name: "",
    relationName: "",
    role: "",
    doorNo: "",
    relationType: "",
    age: "",
    gender: "",
    street: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    phone: "",
    mobileNumber: "",
    maskedAadhar: "",
    email: "",
  })
  const [societyDetails, setSocietyDetails] = useState<ISFillingListOfMembersSocietyDetailsModel>({
    societyName: "",
    category: "",
    isClaimsSociety:"",
    isSocietyProperties:"",
      isWindingMember:"",
      liabilityConditions:"",
      isByeLawsProperties:""
  })


  const [windingDetails, setWindingDetails] = useState<WindingDetailsModel>({
    dateOfDissolution: "",
    propertyDisposal: "",
    dateOfMeeting: "",
    minutesOfMeetingDesc: "",
  })
  const [typelist] = useState<string[]>(["type1", "type2"])

  // const popupState = () => {
  //   let data: any = localStorage.getItem("FASPLoginDetails")
  //   if (!data || data == null || data == "") {
  //     router.push("/")
  //   }
  // }

  // useEffect(() => {
  //   window.addEventListener("popstate", () => {
  //     popupState()
  //   })
  //   return () => {
  //     window.removeEventListener("popstate", () => {
  //       popupState()
  //     })
  //   }
  // }, [])

  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
        // throw Error("Invalid File");
        ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
        e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])){
      if(!regex){
      ShowMessagePopup(false, "Please upload proper file name");
      e.target.value = "";
    }
  }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  // useEffect(() => {
  //   setSocietyDetails({ ...societyDetails, uploadedDoc: file })
  // }, [file])

  const ageCalculator = (dateOfBirth: any) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    //calculate month difference from current date in time
    let month_diff = Date.now() - dob.getTime()

    //convert the calculated difference in date format
    let age_dt = new Date(month_diff)

    //extract year from date
    let year = age_dt.getUTCFullYear()

    //now calculate the age of the user
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }

  const applicantDetailsChange = (e: any) => {
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        e.target.value.length > 0 &&
        e.target.value.length > applicantDetails.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          applicantDetails.aadharNumber.substring(0, startpos) +
          applicantDetails.aadharNumber.substring(
            startpos + 1,
            applicantDetails.aadharNumber.length
          )
      }
      setApplicantDetails({
        ...applicantDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? applicantDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
      setApplicantDetails(newInput)
    }
  }

  const districtChange = (e: any) => {
    // if(e.target.name == 'district'){
    //   setmandals([])
    //   setApplicantCities([])
    setCurrentDistrict(e.target.value)
    setCurrentMandal("")
    // }
  }

  const mandalChange = (e: any) => {
    setCurrentMandal(e.target.value)
  }

  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  const verifyApplicantOtp = async () => {
    if (applicantDetails.otpCode) {
      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(applicantDetails.aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: applicantDetails.otpCode,
      })
      Loading(false)
      // let age =  ageInDays / 365 ;
      if (result.status && result.status === "Success") {
        let data: ISApplicantDetailModel = { ...applicantDetails }
        data["name"] = result.userInfo.name
        data["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        // data["country"] = result.userInfo.country
        data["relationName"] = result.userInfo.co
        // data["state"] = result.userInfo.state
        data["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data["street"] = result.userInfo.street
        data["district"] = result.userInfo.dist.toUpperCase()
        data["pinCode"] = result.userInfo.pc
        data["age"] = ageCalculator(result.userInfo.dob)
        data["otpVerified"] = "true"
        setApplicantDetails(data)
        setCurrentDistrict(result.userInfo.dist.toUpperCase())
      } else {
        let data = { ...applicantDetails }
        data["otpVerified"] = "false"
        setApplicantDetails(data)
        ShowAlert(false, get(result, "message", "Aadhaar API Failed"))
      }
    }
  }

  const generateApplicantOtp = async () => {
    if (applicantDetails.aadharNumber && applicantDetails.aadharNumber.length == 12) {
      Loading(true)
      let result = await UseGetAadharOTP(btoa(applicantDetails.aadharNumber))
      Loading(false)
      if (result && result.status === "Success") {
        ShowAlert(true, "OTP Sent Successfully")
        setSentOTP(true)
        setAadhaarOTPResponse(result)
        let data = { ...applicantDetails }
        data["otpStatus"] = "1"
        setApplicantDetails(data)
      } else {
        ShowAlert(false, "Please Enter Valid Aadhar")
        setAadhaarOTPResponse({})
        let data = { ...applicantDetails }
        data["otpStatus"] = "2"
        setApplicantDetails(data)
      }
    } else {
      ShowAlert(false, "Kindly enter valid Aadhar number")
    }
  }

  const societyDetailsChange = (e: any) => {
    setSocietyDetails({ ...societyDetails, [e.target.name]: e.target.value })
  }

  const windingDetailsChange = (e: any) => {
    setWindingDetails({ ...windingDetails, [e.target.name]: e.target.value })
  }

  const validateInputs = () => {
    let applicant: ISApplicantDetailModel = { ...applicantDetails }
    let society: ISFillingListOfMembersSocietyDetailsModel = { ...societyDetails }
    const errors: any = {}
    if(TempMemory.AadharVerified != true){
      return ShowMessagePopup(false, "Plaese verify aadhar number")
    }
    if (!applicant.aadharNumber) {
      ShowMessagePopup(false, "Please validate aadhar number", "")
    }
    if(society.isByeLawsProperties!="Yes"){
      ShowMessagePopup(false, "Please select validate option for byelaw properties", "")
    }
    if(society.isClaimsSociety!="Yes"){
      ShowMessagePopup(false, "Please select validate option for Claims Society", "")
    }
    if(society.isSocietyProperties!="Yes"){
      ShowMessagePopup(false, "Please select validate option for Society Properties", "")
    }
    if(society.isWindingMember!="Yes"){
      ShowMessagePopup(false, "Please select validate option for Winding Member", "")
    }
    if(society.liabilityConditions!="Yes"){
      ShowMessagePopup(false, "Please select validate option for liability Conditions", "")
    }
    setErrors({ ...errors })
    console.log("errors obj", errors)
    return errors
  }

  async function getFileFromUrl(url: any, name: any, defaultType = "pdf") {
    const response = await instance.get(url, { responseType: "arraybuffer" })

    return new File([response.data], name, {
      type: defaultType,
    })
  }

  React.useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setToken(data.token)
    setLoggedInAadhar(data.aadharNumber)
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)
        getSocietyDetails(data.applicationId, data.token)
          .then((response) => {
            if (response?.success) {
              setExistingSocietyDetail(response.data.daSociety)
              if (checklist?.length > 0 && !checklist.some((x: string) => x == "Winding up of the society")) {
                setSocietyDetails({
                  societyName: response.data.daSociety.societyName
                    ? response.data.daSociety.societyName
                    : "",
                  category: response.data.daSociety.category
                    ? response.data.daSociety.category
                    : "",
                    isByeLawsProperties:"",
                    isClaimsSociety:"",
                    isSocietyProperties:"",
                    isWindingMember:"",
                    liabilityConditions:""
                })
              }
              if (
                response.data.daSociety?.memberDetails &&
                response.data.daSociety?.memberDetails?.length > 0
              ) {
                response.data.daSociety.memberDetails.forEach(
                  (a: any) =>
                    (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber?.toString().substring(8, 12))
                )
                setMembersDetails([...response.data.daSociety.memberDetails])
              }

            }
          })
          .catch(() => {
            Loading(false)
          })
        Loading(false)
      })
      .catch(() => {
        Loading(false)
      })
  }, [])
  const ReqDetails = async (MyKey: any) => {
    let result = await CallingAxios(
      UseGetAadharDetails({
        aadharNumber: btoa(MyKey.aadharNumber),
        transactionNumber: MyKey?.OTPResponse?.transactionNumber,
        otp: MyKey.otpCode,
      })
    )
    if (
      result.status &&
      result.status === "Success" &&
      MyKey?.OTPResponse?.transactionNumber == result.transactionNumber.split(":")[1]
    ) {
      let latestData: any = {
        ...MyKey,
        name: result.userInfo.name ? result.userInfo.name : "",
        memberName: result.userInfo.name ? result.userInfo.name : "",
        relationType: result.userInfo.co ? result.userInfo.co.substring(0, 3) : "",
        relationName: result.userInfo.co ? result.userInfo.co.substring(4) : "",
        age: result.userInfo.dob ? ageCalculator(result.userInfo.dob) : "",
        gender: result.userInfo.gender == "M" ? "Male" : "Female",
        district: result.userInfo.dist ? result.userInfo.dist : "",
        pinCode: result.userInfo.pc ? result.userInfo.pc : "",
        street: result.userInfo.loc ? result.userInfo.street : "",
        villageOrCity: result.userInfo.vtc ? result.userInfo.vtc : "",
        doorNo: result.userInfo.house ? result.userInfo.house : "",
        address:
          (result.userInfo.lm ? result.userInfo.lm + ", \n" : "") +
          (result.userInfo.loc ? result.userInfo.loc + ", \n" : "") +
          (result.userInfo.dist ? result.userInfo.dist + ", \n" : "") +
          (result.userInfo.vtc ? result.userInfo.vtc : "") +
          (result.userInfo.pc ? "-" + result.userInfo.pc : ""),
        OTPResponse: result,
      }

      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails(latestData)
          setTempMemory({ OTPRequested: false, AadharVerified: true })
          break
        default:
          break
      }
    } else {
      ShowMessagePopup(false, "Please Enter Valid OTP", "")
    }
  }
  const ReqOTP = (MyKey: any) => {
    // if (MyKey.aadharNumber && MyKey.aadharNumber.length == 12) {
    CallGetOTP(MyKey)
    // } else {
    //   ShowMessagePopup(false, "Kindly enter valid Aadhar number", "")
    // }
  }
  const CallingAxios = async (myFunction: any) => {
    Loading(true)
    let result = await myFunction
    Loading(false)
    return result
  }

  const CallGetOTP = async (MyKey: any) => {
    if (process.env.IGRS_SECRET_KEY) {
      // 
      const ciphertext = AES.encrypt(MyKey.aadharNumber, process.env.IGRS_SECRET_KEY)
      let result = await CallingAxios(UseGetAadharOTP(ciphertext.toString()))
      // 
      if (result && result.status != "Failure") {
        switch (MyKey) {
          case applicantDetails:
            setTempMemory({ OTPRequested: true, AadharVerified: false })
            break
           default:
            break
        }
        switch (MyKey) {
          case applicantDetails:
            setApplicantDetails({ ...MyKey, OTPResponse: result })
            break
           default:
            break
        }
        ShowMessagePopup(
          true,
          "OTP Sent to Aadhaar Registered Mobile Number.",
          ""
        )
      }
    } else {
      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemory({ OTPRequested: false, AadharVerified: false })
          break

        default:
          break
      }
      ShowMessagePopup(false, "Please Enter Valid Aadhar", "")
    }
  }
  const handleSubmit = async (e: any) => {
    e.preventDefault()
    if (Object.keys(validateInputs()).length == 0) {

      const data = {
        applicantDetails: applicantDetails,
        societyDetails: societyDetails,
        ...windingDetails,
      }
      const newData = new FormData()

      newData.append("applicantDetails[aadharNumber]", btoa(data.applicantDetails.aadharNumber))
      newData.append("applicantDetails[applicationNumber]", existingSocietyDetail.applicationNumber)
      newData.append("applicantDetails[name]", existingSocietyDetail.applicantDetails.name)
      newData.append("applicantDetails[doorNo]", existingSocietyDetail.applicantDetails.doorNo)
      newData.append("applicantDetails[street]", existingSocietyDetail.applicantDetails.street)
      newData.append("applicantDetails[age]", existingSocietyDetail.applicantDetails.age)
      newData.append("applicantDetails[gender]", existingSocietyDetail.applicantDetails.gender)
      newData.append("applicantDetails[country]", "India")
      newData.append("applicantDetails[state]", "Andhra Pradesh")
      newData.append("applicantDetails[district]", existingSocietyDetail.applicantDetails.district)
      newData.append("applicantDetails[mandal]", existingSocietyDetail.applicantDetails.mandal)
      newData.append("applicantDetails[villageOrCity]", existingSocietyDetail.applicantDetails.villageOrCity)
      newData.append("applicantDetails[pinCode]", existingSocietyDetail.applicantDetails.pinCode)
      newData.append("applicantDetails[mobileNumber]", existingSocietyDetail.applicantDetails.mobileNumber)
      newData.append("applicantDetails[relationType]", existingSocietyDetail.applicantDetails.relationType)
      newData.append("applicantDetails[relationName]", existingSocietyDetail.applicantDetails.relationName)
      newData.append("applicantDetails[role]", existingSocietyDetail.applicantDetails.role)
      newData.append("id", existingSocietyDetail._id)

      newData.append("country", "India")
      newData.append("state", "Andhra Pradesh")
      newData.append("windingUpSociety[dateOfDissolution]", windingDetails.dateOfDissolution)
      newData.append("windingUpSociety[propertyDisposal]", windingDetails.propertyDisposal)
      newData.append("windingUpSociety[dateOfMeeting]", windingDetails.dateOfMeeting)
      newData.append("windingUpSociety[minutesOfMeetingDesc]", windingDetails.minutesOfMeetingDesc)
      newData.append("minutesOfMeeting", file.minutesOfMeeting)

       if (checklist &&
        checklist.length > 0 &&
        checklist.some((x: string) => x == "Winding up of the society")) {
        newData.append("isSocietyWinding", "true")
      } else {
        newData.append("isSocietyWinding", "false")
      }
      let object: any = {}
      newData.forEach((value, key) => (object[key] = value))
      object.minutesOfMeeting = await file2Base64(file?.minutesOfMeeting)
      localStorage.setItem("AmendmentData", JSON.stringify(object))
      let code = 0
      const dis = districtList?.find((x: any) => x.name == existingSocietyDetail.district)
      if (dis) {
        code = dis.code
      }
       const paymentsData = {
        type: "sra",
        source: "Society",
        deptId: existingSocietyDetail.applicationNumber,
        rmName: existingSocietyDetail.applicantDetails.name,
        rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
        mobile: existingSocietyDetail.applicantDetails.mobileNumber,
        email: existingSocietyDetail.applicantDetails.email,
        drNumber: code,
        rf: 300,
        uc: 0,
        oc: 0,
        returnURL: process.env.BACKEND_URL + "/societies/redirectPayment",
      }
      let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
      // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
      const encodedData = CryptoJS.AES.encrypt(
        JSON.stringify(paymentsData),
        'igrsSecretPhrase'
      ).toString()
      let paymentLink = document.createElement("a")
      paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
      paymentLink.click()
      setIsPayNowClicked(false)
      setTimeout(function () {
        paymentLink.remove()
      }, 1000)
    }}

  const ShowAlert = (type: any, message: any) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }
  const file2Base64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      if (reader && reader != null && file) {
        reader.readAsDataURL(file)
        reader.onload = () => resolve(reader.result?.toString() || "")
        reader.onerror = (error) => reject(error)
      }
      else {
        resolve("")
      }
    })
  }
  return (
    <div>
      <div className="societyRegSec mx-3">
        <div className="formsec">
        <Row>
                  <Col lg={12} md={12} xs={12}>
                    <div className="d-flex justify-content-between align-items-center page-title mb-3">
                      <div className="pageTitleLeft">
                        <h1>Winding up of the Society(Section 26)</h1>
                      </div>
                      {/* <div className="pageTitleRight">
                        <div className="page-header-btns">
                          <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                            Go Back
                          </a>
                        </div>
                      </div> */}
                    </div>
                  </Col>
                </Row>
          <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
            <Container>
              <div className="regofAppBg my-3">

                <Row>
                <Col lg={3} md={3} xs={12} >
                {!TempMemory.OTPRequested ? (
                  <Form.Group>
                    <TableText
                      label="Enter Aadhaar Number"
                      required={true}
                      LeftSpace={false}
                    />
                    <div className="formGroup">
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="aadharNumber"
                        onChange={(e: any) => {
                          if (!TempMemory.AadharVerified) {
                            applicantDetailsChange(e)
                          }
                        }}
                        disabled={TempMemory.AadharVerified}
                        required={true}
                        value={applicantDetails.aadharNumber}
                      >
                        <option>Select</option>
                        {membersDetails.map((item: any, i: any) => {
                          return (
                            <option key={i + 1} value={item.aadharNumber}>
                              {item.aadharNumber}
                            </option>
                          )
                        })}
                      </select>
                      {!TempMemory.AadharVerified ? (
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            borderRadius: "2px",
                          }}
                          onClick={() => ReqOTP(applicantDetails)}
                          className="verify btn btn-primary"
                        >
                          Get OTP
                        </div>
                      ) : null}
                    </div>
                  </Form.Group>
                ) : (
                  <Form.Group>
                    <TableText label="Enter OTP" required={true} LeftSpace={false} />
                    <div className="formGroup">
                      <TableInputText
                        disabled={false}
                        type="number"
                        placeholder="Enter OTP Received"
                        maxLength={6}
                        required={true}
                        name={"otpCode"}
                        value={applicantDetails.otpCode}
                        onChange={applicantDetailsChange}
                      />
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          borderRadius: "2px",
                        }}
                        onClick={() => {
                          ReqDetails(applicantDetails)
                        }}
                        className="verify btn btn-primary"
                      >
                        Verify
                      </div>
                      <div style={{ display: "flex", justifyContent: "flex-end" }}>
                        <div
                          style={{
                            cursor: "pointer",
                            marginRight: "20px",
                            color: "blue",
                            fontSize: "10px",
                          }}
                          onClick={() => {
                            setTempMemory({ ...TempMemory, OTPRequested: false })
                          }}
                        >
                          clear
                        </div>
                      </div>
                    </div>
                  </Form.Group>
                )}
              </Col>
                 </Row>
              </div>
              <div className="regofAppBg my-3">
                <div className="formSectionTitle">
                  <h3>Society Details</h3>
                </div>
                <Row>
                  <Col lg={3} md={4} xs={12} className="mb-3">
                    <TableText label="Society Name" required={true} LeftSpace={false} />
                    <TableInputText
                      type="text"
                      placeholder="Enter Society Name"
                      required={true}
                      name={"societyName"}
                      disabled
                      value={existingSocietyDetail?.societyName}
                      onChange={()=>{}}
                    />
                  </Col>
                  <Col lg={3} md={12} sm={12}>
                    <TableText label={"Society Type "} required={false} LeftSpace={false} />

                    <TableInputText
                      disabled={true}
                      type="text"
                      required={true}
                      placeholder="category"
                      name="category"
                      onChange={()=>{}}
                      value={existingSocietyDetail?.category}
                    />
                  </Col>
                </Row>
              </div>
              <div className="regofAppBg my-2">
                <div className="formSectionTitle">
                  <h3>Reason for Dissolution</h3>
                  <Row>
                    <Col lg={12} md={12} xs={12} className="mb-2  d-flex ">
                      <TableText
                        label="Whether the members (General Body) have agreed for dissolution?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        required={true}
                        name="isWindingMember"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isWindingMember=="Yes"}
                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        required={true}
                        name="isWindingMember"
                        type="radio"
                        className="fom-checkbox mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.isWindingMember=="No"}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col lg={12} md={12} xs={12} className="mb-2  d-flex ">
                      <TableText
                        label="Whether the quorum has approved for the dissolution?"
                        LeftSpace={false}
                        required={false}
                      />

                      <Form.Check
                        inline
                        label="Yes"
                        required={true}
                        value="Yes"
                        name="liabilityConditions"
                        type="radio"
                        className="fom-checkbox mx-3 mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.liabilityConditions=="Yes"}
                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="liabilityConditions"
                        type="radio"
                        required={true}
                        className="fom-checkbox mb-2 "
                        onChange={societyDetailsChange}
                        checked={societyDetails.liabilityConditions=="No"}
                      />
                    </Col>
                  </Row>
                </div>
              </div>
              <div className="regofAppBg my-2">
                <div className="formSectionTitle">
                  <h3>Claims & Liabilities</h3>
                </div>
                <Row>
                  <Col lg={12} md={12} xs={12} className="mb-2 d-flex">
                    <TableText
                      label="Whether the properties of the society are settled as mentioned in the bye-laws?"
                      LeftSpace={false}
                      required={false}
                    />
                    <Form.Check
                      inline
                      label="Yes"
                      value="Yes"
                      name="isByeLawsProperties"
                      type="radio"
                      required={true}
                      className="fom-checkbox mb-2 mx-2"
                      onChange={societyDetailsChange}
                        checked={societyDetails.isByeLawsProperties=="Yes"}
                    />
                    <Form.Check
                      inline
                      label="No"
                      value="No"
                      name="isByeLawsProperties"
                      type="radio"
                      required={true}
                      className="fom-checkbox mb-3"
                      onChange={societyDetailsChange}
                        checked={societyDetails.isByeLawsProperties=="No"}
                    />
                  </Col>
                  <Row>
                    <Col lg={12} md={12} xs={12} className="mb-2 d-flex">
                      <TableText
                        label="Are there any claims and liabilities against the society?"
                        LeftSpace={false}
                        required={false}
                      />
                      <Form.Check
                        inline
                        label="Yes"
                        value="Yes"
                        name="isClaimsSociety"
                        type="radio"
                        required={true}
                        className="fom-checkbox mb-2 mx-2"
                        onChange={societyDetailsChange}
                        checked={societyDetails.isClaimsSociety=="Yes"}
                      />
                      <Form.Check
                        inline
                        label="No"
                        value="No"
                        name="isClaimsSociety"
                        type="radio"
                        required={true}
                        className="fom-checkbox mb-3"
                        onChange={societyDetailsChange}
                        checked={societyDetails.isClaimsSociety=="No"}
                      />
                    </Col>
                  </Row>
                </Row>
              </div>
              <div className="regofAppBg my-2">
                <Row>
                  <Col lg={12} md={12} xs={12} className="mb-2 d-flex">
                    <TableText
                      label="Are there any liabilities against the property or the society?"
                      LeftSpace={false}
                      required={false}
                    />
                    <Form.Check
                      inline
                      label="Yes"
                      value="Yes"
                      name="isSocietyProperties"
                      type="radio"
                      required={true}
                      className="fom-checkbox mb-2 mx-2"
                      onChange={societyDetailsChange}
                        checked={societyDetails.isSocietyProperties=="Yes"}
                    />

                    <Form.Check
                      inline
                      label="No"
                      required={true}
                      value="No"
                      name="isSocietyProperties"
                      type="radio"
                      className="fom-checkbox mb-3"
                      onChange={societyDetailsChange}
                        checked={societyDetails.isSocietyProperties=="No"}
                    />
                  </Col>
                </Row>
                <Row>
                  <Col lg={3} md={3} xs={12} className="mb-3">
                    <TableText label="Date of Dissolution" LeftSpace={false} required={false} />
                    <TableInputText
                      disabled={false}
                      type="date"
                      placeholder=""
                      required={true}
                      name={"dateOfDissolution"}
                      value={windingDetails.dateOfDissolution}
                      onChange={windingDetailsChange}
                    />
                    {/* {errors.date && <span style={{ color: "red" }} className={styles.columnText}>{errors.date}</span>} */}
                  </Col>
                  <Col lg={3} md={3} xs={12} className="mb-3">
                    <TableText
                      label="Details of Property Disposal"
                      LeftSpace={false}
                      required={false}
                    />
                    <TableInputText
                      type="text"
                      placeholder="Enter Details of Property Disposal"
                      name="propertyDisposal"
                      required
                      onChange={windingDetailsChange}
                      value={windingDetails.propertyDisposal}

                    />
                    {/* {errors.propertydisposal && <span style={{ color: "red" }} className={styles.columnText}>{errors.propertydisposal}</span>} */}
                  </Col>
                  <Col lg={3} md={3} xs={12} className="mb-2 formsec">
                    <TableText
                      label="Date of General Body meeting held"
                      LeftSpace={false}
                      required={false}
                    />
                    <TableInputText
                      type="date"
                      placeholder="Enter Date of meeting with G B"
                      name="dateOfMeeting"
                      required
                      onChange={windingDetailsChange}
                      value={windingDetails.dateOfMeeting}

                    />
                    {/* {errors.dateOfMeeting && <span style={{ color: "red" }} className={styles.columnText}>{errors.dateOfMeeting}</span>} */}
                  </Col>
                  <Col lg={3} md={3} xs={12} className="mb-2">
                    <TableText label="Minutes of Meeting" LeftSpace={false} required={false} />
                    <div className="firmFile">
                      <Form.Control
                        type="file"
                        name="minutesOfMeeting"
                        ref={inputRef}
                        onChange={handleFileChange}
                        accept="application/pdf"
                      />
                    </div>
                  </Col>

                <Col lg={5} md={5} xs={12} className="mb-2">
                    <TableText label="Minutes of Meeting" LeftSpace={false} required={false} />
                    <textarea
                       placeholder={"Enter the Key points"}
                       required={false}
                       value={windingDetails.minutesOfMeetingDesc}
                       onChange={windingDetailsChange}
                       name={"minutesOfMeetingDesc"}
                       maxLength={1000}
                      />
                 </Col>
                 </Row>
              </div>




              <div className="text-center my-2">
                <button type="submit" className="verify btn btn-primary">
                  Make Payment
                </button>
              </div>
            </Container>
          </Form>
        </div>
      </div>
    </div>
  )
}

export default WindingSociety
