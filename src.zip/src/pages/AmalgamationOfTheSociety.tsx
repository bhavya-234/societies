import { ShowMessagePopup } from "@/GenericFunctions"
import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import { useAppDispatch } from "@/hooks/reduxHooks"
import {
  ISAmalgamationMemberDetails,
  ISApplicantDetailModel,
  ISByLawsModel,
  ISIncomingMemberDetailsModel,
  ISSocietyDetailsAmalgamationModel,
  ISSocietyDetailsModel,
} from "@/models/types"
import Image from "next/image"
import instance from "@/redux/api"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { useAppSelector } from "@/redux/hooks"
import { store } from "@/redux/store"
import styles from "@/styles/pages/Forms.module.scss"
import CryptoJS, { AES } from "crypto-js"
import { get } from "lodash"
import Head from "next/head"
import { useRouter } from "next/router"
import React, { useEffect, useRef, useState } from "react"
import { Accordion, Button, Col, Container, Form, Row, Table } from "react-bootstrap"
import { UseGetAadharDetails, UseGetAadharOTP, getSocietyDetails, getSocietyDetailsbyAppNo } from "../axios"
import DynamicVillages from "./societies/dynamicCities"
import DynamicMandals from "./societies/dynamicMandals"

const tabs: string[] = ["Applicant Details", " Incoming Society ", "Society After Amalgamation", "Bye-Laws"]
interface DetailProps {
  checklistamalgam?: any
}
export default function Details({ checklistamalgam }: DetailProps) {
  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  let Documentsoption: any = useAppSelector((state) => state.form.DocumentDetails)

  const ageCalculator = (dateOfBirth: any) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    //calculate month difference from current date in time
    let month_diff = Date.now() - dob.getTime()

    //convert the calculated difference in date format
    let age_dt = new Date(month_diff)

    //extract year from date
    let year = age_dt.getUTCFullYear()

    //now calculate the age of the user
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }

  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const [isPayNowClicked, setIsPayNowClicked] = useState<boolean>(false)
  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  const [existingMemberDetail, setExistingMemberDetail] = useState<any>([])
  const [token, setToken] = useState<string>("")
  const [displayOption, setDisplayOption] = useState<string>("display")
  const [display, setDisplay] = useState<boolean>(false)
  const [currentmemberDistrict, setCurrentmemberDistrict] = useState<any>([])
  const [currentmemberMandal, setCurrentmemberMandal] = useState<any>([])
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [addSociety, setAddSociety] = useState<string>("")
  const [NewMemberList, setNewMemberList] = useState<any>([{}])

  const [activeTab, setActiveTab] = useState<number>(0)
  const [existingquorumMembers, setexistingquorumMembers] = useState<any>([{}])
  const [file, setFile] = useState<any>([])
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [maxTotalMembers, setMaxTotalMembers] = useState<number>(1)
  const [indexmember, setindexmember] = useState<any>(-1)
  const ref = useRef<HTMLElement | null>(null)
  const refUpdate = useRef<HTMLDivElement | null>(null)
  const refDelete = useRef<HTMLElement | null>(null)
  const countryList: string[] = ["India"]
  const stateList: string[] = ["Andhra Pradesh"]
  const genderList: string[] = ["Female", "Male", "Other"]
  const [errors, setErrors] = useState<any>({})
  const [isCheckFirm, setIsCheckFirm] = useState<boolean>(false)
  const [isCheckFirmBtn, setIsCheckFirmBtn] = useState<boolean>(true)
  const [isCheckNation, setIsCheckNation] = useState<boolean>(false)
  const [isBtnDisabled, setIsBtnDisabled] = useState<boolean>(false)
  const [TempMemorymember, setTempMemorymember] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  const [SelectedMemberDetails, setSelectedMemberDetails] =
    useState<any>({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
  const handleMemberUpdate = (index: any) => {
    let object: any = { ...SelectedMemberDetails }
    if (
      object.aadharNumber == "" ||
      object.relationType == "" ||
      object.gender == "" ||
      object.memberType == "" ||
      object.age == "" ||
      object.doorNo == "" ||
      object.district == "" ||
      object.mandal == "" ||
      object.villageOrCity == "" ||
      object.pinCode == "" ||
      object.relationName == "" ||
      object.mobileNumber == "" ||
      object.joiningDate == "" ||
      object.role == "" ||
      object.qualification == "" ||
      object.occupation == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for Updated Member", "")
    } else if (object.soundMind !== "Yes") {
      return ShowMessagePopup(false, "Please select validate option for soundMind", "")
    } else if (object.inSolvent !== "No") {
      return ShowMessagePopup(false, "Please select validate option for insolvent", "")
    }
    else if (object.offense !== "No") {
      return ShowMessagePopup(false, "Please select validate option for offense", "")
    } else if (object.appointment !== "No") {
      return ShowMessagePopup(false, "Please select validate option for appointment", "")
    } else if (!object.memberType) {
      return ShowMessagePopup(false, "Please select member type", "")
    } else if (!object.mandal) {
      return ShowMessagePopup(false, "Please select mandal", "")
    } else if (!object.villageOrCity) {
      return ShowMessagePopup(false, "Please select village or city", "")
    }
    
    let Details: any[] = [...incomingMemberDetails]
    Details.splice(index, 1, object)
    setincomingMemberDetails([...Details])
    console.log("index", index)
    setTempMemorymember({ OTPRequested: false, AadharVerified: false })
    setSelectedMemberDetails({
      //   OTPResponse: { transactionNumber: "" },
      // KYCResponse: {},
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, " Member Updated Successfully", "")
    setindexmember(-1)
  }
  const handleMemberAdddata = () => {
    const totalmembers = membersDetails.length;
    setMaxTotalMembers(maxTotalMembers + 1);
    if (totalmembers < 20) {
      setMembersDetails([
        ...membersDetails,
        {
          spoof: "",
          memberType: "",
          relationName: "",
          gender: "",
          position: "",
          age: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          memberName: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "",
          state: "",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          phone: "",
        },
      ])
    } else {
      ShowMessagePopup(false, "You have reached adding maximum member count!", "")
    }

  }
  // const handleMemberAdd = () => {
 
  //   let object: any = { ...SelectedMemberDetails }
  //   if (
  //     object.aadharNumber == "" ||
  //     object.relationType == "" ||
  //     object.gender == "" ||
  //     object.age == "" ||
  //     object.doorNo == "" ||
  //     object.district == "" ||
  //     object.mandal == "" ||
  //     object.villageOrCity == "" ||
  //     object.pinCode == "" ||
  //     object.relationName == "" ||
  //     object.mobileNumber == "" ||
  //     object.joiningDate == "" ||
  //     object.role == "" ||
  //     object.qualification == "" ||
  //     object.memberType == "" ||

  //     object.occupation == ""
  //   ) {
  //     return ShowMessagePopup(false, "Kindly fill all inputs for New member", "")
  //   } else if (object.soundMind !== "Yes") {
  //     return ShowMessagePopup(false, "Please select validate option for soundMind", "")
  //   } else if (object.inSolvent !== "No") {
  //     return ShowMessagePopup(false, "Please select validate option for insolvent", "")
  //   } else if (!object.memberType) {
  //     return ShowMessagePopup(false, "Please select member type", "")
  //   }
  //   else if (object.offense !== "No") {
  //     return ShowMessagePopup(false, "Please select validate option for offense", "")
  //   } else if (object.appointment !== "No") {
  //     return ShowMessagePopup(false, "Please select validate option for appointment", "")
  //   } else if (!object.mandal) {
  //     return ShowMessagePopup(false, "Please select mandal", "")
  //   } else if (!object.villageOrCity) {
  //     return ShowMessagePopup(false, "Please select village or city", "")
  //   } else if (
  //     object.mobileNumber &&
  //     (object.mobileNumber.length != 10 ||
  //       (object.mobileNumber.length == 10 &&
  //         object.mobileNumber.charAt(0) != "6" &&
  //         object.mobileNumber.charAt(0) != "7" &&
  //         object.mobileNumber.charAt(0) != "8" &&
  //         object.mobileNumber.charAt(0) != "9"))
  //   ) {
  //     return ShowMessagePopup(false, "Please enter vaild mobile number", "")
  //   } else if ((
  //     incomingMemberDetails?.length > 0 &&
  //     (incomingMemberDetails.some((x: any) => x.aadharNumber?.toString() == object.aadharNumber?.toString()) ||

  //       membersDetails.some((x: any) => x.aadharNumber?.toString() == object.aadharNumber?.toString())))
  //   ) {
  //     setTempMemorymember({ OTPRequested: false, AadharVerified: false })
  //     setSelectedMemberDetails(
  //       {
  //         //   OTPResponse: { transactionNumber: "" },
  //         // KYCResponse: {},
  //         memberType: "",
  //         relationName: "",
  //         joiningDate: "",
  //         qualification: "",
  //         soundMind: "",
  //         inSolvent: "",
  //         offense: "",
  //         appointment: "",
  //         maskedAadhar: "",
  //         aadharNumber: "",
  //         gender: "",
  //         role: "",
  //         age: "",
  //         otpStatus: "",
  //         otpCode: "",
  //         otpVerified: "",
  //         occupation: "",
  //         doorNo: "",
  //         street: "",
  //         country: "India",
  //         state: "Andhra Pradesh",
  //         district: "",
  //         mandal: "",
  //         villageOrCity: "",
  //         pinCode: "",
  //         mobileNumber: "",
  //         email: "",
  //         memberName: "",
  //         relationType: "",
  //       }

  //     )
  //     return ShowMessagePopup(
  //       false,
  //       "Aadhaar number is already exist. Please enter new aadhaar number",
  //       ""
  //     )
  //   } else if (parseInt(object.age) < 18) {
  //     setTempMemorymember({ OTPRequested: false, AadharVerified: false })
  //     setSelectedMemberDetails(
  //       {
  //         //   OTPResponse: { transactionNumber: "" },
  //         // KYCResponse: {},
  //         memberType: "",
  //         relationName: "",
  //         joiningDate: "",
  //         qualification: "",
  //         soundMind: "",
  //         inSolvent: "",
  //         offense: "",
  //         appointment: "",
  //         maskedAadhar: "",
  //         aadharNumber: "",
  //         gender: "",
  //         role: "",
  //         age: "",
  //         otpStatus: "",
  //         otpCode: "",
  //         otpVerified: "",
  //         occupation: "",
  //         doorNo: "",
  //         street: "",
  //         country: "India",
  //         state: "Andhra Pradesh",
  //         district: "",
  //         mandal: "",
  //         villageOrCity: "",
  //         pinCode: "",
  //         mobileNumber: "",
  //         email: "",
  //         memberName: "",
  //         relationType: "",
  //       }
  //     )
  //     return ShowMessagePopup(false, "Minimum age of partner should be 18", "")
  //   } else if (parseInt(object.share) < 0 || parseInt(object.share) >= 100) {
  //     return ShowMessagePopup(false, "share should be above 0 and less than 100 percent", "")
  //   } else if (
  //     incomingMemberDetails?.length > 0 &&
  //     incomingMemberDetails.some((x: any) => parseInt(x.mobileNumber) == parseInt(object.mobileNumber))
  //   ) {
  //     return ShowMessagePopup(
  //       false,
  //       "Mobile number is already exist. Please enter new mobile number",
  //       ""
  //     )
  //   } else if (
  //     incomingMemberDetails?.length > 0 &&
  //     incomingMemberDetails.some(
  //       (x: any) =>
  //         x.email != "" &&
  //         x.email?.length > 0 &&
  //         x.email.trim() != "" &&
  //         object.email != "" &&
  //         object.email.length > 0 &&
  //         object.email.trim() != "" &&
  //         x.email.toLowerCase() == object.email.toLowerCase()
  //     )
  //   ) {
  //     return ShowMessagePopup(false, "email is already exist. Please enter new email", "")
  //   }
  //   let Details: any[] = [...incomingMemberDetails]
  //   Details.push(object)
  //   setincomingMemberDetails(Details)
  //   setTempMemorymember({ OTPRequested: false, AadharVerified: false })
  //   setSelectedMemberDetails({
  //     //   OTPResponse: { transactionNumber: "" },
  //     // KYCResponse: {},
  //     memberType: "",
  //     relationName: "",
  //     joiningDate: "",
  //     qualification: "",
  //     soundMind: "",
  //     inSolvent: "",
  //     offense: "",
  //     appointment: "",
  //     maskedAadhar: "",
  //     aadharNumber: "",
  //     gender: "",
  //     role: "",
  //     age: "",
  //     otpStatus: "",
  //     otpCode: "",
  //     otpVerified: "",
  //     occupation: "",
  //     doorNo: "",
  //     street: "",
  //     country: "India",
  //     state: "Andhra Pradesh",
  //     district: "",
  //     mandal: "",
  //     villageOrCity: "",
  //     pinCode: "",
  //     mobileNumber: "",
  //     email: "",
  //     memberName: "",
  //     relationType: "",
  //   })
  //   ShowMessagePopup(true, "New Member Added Successfully", "")
  // }
  const handleMemberAdd = () => {
   
    let object: any = { ...SelectedMemberDetails }
    if (
      object.aadharNumber == "" ||
      object.relationType == "" ||
      object.gender == "" ||
      object.age == "" ||
      object.doorNo == "" ||
      object.district == "" ||
      object.mandal == "" ||
      object.villageOrCity == "" ||
      object.pinCode == "" ||
      object.relationName == "" ||
      object.mobileNumber == "" ||
      object.joiningDate == "" ||
      object.role == "" ||
      object.qualification == "" ||
      object.memberType == "" ||

      object.occupation == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for New member", "")
    } else if (object.soundMind !== "Yes") {
      return ShowMessagePopup(false, "Please select validate option for soundMind", "")
    } else if (object.inSolvent !== "No") {
      return ShowMessagePopup(false, "Please select validate option for insolvent", "")
    } else if (!object.memberType) {
      return ShowMessagePopup(false, "Please select member type", "")
    }
    else if (object.offense !== "No") {
      return ShowMessagePopup(false, "Please select validate option for offense", "")
    } else if (object.appointment !== "No") {
      return ShowMessagePopup(false, "Please select validate option for appointment", "")
    } else if (!object.mandal) {
      return ShowMessagePopup(false, "Please select mandal", "")
    } else if (!object.villageOrCity) {
      return ShowMessagePopup(false, "Please select village or city", "")
    } else if (
      object.mobileNumber &&
      (object.mobileNumber.length != 10 ||
        (object.mobileNumber.length == 10 &&
          object.mobileNumber.charAt(0) != "6" &&
          object.mobileNumber.charAt(0) != "7" &&
          object.mobileNumber.charAt(0) != "8" &&
          object.mobileNumber.charAt(0) != "9"))
    ) {
      return ShowMessagePopup(false, "Please enter vaild mobile number", "")
    } else if (
      afteramalgamationMemberDetails?.length > 0 &&
      afteramalgamationMemberDetails.some((x: any) => x.aadharNumber?.toString() == object.aadharNumber?.toString()&&x.status=="Active")
    ) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }

      )
      return ShowMessagePopup(
        false,
        "Aadhaar number is already exist. Please enter new aadhaar number",
        ""
      )
    } else if (parseInt(object.age) < 18) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }
      )
      return ShowMessagePopup(false, "Minimum age of partner should be 18", "")
    } else if (parseInt(object.share) < 0 || parseInt(object.share) >= 100) {
      return ShowMessagePopup(false, "share should be above 0 and less than 100 percent", "")
    } else if (
      afteramalgamationMemberDetails?.length > 0 &&
      afteramalgamationMemberDetails.some((x: any) => parseInt(x.mobileNumber) == parseInt(object.mobileNumber))
    ) {
      return ShowMessagePopup(
        false,
        "Mobile number is already exist. Please enter new mobile number",
        ""
      )
    } else if (
      afteramalgamationMemberDetails?.length > 0 &&
      afteramalgamationMemberDetails.some(
        (x: any) =>
          x.email != "" &&
          x.email?.length > 0 &&
          x.email.trim() != "" &&
          object.email != "" &&
          object.email.length > 0 &&
          object.email.trim() != "" &&
          x.email.toLowerCase() == object.email.toLowerCase()
      )
    ) {
      return ShowMessagePopup(false, "email is already exist. Please enter new email", "")
    }
    let Details: any[] = [...afteramalgamationMemberDetails]
    Details.push(object)
    setafteramalgamationMemberDetails(Details)
    setTempMemorymember({ OTPRequested: false, AadharVerified: false })
    setSelectedMemberDetails({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, "New Member Added Successfully", "")
  }
  const [applicantDetails, setApplicantDetails] = useState<ISApplicantDetailModel>({
    gender: "",
    age: "",
    maskedAadhar: "",
    aadharNumber: "",
    name: "",
    role: "",
    relationType: "",
    relationName: "",
    doorNo: "",
    street: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    phone: "",
    mobileNumber: "",
    email: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
  })
  const [requestType, setrequestType] = useState<any>({
    isAmalgamChange: "",
  })
  const [IncomingSocietiesDetails, setIncomingSocietiesDetails] = useState<any>([])

  const [societyDetails, setSocietyDetails] = useState<ISSocietyDetailsModel>({
    reasonForAmalgam: "",
    applicationNumber: "",
    incomingsociety: "",
    aim: "",
    objective: "",
    address: "",
    members: "",
    doorNo: "",
    street: "",
    state: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    amalgamationProcess: "",
    majority: "",
    quorum: "",
  })
  const [byelaws, setbyelaws] = useState<ISByLawsModel>({
    bearers: "",
    auditor: "",
    finance: "",
    funds: "",
    liabilities: "",
    settlements: "",
  })

  const [incomingMemberDetails, setincomingMemberDetails] = useState<
    ISIncomingMemberDetailsModel[]
  >([

  ])
  // TODO: change this type once uncommented below code is fixed
  const [quorumMemberDetails, setquorumMemberDetails] = useState<any[]>([
    {
      quorum: "",
      memberType: "",
      relationName: "",
      joiningDate: "",
      maskedAadhar: "",
      doorNo: "",
      street: "",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      aadharNumber: "",
      gender: "",
      age: "",
      address: "",
      role: "",
      occupation: "",
      mobileNumber: "",
      memberName: "",
    },
  ])
  const [membersDetails, setMembersDetails] = useState<any>([])
  const [byelawDetails, setbyelawDetails] = useState<any>({})
  const byelawsDetailsChange = (e: any) => {
    const data = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setbyelawDetails(data)
  }
  const [afteramalgamationMemberDetails, setafteramalgamationMemberDetails] = useState<any>([
    {
      memberType: "",
      relationName: "",
      joiningDate: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      doorNo: "",
      street: "",
      state: "",
      country: "",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      role: "",
      age: "",
      address: "",
      occupation: "",
      mobileNumber: "",
      memberName: "",
    },
  ])
  const [FormErrors, setFormErrors] = useState<any>({})
  const [selectedCount, setSelectedCount] = useState(0)
  const handleCheckboxChange = (event: any) => {
    const checkbox = event.target
    if (checkbox.checked) {
      if (selectedCount >= 3) {
        checkbox.checked = false
        return
      }
      setSelectedCount(selectedCount + 1)
    } else {
      setSelectedCount(selectedCount - 1)
    }
  }
  const [societyDetailsafteramalgamation, setsocietyDetailsafteramalgamation] = useState<
    ISSocietyDetailsAmalgamationModel | any
  >({
    Address: "",
    doorNo: "",
    street: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    amalgamationName: "",
    effectDate: "",
    newaim: "",
    newobjective: "",
  })
  const [isError, setIsError] = useState<boolean>(false)
  const [errorMessage, setErrorMessage] = useState<string>("")

  const [currentDistrict, setCurrentDistrict] = useState<string>("")
  const [districtList, setDistricts] = useState<any>([])
  const [currentMandal, setCurrentMandal] = useState<string>("")
  const [typelist] = useState<string[]>(["Individual", "Coorporate"])
  const [TempMemory, setTempMemory] = useState<any>({ OTPRequested: false, AadharVerified: false })

  const router = useRouter()
  const dispatch = useAppDispatch()
  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }
  // const popupState = () => {
  //   let data: any = localStorage.getItem("FASPLoginDetails")
  //   if (!data || data == null || data == "") {
  //     router.push("/")
  //   }
  // }
  // useEffect(() => {
  //   window.addEventListener("popstate", () => {
  //     popupState()
  //   })
  //   return () => {
  //     window.removeEventListener("popstate", () => {
  //       popupState()
  //     })
  //   }
  // }, [])
  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }
  const checkFirmDB = (e: any) => {
    e.preventDefault()
    const errors: any = {}

    let ob: any = {
      societyName: societyDetailsafteramalgamation.amalgamationName.trim(),
      district: existingSocietyDetail.district,
    }
    if (

      !societyDetailsafteramalgamation.amalgamationName ||
      societyDetailsafteramalgamation.amalgamationName.trim().length < 4 ||
      societyDetailsafteramalgamation.amalgamationName.trim().length > 20
    ) {
      errors["societyName"] = "*Society Name should contain 4 - 20 characters."
    } else {
      let obj: any = {
        registrationName: societyDetailsafteramalgamation.amalgamationName.trim(),
      }
      instance
        .post("checkAvailability", obj)
        .then((response: any) => {
          if (response.data.success == false) {
            ShowAlert(false, response.data.message)
            setIsCheckNation(false)
          }
          if (response.data.success == true) {
            instance
              .post("societies/check", ob)
              .then((response: any) => {
                if (
                  response.data.message == "Society already exists!" &&
                  response.data.success == false
                ) {
                  ShowAlert(false, response.data.message)
                }
                if (
                  response.data.message == "Society is available to register" &&
                  response.data.success == true
                ) {
                  ShowAlert(true, response.data.message)
                  setIsCheckFirm(true)
                } else {
                  setIsCheckFirm(false)
                }
              })
              .catch((error) => {
                if (error.message == "Request failed with status code 400") {
                  ShowAlert(false, "Society Name is Mandatory")
                }
              })
          } else {
            setIsCheckNation(false)
          }
          Loading(false)
        })
        .catch((error) => {
          if (error.message == "Request failed with status code 400") {
            ShowAlert(false, "Society Name & District is Mandatory")
          }
        })
    }
    setFormErrors({ ...errors })
  }

  const renderTabHeaders = (): any => {
    return tabs.map((item: string, index: number) => {
      return (
        <div
          className={activeTab === index ? styles.activeTabHeader : styles.tabHeader}
          key={index}
        >
          {item}
        </div>
      )
    })
  }

  const goToPrevTab = (): void => {
    if (document.getElementById("tabDiv")) {
      document.getElementById("tabDiv")?.scrollIntoView()
    }
    setActiveTab(activeTab < 1 ? activeTab : activeTab - 1)
  }

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
        // throw Error("Invalid File");
        ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
        e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])){
      if(!regex){
      ShowMessagePopup(false, "Please upload proper file name");
      e.target.value = "";
    }
  }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  const districtChange = (e: any) => {
    setCurrentDistrict(e.target.value)
    setCurrentMandal("")
  }

  const mandalChange = (e: any) => {
    setCurrentMandal(e.target.value)
  }

  const applicantDetailsChange = (e: any) => {
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        e.target.value.length > 0 &&
        e.target.value.length > applicantDetails.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          applicantDetails.aadharNumber.substring(0, startpos) +
          applicantDetails.aadharNumber.substring(
            startpos + 1,
            applicantDetails.aadharNumber.length
          )
      }
      setApplicantDetails({
        ...applicantDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? applicantDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
      setApplicantDetails(newInput)
    }
  }
  const societyDetailsChange = (e: any) => {
    setSocietyDetails({ ...societyDetails, [e.target.name]: e.target.value })
    console.log(societyDetails)
  }

  const amalgamationDetailsChange = (e: any) => {
    setsocietyDetailsafteramalgamation({
      ...societyDetailsafteramalgamation,
      [e.target.name]: e.target.value,
    })
    console.log(societyDetailsafteramalgamation)
  }

  const byelawdetailschange = (e: any) => {
    setbyelaws({ ...byelaws, [e.target.name]: e.target.value })
    console.log(byelaws)
  }

  const validateInputs = () => {
    let applicant: ISApplicantDetailModel = { ...applicantDetails }
    const errors: any = {}
    const societyDet = { ...societyDetails }
    const societyafteramalgamationDet = { ...societyDetailsafteramalgamation }
    if (activeTab === 0) {
      if (
        applicant.aadharNumber == "" ||
        applicant.name == "" ||
        applicant.relationName == "" ||
        applicant.role == "" ||
        applicant.doorNo == "" ||
        applicant.district == "" ||
        applicant.mandal == "" ||
        applicant.villageOrCity == "" ||
        applicant.pinCode == "" ||
        applicant.mobileNumber == ""
      ) {
        return ShowMessagePopup(false, "Kindly fill all required input fields")
      } else if (TempMemory.AadharVerified != true) {
        return ShowMessagePopup(false, "Plaese verify aadhar number")
      }
      return true
    } else if (activeTab === 2) {
      if (
        societyafteramalgamationDet.doorNo == "" ||
        societyafteramalgamationDet.street == "" ||
        societyafteramalgamationDet.district == "" ||
        societyafteramalgamationDet.mandal == "" ||
        societyafteramalgamationDet.villageOrCity == "" ||
        societyafteramalgamationDet.pinCode == "" ||
        societyafteramalgamationDet.amalgamationName == "" ||
        societyafteramalgamationDet.effectDate == "" ||
        societyafteramalgamationDet.newaim == "" ||
        societyafteramalgamationDet.newobjective == ""
      ) {
        return ShowMessagePopup(false, "Kindly fill all required input fields")
      } else if (afteramalgamationMemberDetails?.length < 3) {
        return ShowMessagePopup(false, "Minimum 3 members should me there in the society")
      }
      return true
    } else if (activeTab === 3) {
      if (byelaws.bearers != "Yes") {
        return ShowMessagePopup(false, "Please select validate option for bearers")
      }
      if (byelaws.auditor != "Yes") {
        return ShowMessagePopup(false, "Please select validate option for auditor")
      }
      if (byelaws.finance != "Yes") {
        return ShowMessagePopup(false, "Please select validate option for finance")
      }
      if (byelaws.funds != "Yes") {
        return ShowMessagePopup(false, "Please select validate option for funds")
      }
      if (byelaws.liabilities != "Yes") {
        return ShowMessagePopup(false, "Please select validate option for liabilities")
      }
      if (byelaws.settlements != "Yes") {
        return ShowMessagePopup(false, "Please select validate option for settlements")
      }

      return true
    }
    return true
  }
  const districtmemberChange = (e: any) => {
    setCurrentmemberDistrict(e.target.value)
    setCurrentmemberMandal("")
  }
  const mandalmemberChange = (e: any) => {
    setCurrentmemberMandal(e.target.value)
  }
  const handleMemberRemovenew = (index: number) => {
    let data: any = [...incomingMemberDetails]
    data.splice(index, 1)
    setincomingMemberDetails(data)
  }
  const handleMemberEdit = (index: number) => {
    Loading(true)
    setTimeout(() => {
      setCurrentmemberDistrict(incomingMemberDetails[index].district)
      setCurrentmemberMandal(incomingMemberDetails[index].mandal)
      setindexmember(index)
      setTempMemorymember({ OTPRequested: false, AadharVerified: true })

      setSelectedMemberDetails(incomingMemberDetails[index])

      console.log("membersDetails[index]", incomingMemberDetails[index])
      Loading(false)
    }, 800);

  }
  const generateApplicantOtp = async () => {
    if (applicantDetails.aadharNumber && applicantDetails.aadharNumber.length == 12) {
      Loading(true)
      let result = await UseGetAadharOTP(btoa(applicantDetails.aadharNumber))
      Loading(false)
      if (result && result.status === "Success") {
        ShowAlert(true, "OTP Sent to Aadhaar Registered Mobile Number")
        setSentOTP(true)
        setAadhaarOTPResponse(result)
        let data = { ...applicantDetails }
        data["otpStatus"] = "1"
        setApplicantDetails(data)
      } else {
        ShowAlert(false, "Please Enter Valid Aadhar")
        setAadhaarOTPResponse({})
        let data = { ...applicantDetails }
        data["otpStatus"] = "2"
        setApplicantDetails(data)
      }
    } else {
      ShowAlert(false, "Kindly enter valid Aadhar number")
    }
  }

  async function getFileFromUrl(url: any, name: any, defaultType = "pdf") {
    const response = await instance.get(url, { responseType: "arraybuffer" })

    return new File([response.data], name, {
      type: defaultType,
    })
  }
  useEffect(() => {
    if (
      activeTab === 2 &&
      existingSocietyDetail?.memberDetails &&
      existingSocietyDetail?.memberDetails?.length > 0
    ) {
      setafteramalgamationMemberDetails([
        ...existingSocietyDetail?.memberDetails,
        ...incomingMemberDetails,
      ])
      setbyelawDetails({
        ...byelawDetails, quorumSize: Math.round(((existingSocietyDetail.memberDetails.length + incomingMemberDetails.length) / 2) + 1)
      })
    } else if (activeTab === 2) {
      setafteramalgamationMemberDetails([...incomingMemberDetails])
    }
  }, [activeTab])
  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setToken(data?.token)
    setLoggedInAadhar(data?.aadharNumber)
    setApplicantDetails({
      ...applicantDetails,
    })
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)
        getSocietyDetails(data.applicationId, data.token)
          .then((response) => {
            if (response?.success) {
              setExistingSocietyDetail(response.data.daSociety)
              setSocietyDetails({
                doorNo: "",
                street: "",
                state: "",
                district: "",
                applicationNumber: "",
                mandal: "",
                villageOrCity: "",
                pinCode: "",
                amalgamationProcess: "",
                majority: "",
                quorum: "",
                members: "",
                reasonForAmalgam: "",
                aim: "",
                objective: "",
                incomingsociety: "",
                address: "",
              })

              if (
                response.data.daSociety.memberDetails &&
                response.data.daSociety.memberDetails?.length > 0
              ) {
                response.data.daSociety.memberDetails.forEach(
                  (a: any) =>
                    (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber.toString().substring(8, 12))
                )
                setafteramalgamationMemberDetails([
                  ...incomingMemberDetails,
                  ...response.data.daSociety.memberDetails,
                ])
              }
              if (
                response.data.daSociety?.memberDetails &&
                response.data.daSociety?.memberDetails?.length > 0
              ) {
                response.data.daSociety.memberDetails.forEach(
                  (a: any) =>
                    (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber?.toString().substring(8, 12))
                )
                setMembersDetails([...response.data.daSociety.memberDetails])
              }
             
              if (response.data.daSociety.byeLaws) {
               
                setbyelawDetails({
                  ...byelawDetails,
                  // quorumSize: Math.round((response.data.daSociety.memberDetails.length/2)+1),
                  quorumSize: Math.round(((response.data.daSociety.memberDetails.length + incomingMemberDetails.length) / 2) + 1)
                  // quorumSize: Math.round((afteramalgamationMemberDetails.length/ 2) + 1)
                })
              }
              console.log("afteramalgamationMemberDetails", afteramalgamationMemberDetails.length)
            }
          })
          .catch(() => {
            Loading(false)
          })
        Loading(false)
      })
      .catch(() => {
        Loading(false)
      })
  }, [])
  const getdetails = (index: any) => {
    // let datasociety = {...societyDetails} 

    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setToken(data?.token)
    setLoggedInAadhar(data?.aadharNumber)
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)
    
        getSocietyDetailsbyAppNo(societyDetails.applicationNumber, data.token)
          .then((response) => {
        
            if (response?.success) {
          
              if (!IncomingSocietiesDetails.some((x: any) => x.applicationNumber == response.data.daSociety.applicationNumber)) {
                setIncomingSocietiesDetails([...IncomingSocietiesDetails, response.data.daSociety])
              } else {
                ShowMessagePopup(false, "Society is already taken.Please enter new society")
              }

            }
          })
          .catch(() => {
            Loading(false)
          })
        Loading(false)
      })
      .catch(() => {
        Loading(false)
      })
  }
  const file2Base64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      if (reader && reader != null && file) {
        reader.readAsDataURL(file)
        reader.onload = () => resolve(reader.result?.toString() || "")
        reader.onerror = (error) => reject(error)
      } else {
        resolve("")
      }
    })
  }

  const handleMemberRemove = (index: number) => {
    let data = [...afteramalgamationMemberDetails]
    delete data[index]
    let memList: ISAmalgamationMemberDetails[] = []
    data.forEach((x) => {
      if (x) {
        memList.push(x)
      }
    })
    setafteramalgamationMemberDetails(memList)
  }
  const [checkedList, setCheckedList] = useState<string[]>([])

  const [checkedItems, setCheckedItems] = useState<any[]>([])
  const changeCheck = (e: React.ChangeEvent<HTMLInputElement>) => {
    const checkedValue = e.target.value
    const isChecked = e.target.checked
    if (isChecked) {
      setCheckedList((prevCheckedList) => [...prevCheckedList, checkedValue])
      //  array list
      const checkedItem = afteramalgamationMemberDetails.find(
        (item: any) => item.memberName == checkedValue
      )
      if (checkedItem && !checkedItems.some((item) => item.memberName === checkedValue)) {
        setCheckedItems((prevCheckedItems) => [...prevCheckedItems, checkedItem])
      } else {
        setCheckedList((prevCheckedList) =>
          prevCheckedList.filter((value) => value !== checkedValue)
        )
      }
    } else {
      setCheckedList((prevCheckedList) => prevCheckedList.filter((value) => value !== checkedValue))
      setCheckedItems((prevCheckedItems) =>
        prevCheckedItems.filter((item) => item.memberName !== checkedValue)
      )
    }
  }
  const handleSubmit = async (e: any) => {
    e.preventDefault()
    if (validateInputs()) {
      if (activeTab < 3) {
        setActiveTab(activeTab + 1)
        if (activeTab == 2) {
          setafteramalgamationMemberDetails([
            ...incomingMemberDetails,
            ...existingSocietyDetail?.memberDetails,
          ])
        }
      }
      const {
        idProofs,
        memorandum,
        byeLaws,
        affidavit,
        affidavitByAuditor,
        selfSignedDeclaration,
      } = file
      const data = {
        applicantDetails: applicantDetails,
        // memorandum: memorandum,
        // affidavitByAuditor: affidavitByAuditor,
        // idProofs: idProofs,
        // byeLaws: byeLaws,
        // affidavit: affidavit,
        // selfSignedDeclaration: selfSignedDeclaration,
        societyDetails: societyDetails,
        incomingMemberDetails: incomingMemberDetails,
        afteramalgamationMemberDetails: afteramalgamationMemberDetails,
        quorumMemberDetails: quorumMemberDetails,
        societyDetailsafteramalgamation: societyDetailsafteramalgamation,
      }

      const newData = new FormData()
      newData.append("id", existingSocietyDetail._id)
      newData.append("applicantDetails[aadharNumber]", btoa(data.applicantDetails.aadharNumber))
      newData.append("applicantDetails[applicationNumber]", existingSocietyDetail.applicationNumber)
      newData.append("applicantDetails[name]", data.applicantDetails.name)
      newData.append("applicantDetails[doorNo]", data.applicantDetails.doorNo)
      newData.append("applicantDetails[street]", data.applicantDetails.street)
      newData.append("applicantDetails[age]", data.applicantDetails.age)
      newData.append("applicantDetails[gender]", data.applicantDetails.gender)
      newData.append("applicantDetails[country]", "India")
      newData.append("applicantDetails[state]", "Andhra Pradesh")
      newData.append("applicantDetails[district]", data.applicantDetails.district)
      newData.append("applicantDetails[mandal]", data.applicantDetails.mandal)
      newData.append("applicantDetails[villageOrCity]", data.applicantDetails.villageOrCity)
      newData.append("applicantDetails[pinCode]", data.applicantDetails.pinCode)
      newData.append("applicantDetails[mobileNumber]", data.applicantDetails.mobileNumber)
      newData.append("applicantDetails[relationType]", data.applicantDetails.relationType)
      newData.append("applicantDetails[relationName]", data.applicantDetails.relationName)

      if (
        checklistamalgam &&
        checklistamalgam.length > 0 &&
        checklistamalgam.some((x: string) => x == "Amalgamation of the society")
      ) {
        newData.append("isAmalgamChange", "true")
      } else {
        newData.append("isAmalgamChange", "false")
      }
      for (let i = 0; i < IncomingSocietiesDetails?.length; i++) {
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][societyName]", IncomingSocietiesDetails[i].societyName)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][reasonForAmalgam]", IncomingSocietiesDetails[i].reasonForAmalgam)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][doorNo]", IncomingSocietiesDetails[i].doorNo)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][street]", IncomingSocietiesDetails[i].street)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][country]", "India")
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][state]", "Andhra Pradesh")
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][district]", IncomingSocietiesDetails[i].district)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][mandal]", IncomingSocietiesDetails[i].mandal)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][villageOrCity]", IncomingSocietiesDetails[i].villageOrCity)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][pinCode]", IncomingSocietiesDetails[i].pinCode)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][aim]", IncomingSocietiesDetails[i].aim)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][objective]", IncomingSocietiesDetails[i].objective)
        newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][applicationNumber]", IncomingSocietiesDetails[i].applicationNumber)
        // newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingSocietyDetails][amalgamStatus]", "InActive")
        for (let j = 0; j < IncomingSocietiesDetails?.memberDetails?.length; j++) {
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][aadharNumber]", btoa(IncomingSocietiesDetails[i].memberDetails[j].aadharNumber))
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][memberName]", IncomingSocietiesDetails[i].memberDetails[j].memberName)
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][relationName]", IncomingSocietiesDetails[i].memberDetails[j].relationName)
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][occupation]", IncomingSocietiesDetails[i].memberDetails[j].occupation)
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][age]", IncomingSocietiesDetails[i].memberDetails[j].age)
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][gender]", IncomingSocietiesDetails[i].memberDetails[j].gender)
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][role]", IncomingSocietiesDetails[i].memberDetails[j].role)
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][joiningDate]", IncomingSocietiesDetails[i].memberDetails[j].joiningDate)
          newData.append(
            "incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][street]",
            IncomingSocietiesDetails[i].memberDetails[j].street ? IncomingSocietiesDetails[i].memberDetails[j].street : ""
          )
          newData.append(
            "incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][doorNo]",
            IncomingSocietiesDetails[i].memberDetails[j].doorNo ? IncomingSocietiesDetails[i].memberDetails[j].doorNo : ""
          )
          newData.append(
            "incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][district]",
            IncomingSocietiesDetails[i].memberDetails[j].district ? IncomingSocietiesDetails[i].memberDetails[j].district : ""
          )
          newData.append(
            "incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][mandal]",
            IncomingSocietiesDetails[i].memberDetails[j].mandal ? IncomingSocietiesDetails[i].memberDetails[j].mandal : ""
          )
          newData.append(
            "incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][villageOrCity]",
            IncomingSocietiesDetails[i].memberDetails[j].villageOrCity ? IncomingSocietiesDetails[i].memberDetails[j].villageOrCity : ""
          )
          newData.append(
            "incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][pinCode]",
            IncomingSocietiesDetails[i].memberDetails[j].pinCode ? IncomingSocietiesDetails[i].memberDetails[j].pinCode : ""
          )
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][status]", "Active")
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][country]", "India")
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][state]", "Andhra Pradesh")
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][memberType]", IncomingSocietiesDetails[i].memberDetails[j].memberType)
          newData.append("incomingSocietyAmalgamDetails[" + i + "][incomingmemberDetails][" + j + "][mobileNumber]", IncomingSocietiesDetails[i].memberDetails[j].mobileNumber)
        }
      }
      newData.append("country", "India")
      newData.append("state", "Andhra Pradesh")
      console.log("afteramalgamationMemberDetails::", afteramalgamationMemberDetails);
      for (let j = 0; j < afteramalgamationMemberDetails?.length; j++) {
        newData.append("memberDetails[" + j + "][aadharNumber]", btoa(data.afteramalgamationMemberDetails[j].aadharNumber))
        newData.append("memberDetails[" + j + "][memberName]", data.afteramalgamationMemberDetails[j].memberName)
        newData.append("memberDetails[" + j + "][relationName]", data.afteramalgamationMemberDetails[j].relationName)
        newData.append("memberDetails[" + j + "][occupation]", data.afteramalgamationMemberDetails[j].occupation)
        newData.append("memberDetails[" + j + "][age]", data.afteramalgamationMemberDetails[j].age)
        newData.append("memberDetails[" + j + "][gender]", data.afteramalgamationMemberDetails[j].gender)
        newData.append("memberDetails[" + j + "][role]", data.afteramalgamationMemberDetails[j].role)
        newData.append("memberDetails[" + j + "][joiningDate]", data.afteramalgamationMemberDetails[j].joiningDate)
        newData.append(
          "memberDetails[" + j + "][street]",
          data.afteramalgamationMemberDetails[j].street ? data.afteramalgamationMemberDetails[j].street : ""
        )
        newData.append(
          "memberDetails[" + j + "][doorNo]",
          data.afteramalgamationMemberDetails[j].doorNo ? data.afteramalgamationMemberDetails[j].doorNo : ""
        )
        newData.append(
          "memberDetails[" + j + "][district]",
          data.afteramalgamationMemberDetails[j].district ? data.afteramalgamationMemberDetails[j].district : ""
        )
        newData.append(
          "memberDetails[" + j + "][mandal]",
          data.afteramalgamationMemberDetails[j].mandal ? data.afteramalgamationMemberDetails[j].mandal : ""
        )
        newData.append(
          "memberDetails[" + j + "][villageOrCity]",
          data.afteramalgamationMemberDetails[j].villageOrCity ? data.afteramalgamationMemberDetails[j].villageOrCity : ""
        )
        newData.append(
          "memberDetails[" + j + "][pinCode]",
          data.afteramalgamationMemberDetails[j].pinCode ? data.afteramalgamationMemberDetails[j].pinCode : ""
        )
        newData.append("memberDetails[" + j + "][status]", "Active")
        newData.append("memberDetails[" + j + "][country]", "India")
        newData.append("memberDetails[" + j + "][state]", "Andhra Pradesh")
        newData.append("memberDetails[" + j + "][memberType]", data.afteramalgamationMemberDetails[j].memberType)
        newData.append("memberDetails[" + j + "][mobileNumber]", data.afteramalgamationMemberDetails[j].mobileNumber)
      }
      newData.append("societyName", data.societyDetailsafteramalgamation.amalgamationName)
      newData.append("effectDate", data.societyDetailsafteramalgamation.effectDate)
      newData.append("aim", data.societyDetailsafteramalgamation.newaim)
      newData.append("objective", data.societyDetailsafteramalgamation.newobjective)
      newData.append("doorNo", data.societyDetailsafteramalgamation.doorNo)
      newData.append("street", data.societyDetailsafteramalgamation.street)
      newData.append("district", data.societyDetailsafteramalgamation.district)
      newData.append("mandal", data.societyDetailsafteramalgamation.mandal)
      newData.append(
        "villageOrCity",
        data.societyDetailsafteramalgamation.villageOrCity
      )
      newData.append("pinCode", data.societyDetailsafteramalgamation.pinCode)
      newData.append("idProofs", file.idProofs)
      newData.append("memorandum", file.memorandum)
      newData.append("byeLaws", file.byeLaws)
      newData.append("affidavitByAuditor", file.affidavitByAuditor)
      newData.append("affidavit", file.affidavit)
      newData.append("selfSignedDeclaration", file.selfSignedDeclaration)
      let object: any = {}
      if (activeTab === 3) {
        newData.forEach((value, key) => (object[key] = value))
        object.selfSignedDeclaration = await file2Base64(file?.selfSignedDeclaration)
        object.byeLaws = await file2Base64(file?.byeLaws)
        object.idProofs = await file2Base64(file?.idProofs)
        object.memorandum = await file2Base64(file?.memorandum)
        object.affidavitByAuditor = await file2Base64(file?.affidavitByAuditor)
        object.affidavit = await file2Base64(file?.affidavit)
        localStorage.setItem("AmendmentData", JSON.stringify(object))
        //store.dispatch(SaveDocumentDetails(JSON.stringify(object)))

        let code = 0
        const dis = districtList?.find((x: any) => x.name == existingSocietyDetail.district)
        if (dis) {
          code = dis.code
        }
        const paymentsData = {
          type: "sra",
          source: "Society",
          deptId: existingSocietyDetail.applicationNumber,
          rmName: existingSocietyDetail.applicantDetails.name,
          rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
          mobile: existingSocietyDetail.applicantDetails.mobileNumber,
          email: existingSocietyDetail.applicantDetails.email,
          drNumber: code,
          rf: 300,
          uc: 0,
          oc: 0,
          returnURL: process.env.BACKEND_URL + "/societies/redirectPayment",
        }
        let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
        const encodedData = CryptoJS.AES.encrypt(
          JSON.stringify(paymentsData),
          'igrsSecretPhrase'
        ).toString()
        let paymentLink = document.createElement("a")
        paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
        //paymentLink.target = "_blank";
        paymentLink.click()
        setIsPayNowClicked(false)
        setTimeout(function () {
          paymentLink.remove()
        }, 1000)
      }
    }
  }

  // const membersDetailsChange = (e: any, index: any) => {
  //   if (e.target.name == "maskedAadhar") {
  //     let data = [...incomingMemberDetails]
  //     let newNo = ""
  //     let newVal = ""
  //     let aadharNo = ""
  //     if (e.target.value.length > 0 && e.target.value.length > data[index].aadharNumber.length) {
  //       newNo = e.target.value[e.target.value.length - 1]
  //     } else if (e.target.value.length == 0) {
  //       newNo = "del"
  //     }
  //     for (let i = 0; i <= e.target.value.length - 1; i++) {
  //       if (i < 8) {
  //         newVal = newVal + "X"
  //       } else {
  //         newVal = newVal + e.target.value[i]
  //       }
  //     }
  //     if (newNo == "") {
  //       let startpos = parseInt(e.target.selectionStart)
  //       aadharNo =
  //         data[index].aadharNumber.substring(0, startpos) +
  //         data[index].aadharNumber.substring(startpos + 1, data[index].aadharNumber.length)
  //     }
  //     const det = {
  //       ...data[index],
  //       maskedAadhar: newVal,
  //       aadharNumber:
  //         newNo == "del" ? "" : newNo != "" ? data[index].aadharNumber + newNo : aadharNo,
  //     }
  //     data.splice(index, 1, det)

  //     setincomingMemberDetails(data)
  //   } else {
  //     let data = [...incomingMemberDetails]
  //     const det = { ...data[index], [e.target.name]: e.target.value }
  //     data.splice(index, 1, det)
  //     setincomingMemberDetails(data)
  //   }
  // }
  const [relationtypelist] = useState<any>(["S/O", "D/O", "W/O", "H/O"])
  const [roleList] = useState<any>([
    "President",
    "Vice President",
    "Secretary",
    "Joint Secretary",
    "Treasurer",
    "Member",
  ])
  const membersDetailsChange = (e: any) => {
    let tempDetails: any = { ...SelectedMemberDetails }
    let AddName = e.target.name
    let AddValue = e.target.value

    if (AddName == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        // SelectedMemberDetails.aadharNumber &&
        e.target.value.length > 0 &&
        e.target.value.length > SelectedMemberDetails?.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value && e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          SelectedMemberDetails?.aadharNumber?.substring(0, startpos) +
          SelectedMemberDetails?.aadharNumber?.substring(
            startpos + 1,
            SelectedMemberDetails?.aadharNumber?.length
          )
      }
      setSelectedMemberDetails({
        ...tempDetails,
        [AddName]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? SelectedMemberDetails?.aadharNumber + newNo : aadharNo,
      })
    } else {
      setSelectedMemberDetails({ ...tempDetails, [AddName]: AddValue })
    }
  }
  const ReqDetails = async (MyKey: any) => {
    let result = await CallingAxios(
      UseGetAadharDetails({
        aadharNumber: btoa(MyKey.aadharNumber),
        transactionNumber: MyKey?.OTPResponse?.transactionNumber,
        otp: MyKey.otpCode,
      })
    )
    if (
      result.status &&
      result.status === "Success" &&
      MyKey?.OTPResponse?.transactionNumber == result.transactionNumber.split(":")[1]
    ) {
      let latestData: any = {
        ...MyKey,
        name: result.userInfo.name ? result.userInfo.name.toUpperCase() : "",
        memberName: result.userInfo.name ? result.userInfo.name.toUpperCase() : "",
        relationType: result.userInfo.co ? result.userInfo.co.substring(0, 3) : "",
        relationName: result.userInfo.co ? result.userInfo.co.substring(4).toUpperCase() : "",
        age: result.userInfo.dob ? ageCalculator(result.userInfo.dob) : "",
        gender: result.userInfo.gender.toUpperCase() == "M" ? "Male" : "Female",
        district: result.userInfo.dist ? result.userInfo.dist.toUpperCase() : "",
        pinCode: result.userInfo.pc ? result.userInfo.pc : "",
        street: result.userInfo.loc ? result.userInfo.street : "",
        villageOrCity: result.userInfo.vtc ? result.userInfo.vtc : "",
        doorNo: result.userInfo.house ? result.userInfo.house : "",
        address:
          (result.userInfo.lm ? result.userInfo.lm + ", \n" : "") +
          (result.userInfo.loc ? result.userInfo.loc + ", \n" : "") +
          (result.userInfo.dist ? result.userInfo.dist + ", \n" : "") +
          (result.userInfo.vtc ? result.userInfo.vtc : "") +
          (result.userInfo.pc ? "-" + result.userInfo.pc : ""),
        OTPResponse: result,
      }

      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails(latestData)
          setTempMemory({ OTPRequested: false, AadharVerified: true })
          break
        case SelectedMemberDetails:
          setSelectedMemberDetails(latestData)
          setTempMemorymember({ OTPRequested: false, AadharVerified: true })
          break

        default:
          break
      }
    } else {
      ShowMessagePopup(false, "Please Enter Valid OTP", "")
      setApplicantDetails({
        ...applicantDetails,
        otpCode: "",
      })
    }
  }
  const ReqOTP = (MyKey: any) => {
    if (MyKey.aadharNumber && MyKey.aadharNumber.length == 12) {
      CallGetOTP(MyKey)
    } else {
      ShowMessagePopup(false, "Kindly enter valid Aadhar number", "")
    }
  }
  const CallingAxios = async (myFunction: any) => {
    Loading(true)
    let result = await myFunction
    Loading(false)
    return result
  }
  const CallGetOTP = async (MyKey: any) => {
    if (process.env.IGRS_SECRET_KEY) {
      
      const ciphertext = AES.encrypt(MyKey.aadharNumber, process.env.IGRS_SECRET_KEY)
      let result = await CallingAxios(UseGetAadharOTP(ciphertext.toString()))
      
      if (result && result.status != "Failure") {
        switch (MyKey) {
          case applicantDetails:
            setTempMemory({ OTPRequested: true, AadharVerified: false })
            break
          case SelectedMemberDetails:
            setTempMemorymember({ OTPRequested: true, AadharVerified: false })
            break
          default:
            break
        }
        switch (MyKey) {
          case applicantDetails:
            setApplicantDetails({ ...MyKey, OTPResponse: result })
            break
          case SelectedMemberDetails:
            setSelectedMemberDetails({ ...MyKey, OTPResponse: result })
            break
          default:
            break
        }
        ShowMessagePopup(
          true,
          "OTP Sent to Aadhaar Registered Mobile Number.",
          ""
        )
      }
      else {

        switch (MyKey) {
          case applicantDetails:
            setApplicantDetails({
              ...MyKey,
              otpCode: "",
              OTPResponse: { transactionNumber: "" },
              KYCResponse: {},
            })
            setTempMemory({ OTPRequested: false, AadharVerified: false })
            break
          case SelectedMemberDetails:
            setSelectedMemberDetails({
              ...MyKey,
              otpCode: "",
              OTPResponse: { transactionNumber: "" },
              KYCResponse: {},
            })
            setTempMemorymember({ OTPRequested: false, AadharVerified: false })
            break
          default:
            break
        }
        ShowMessagePopup(false, "Please Enter Valid Aadhar", "")
        setApplicantDetails({
          ...applicantDetails,
          maskedAadhar: "",

        })
      }
    }
  }
  const afteramalgamationMemberDetailsChange = (e: any, index: any) => {
    if (e.target.name == "maskedAadhar") {
      let data = [...afteramalgamationMemberDetails]
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (e.target.value.length > 0 && e.target.value.length > data[index].aadharNumber.length) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          data[index].aadharNumber.substring(0, startpos) +
          data[index].aadharNumber.substring(startpos + 1, data[index].aadharNumber.length)
      }
      const det = {
        ...data[index],
        maskedAadhar: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? data[index].aadharNumber + newNo : aadharNo,
      }
      data.splice(index, 1, det)

      setafteramalgamationMemberDetails(data)
    } else {
      let data = [...afteramalgamationMemberDetails]
      const det = { ...data[index], [e.target.name]: e.target.value }
      data.splice(index, 1, det)
      setafteramalgamationMemberDetails(data)
    }
  }
  const quorumAfterAmalgamationChange = (e: any, index: any) => {
    let AddName = e.target.name
    let AddValue = e.target.value
    if (AddName == "quorum") {
      AddValue = e.target.checked
      setquorumMemberDetails({ ...quorumMemberDetails, [AddName]: AddValue })
    } else {
      setquorumMemberDetails({ ...quorumMemberDetails, [AddName]: AddValue })
    }
  }

  const tableHeaders = [
    "Type",
    "Aadhaar No ",
    "Name of the Member",
    "Relation Name",
    "Age / Gender",
    "Role/Position",
    "Occupation",
    "Date of Joining",
    "Address",
    "Contact Details",
  ]

  const tableHeaders1 = [
    // <Form.Check
    //   inline
    //   label=""
    //   value="quorm"
    //   name="quorum"
    //   type="checkbox"
    //   className="fom-checkbox"
    // />,
    "Type",
    "Aadhaar No ",
    "Name of the Member",
    "Relation Name",
    "Age / Gender",
    "Role/Position",
    "Occupation",
    "Date of Joining",
    "Address",
    "Contact Details",
  ]

  const tableHeaders2 = [
    "Type",
    "Aadhaar No ",
    "Name of the Member",
    "Relation Name",
    "Age / Gender",
    "Role/Position",
    "Occupation",
    "Date of Joining",
    "Address",
    "Contact Details",
  ]

  return (
    <>
      <Head>
        <title>Amalgamation of the Society</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      <div className={styles.RegistrationMain}>
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between align-items-center page-title mb-3">
                  <div className="pageTitleLeft">
                    <h1>Amalgamation of the Society(Section 21)</h1>
                  </div>
                  {/* <div className="pageTitleRight">
                    <div className="page-header-btns">
                      <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                        Go Back
                      </a>
                    </div>
                  </div> */}
                </div>
              </Col>
            </Row>
            {/* {checklist &&
                    checklist.length > 0 &&
                    checklist.some((x: string) => x == "Amalgamation of the society") ? (
                    <Col lg={4} md={12} sm={12}>
                      <div className="firmDuration">
                        <Form.Check
                          inline
                          label="Change in the name of the society"
                          value={requestType.isAmalgamChange}
                          name="isNameChange"
                          type="checkbox"
                          className="fom-checkbox"
                          disabled={true}
                          checked={true}
                        />

                      </div>{" "}
                    </Col>
                  ) : null} */}
            <Row>
              <Col lg={8} md={12} xs={12}>
                <div className={styles.tabContainer} id="tabDiv">
                  {renderTabHeaders()}
                </div>
              </Col>
            </Row>
          </Container>
          {/* <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit}> */}
          <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
            <Container>
              {activeTab === 0 && (
                <div className="regofAppBg mb-3">
                  <Container>
                    <div className="formsec panelDesc">
                      <Row>
                        <Col lg={3} md={3} xs={12} >
                          {!TempMemory.OTPRequested ? (
                            <Form.Group>
                              <TableText
                                label="Enter Aadhaar Number"
                                required={true}
                                LeftSpace={false}
                              />
                              <div className="formGroup">
                                <TableInputText
                                  disabled={TempMemory.AadharVerified}
                                  type={"text"}
                                  maxLength={12}
                                  dot={false}
                                  placeholder="Enter Aadhaar Number"
                                  required={true}
                                  name={"maskedAadhar"}
                                  value={applicantDetails.maskedAadhar}
                                  onChange={(e: any) => {
                                    if (!TempMemory.AadharVerified) {
                                      applicantDetailsChange(e)
                                    }
                                  }}
                                  onKeyPress={true}
                                  onPaste={(e: any) => e.preventDefault()}
                                />
                                {!TempMemory.AadharVerified ? (
                                  <div
                                    style={{
                                      display: "flex",
                                      justifyContent: "center",
                                      alignItems: "center",
                                      borderRadius: "2px",
                                    }}
                                    onClick={() => ReqOTP(applicantDetails)}
                                    className="verify btn btn-primary"
                                  >
                                    Get OTP
                                  </div>
                                ) : null}
                              </div>
                            </Form.Group>
                          ) : (
                            <Form.Group>
                              <TableText label="Enter OTP" required={true} LeftSpace={false} />
                              <div className="formGroup">
                                <TableInputText
                                  disabled={false}
                                  type="number"
                                  placeholder="Enter OTP Received"
                                  maxLength={6}
                                  required={true}
                                  name={"otpCode"}
                                  value={applicantDetails.otpCode}
                                  onChange={applicantDetailsChange}
                                />
                                <div
                                  style={{
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    borderRadius: "2px",
                                  }}
                                  onClick={() => {
                                    ReqDetails(applicantDetails)
                                  }}
                                  className="verify btn btn-primary"
                                >
                                  Verify
                                </div>
                                <div style={{ display: "flex", justifyContent: "flex-end" }}>
                                  <div
                                    style={{
                                      cursor: "pointer",
                                      marginRight: "20px",
                                      color: "blue",
                                      fontSize: "10px",
                                    }}
                                    onClick={() => {
                                      setTempMemory({ ...TempMemory, OTPRequested: false })

                                    }}
                                  >
                                    clear
                                  </div>
                                </div>
                              </div>
                            </Form.Group>
                          )}
                        </Col>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <TableText
                            label="Name of the Applicant"
                            required={false}
                            LeftSpace={false}
                          />
                          <TableInputText
                            type="text"
                            placeholder="Enter Name of the Applicant"
                            required
                            name="name"
                            value={applicantDetails.name}
                            onChange={()=>{}}
                            maxLength={12}
                            disabled
                          />
                          <Row className={styles.columnText} style={{ display: "flex" }}>
                            <Col lg={9} md={4} xs={12}>
                              Gender: {applicantDetails.gender} / Age: {applicantDetails.age}
                            </Col>
                          </Row>
                        </Col>
                        <Col lg={3} md={12} sm={12} className="">
                          <TableText label="Relation Name" required={false} LeftSpace={false} />
                          <Form.Group className="inline">
                            <div className="inline formGroup">
                              <Form.Select
                                name="relationType"
                                onChange={applicantDetailsChange}
                                value={applicantDetails.relationType}
                              >
                                <option>S/O</option>
                                <option>D/O</option>
                                <option>W/O</option>
                                <option>H/O</option>
                              </Form.Select>
                              <input
                                className="form-control"
                                type="text"
                                style={{ textTransform: 'uppercase' }}
                                name="relationName"
                                onChange={()=>{}}
                                value={applicantDetails.relationName}
                                disabled={true}
                              />
                            </div>
                          </Form.Group>
                        </Col>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <TableText label="Role" required={false} LeftSpace={false} />
                          <TableInputText
                            type="text"
                            placeholder="Enter Role"
                            name="role"
                            required
                            value={applicantDetails.role}
                            onChange={applicantDetailsChange}
                          />
                          {errors.role && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.role}
                            </span>
                          )}
                        </Col>
                      </Row>
                      <div className="regFormBorder"></div>
                      <div className=" page-title mb-3">
                        <div className="formSectionTitle">
                          <h3>Address</h3>
                        </div>

                        <Row>
                          <Col lg={3} md={3} xs={12} className="mb-3">
                            <TableText label="Door No" required={true} LeftSpace={false} />
                            <TableInputText
                              type="text"
                              placeholder="Enter Door No"
                              required
                              name="doorNo"
                              value={applicantDetails.doorNo}
                              onChange={applicantDetailsChange}
                            />
                            {errors.doorNo && (
                              <span style={{ color: "red" }} className={styles.columnText}>
                                {errors.doorNo}
                              </span>
                            )}
                          </Col>
                          <Col lg={3} md={3} xs={12} className="mb-3">
                            <TableText label="Street" LeftSpace={false} required={false} />
                            <TableInputText
                              type="text"
                              placeholder="Enter Street"
                              name="street"
                              required={false}
                              value={applicantDetails.street}
                              onChange={applicantDetailsChange}
                            />
                            {errors.street && (
                              <span style={{ color: "red" }} className={styles.columnText}>
                                {errors.street}
                              </span>
                            )}
                          </Col>
                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="District" required={true} LeftSpace={false} />
                            <select
                              className="form-control"
                              name="district"
                              style={{ textTransform: 'uppercase' }}
                              onChange={(event) => {
                                applicantDetailsChange(event)
                                districtChange(event)
                              }}
                              value={applicantDetails.district}
                              required={true}
                            >
                              <option>Select</option>
                              {districtList.map((item: any, i: number) => {
                                return (
                                  <option key={i + 1} value={item.name}>
                                    {item.name}
                                  </option>
                                )
                              })}
                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Mandal" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="mandal"
                              onChange={(event) => {
                                applicantDetailsChange(event)
                                mandalChange(event)
                              }}
                              value={applicantDetails.mandal}
                              required={true}
                              defaultValue={"Select"}
                            >
                              <option>Select</option>
                              <DynamicMandals
                                currentDistrict={applicantDetails.district}
                                setDetails={() => setApplicantDetails({ ...applicantDetails })}
                              ></DynamicMandals>
                            </select>
                          </Col>

                          <Col lg={3} md={4} xs={12} className="mb-3">
                            <TableText label="Village" required={true} LeftSpace={false} />
                            <select style={{ textTransform: 'uppercase' }}
                              className="form-control"
                              name="villageOrCity"
                              onChange={applicantDetailsChange}
                              value={applicantDetails.villageOrCity}
                              required={true}
                              defaultValue={"Select"}
                            >
                              <option>Select</option>
                              <DynamicVillages
                                currentDistrict={applicantDetails.district}
                                currentMandal={applicantDetails.mandal}
                                setDetails={() => setApplicantDetails({ ...applicantDetails })}
                              ></DynamicVillages>
                            </select>
                          </Col>
                          <Col lg={3} md={3} xs={12} className="mb-3">
                            <TableText label="Pin Code" required={true} LeftSpace={false} />
                            <TableInputText
                              type="text"
                              placeholder="Enter Pin Code"
                              name="pinCode"
                              required
                              value={applicantDetails.pinCode}
                              onChange={applicantDetailsChange}
                              maxLength={6}
                            />
                            {errors.pinCode && (
                              <span style={{ color: "red" }} className={styles.columnText}>
                                {errors.pinCode}
                              </span>
                            )}
                          </Col>
                        </Row>
                        <div className="regFormBorder"></div>
                        <div className="formSectionTitle">
                          <h3>Contact Details</h3>
                        </div>
                        <Row>
                          <Col lg={3} md={12} sm={12} className="my-2">
                            <TableText
                              label={"Landline Phone No"}
                              required={false}
                              LeftSpace={false}
                            />
                            <TableInputText
                              type="number"
                              maxLength={7}
                              placeholder="Landline Phone No"
                              required={false}
                              name="phone"
                              value={applicantDetails.phone}
                              onChange={applicantDetailsChange}
                            />
                            {errors.phone && (
                              <span style={{ color: "red" }} className={styles.columnText}>
                                {errors.phone}
                              </span>
                            )}
                          </Col>
                          <Col lg={3} md={12} sm={12} className="my-2">
                            <TableText label={"Mobile No"} required={false} LeftSpace={false} />
                            <TableInputText
                              maxLength={10}
                              type="number"
                              placeholder="Enter Mobile No"
                              required={true}
                              name="mobileNumber"
                              value={applicantDetails.mobileNumber}
                              onChange={applicantDetailsChange}
                            />
                            {errors.mobileNumber && (
                              <span style={{ color: "red" }} className={styles.columnText}>
                                {errors.mobileNumber}
                              </span>
                            )}
                          </Col>
                          <Col lg={3} md={12} sm={12} className="my-2">
                            <TableText label={"Email address"} required={false} LeftSpace={false} />
                            <TableInputText
                              type="email"
                              placeholder="Enter Email ID"
                              required={true}
                              name="email"
                              maxLength={40}
                               value={applicantDetails.email}
                              onChange={applicantDetailsChange}
                            />
                            {errors.email && (
                              <span style={{ color: "red" }} className={styles.columnText}>
                                {errors.email}
                              </span>
                            )}
                          </Col>
                        </Row>
                      </div>
                    </div>
                  </Container>
                </div>
              )}
              {activeTab === 1 && (

                <div className="regofAppBg mb-3">
                  {/* <Container>
                    <div className="panelDesc">
                      <Row>
                        <Col lg={6} md={6} xs={12} className="mb-3">
                          <TableText
                            label="Reason for Amalgamation of the Society"
                            required={true}
                            LeftSpace={false}
                          />
                          <TableInputText
                            type="text"
                            placeholder="Enter Reason for Amalgamation of the Society"
                            name="reasonForAmalgam"
                            required
                            value={societyDetails.reasonForAmalgam}
                            onChange={societyDetailsChange}
                          />
                          {errors.reasonForAmalgam && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.reasonForAmalgam}
                            </span>
                          )}
                        </Col>
                        <Col lg={6} md={6} xs={12} className="mb-3">
                          <TableText
                            label="Name of the incoming Society for Amalgamation"
                            required={true}
                            LeftSpace={false}
                          />
                          <TableInputText
                            type="text"
                            placeholder="Enter Name of the incoming Society for Amalgamation"
                            name="incomingsociety"
                            required
                            value={societyDetails.incomingsociety}
                            onChange={societyDetailsChange}
                          />
                          {errors.incomingsociety && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.incomingsociety}
                            </span>
                          )}
                        </Col>
                      </Row>
                      <Row>
                        <div className="d-flex ">
                          <div className="mt-1">
                            <TableText
                              label={
                                "Whether the amalgamation has been accepeted by the majority of the members ?"
                              }
                              required={false}
                              LeftSpace={false}
                            />
                          </div>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="majority"
                            type="radio"
                            className="fom-checkbox mx-2"
                            onChange={societyDetailsChange}
                            checked={societyDetails.majority === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="majority"
                            type="radio"
                            className="fom-checkbox"
                            onChange={societyDetailsChange}
                            checked={societyDetails.majority === "No"}
                          />
                        </div>
                      </Row>
                      <Row>
                        <div className="d-flex ">
                          <div className="mt-1">
                            <TableText
                              label={
                                "Whether the amalgamation has been accepeted by the quorum members?"
                              }
                              required={false}
                              LeftSpace={false}
                            />
                          </div>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="quorum"
                            type="radio"
                            className="fom-checkbox mx-2"
                            onChange={societyDetailsChange}
                            checked={societyDetails.quorum === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="quorum"
                            type="radio"
                            className="fom-checkbox"
                            onChange={societyDetailsChange}
                            checked={societyDetails.quorum === "No"}
                          />
                        </div>
                      </Row>
                      <Row>
                        <div className="d-flex ">
                          <div className="mt-1">
                            <TableText
                              label={
                                "Whether the process of amalgamation is carried out as mentioned in the bye-laws?"
                              }
                              required={false}
                              LeftSpace={false}
                            />
                          </div>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="amalgamationProcess"
                            type="radio"
                            className="fom-checkbox mx-2"
                            onChange={societyDetailsChange}
                            checked={societyDetails.amalgamationProcess === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="amalgamationProcess"
                            type="radio"
                            className="fom-checkbox"
                            onChange={societyDetailsChange}
                            checked={societyDetails.amalgamationProcess === "No"}
                          />
                        </div>
                      </Row>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <div className="d-flex justify-content-between align-items-center page-title mb-3">
                            <div className="pageTitleLeft">
                              <h1>Details of the Incoming Society</h1>
                            </div>
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <TableText label="Aim" required={false} LeftSpace={false} />
                          <TableInputText
                            type="text"
                            placeholder="Enter Aim"
                            name="aim"
                            required
                            value={societyDetails.aim}
                            onChange={societyDetailsChange}
                          />
                          {errors.aim && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.aim}
                            </span>
                          )}
                        </Col>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <TableText label="Objective" required={false} LeftSpace={false} />
                          <TableInputText
                            type="text"
                            placeholder="Enter Objective"
                            name="objective"
                            required
                            value={societyDetails.objective}
                            onChange={societyDetailsChange}
                          />
                          {errors.objective && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.objective}
                            </span>
                          )}
                        </Col>
                      </Row>
                      <Row>
                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Door No" required={true} LeftSpace={false} />
                          <TableInputText
                            disabled={false}
                            type="text"
                            placeholder="Enter Door No"
                            required={true}
                            name={"doorNo"}
                            value={societyDetails.doorNo}
                            onChange={societyDetailsChange}
                          />
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Street" required={false} LeftSpace={false} />
                          <TableInputText
                            disabled={false}
                            type="text"
                            placeholder="Enter Street"
                            required={false}
                            name={"street"}
                            value={societyDetails.street}
                            onChange={societyDetailsChange}
                          />
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="District" required={true} LeftSpace={false} />
                          <select style={{ textTransform: 'uppercase' }}
                            className="form-control"
                            name="district"
                            onChange={(event) => {
                              societyDetailsChange(event)
                              districtChange(event)
                            }}
                            value={societyDetails.district}
                            required={true}
                          >
                            <option>Select</option>
                            {districtList.map((item: any, i: number) => {
                              return (
                                <option key={i + 1} value={item.name}>
                                  {item.name}
                                </option>
                              )
                            })}
                          </select>
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Mandal" required={true} LeftSpace={false} />
                          <select style={{ textTransform: 'uppercase' }}
                            className="form-control"
                            name="mandal"
                            onChange={(event) => {
                              societyDetailsChange(event)
                              mandalChange(event)
                            }}
                            value={societyDetails.mandal}
                            required={true}
                            defaultValue={"Select"}
                          >
                            <option>Select</option>
                            <DynamicMandals
                              currentDistrict={societyDetails.district}
                              setDetails={() => setSocietyDetails({ ...societyDetails })}
                            ></DynamicMandals>
                          </select>
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Village" required={true} LeftSpace={false} />
                          <select style={{ textTransform: 'uppercase' }}
                            className="form-control"
                            name="villageOrCity"
                            onChange={societyDetailsChange}
                            value={societyDetails.villageOrCity}
                            required={true}
                            defaultValue={"Select"}
                          >
                            <option>Select</option>
                            <DynamicVillages
                              currentDistrict={societyDetails.district}
                              currentMandal={societyDetails.mandal}
                              setDetails={() => setSocietyDetails({ ...societyDetails })}
                            ></DynamicVillages>
                          </select>
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="PIN Code" required={true} LeftSpace={false} />
                          <Form.Control
                            disabled={false}
                            type="text"
                            maxLength={6}
                            placeholder="Enter PIN Code"
                            required={true}
                            name={"pinCode"}
                            value={societyDetails.pinCode}
                            onChange={societyDetailsChange}
                            onKeyPress={onNumberOnlyChange}
                          />
                        </Col>
                      </Row>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <div className="d-flex justify-content-between align-items-center page-title mb-3">
                            <div className="pageTitleLeft">
                              <h1>Members</h1>
                            </div>
                          </div>
                        </Col>
                      </Row>
                      <Form autoComplete="off">
                        <div className="regofAppBg mb-3 dahboardProcedureSec" >
                          <>

                            <div className="societyMemberDetailsList">
                              <Row className="membersDetailsList">
                                <div className="societyMemberDetailsList">
                                  <Row className="membersDetailsList d-flex align-items-center"></Row>
                                  <Row className="membersDetailsList">
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Member Type"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="memberType"
                                          required={false}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.memberType}
                                        >
                                          <option>Select</option>
                                          {typelist.map((item: any, i: number) => {
                                            return (
                                              <option key={i + 1} value={item}>
                                                {item}
                                              </option>
                                            )
                                          })}
                                        </select>
                                      </Form.Group>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">

                                      {!TempMemorymember.OTPRequested ? (
                                        <Form.Group>
                                          <TableText
                                            label="Enter Aadhaar Number"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <div className="formGroup">
                                            <TableInputText
                                              disabled={TempMemorymember.AadharVerified}
                                              type="text"
                                              maxLength={12}
                                              placeholder="Enter Aadhaar Number"
                                              required={false}
                                              dot={false}
                                              name={"maskedAadhar"}
                                              value={SelectedMemberDetails.maskedAadhar}
                                              onChange={(e: any) => {
                                                if (!TempMemorymember.AadharVerified) {
                                                  membersDetailsChange(e)
                                                }
                                              }}
                                              onKeyPress={true}
                                              onPaste={(e: any) => e.preventDefault()}
                                            />
                                            {!TempMemorymember.AadharVerified ? (
                                              <div
                                                style={{
                                                  display: "flex",
                                                  justifyContent: "center",
                                                  alignItems: "center",
                                                  borderRadius: "2px",
                                                }}
                                                onClick={() => ReqOTP(SelectedMemberDetails)}
                                                className="verify btn btn-primary"
                                              >
                                                Get OTP
                                              </div>
                                            ) : null}
                                          </div>
                                        </Form.Group>
                                      ) : (
                                        <Form.Group>
                                          <TableText
                                            label="Enter OTP"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="formGroup">
                                            <TableInputText
                                              disabled={false}
                                              type="number"
                                              placeholder="Enter OTP Received"
                                              maxLength={6}
                                              required={false}
                                              name={"otpCode"}
                                              value={SelectedMemberDetails.otpCode}
                                              onChange={membersDetailsChange}
                                            />
                                            <div
                                              style={{
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center",
                                                borderRadius: "2px",
                                              }}
                                              onClick={() => {
                                                ReqDetails(SelectedMemberDetails)
                                              }}
                                              className="verify btn btn-primary"
                                            >
                                              Verify
                                            </div>
                                            <div
                                              style={{ display: "flex", justifyContent: "flex-end" }}
                                            >
                                              <div
                                                style={{
                                                  cursor: "pointer",
                                                  marginRight: "20px",
                                                  color: "blue",
                                                  fontSize: "10px",
                                                }}
                                                onClick={() => {
                                                  setTempMemorymember({
                                                    ...TempMemorymember,
                                                    OTPRequested: false,

                                                  })
                                                  setSelectedMemberDetails({ ...SelectedMemberDetails, aaddharNumber: "", maskedAadhar: "" })

                                                }}
                                              >
                                                clear
                                              </div>
                                            </div>
                                          </div>
                                        </Form.Group>
                                      )}
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Name of the Member"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <TableInputText
                                          // className="form-control"
                                          name="memberName"
                                          disabled
                                          required={false}
                                          placeholder="Enter Name of the Member"
                                          onChange={(event: any) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.memberName}
                                          type={"text"}
                                        />
                                        <Row className={styles.columnText}>
                                          <Col lg={9} md={4} xs={12}>
                                            Gender:{SelectedMemberDetails.gender}/Age:
                                            {SelectedMemberDetails.age}
                                          </Col>
                                        </Row>
                                      </Form.Group>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group className="inline">
                                        <TableText
                                          label="Relation Name"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <div className="inline formGroup">
                                          <Form.Select
                                            name="relationType"
                                            onChange={(event) => membersDetailsChange(event)}
                                            disabled={false}
                                            required={false}
                                            value={SelectedMemberDetails.relationType}
                                          >
                                            <option>Select</option>
                                            {relationtypelist.map((item: any, i: number) => {
                                              return (
                                                <option key={i + 1} value={item}>
                                                  {item}
                                                </option>
                                              )
                                            })}
                                          </Form.Select>
                                          <input

                                            className="form-control"
                                            type="text"
                                            name="relationName"
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.relationName}
                                            disabled={true}
                                            required={false}
                                          />
                                        </div>
                                      </Form.Group>
                                    </Col>
                                    <Col lg={3} md={2} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Role/Position"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="role"
                                          required={false}
                                          onChange={(event) =>
                                            membersDetailsChange(event)
                                          }
                                          value={SelectedMemberDetails.role}
                                        >
                                          <option>Select</option>
                                          {roleList.map((item: any) => {
                                            return <option value={item}>{item}</option>
                                          })}
                                        </select>
                                      </Form.Group>
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Occupation"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <input
                                          style={{ textTransform: 'uppercase' }}
                                          required={false}
                                          className="form-control"
                                          name="occupation"
                                          placeholder="Enter Occupation"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.occupation}
                                        />
                                      </Form.Group>
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Qualification"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <input
                                          required={false}
                                          className="form-control"
                                          style={{ textTransform: 'uppercase' }}
                                          name="qualification"
                                          placeholder="Enter Qualification"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.qualification}
                                        />
                                      </Form.Group>
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <TableText
                                          label="Date of Joining as a Member"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <input
                                          required={false}
                                          type="date"
                                          className="form-control"
                                          name="joiningDate"
                                          placeholder="DD/MM/YYYY"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.joiningDate}
                                        />
                                      </Form.Group>
                                    </Col>
                                    <div className="formSectionTitle">
                                      <h3>Address</h3>
                                    </div>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="Door No" required={true} LeftSpace={false} />
                                      <TableInputText
                                        disabled={false}
                                        type="text"
                                        placeholder="Enter Door No"
                                        required={false}
                                        name="doorNo"
                                        onChange={(event: any) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.doorNo}
                                      />
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText
                                        label="Street Name"
                                        required={false}
                                        LeftSpace={false}
                                      />
                                      <TableInputText
                                        disabled={false}
                                        type="text"
                                        placeholder="Enter Street Name"
                                        required={false}
                                        name="street"
                                        onChange={(event: any) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.street}
                                      />
                                    </Col>


                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="District" required={true} LeftSpace={false} />
                                      <select style={{ textTransform: 'uppercase' }}
                                        className="form-control"
                                        name="district"
                                        onChange={(event) => {
                                          membersDetailsChange(event)
                                          districtmemberChange(event)
                                        }}
                                        value={SelectedMemberDetails.district}
                                      >
                                        <option>Select</option>
                                        {districtList.map((item: any, i: any) => {
                                          return (
                                            <option key={i + 1} value={item.name}>
                                              {item.name}
                                            </option>
                                          )
                                        })}
                                      </select>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="Mandal" required={true} LeftSpace={false} />
                                      <select style={{ textTransform: 'uppercase' }}
                                        className="form-control"
                                        name="mandal"
                                        id={"mandal"}
                                        placeholder="Mandal"
                                        onChange={(event) => {
                                          membersDetailsChange(event)
                                          mandalmemberChange(event)
                                        }}
                                        value={SelectedMemberDetails.mandal}
                                      >
                                        <option>Select</option>
                                        {currentmemberDistrict && (
                                          <DynamicMandals
                                            currentDistrict={currentmemberDistrict}
                                            setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                          ></DynamicMandals>
                                        )}</select>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="Village" required={true} LeftSpace={false} />
                                      <select style={{ textTransform: 'uppercase' }}
                                        className="form-control"
                                        name="villageOrCity"
                                        id={"villageOrCity"}
                                        placeholder="Village/City"
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.villageOrCity}
                                      // defaultValue={"Select"}
                                      >
                                        <option>Select</option>
                                        {currentmemberDistrict && currentmemberMandal && <DynamicVillages
                                          currentDistrict={currentmemberDistrict}
                                          currentMandal={currentmemberMandal}
                                          setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                        ></DynamicVillages>}

                                      </select>
                                    </Col>

                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText label="PIN Code" required={true} LeftSpace={false} />
                                      <Form.Control
                                        disabled={false}
                                        type="text"
                                        maxLength={6}
                                        placeholder="Enter PIN Code"
                                        required={false}
                                        name={"pinCode"}
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.pinCode}
                                        onKeyPress={onNumberOnlyChange}
                                      />
                                    </Col>
                                    <div className="formSectionTitle">
                                      <h3>Contact Details</h3>
                                    </div>


                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText
                                        label="Mobile Number"
                                        required={true}
                                        LeftSpace={false}
                                      />
                                      <Form.Control
                                        disabled={false}
                                        type="number"
                                        // autoComplete="off"
                                        maxLength={10}
                                        placeholder="Enter Mobile Number"
                                        required={false}
                                        name="mobileNumber"
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.mobileNumber}
                                      // onKeyPress={onNumberOnlyChange}

                                      />
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText
                                        label="Email Address"
                                        required={false}
                                        LeftSpace={false}
                                      />
                                      <Form.Control
                                        disabled={false}
                                        type="email"
                                        placeholder="Enter Email Address"
                                        required={false}
                                        name={"email"}
                                        maxLength={40}
                                        minLength={15}
                                        onChange={(event) => membersDetailsChange(event)}
                                        value={SelectedMemberDetails.email}
                                      />
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Wether the member is of sound mind?"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="soundMind"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.soundMind === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="soundMind"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.soundMind === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Whether the member is declared to be insolvent or an undischarged insolvent?"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="inSolvent"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.inSolvent === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="inSolvent"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.inSolvent === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Whether the member is convicted of an offense of moral turpitude? "
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="offense"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.offense === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="offense"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.offense === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                  <Row>
                                    <Col>
                                      <div className="mb-3 d-flex">
                                        <TableText
                                          label="Whether the member is disqualified for such an appointment by an order of a court?"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <div className="firmChangeList px-4">
                                          <Form.Check
                                            inline
                                            label="Yes"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="appointment"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="Yes"
                                            checked={SelectedMemberDetails.appointment === "Yes"}
                                          />
                                          <Form.Check
                                            inline
                                            label="No"
                                            disabled={false}
                                            type="radio"
                                            required={false}
                                            name="appointment"
                                            onChange={(event) => membersDetailsChange(event)}
                                            defaultValue="No"
                                            checked={SelectedMemberDetails.appointment === "No"}
                                          />
                                        </div>
                                      </div>
                                    </Col>
                                  </Row>
                                </div>
                              </Row>

                            </div>{" "}
                          </>
                          <Row>
                            <Col lg={12} md={12} xs={12} className="">
                              <div className="addotherBtnInfo text-center mb-3">
                                {indexmember == -1 && (
                                  <div onClick={handleMemberAdd} className="btn btn-primary addPartner">
                                    Add Member
                                  </div>
                                )}
                                {indexmember != -1 && (
                                  <div
                                    onClick={(index: any) => {
                                      handleMemberUpdate(indexmember)
                                    }}
                                    className="btn btn-primary addPartner mb-3"
                                  >
                                    Update Member
                                  </div>
                                )}
                              </div>
                            </Col>
                          </Row>
                          <Row>
                            <div className="dashboardRegSec">
                              <Row>
                                {incomingMemberDetails && incomingMemberDetails?.length > 0 ? (
                                  <div ref={refUpdate} className="addedPartnerSec mt-3">
                                    <Row className="mb-4">
                                      <Col lg={12} md={12} xs={12}>
                                        <Table striped bordered className="tableData listData ">
                                          <thead>
                                            <tr>
                                              <th>Type</th>
                                              <th>Aadhaar No</th>
                                              <th>Name of the member</th>
                                              <th>Relation Name</th>
                                              <th>Age/Gender</th>
                                              <th>Role/Position</th>
                                              <th>Occupation</th>
                                              <th>Date of Joining</th>
                                              <th>Address</th>
                                              <th>Contact</th>
                                              <th>Action</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {incomingMemberDetails?.length > 0 && incomingMemberDetails.map((item: any, i: number) => {
                                              return (
                                                <tr>
                                                  <td
                                                    className="text-wrap-table"
                                                    title={item.memberType}
                                                  >
                                                    {item.memberType}
                                                  </td>

                                                  <td className="text-wrap-table" title={item.maskedAadhar}>
                                                    {item.maskedAadhar}
                                                  </td>
                                                  <td className="text-wrap-table" title={item.memberName}>{item.memberName}</td>
                                                  <td className="text-wrap-table" title={item.relationName}>{item.relationName}</td>
                                                  <td className="text-wrap-table" title={`${item.age}/${item.gender}`}>{item.age} / {item.gender}</td>
                                                  <td className="text-wrap-table" title={item.role}>{item.role}</td>
                                                  <td className="text-wrap-table" title={item.occupation}>{item.occupation}</td>
                                                  <td className="text-wrap-table" title={item.joiningDate}>{item.joiningDate}</td>
                                                  <td className="text-wrap-table"
                                                    title={`${item.doorNo},${item.street},${item.district},${item.mandal},${item.villageOrCity},${item.pinCode}`}>

                                                    {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                                                  </td>
                                                  <td
                                                    className="text-wrap-table"
                                                    title={item.mobileNumber}
                                                  >
                                                    {item.mobileNumber}
                                                  </td>
                                                  <td>
                                                    {" "}
                                                    <Image
                                                      alt="Image"
                                                      height={15}
                                                      width={15}
                                                      src="/assets/edit.svg"
                                                      style={{ cursor: "pointer" }}
                                                      onClick={() => {
                                                        handleMemberEdit(i)
                                                      }}
                                                    />
                                                    <Image
                                                      alt="Image"
                                                      height={20}
                                                      width={20}
                                                      src="/assets/delete-icon.svg"
                                                      style={{ cursor: "pointer" }}
                                                      onClick={() => {
                                                        handleMemberRemovenew(i)
                                                      }}
                                                    />
                                                  </td>
                                                </tr>
                                              )
                                            })}
                                          </tbody>
                                        </Table>
                                      </Col>
                                    </Row>
                                  </div>
                                ) : null}
                              </Row>
                            </div>
                          </Row>

                          <div className="firmSubmitSec">
                            <Row>
                              <Col lg={12} md={12} xs={12}>
                                {(existingSocietyDetail?.status == "Incomplete") && (
                                  <>
                                    <div className="d-flex justify-content-center text-center">
                                      {" "}
                                      <Button
                                        className={styles.prev}
                                        onClick={goToPrevTab}
                                        type="button"
                                      >
                                        Back
                                      </Button>
                                      <Button type="submit">Save & Next</Button>
                                    </div>
                                  </>
                                )}
                              </Col>
                            </Row>
                          </div>
                        </div>
                      </Form>

                    </div>
                  </Container> */}
                  <Container>
                    <Row>
                      <Col lg={3} md={3} xs={12} className="mb-3">
                        <TableText
                          label="Society Application Number"
                          required={true}
                          LeftSpace={false}
                        />
                        <TableInputText
                          type="text"
                          placeholder="Enter Society Application Number"
                          required={false}
                          name="applicationNumber"
                          value={societyDetails.applicationNumber}
                          onChange={societyDetailsChange}
                        />
                      </Col>
                      <Col lg={2} md={2} xs={12} className="pt-3 mx-4">
                        <Button onClick={getdetails}>Get Details</Button>
                      </Col>
                    </Row>
                    <Accordion defaultActiveKey="1">
                      <div className="regofAppBg ">
                        {IncomingSocietiesDetails.map((form, index) => {
                          return (
                            <>
                              <Accordion.Item eventKey={`${index + 1}`} className="mb-3">
                                <Accordion.Header className="mb-0">
                                  {`Society ${index + 1}`}
                                </Accordion.Header>
                                <Accordion.Body>
                                  <div key={index + 1} className="societyMemberDetailsList">
                                    <Row className="membersDetailsList" key={index}>
                                      <div
                                        key={index + 1}
                                        className="firmApplicationSec"
                                      >
                                        <div className="formSectionTitle">
                                          <h3>Society Details</h3>
                                        </div>
                                        <Row key={index}>
                                          <Col lg={2} md={4} xs={12} className="mb-3">
                                            <div className="form-group">
                                              <label className="form-label">Society Name</label>
                                              <div className="valuePrev">
                                                {form.societyName}
                                              </div>
                                            </div>
                                          </Col>
                                          <Col lg={2} md={4} xs={12} className="mb-3">
                                            <div className="form-group">
                                              <label className="form-label">Application Number</label>
                                              <div className="valuePrev">
                                                {form.applicationNumber}
                                              </div>
                                            </div>
                                          </Col>
                                          <Col lg={2} md={4} xs={12} className="mb-3">
                                            <div className="form-group">
                                              <label className="form-label">Category</label>
                                              <div className="valuePrev">
                                                {form.category}
                                              </div>
                                            </div>
                                          </Col>
                                          <Col lg={3} md={4} xs={12} className="mb-3">
                                            <div className="form-group">
                                              <label className="form-label">Aim</label>
                                              <div className="valuePrev">
                                                {form.aim}
                                              </div>
                                            </div>
                                          </Col>
                                          <Col lg={3} md={3} xs={12} className="mb-3">
                                            <div className="form-group">
                                              <label className="form-label">Objective</label>
                                              <div className="valuePrev">
                                                {form.objective}
                                              </div>
                                            </div>
                                          </Col>
                                          <Col lg={12} md={12} xs={12} className="mb-3">
                                            <div className="form-group">
                                              <label className="form-label">Address</label>
                                              <div className="valuePrev">
                                                {form.doorNo}
                                                {form.street && (
                                                  <span> / {form.street}</span>
                                                )}
                                                {form.villageOrCity && (
                                                  <span> / {form.villageOrCity}</span>
                                                )}
                                                {form.mandal && (
                                                  <span> / {form.mandal}</span>
                                                )}
                                                {form.district && (
                                                  <span> / {form.district}</span>
                                                )}
                                                {form.state && (
                                                  <span> / {form.state}</span>
                                                )}

                                                {form.pinCode && (
                                                  <span> / {form.pinCode}</span>
                                                )}

                                              </div>
                                            </div>
                                          </Col>
                                        </Row>
                                        <div key={index} className="dashboardRegSec">
                                          <Row>
                                            {/* {form.memberDetails && form.memberDetails?.length > 0 ? ( */}
                                            <div ref={refUpdate} className="addedPartnerSec mt-3">
                                              <Row className="mb-4">
                                                <Col lg={12} md={12} xs={12}>
                                                  <Table striped bordered className="tableData listData ">
                                                    <thead>
                                                      <tr>
                                                        <th>Type</th>
                                                        <th>Aadhaar No</th>
                                                        <th>Name of the member</th>
                                                        <th>Relation Name</th>
                                                        <th>Age/Gender</th>
                                                        <th>Role/Position</th>
                                                        <th>Occupation</th>
                                                        <th>Date of Joining</th>
                                                        <th>Address</th>
                                                        <th>Contact</th>

                                                      </tr>
                                                    </thead>
                                                    <tbody>
                                                      {form.memberDetails?.length > 0 && form.memberDetails.map((item: any, i: number) => {
                                                        return (
                                                          <>{
                                                            form.status != "InActive" ?
                                                              <tr>
                                                                <td
                                                                  className="text-wrap-table"
                                                                  title={item.memberType}
                                                                >
                                                                  {item.memberType}
                                                                </td>

                                                                <td className="text-wrap-table" title={item.maskedAadhar}>
                                                                  {item.maskedAadhar = "XXXXXXXX" + item.aadharNumber?.toString().substring(8, 12)}
                                                                </td>
                                                                <td className="text-wrap-table" title={item.memberName}>{item.memberName}</td>
                                                                <td className="text-wrap-table" title={item.relationName}>{item.relationName}</td>
                                                                <td className="text-wrap-table" title={`${item.age}/${item.gender}`}>{item.age} / {item.gender}</td>
                                                                <td className="text-wrap-table" title={item.role}>{item.role}</td>
                                                                <td className="text-wrap-table" title={item.occupation}>{item.occupation}</td>
                                                                <td className="text-wrap-table" title={item.joiningDate}>{item.joiningDate}</td>
                                                                <td className="text-wrap-table"
                                                                  title={`${item.doorNo},${item.street},${item.district},${item.mandal},${item.villageOrCity},${item.pinCode}`}>

                                                                  {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                                                                </td>
                                                                <td
                                                                  className="text-wrap-table"
                                                                  title={item.mobileNumber}
                                                                >
                                                                  {item.mobileNumber}
                                                                </td>

                                                              </tr>
                                                              : null
                                                          }</>
                                                        )
                                                      })}
                                                    </tbody>
                                                  </Table>
                                                </Col>
                                              </Row>
                                            </div>
                                            {/* ) : null} */}
                                          </Row>
                                        </div>
                                        {/* </div> */}
                                      </div>
                                    </Row></div>
                                </Accordion.Body>
                              </Accordion.Item> </>)
                        })}</div>
                    </Accordion>
                  </Container>
                </div>
              )}
              {activeTab === 2 && (
                <div className="regofAppBg mb-3">
                  <Container>
                    <div className="panelDesc">
                      <Row className="formsec">
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <Form.Group>
                            <TableText
                              label="Name After Amalgamation"
                              required={true}
                              LeftSpace={false}
                            />
                            <div className="formGroup">
                              <input
                                className="form-control"
                                type="text"
                                maxLength={50}
                                required={true}
                                placeholder="Name After Amalgamation"
                                name="amalgamationName"
                                onChange={amalgamationDetailsChange}
                                value={societyDetailsafteramalgamation.amalgamationName}
                              />

                              <div
                                onClick={checkFirmDB}
                                className="Check Society Availability verify btn btn-primary"
                              >
                                Check
                              </div>
                            </div>
                          </Form.Group>
                        </Col>
                        <Col lg={3} md={3} xs={12} className="mb-3">
                          <TableText label="Date of Effect" required={true} LeftSpace={false} />
                          <TableInputText
                            disabled={false}
                            type="date"
                            placeholder="Enter Date of Effect"
                            required={true}
                            name={"effectDate"}
                            value={societyDetailsafteramalgamation.effectDate}
                            onChange={amalgamationDetailsChange}
                          />
                          {errors.date && (
                            <span style={{ color: "red" }} className={styles.columnText}>
                              {errors.date}
                            </span>
                          )}
                        </Col>

                      </Row>
                      <Row>
                        <Col lg={6} md={4} xs={12} className="mb-3">
                          <TableText label="Aim" required={true} LeftSpace={false} />

                          <textarea
                            className="form-control textarea"
                            disabled={false}
                            placeholder="Enter aim"
                            required={true}
                            name={"newaim"}
                            value={societyDetailsafteramalgamation.newaim}
                            onChange={amalgamationDetailsChange}
                            maxLength={10000}
                          ></textarea>
                        </Col>
                        <Col lg={6} md={4} xs={12} className="mb-3">
                          <TableText label="Objective" required={true} LeftSpace={false} />

                          <textarea
                            className="form-control textarea"
                            disabled={false}
                            placeholder="Enter objective"
                            required={true}
                            name={"newobjective"}
                            value={societyDetailsafteramalgamation.newobjective}
                            onChange={amalgamationDetailsChange}
                            maxLength={10000}
                          ></textarea>
                        </Col>
                      </Row>
                      <div className="d-flex justify-content-between align-items-center page-title mb-3">
                        <div className="pageTitleLeft">
                          <h1>Address</h1>
                        </div>
                      </div>
                      <Row>
                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Door No" required={true} LeftSpace={false} />
                          <TableInputText
                            disabled={false}
                            type="text"
                            placeholder="Enter Door No"
                            required={true}
                            name={"doorNo"}
                            value={societyDetailsafteramalgamation.doorNo}
                            onChange={amalgamationDetailsChange}
                          />
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Street" required={false} LeftSpace={false} />
                          <TableInputText
                            disabled={false}
                            type="text"
                            placeholder="Enter Street"
                            required={false}
                            name={"street"}
                            value={societyDetailsafteramalgamation.street}
                            onChange={amalgamationDetailsChange}
                          />
                        </Col>
                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="District" required={true} LeftSpace={false} />
                          <select style={{ textTransform: 'uppercase' }}
                            className="form-control"
                            name="district"
                            onChange={(event) => {
                              amalgamationDetailsChange(event)
                              districtChange(event)
                            }}
                            value={societyDetailsafteramalgamation.district}
                            required={true}
                          // disabled={true}
                          >
                            <option>Select</option>
                            {districtList.map((item: any, i: number) => {
                              return (
                                <option key={i + 1} value={item.name}>
                                  {item.name}
                                </option>
                              )
                            })}
                          </select>
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Mandal" required={true} LeftSpace={false} />
                          <select style={{ textTransform: 'uppercase' }}
                            className="form-control"
                            name="mandal"
                            onChange={(event) => {
                              amalgamationDetailsChange(event)
                              mandalChange(event)
                            }}
                            value={societyDetailsafteramalgamation.mandal}
                            required={true}
                            defaultValue={"Select"}
                          >
                            <option>Select</option>
                            <DynamicMandals
                              currentDistrict={societyDetailsafteramalgamation.district}
                              setDetails={() =>
                                setsocietyDetailsafteramalgamation({
                                  ...societyDetailsafteramalgamation,
                                })
                              }
                            ></DynamicMandals>
                          </select>
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="Village" required={true} LeftSpace={false} />
                          <select style={{ textTransform: 'uppercase' }}
                            className="form-control"
                            name="villageOrCity"
                            onChange={amalgamationDetailsChange}
                            value={societyDetailsafteramalgamation.villageOrCity}
                            required={true}
                            defaultValue={"Select"}
                          >
                            <option>Select</option>
                            <DynamicVillages
                              currentDistrict={societyDetailsafteramalgamation.district}
                              currentMandal={societyDetailsafteramalgamation.mandal}
                              setDetails={() =>
                                setsocietyDetailsafteramalgamation({
                                  ...societyDetailsafteramalgamation,
                                })
                              }
                            ></DynamicVillages>
                          </select>
                        </Col>

                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText label="PIN Code" required={true} LeftSpace={false} />
                          <Form.Control
                            disabled={false}
                            type="text"
                            maxLength={6}
                            placeholder="Enter PIN Code"
                            required={true}
                            name={"pinCode"}
                            value={societyDetailsafteramalgamation.pinCode}
                            onChange={amalgamationDetailsChange}
                            onKeyPress={onNumberOnlyChange}
                          />
                        </Col>
                      </Row>
                      <Row>
                        <Col lg={3} md={4} xs={12} className="mb-3">
                          <TableText
                            label="Size of the Quorum ( Minimum 3 )"
                            required={false}
                            LeftSpace={false}
                          />
                          <TableInputText
                            disabled={true}
                            type="number"
                            placeholder="Enter Quorum Size"
                            required={false}
                            name="quorumSize"
                            value={byelawDetails.quorumSize}
                            onChange={()=>{}}
                          />
                        </Col>
                      </Row>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <div className="d-flex justify-content-between align-items-center page-title mb-3">
                            <div className="pageTitleLeft">
                              <h1>Members</h1>
                            </div>
                          </div>
                        </Col>
                      </Row>

                      <Table
                        striped
                        bordered
                        style={{ width: "100%" }}
                        className="tableData"
                      >
                        <thead>
                          <tr>
                            {tableHeaders1.map((header: any, i: number) => {
                              return <th key={i}>{header}</th>
                            })}
                          </tr>
                        </thead>
                        <tbody>
                          {afteramalgamationMemberDetails?.length > 0 && afteramalgamationMemberDetails.map((form1: any, index: number) => {
                            return (
                              <>{
                                form1.status != "InActive" ?
                                  <tr key={index}>
                                    {/* <td className="">
                                  <Form.Check
                                    inline
                                    label=""
                                    name="quorum"
                                    type="checkbox"
                                    value={form1.memberName}
                                    className="fom-checkbox"
                                    onChange={changeCheck}
                                    checked={checkedList.includes(form1.memberName)}
                                  />
                                </td> */}
                                    <td className="text-wrap-table" title={form1.memberType}>{form1.memberType}</td>
                                    <td className="text-wrap-table" title={form1.maskedAadhar}>

                                      {form1.maskedAadhar}</td>
                                    <td className="text-wrap-table" title={form1.memberName}>{form1.memberName}</td>
                                    <td className="text-wrap-table" title={form1.relationName}>{form1.relationName}</td>
                                    <td className="text-wrap-table" title={`${form1.age}/${form1.gender}`}>{`${form1.age}/${form1.gender}`}</td>
                                    <td className="text-wrap-table" title={form1.role}>{form1.role}</td>
                                    <td className="text-wrap-table" title={form1.occupation}>{form1.occupation}</td>
                                    <td className="text-wrap-table" title={form1.joiningDate}>{form1.joiningDate}</td>
                                    <td className="text-wrap-table" title={`${form1.doorNo},${form1.street},${form1.district},${form1.mandal},${form1.villageOrCity},${form1.pinCode}`}>
                                      {`${form1.doorNo}/${form1.street}/${form1.villageOrCity}/${form1.mandal}/${form1.district}/${form1.state}/${form1.country}`}</td>

                                    <td className="text-wrap-table" title={form1.mobileNumber}>{form1.mobileNumber}</td>
                                  </tr> : null
                              }</>
                            )
                          })}
                        </tbody>
                      </Table>
                      <Row>
                        <Col lg={10} md={12} xs={12} className="d-flex ">
                          <TableText
                            label="Any Incoming Members"
                            LeftSpace={false}
                            required={false}
                          />
                          <Form.Check
                            inline
                            label="Yes"
                            required={true}
                            name="anyincomingmembers"
                            type="radio"
                            className="fom-checkbox mx-3"
                            onChange={() => setDisplayOption("display")}
                            value="Yes"
                            checked={displayOption === "display"}

                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="anyincomingmembers"
                            type="radio"
                            className="fom-checkbox"
                            checked={displayOption === "not-display"}
                            onChange={() => setDisplayOption("not-display")}
                          />
                        </Col>
                      </Row>
                      {displayOption === "display" && (
                        <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
                          <div className="regofAppBg mb-3 dahboardProcedureSec">
                            <>
                              <div className="societyMemberDetailsList">
                                <Row className="membersDetailsList">
                                  <div className="societyMemberDetailsList">
                                    <Row className="membersDetailsList d-flex align-items-center"></Row>
                                    <Row className="membersDetailsList">
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Member Type"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <select style={{ textTransform: 'uppercase' }}
                                            className="form-control"
                                            name="memberType"
                                            required={false}
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.memberType}
                                          >
                                            <option>Select</option>
                                            {typelist.map((item: any, i: number) => {
                                              return (
                                                <option key={i + 1} value={item}>
                                                  {item}
                                                </option>
                                              )
                                            })}
                                          </select>
                                        </Form.Group>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >

                                        {!TempMemorymember.OTPRequested ? (
                                          <Form.Group>
                                            <TableText
                                              label="Enter Aadhaar Number"
                                              required={true}
                                              LeftSpace={false}
                                            />
                                            <div className="formGroup">
                                              <TableInputText
                                                disabled={TempMemorymember.AadharVerified}
                                                type="text"
                                                maxLength={12}
                                                placeholder="Enter Aadhaar Number"
                                                required={false}
                                                dot={false}
                                                name={"maskedAadhar"}
                                                value={SelectedMemberDetails.maskedAadhar}
                                                onChange={(e: any) => {
                                                  if (!TempMemorymember.AadharVerified) {
                                                    membersDetailsChange(e)
                                                  }
                                                }}
                                                onKeyPress={true}
                                                onPaste={(e: any) => e.preventDefault()}
                                              />
                                              {!TempMemorymember.AadharVerified ? (
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                    borderRadius: "2px",
                                                  }}
                                                  onClick={() => ReqOTP(SelectedMemberDetails)}
                                                  className="verify btn btn-primary"
                                                >
                                                  Get OTP
                                                </div>
                                              ) : null}
                                            </div>
                                          </Form.Group>
                                        ) : (
                                          <Form.Group>
                                            <TableText
                                              label="Enter OTP"
                                              required={false}
                                              LeftSpace={false}
                                            />
                                            <div className="formGroup">
                                              <TableInputText
                                                disabled={false}
                                                type="number"
                                                placeholder="Enter OTP Received"
                                                maxLength={6}
                                                required={false}
                                                name={"otpCode"}
                                                value={SelectedMemberDetails.otpCode}
                                                onChange={membersDetailsChange}
                                              />
                                              <div
                                                style={{
                                                  display: "flex",
                                                  justifyContent: "center",
                                                  alignItems: "center",
                                                  borderRadius: "2px",
                                                }}
                                                onClick={() => {
                                                  ReqDetails(SelectedMemberDetails)
                                                }}
                                                className="verify btn btn-primary"
                                              >
                                                Verify
                                              </div>
                                              <div
                                                style={{ display: "flex", justifyContent: "flex-end" }}
                                              >
                                                <div
                                                  style={{
                                                    cursor: "pointer",
                                                    marginRight: "20px",
                                                    color: "blue",
                                                    fontSize: "10px",
                                                  }}
                                                  onClick={() => {
                                                    setTempMemorymember({
                                                      ...TempMemorymember,
                                                      OTPRequested: false,
                                                    })
                                                  }}
                                                >
                                                  clear
                                                </div>
                                              </div>
                                            </div>
                                          </Form.Group>
                                        )}
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Name of the Member"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <TableInputText
                                            // className="form-control"
                                            name="memberName"
                                            disabled
                                            required={false}
                                            placeholder="Enter Name of the Member"
                                            onChange={() =>{}}
                                            value={SelectedMemberDetails.memberName}
                                            type={"text"}
                                          />
                                          <Row className={styles.columnText}>
                                            <Col lg={9} md={4} xs={12}>
                                              Gender:{SelectedMemberDetails.gender}/Age:
                                              {SelectedMemberDetails.age}
                                            </Col>
                                          </Row>
                                        </Form.Group>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group className="inline">
                                          <TableText
                                            label="Relation Name"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <div className="inline formGroup">
                                            <Form.Select
                                              name="relationType"
                                              onChange={(event) => membersDetailsChange(event)}
                                              disabled={false}
                                              required={false}
                                              value={SelectedMemberDetails.relationType}
                                            >
                                              <option>Select</option>
                                              {relationtypelist.map((item: any, i: number) => {
                                                return (
                                                  <option key={i + 1} value={item}>
                                                    {item}
                                                  </option>
                                                )
                                              })}
                                            </Form.Select>
                                            <input

                                              className="form-control"
                                              type="text"
                                              name="relationName"
                                              onChange={()=> {}}
                                              value={SelectedMemberDetails.relationName}
                                              disabled={true}
                                              required={false}
                                            />
                                          </div>
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={2} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Role/Position"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <select style={{ textTransform: 'uppercase' }}
                                            className="form-control"
                                            name="role"
                                            required={false}
                                            onChange={(event) =>
                                              membersDetailsChange(event)
                                            }
                                            value={SelectedMemberDetails.role}
                                          >
                                            <option>Select</option>
                                            {roleList.map((item: any) => {
                                              return <option value={item}>{item}</option>
                                            })}
                                          </select>
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Occupation"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <TableInputText
                                            required={false}
                                            type="text"
                                            name="occupation"
                                            placeholder="Enter Occupation"
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.occupation}
                                          />
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Qualification"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <TableInputText
                                            required={false}
                                            type="text"
                                            name="qualification"
                                            placeholder="Enter Qualification"
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.qualification}
                                          />
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Date of Joining as a Member"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <input
                                            required={false}
                                            type="date"
                                            className="form-control"
                                            name="joiningDate"
                                            placeholder="DD/MM/YYYY"
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.joiningDate}
                                          />
                                        </Form.Group>
                                      </Col>
                                      <div className="formSectionTitle">
                                        <h3>Address</h3>
                                      </div>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText label="Door No" required={true} LeftSpace={false} />
                                        <TableInputText
                                          disabled={false}
                                          type="text"
                                          placeholder="Enter Door No"
                                          required={false}
                                          name="doorNo"
                                          onChange={(event: any) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.doorNo}
                                        />
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText
                                          label="Street Name"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <TableInputText
                                          disabled={false}
                                          type="text"
                                          placeholder="Enter Street Name"
                                          required={false}
                                          name="street"
                                          onChange={(event: any) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.street}
                                        />
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <TableText label="District" required={true} LeftSpace={false} />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="district"
                                          onChange={(event) => {
                                            membersDetailsChange(event)
                                            districtmemberChange(event)
                                          }}
                                          value={SelectedMemberDetails.district}
                                        >
                                          <option>Select</option>
                                          {districtList.map((item: any, i: any) => {
                                            return (
                                              <option key={i + 1} value={item.name}>
                                                {item.name}
                                              </option>
                                            )
                                          })}
                                        </select>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText label="Mandal" required={true} LeftSpace={false} />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="mandal"
                                          id={"mandal"}
                                          placeholder="Mandal"
                                          onChange={(event) => {
                                            membersDetailsChange(event)
                                            mandalmemberChange(event)
                                          }}
                                          value={SelectedMemberDetails.mandal}
                                        // defaultValue={"Select"}
                                        >
                                          <option>Select</option>
                                          {currentmemberDistrict && (
                                            <DynamicMandals
                                              currentDistrict={currentmemberDistrict}
                                              setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                            ></DynamicMandals>
                                          )}</select>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} className="mb-3">
                                        <TableText label="Village" required={true} LeftSpace={false} />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="villageOrCity"
                                          id={"villageOrCity"}
                                          placeholder="Village/City"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.villageOrCity}
                                        // defaultValue={"Select"}
                                        >
                                          <option>Select</option>
                                          {currentmemberDistrict && currentmemberMandal && <DynamicVillages
                                            currentDistrict={currentmemberDistrict}
                                            currentMandal={currentmemberMandal}
                                            setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                          ></DynamicVillages>}

                                        </select>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} className="mb-3">
                                        <TableText label="PIN Code" required={true} LeftSpace={false} />
                                        <Form.Control
                                          disabled={false}
                                          type="text"
                                          maxLength={6}
                                          placeholder="Enter PIN Code"
                                          required={false}
                                          name={"pinCode"}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.pinCode}
                                          onKeyPress={onNumberOnlyChange}
                                        />
                                      </Col>
                                      <div className="formSectionTitle">
                                        <h3>Contact Details</h3>
                                      </div>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText
                                          label="Mobile Number"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <Form.Control
                                          disabled={false}
                                          type="text"
                                          maxLength={10}
                                          placeholder="Enter Mobile Number"
                                          required={false}
                                          name={"mobileNumber"}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.mobileNumber}
                                          onKeyPress={onNumberOnlyChange}
                                        />
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <TableText
                                          label="Email Address"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <Form.Control
                                          disabled={false}
                                          type="text"
                                          placeholder="Enter Email Address"
                                          required={false}
                                          maxLength={40}
                                          minLength={15}
                                          name={"email"}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.email}
                                        />
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is of sound mind?"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="soundMind"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.soundMind === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="soundMind"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.soundMind === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is declared to be insolvent or an undischarged insolvent?"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="inSolvent"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.inSolvent === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="inSolvent"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.inSolvent === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is convicted of an offense of moral turpitude? "
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="offense"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.offense === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="offense"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.offense === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is disqualified for such an appointment by an order of a court?"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="appointment"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.appointment === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="appointment"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.appointment === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                  </div>
                                </Row>

                              </div>{" "}
                            </>
                            <Row>
                              <Col lg={12} md={12} xs={12} className="mb-4">
                                <div className="addotherBtnInfo text-center">
                                  <div onClick={handleMemberAdd} className="btn btn-primary addPartner">
                                    Add Member
                                  </div>
                                </div>
                              </Col>
                            </Row>

                          </div>
                        </Form>
                      )}
                      {/* <div className="my-3">
                        <div className="uploadFirmList my-1">
                          <h3>Quorum</h3>
                        </div>
                        <Table
                          striped
                          bordered
                          style={{ width: "100%" }}
                          className="tableData"
                        >
                          <thead>
                            <tr>
                              {tableHeaders2.map((header: any, i: number) => {
                                return <th key={i}>{header}</th>
                              })}
                            </tr>
                          </thead>
                          <tbody>
                            {checkedItems.map((form2: any, index: number) => {
                              return (
                                <tr key={index}>
                                  <td className="text-wrap-table" title={form2.memberType} >{form2.memberType}</td>
                                  <td className="text-wrap-table" title={form2.maskedAadhar} >{form2.maskedAadhar}</td>
                                  <td className="text-wrap-table" title={form2.memberName} >{form2.memberName}</td>
                                  <td className="text-wrap-table" title={form2.relationName}>{form2.relationName}</td>
                                  <td className="text-wrap-table" title={`${form2.age}/${form2.gender}`} >{`${form2.age}/${form2.gender}`}</td>
                                  <td className="text-wrap-table" title={form2.role} >{form2.role}</td>
                                  <td className="text-wrap-table" title={form2.occupation} >{form2.occupation}</td>
                                  <td className="text-wrap-table" title={form2.joiningDate} >{form2.joiningDate}</td>
                                  <td className="text-wrap-table" title={`${form2.doorNo},${form2.street},${form2.district},${form2.mandal},${form2.villageOrCity},${form2.pinCode}`}
                                  >{`${form2.doorNo}/${form2.street}/${form2.villageOrCity}/${form2.mandal}/${form2.district}/${form2.state}/${form2.country}`}</td>

                                  <td className="text-wrap-table" title={form2.mobileNumber} >{form2.mobileNumber}</td>
                                </tr>
                              )
                            })}
                          </tbody>
                        </Table>
                      </div> */}
                      {/* <Row className=" my-5 px-5">
                        <Col lg={5} md={4} xs={12} className="">
                        </Col>
                        <Col lg={4} md={4} xs={12} className="">
                          <Button type="submit" className="mx-2" onClick={submitHandler}>
                            Save & Next
                          </Button>
                        </Col>
                        <Col lg={3} md={4} xs={12} className="">
                        </Col>
                      </Row> */}
                    </div>
                  </Container>
                </div>
              )}
              {activeTab === 3 && (
                <div className="regofAppBg mb-3">
                  <div className="panelDesc">
                    <div className="d-flex justify-content-between align-items-center page-title mb-3">
                      <div className="pageTitleLeft">
                        <h1> Bye-Laws</h1>
                      </div>
                    </div>
                    <Row>
                      <div className="d-flex ">
                        <div className="mt-1">
                          <TableText
                            label={
                              "Whether the bye-laws contain the conditions of Office Bearers? (Appointment, Election, Removal, Recall, Responsibilites)"
                            }
                            required={false}
                            LeftSpace={false}
                          />
                        </div>
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="bearers"
                          type="radio"
                          className="fom-checkbox mx-2"
                          onChange={byelawdetailschange}
                          checked={byelaws.bearers === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="bearers"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawdetailschange}
                          checked={byelaws.bearers === "No"}
                        />
                      </div>
                    </Row>
                    <Row>
                      <div className="d-flex ">
                        <div className="mt-1">
                          <TableText
                            label={"Whether the bye-laws contain the details of finance ?"}
                            required={false}
                            LeftSpace={false}
                          />
                        </div>
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="finance"
                          type="radio"
                          className="fom-checkbox mx-2"
                          onChange={byelawdetailschange}
                          checked={byelaws.finance === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="finance"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawdetailschange}
                          checked={byelaws.finance === "No"}
                        />
                      </div>
                    </Row>
                    <Row>
                      <div className="d-flex ">
                        <div className="mt-1">
                          <TableText
                            label={"Whether the bye-laws contain the details of the auditor ?"}
                            required={false}
                            LeftSpace={false}
                          />
                        </div>
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="auditor"
                          type="radio"
                          className="fom-checkbox mx-2"
                          onChange={byelawdetailschange}
                          checked={byelaws.auditor === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="auditor"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawdetailschange}
                          checked={byelaws.auditor === "No"}
                        />
                      </div>
                    </Row>
                    <Row>
                      <div className="d-flex ">
                        <div className="mt-1">
                          <TableText
                            label={
                              "Whether the bye-laws contain the conditions for raising of the funds?"
                            }
                            required={false}
                            LeftSpace={false}
                          />
                        </div>
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="funds"
                          type="radio"
                          className="fom-checkbox mx-2"
                          onChange={byelawdetailschange}
                          checked={byelaws.funds === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="funds"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawdetailschange}
                          checked={byelaws.funds === "No"}
                        />
                      </div>
                    </Row>
                    <Row>
                      <div className="d-flex ">
                        <div className="mt-1">
                          <TableText
                            label={
                              "Whether the bye-laws contain the conditions for liabilities of members in financial matters and exchange of debts ?"
                            }
                            required={false}
                            LeftSpace={false}
                          />
                        </div>
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="liabilities"
                          type="radio"
                          className="fom-checkbox mx-2"
                          onChange={byelawdetailschange}
                          checked={byelaws.liabilities === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="liabilities"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawdetailschange}
                          checked={byelaws.liabilities === "No"}
                        />
                      </div>
                    </Row>
                    <Row>
                      <div className="d-flex ">
                        <div className="mt-1">
                          <TableText
                            label={
                              "Whether the bye-laws contain the other matters like settlement of internal disputes or dissolution of society ?"
                            }
                            required={false}
                            LeftSpace={false}
                          />
                        </div>
                        <Form.Check
                          inline
                          label="Yes"
                          value="Yes"
                          name="settlements"
                          type="radio"
                          className="fom-checkbox mx-2"
                          onChange={byelawdetailschange}
                          checked={byelaws.settlements === "Yes"}
                        />
                        <Form.Check
                          inline
                          label="No"
                          value="No"
                          name="settlements"
                          type="radio"
                          className="fom-checkbox"
                          onChange={byelawdetailschange}
                          checked={byelaws.settlements === "No"}
                        />
                      </div>
                    </Row>
                    <div className="regofAppBg my-3">
                      <div className="d-flex justify-content-between align-items-center page-title mb-3">
                        <div className="pageTitleLeft">
                          <h1>
                            Upload Society Related Documents-(All Uploaded Documents should be in
                            PDF format only upto 5MB )
                          </h1>
                        </div>
                      </div>
                      <Row>
                        <Col lg={3} md={12} sm={12} className="my-2">
                          <TableText
                            label={"Memorandum of Association"}
                            required={true}
                            LeftSpace={false}
                          />
                          <div className="firmFile">
                            <Form.Control
                              type="file"
                              name="memorandum"
                              required={true}
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </div>
                        </Col>
                        <Col lg={3} md={12} sm={12} className="my-2">
                          <TableText label={"Bye - Laws "} required={true} LeftSpace={false} />
                          <div className="firmFile">
                            <Form.Control
                              type="file"
                              required={true}
                              name="byeLaws"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </div>
                        </Col>
                        <Col lg={3} md={12} sm={12} className="my-2">
                          <TableText
                            label={"ID Proofs of Members "}
                            required={true}
                            LeftSpace={false}
                          />
                          <div className="firmFile">
                            <Form.Control
                              type="file"
                              required={true}
                              name="idProofs"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </div>
                        </Col>
                        <Col lg={3} md={12} sm={12} className="my-2">
                          <TableText
                            label={"Self Signed Declaration of Members "}
                            required={true}
                            LeftSpace={false}
                          />
                          <div className="firmFile">
                            <Form.Control
                              type="file"
                              required={true}
                              name="selfSignedDeclaration"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </div>
                        </Col>
                        <Col lg={3} md={12} sm={12} className="my-2">
                          <TableText
                            label={"Affidavit  /  Lease Agreement "}
                            required={true}
                            LeftSpace={false}
                          />
                          <div className="firmFile">
                            <Form.Control
                              type="file"
                              name="affidavit"
                              required={true}
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </div>
                        </Col>
                        <Col lg={3} md={12} sm={12} className="my-2">
                          <TableText
                            label={"Affidavit by Auditor"}
                            required={true}
                            LeftSpace={false}
                          />
                          <div className="firmFile">
                            <Form.Control
                              type="file"
                              required={true}
                              name="affidavitByAuditor"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/pdf"
                            />
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>
                </div>
              )}

              <div className="firmSubmitSec">
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <>
                      <div className="d-flex justify-content-center text-center">
                        {" "}
                        {activeTab !== 0 ? (
                          <Button className={styles.prev} onClick={goToPrevTab} type="button">
                            Back
                          </Button>
                        ) : (
                          <div></div>
                        )}
                        {activeTab < 3 ? (<>{activeTab < 2 ? <>
                          <Button type="submit"> Next</Button>
                        </> :
                          <>
                            {isCheckFirm && <Button type="submit"> Next</Button>}
                          </>}</>

                        ) : (
                          <>
                            {/* <Button type="submit">Save</Button> */}
                            <Button
                              variant="primary"
                              type="submit"
                              onClick={() => setIsPayNowClicked(true)}
                            >
                              Pay now
                            </Button>
                          </>
                        )}
                      </div>
                    </>
                  </Col>
                </Row>
              </div>
            </Container>
          </Form>
        </div>
      </div>
    </>
  )
}
