import React, { useEffect, useRef } from "react"
import Head from "next/head"
import { Container, Col, Row, Form, Button } from "react-bootstrap"
import styles from "@/styles/pages/Forms.module.scss"
import { useState } from "react"
import { PopupAction } from "@/redux/commonSlice"
import { profileUpdate } from "@/axios"
import { useRouter } from "next/router"
import { useAppDispatch } from "@/hooks/reduxHooks"
import CryptoJS from "crypto-js"
import { ShowMessagePopup } from "@/GenericFunctions"
const profile = () => {
  const router = useRouter()
  const dispatch = useAppDispatch()
  const [update, setupdate] = useState<any>({
    fullName: "",
    mobileNumber: "",
    selfSignedSignature: "",
  })
  const [locData, setLocData] = useState<any>({})
  const [file, setFile] = useState<any>([])
  const [FormErrors, setFormErrors] = useState<any>({})

  const profiledata = (e: any) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setupdate(newInput)
  }

  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }

  const ShowAlert = (type: any, message: any, redirectOnSuccess: any) => {
    dispatch(PopupAction({ enable: true, type, message, redirectOnSuccess }))
  }

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    } else if (e.target.files[0].type != "image/jpeg" && e.target.files[0].type != "image/jpg" && e.target.files[0].type != "image/png" && e.target.files[0].type != "image/svg") {
      ShowMessagePopup(false, "Please upload jpg/jpeg/png/svg type signature", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["jpg","jpeg","png","svg"];
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
        // throw Error("Invalid File");
        ShowMessagePopup(false, "Irrelevant file type. Only image/png/jpg/jpeg/svg can be uploaded.");
        e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])){
      if(!regex){
      ShowMessagePopup(false, "Please upload proper file name");
      e.target.value = "";
    }
  }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  const handleSubmit = (e: any) => {
    e.preventDefault()
    if (update.fullName == "" || update.fullName.trim() == "") {
      ShowMessagePopup(false, "Please enter full name", "")
    } else if (update.mobileNumber == "") {
      ShowMessagePopup(false, "Please enter mobile number", "")
    } else {
      const newData = new FormData()
      newData.append("fullName", update?.fullName)
      newData.append("mobileNumber", update?.mobileNumber)
      newData.append("selfSignedSignature", file?.signature)
      let data: any = localStorage.getItem("FASPLoginDetails")
      if (data && data != "" && process.env.SECRET_KEY) {
        let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
        data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
      }
      if (data && data.token) {
        profileUpdate(newData, data.token)
          .then((res) => {
            if (res.success) {
              ShowMessagePopup(true, "Profile updated successfully", "")
              router.push("/report")
              setupdate({
                fullName: "",
                mobileNumber: "",
                selfSignedSignature: ""
              })
            } else {
              ShowMessagePopup(false, res.message, "")
            }
          })
          .catch(() => {
            console.log("error")
          })
      }
    }
  }

  const popupState = () => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (!data || data == null || data == "") {
      router.push("/")
    }
  }

  useEffect(() => {
    window.addEventListener("popstate", () => {
      popupState()
    })
    return () => {
      window.removeEventListener("popstate", () => {
        popupState()
      })
    }
  }, [])

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLocData(data)
      setupdate({ ...update, fullName: data.fullName, mobileNumber: data.mobileNumber })
    }
  }, [])

  const inputRef = useRef<HTMLInputElement | null>(null)

  return (
    <>
      <Head>
        <title>Profile</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>
      {locData && locData?.userType && locData?.userType != "user" && (
        <div className="logiRegMainSec">
          <div className="societyRegSec">
            <Container>
              <div className="regContainerSec">
                <div className="regFieldsMain loginFieldsSec departmentSec">
                  <Form
                    className={`formsec ${styles.RegistrationInput}`}
                    encType="multipart/form-data"
                  >
                    <div className="d-flex justify-content-between mb-3">
                      <div className="formSectionTitle">
                        <h3>Profile</h3>
                      </div>
                            </div>

                    <div className="firmRegFieldsList regofAppBg">
                      <Row>
                        <Col lg={12} md={12} xs={12} className="mb-3">
                          <Form.Group>
                            <Form.Label>Full Name</Form.Label>
                            <Form.Control
                              type="text"
                              placeholder="Enter Full Name"
                              name="fullName"
                              required
                              onChange={profiledata}
                              value={update.fullName}
                            />
                            <span style={{ color: "red" }}>
                              {FormErrors.fullName ? FormErrors.fullName : ""}
                            </span>
                          </Form.Group>
                        </Col>
                        <Col lg={12} md={12} xs={12} className="mb-3">
                          <Form.Group>
                            <Form.Label>Mobile Number</Form.Label>
                            <Form.Control
                              type="text"
                              placeholder="Enter Phone Number"
                              name="mobileNumber"
                              required
                              onChange={profiledata}
                              value={update.mobileNumber}
                              onKeyPress={onNumberOnlyChange}
                              maxLength={10}
                            />
                            <span style={{ color: "red" }}>
                              {FormErrors.mobileNumber ? FormErrors.mobileNumber : ""}
                            </span>
                          </Form.Group>
                        </Col>
                        <Col lg={12} md={12} xs={12} className="mb-3">
                          <Form.Group>
                            <Form.Label>Signature</Form.Label>
                            <Form.Control
                              type="file"
                              name="signature"
                              ref={inputRef}
                              onChange={handleFileChange}
                              accept="application/jpg,application/png,application/jpeg,application/svg,"
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                    </div>
                    <div className="firmSubmitSec">
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <div className="d-flex justify-content-between align-items-center text-center">
                            <Button type="button" onClick={handleSubmit}>
                              Submit
                            </Button>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </Form>
                </div>
              </div>
            </Container>
          </div>
        </div>
      )}
      {(!locData?.userType || locData?.userType == "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}

export default profile
