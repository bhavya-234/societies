import React, { useRef, useState } from "react"
import Head from "next/head"
import styles from "@/styles/pages/Forms.module.scss"
import styles1 from "@/styles/components/Table.module.scss"
import { Container, Col, Row, Form, Button, Accordion } from "react-bootstrap"
import TableText from "@/components/TableText"
import TableInputText from "@/components/TableInputText"
import { useAppDispatch } from "@/hooks/reduxHooks"
import {
  ISDivisionOfTheSocietyApplicantDetailsModel,
  ISDivisionOfTheSocietyFirmDetailsModel,
} from "@/models/types"
import { ShowMessagePopup } from "@/GenericFunctions"

export default function Details() {
  const dispatch = useAppDispatch()
  const [firmDetails, setFirmDetails] = useState<ISDivisionOfTheSocietyFirmDetailsModel>({
    firmName: "",
    firmDurationFrom: "",
    firmDurationTo: "",
    industryType: "",
    businessType: "",
  })
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [errors, setErrors] = useState<any>({})
  const [applicantDetails, setapplicantDetails] =
    useState<any>({
      aadhaarNumber: "",
      applicantName: "",
      role: "",
      relation: "",
      doorNo: "",
      street: "",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      landPhoneNumber: "",
      mobileNumber: "",
      email: "",
      reasonfordivision: "",
      dividesociety: "",
      society1: "",
      society2: "",
    })
  const [file, setFile] = useState<any>([])

  const firmDetailsChange = (e: { target: { name: any; value: any } }) => {
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
    setFirmDetails(newInput)
  }

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
        // throw Error("Invalid File");
        ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
        e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])){
      if(!regex){
      ShowMessagePopup(false, "Please upload proper file name");
      e.target.value = "";
    }
  }
  }

  const applicantDetailsChange = (e: any) => {
    setapplicantDetails({ ...applicantDetails, [e.target.name]: e.target.value })
    console.log(applicantDetails)
  }

  const validateInputs = () => {
    let applicant = { ...applicantDetails }
    const errors: any = {}
    if (!applicant.aadhaarNumber) {
      errors.aadharNumber = "Please validate aadhar number"
    }
    if (!applicant.applicantName) {
      errors.applicantName = "Please enter name"
    }
    if (!applicant.relation) {
      errors.relation = "Please Enter Relation Name"
    }
    if (!applicant.role) {
      errors.role = "Please Enter role"
    }
    if (!applicant.doorNo) {
      errors.doorNo = "Please enter door number"
    }
    if (!applicant.street) {
      errors.street = "Please enter street"
    }

    if (!applicant.district) {
      errors.district = "Please select Applicant District"
    }
    if (!applicant.mandal) {
      errors.mandal = "Please select Applicant Mandal"
    }
    if (!applicant.villageOrCity) {
      errors.villageOrCity = "Please select Applicant Village Or City"
    }
    if (!applicant.pinCode) {
      errors.pinCode = "Please enter pinCode"
    }
    if (!applicant.landPhoneNumber) {
      errors.landPhoneNumber = "Please enter Landline number "
    }
    if (!applicant.mobileNumber) {
      errors.mobileNumber = "Please enter phone number"
    }
    if (!applicant.email) {
      errors.email = "Please enter email id"
    }
    if (!applicant.reasonfordivision) {
      errors.reasonfordivision = "Please enter reason for division"
    }
    if (!applicant.dividesociety) {
      errors.dividesociety = "Please enter value"
    }
    if (!applicant.society1) {
      errors.society1 = "Please enter society1 value"
    }
    if (!applicant.society2) {
      errors.society2 = "Please enter society2 value"
    }
    setErrors({ ...errors })
    console.log("errors obj", errors)
    return errors
  }

  const submitHandler = () => {
    if (Object.keys(validateInputs()).length == 0) {
    }
  }

  return (
    <>
      <Head>
        <title>Amalgamation Of The Society</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>
      <div className={styles.RegistrationMain}>
        <div className="societyRegSec">
          <div className="dahboardProcedureSec">
            <Container>
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="d-flex justify-content-between align-items-center page-title mb-3">
                    <div className="pageTitleLeft ms-3">
                      <h1>Division Of The Society</h1>
                    </div>
                  </div>
                </Col>
              </Row>
              <Container>
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <Accordion defaultActiveKey={"0"}>
                      <Accordion.Item eventKey="0">
                        <Accordion.Body>
                          <div className=" formsec panelDesc">
                            <h3>Applicant Details</h3>
                            <Row>
                              <Col lg={3} md={3} xs={12} className="formsec">
                                <TableText
                                  label="Enter Aadhaar Number"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <div className="formGroup">
                                  <div>
                                    <Form.Control
                                      type="text"
                                      name="otpCode"
                                      required
                                      onChange={applicantDetailsChange}
                                      value={applicantDetails.aadhaarNumber}
                                    />
                                    <div className="verify btn btn-primary"> Verify</div>
                                  </div>
                                </div>
                                {errors.aadharNumber && (
                                  <span style={{ color: "red" }} className={styles.columnText}>
                                    {errors.aadharNumber}
                                  </span>
                                )}
                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText
                                  label="Name of the Applicant"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <TableInputText
                                  type="text"
                                  placeholder="Enter Name of the Applicant"
                                  required
                                  name="applicantName"
                                  value={applicantDetails.applicantName}
                                  onChange={applicantDetailsChange}
                                  maxLength={12}
                                />
                                <TableText
                                  label="Gender: Male"
                                  required={false}
                                  LeftSpace={false}
                                />
                              </Col>
                              <Col lg={3} md={12} sm={12} className="">
                                <TableText
                                  label="Relation Name"
                                  required={false}
                                  LeftSpace={false}
                                />
                                <Form.Group className="inline">
                                  <div className="inline formGroup">
                                    <Form.Select name="relationType" onChange={() => {}} value={""}>
                                      <option>S/O</option>
                                      <option>D/O</option>
                                      <option>W/O</option>
                                      <option>H/O</option>
                                    </Form.Select>
                                    <input
                                      className="form-control"
                                      type="text"
                                      name="relation"
                                      onChange={()=>{}}
                                      value={applicantDetails.relation}
                                      disabled={true}
                                    />
                                  </div>
                                </Form.Group>
                              </Col>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText label="Role" required={false} LeftSpace={false} />
                                <TableInputText
                                  type="text"
                                  placeholder="Enter Role"
                                  name="role"
                                  required
                                  value={applicantDetails.role}
                                  onChange={applicantDetailsChange}
                                />
                                {errors.role && (
                                  <span style={{ color: "red" }} className={styles.columnText}>
                                    {errors.role}
                                  </span>
                                )}
                              </Col>
                            </Row>
                            <div className="regFormBorder"></div>
                            <div className=" page-title mb-3">
                              <div className="formSectionTitle">
                                <h3>Address</h3>
                              </div>
                              <Row>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Door No" required={true} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Door No"
                                    required
                                    name="doorNo"
                                    value={applicantDetails.doorNo}
                                    onChange={applicantDetailsChange}
                                  />
                                  {errors.doorNo && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.doorNo}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Street" LeftSpace={false} required={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Street"
                                    name="street"
                                    required
                                    value={applicantDetails.street}
                                    onChange={applicantDetailsChange}
                                  />
                                  {errors.street && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.street}
                                    </span>
                                  )}
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="District" required={true} LeftSpace={false} />
                                  <div className="inline formGroup">
                                    <select style={{ textTransform: 'uppercase' }}
                                      className={styles1.columnDropDownBox}
                                      name="district"
                                      value={applicantDetails.district}
                                      onChange={applicantDetailsChange}
                                    >
                                      <option>Select</option>
                                      <option>guntur</option>
                                      <option>vijayawada</option>
                                    </select>
                                  </div>
                                  {errors.district && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.district}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Mandal" required={true} LeftSpace={false} />
                                  <div className="inline formGroup">
                                    <select style={{ textTransform: 'uppercase' }}
                                      className={styles1.columnDropDownBox}
                                      name="mandal"
                                      value={applicantDetails.mandal}
                                      onChange={applicantDetailsChange}
                                    >
                                      <option>Select</option>
                                      <option>mandal1</option>
                                      <option>mandal2</option>
                                    </select>
                                  </div>
                                  {errors.mandal && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.mandal}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText
                                    label="Village/City"
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <div className="inline formGroup">
                                    <select style={{ textTransform: 'uppercase' }}
                                      className={styles1.columnDropDownBox}
                                      name="villageOrCity"
                                      value={applicantDetails.villageOrCity}
                                      onChange={applicantDetailsChange}
                                    >
                                      <option>Select</option>
                                      <option>kankipadu</option>
                                      <option>guduru</option>
                                    </select>
                                  </div>
                                  {errors.villageOrCity && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.villageOrCity}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={3} xs={12} className="mb-3">
                                  <TableText label="Pin Code" required={true} LeftSpace={false} />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Pin Code"
                                    name="pinCode"
                                    required
                                    value={applicantDetails.pinCode}
                                    onChange={applicantDetailsChange}
                                    maxLength={12}
                                  />
                                  {errors.pinCode && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.pinCode}
                                    </span>
                                  )}
                                </Col>
                              </Row>
                              <div className="regFormBorder"></div>
                              <div className="formSectionTitle">
                                <h3>Contact Details</h3>
                              </div>
                              <Row>
                                <Col lg={3} md={12} sm={12} className="my-2">
                                  <TableText
                                    label={"Landline Phone No"}
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    type="text"
                                    placeholder="Landline Phone No"
                                    required={true}
                                    name="landPhoneNumber"
                                    value={applicantDetails.landPhoneNumber}
                                    onChange={applicantDetailsChange}
                                  />
                                  {errors.landPhoneNumber && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.landPhoneNumber}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={12} sm={12} className="my-2">
                                  <TableText
                                    label={"Mobile No"}
                                    required={true}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Mobile No"
                                    required={true}
                                    name="mobileNumber"
                                    value={applicantDetails.mobileNumber}
                                    onChange={applicantDetailsChange}
                                  />
                                  {errors.mobileNumber && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.mobileNumber}
                                    </span>
                                  )}
                                </Col>
                                <Col lg={3} md={12} sm={12} className="my-2">
                                  <TableText
                                    label={"Email ID"}
                                    required={false}
                                    LeftSpace={false}
                                  />
                                  <TableInputText
                                    type="text"
                                    placeholder="Enter Email ID"
                                    required={true}
                                    name="email"
                                    value={applicantDetails.email}
                                    maxLength={40}
                                    minLength={15}
                                    onChange={applicantDetailsChange}
                                  />
                                  {errors.email && (
                                    <span style={{ color: "red" }} className={styles.columnText}>
                                      {errors.email}
                                    </span>
                                  )}
                                </Col>
                              </Row>
                            </div>
                          </div>
                        </Accordion.Body>
                      </Accordion.Item>
                    </Accordion>
                  </Col>
                </Row>
              </Container>
              <Container className="mt-3">
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <Accordion defaultActiveKey={"1"}>
                      <Accordion.Item eventKey="1">
                        <Accordion.Body>
                          <div className=" formsec panelDesc">
                            <Row>
                              <Col lg={12} md={12} xs={12}>
                                <div className="regofAppBg mb-3">
                                  <div className="formSectionTitle">
                                    <h3>Society Details</h3>
                                  </div>
                                  <Row>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <Form.Group>
                                        <div className="d-flex justify-content-between">
                                          <Form.Label>Society Name</Form.Label>
                                          <button className="availability">
                                            Check Availability
                                          </button>
                                        </div>
                                        <Form.Control
                                          type="text"
                                          placeholder="Enter Firm Name"
                                          name="firmName"
                                          onChange={firmDetailsChange}
                                          value={firmDetails.firmName}
                                        />
                                      </Form.Group>
                                    </Col>
                                    <Col lg={3} md={3} xs={12} className="mb-3">
                                      <TableText
                                        label="Society Type"
                                        LeftSpace={false}
                                        required={false}
                                      />
                                      <div className="inline formGroup">
                                        <select style={{ textTransform: 'uppercase' }} className={styles1.columnDropDownBox}>
                                          <option>Select</option>
                                        </select>
                                      </div>
                                    </Col>
                                  </Row>
                                </div>
                              </Col>
                            </Row>
                          </div>
                        </Accordion.Body>
                      </Accordion.Item>
                    </Accordion>
                  </Col>
                </Row>
              </Container>
              <div className="formSectionTitle ms-3">
                <h3>
                  Request Type <span style={{ color: "red" }}>*</span>
                </h3>
              </div>
              <div className="my-2 ms-3">
                <Form.Check
                  inline
                  label="Amalgamation of the society"
                  value="Amalgamation"
                  name="Amalgamation"
                  type="checkbox"
                  className="fom-checkbox"
                  checked={true}
                />
              </div>
              <Container className="mt-3">
                <Row>
                  <Col lg={12} md={12} xs={12}>
                    <Accordion defaultActiveKey={"2"}>
                      <Accordion.Item eventKey="2">
                        <Accordion.Body>
                          <div className=" formsec panelDesc">
                            <Row>
                              <Col lg={6} md={6} xs={12} className="mb-3">
                                <TableText
                                  label="Reason for Division"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <TableInputText
                                  type="text"
                                  placeholder="Enter Reason for Division"
                                  name="reasonfordivision"
                                  required
                                  onChange={applicantDetailsChange}
                                  value={applicantDetails.reasonfordivision}
                                  maxLength={12}
                                />
                                {errors.reasonfordivision && (
                                  <span style={{ color: "red" }} className={styles.columnText}>
                                    {errors.reasonfordivision}
                                  </span>
                                )}
                              </Col>
                            </Row>
                            <Row>
                              <Col lg={12} md={12} xs={12} className="mb-2  d-flex ">
                                <TableText
                                  label="Is the division is made as mentioned in the Bye-Laws?"
                                  LeftSpace={false}
                                  required={false}
                                />
                                <Form.Check
                                  inline
                                  label="Yes"
                                  value="Yes"
                                  name="liabilityConditions"
                                  type="radio"
                                  className="fom-checkbox mx-3 mb-2 "
                                  onChange={undefined}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  value="No"
                                  name="liabilityConditions"
                                  type="radio"
                                  className="fom-checkbox mb-2 "
                                  onChange={undefined}
                                />
                              </Col>
                            </Row>
                            <Row>
                              <Col lg={6} md={6} xs={12} className="mb-3">
                                <TableText
                                  label="Is the society going to divide into one or more"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <TableInputText
                                  type="text"
                                  placeholder="Enter "
                                  name="dividesociety"
                                  required
                                  onChange={applicantDetailsChange}
                                  value={applicantDetails.dividesociety}
                                  maxLength={12}
                                />
                                {errors.dividesociety && (
                                  <span style={{ color: "red" }} className={styles.columnText}>
                                    {errors.dividesociety}
                                  </span>
                                )}
                              </Col>
                            </Row>
                            <Row>
                              <Col lg={12} md={12} xs={12}>
                                <div className="d-flex justify-content-between align-items-center page-title mb-3">
                                  <div className="pageTitleLeft">
                                    <h1> After Division</h1>
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col lg={3} md={3} xs={12} className="mb-3">
                                <TableText
                                  label=" Resolution for division"
                                  required={true}
                                  LeftSpace={false}
                                />
                                <div className="firmFile">
                                  <Form.Control
                                    type="file"
                                    name="affidavit"
                                    ref={inputRef}
                                    onChange={handleFileChange}
                                    accept="application/pdf"
                                  />
                                </div>
                              </Col>
                            </Row>
                            <Row>
                              <Col lg={12} md={12} xs={12} className="mb-3">
                                <TableText
                                  label="Does the resolution contain proposals to the division of the assets & liabilities of the society?"
                                  required={false}
                                  LeftSpace={false}
                                />
                              </Col>
                              <Col lg={12} md={12} xs={12} className="mb-3">
                                <TableText
                                  label=" Specify the area of operation of New divided societies"
                                  required={false}
                                  LeftSpace={false}
                                />
                              </Col>
                              <Col lg={6} md={6} xs={12} className="mb-3">
                                <TableText label="Society 1" required={true} LeftSpace={false} />
                                <TableInputText
                                  type="text"
                                  placeholder="Enter Society 1"
                                  name="society1"
                                  required
                                  onChange={applicantDetailsChange}
                                  value={applicantDetails.society1}
                                  maxLength={12}
                                />
                                {errors.society1 && (
                                  <span style={{ color: "red" }} className={styles.columnText}>
                                    {errors.society1}
                                  </span>
                                )}
                              </Col>
                              <Col lg={6} md={6} xs={12} className="mb-3">
                                <TableText label="Society 2" required={true} LeftSpace={false} />
                                <TableInputText
                                  type="text"
                                  placeholder="Enter Society 2"
                                  name="society2"
                                  required
                                  onChange={applicantDetailsChange}
                                  value={applicantDetails.society2}
                                  maxLength={12}
                                />
                                {errors.society2 && (
                                  <span style={{ color: "red" }} className={styles.society2}>
                                    {errors.society2}
                                  </span>
                                )}
                              </Col>
                              <Col lg={6} md={6} xs={12} className="mb-2">
                                <TableText
                                  label="Members of the new society 1"
                                  LeftSpace={false}
                                  required={false}
                                />
                                <TableInputText
                                  placeholder={"Enter Here"}
                                  required={false}
                                  value={""}
                                  onChange={undefined}
                                  name={""}
                                  maxLength={20}
                                  type={""}
                                />
                              </Col>
                              <Col lg={6} md={6} xs={12} className="mb-2">
                                <TableText
                                  label="Members of the new society 2"
                                  LeftSpace={false}
                                  required={false}
                                />
                                <TableInputText
                                  placeholder={"Enter Here"}
                                  required={false}
                                  value={""}
                                  onChange={undefined}
                                  name={""}
                                  maxLength={20}
                                  type={""}
                                />
                              </Col>
                            </Row>
                            <Row>
                              <Col lg={5} className="mx-3"></Col>
                              <Col lg={4}>
                                <Button type="submit" onClick={submitHandler}>
                                  Make Payment
                                </Button>
                              </Col>
                              <Col lg={3}></Col>
                            </Row>
                          </div>
                        </Accordion.Body>
                      </Accordion.Item>
                    </Accordion>
                  </Col>
                </Row>
              </Container>
            </Container>
          </div>
        </div>
      </div>
    </>
  )
}
