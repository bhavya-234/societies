import React, { useEffect, useState } from "react"
import Head from "next/head"
import styles from "@/styles/pages/Forms.module.scss"
import { Container, Col, Row, Form, Button } from "react-bootstrap"
import { PopupAction } from "@/redux/commonSlice"
import CryptoJS from "crypto-js"
import { useAppDispatch } from "@/hooks/reduxHooks"
import { useRouter } from "next/router"
import Details from "./AmalgamationOfTheSociety"
import { getSocietyDetails } from "@/axios"
import WindingSociety from "./WindingSociety"
import DissolutionSociety from "./DissolutionSociety"
import FillingListofMembers from "./FillingListofMembers"
import AmendmentDetailsChange from "./AmendmentDetailsChange"
const listofAmendment = () => {
  const router = useRouter()
  const dispatch = useAppDispatch()

  const ShowAlert = (type: any, message: any) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }

  const [checkedList, setCheckedList] = useState<string[]>([])
  const [unchecked, setUncheckedList] = useState<string[]>([])
  const [isPreview, setIsPreview] = useState<boolean>(false)

  const handlesubmit = () => {
    setIsPreview(true)

  }
  const [token, setToken] = useState<string>("")

  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setToken(data?.token)
    getSocietyDetails(data?.applicationId, data?.token).then((response) => {
      setExistingSocietyDetail(response.data?.daSociety)
    })
  }, [])

  const changeCheck = (e: React.ChangeEvent<HTMLInputElement>) => {
    const checkedValue = e.target.value
    const isChecked = e.target.checked

    if (isChecked) {
      if (
        checkedValue == "Change in the name of the society" ||
        checkedValue == "Change in the aims and objectives of the society" ||
        checkedValue == "Amendment of Memorandum and Bye-laws"
      ) {
        let disabledCheckboxes = [
          "Amalgamation of the society",
          "Winding up of the society",
          "Dissolution and winding up of the society",
          "Change of place of Registered Society Inside/Outside the District",
          "Filing of list of members",
        ]
        setCheckedList((prevCheckedList) => [...prevCheckedList, checkedValue])
        setCheckedList((prevCheckedList) =>
          prevCheckedList.filter((element) => !disabledCheckboxes.includes(element))
        )
      }

      if (
        checkedValue == "Amalgamation of the society" ||
        checkedValue == "Winding up of the society" ||
        checkedValue == "Dissolution and winding up of the society" ||
        checkedValue == "Change of place of Registered Society Inside/Outside the District" ||
        checkedValue == "Filing of list of members"
      ) {
        setCheckedList((prevCheckedList) => [...prevCheckedList, checkedValue])
        setCheckedList((prevCheckedList) =>
          prevCheckedList.filter((value) => value == checkedValue)
        )
      }
      // console.log("checkedlist", checkedList)
    } else {
      setCheckedList((prevCheckedList) => prevCheckedList.filter((value) => value !== checkedValue))
      //   setUncheckedList((prevUncheckedList) => [...prevUncheckedList, checkedValue]);
      //   console.log("uncheked",unchecked)
    }
  }

  return (
    <>
      <Head>
        <title>Amendments</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>
      {(existingSocietyDetail?.status === "Approved" ||existingSocietyDetail?.status === "Rejected")&&
((existingSocietyDetail?.historyDetails?.length>0 && existingSocietyDetail?.historyDetails?.some((x:any) => x.status == "Approved"))||
(existingSocietyDetail?.processingHistory?.length>0 && existingSocietyDetail?.processingHistory?.some((x:any) => x.status == "Approved"))
  )
&& <>
      {!isPreview ? (
        <div className={styles.RegistrationMain}>
          <div className="societyRegSec">
            <Container className="formsec ">
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="d-flex justify-content-between align-items-center page-title mb-3">
                    <div className="pageTitleLeft">
                      <h1>Amendment of Society (Under Sections:8,9,10,21,24,26)</h1>
                    </div>
                    {/* <div className="pageTitleRight">
                      <div className="page-header-btns">
                        <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                          Go Back
                        </a>
                      </div>
                    </div> */}
                  </div>
                </Col>
              </Row>
              <div className={styles.AmendmentDetails}>
                <h3>Amendment Details</h3>
              </div>
              <Row>
                <div className={styles.sectionContainer}>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionItems}>
                      <h5 className={styles.sectionAct}>Under Section 6(3),8,21</h5>
                    </div>
                  </Col>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionDetailItems}>
                      <Row>
                        <Col lg={12} md={12} xs={12} className="py-1">
                          <Form.Check
                            inline
                            label="Change in the name of the society.(Section 6(3))"
                            type="checkbox"
                            className="fom-checkbox"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some(
                                  (x: any) => x == "Change in the name of the society"
                                )
                                : false
                            }
                            value="Change in the name of the society"
                            // disabled={checkboxes[0].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>

                      <Row>
                        <Col lg={12} md={12} xs={12} className="py-1">
                          <Form.Check
                            inline
                            label="Change in the aims and objectives of the society.(Section 21)"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Change in the aims and objectives of the society"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some(
                                  (x: any) =>
                                    x == "Change in the aims and objectives of the society"
                                )
                                : false
                            }
                            // disabled={checkboxes[1].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>

                      <Row>
                        <Col lg={12} md={12} xs={12} className="py-1">
                          <Form.Check
                            inline
                            label="Amalgamation of the society.(Section 21)"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Amalgamation of the society"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some((x: any) => x == "Amalgamation of the society")
                                : false
                            }
                            // disabled={checkboxes[2].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>
                      <Row>
                        <Col lg={12} md={12} xs={12} className="py-1">
                          <Form.Check
                            inline
                            label="Amendment of Memorandum and Bye-laws.(Section 8)"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Amendment of Memorandum and Bye-laws"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some(
                                  (x: any) => x == "Amendment of Memorandum and Bye-laws"
                                )
                                : false
                            }
                            // disabled={checkboxes[4].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>
                    </div>
                  </Col>
                  <hr />
                </div>
              </Row>
              <Row>
                <div className={styles.sectionContainer}>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionItems}>
                      <h5 className={styles.sectionAct}>Under Section 9</h5>
                    </div>
                  </Col>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionDetailItems}>
                      {/* <Row>
                        <Col lg={12} md={12} xs={12}>
                          <Form.Check
                            inline
                            label="Filling of Annual list"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Filling of Annual list"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some((x: any) => x == "Filling of Annual list")
                                : false
                            }
                            // disabled={checkboxes[5].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row> */}
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <Form.Check
                            inline
                            label="Filing of list of members(Section 9)"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Filing of list of members"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some((x: any) => x == "Filing of list of members")
                                : false
                            }
                            // disabled={checkboxes[5].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>
                    </div>
                  </Col>
                  <hr />
                </div>
              </Row>

              <Row>
                <div className={styles.sectionContainer}>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionItems}>
                      <h5 className={styles.sectionAct}>Under Section 10</h5>
                    </div>
                  </Col>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionDetailItems}>
                      <Row>
                        <Col lg={12} md={12} xs={12}>
                          <Form.Check
                            inline
                            label="Change of place of Registered Society Inside/Outside the District.(Section 10)"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Change of place of Registered Society Inside/Outside the District"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some(
                                  (x: any) =>
                                    x ==
                                    "Change of place of Registered Society Inside/Outside the District"
                                )
                                : false
                            }
                            //  disabled={checkboxes[6].disabled}

                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>
                    </div>
                  </Col>
                  <hr />
                </div>
              </Row>

              <Row>
                <div className={styles.sectionContainer}>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionItems}>
                      <h5 className={styles.sectionAct}>Under Section 24</h5>
                    </div>
                  </Col>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionDetailItems}>
                      <Row>

                        <Col lg={12} md={12} xs={12}>
                          <Form.Check
                            inline
                            label="Dissolution of the Society.(Section 24)"
                            type="checkbox"
                            className="fom-checkbox"
                            value="Dissolution and winding up of the society"

                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some(
                                  (x: any) => x == "Dissolution and winding up of the society"
                                )
                                : false
                            }
                            // disabled={checkboxes[7].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>
                    </div>
                  </Col>
                  <hr />
                </div>
              </Row>

              <Row>
                <div className={styles.sectionContainer}>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionItems}>
                      <h5 className={styles.sectionAct}>Under Section 26</h5>
                    </div>
                  </Col>
                  <Col lg={6} md={6} xs={6}>
                    <div className={styles.sectionDetailItems}>
                      <Row>

                        <Col lg={12} md={12} xs={12}>
                          <Form.Check
                            inline
                            label="Winding up of the society.(Section 26)"
                            type="checkbox"
                            disabled={existingSocietyDetail.isSocietyDissolved=="True"?false:true}
                            className="fom-checkbox"
                            value="Winding up of the society"
                            checked={
                              checkedList && checkedList.length > 0
                                ? checkedList.some((x: any) => x == "Winding up of the society")
                                : false
                            }
                            // disabled={checkboxes[8].disabled}
                            onChange={(e: any) => changeCheck(e)}
                          />
                        </Col>
                      </Row>
                    </div>
                  </Col>
                </div>
              </Row>
              <hr />

              <Row>
                <Col lg={12} md={12} xs={12} style={{ textAlign: "center" }}>
                  <Button onClick={() => handlesubmit()}>Continue</Button>
                </Col>
              </Row>
            </Container>
          </div>
        </div>
      ) : (
        <></>
      )}
      {checkedList &&
        checkedList.length > 0 &&
        checkedList.some((x: string) => x == "Amalgamation of the society") && (
          <> {isPreview ? <Details checklistamalgam={checkedList} /> : <></>}</>)}
          {checkedList &&
        checkedList.length > 0 &&
        checkedList.some((x: string) => x == "Change of place of Registered Society Inside/Outside the District") && (
          <> {isPreview ?<AmendmentDetailsChange checklist={checkedList} />  : <></>}</>)}
      {checkedList &&
        checkedList.length > 0 &&
        (checkedList.some((x: string) => x == "Change in the name of the society") ||
          checkedList.some((x: string) => x == "Change in the aims and objectives of the society") ||
           checkedList.some((x: string) => x == "Amendment of Memorandum and Bye-laws")) && (
          <>{isPreview ? <AmendmentDetailsChange checklist={checkedList} /> : <></>}</>)

      }
       {checkedList &&
        checkedList.length > 0 &&
        checkedList.some((x: string) => x == "Winding up of the society") && (
          <> {isPreview ? <WindingSociety checklistwinding={checkedList} /> : <></>}</>)}
       {checkedList &&
        checkedList.length > 0 &&
        checkedList.some((x: string) => x == "Dissolution and winding up of the society") && (
          <> {isPreview ? <DissolutionSociety checklistdissolution={checkedList} /> : <></>}</>)}
        {/* {checkedList &&
        checkedList.length > 0 &&
        checkedList.some((x: string) => x == "Filling of Annual list") && (
          <> {isPreview ? <AnnualList checklistannual={checkedList} /> : <></>}</>)} */}
           {checkedList &&
        checkedList.length > 0 &&
        checkedList.some((x: string) => x == "Filing of list of members") && (
          <> {isPreview ? <FillingListofMembers checkmemberlist={checkedList} /> : <></>}</>)}

      </>}

      {(existingSocietyDetail?.status != "Approved"&&existingSocietyDetail?.status != "Rejected" &&
        <Col lg={12} md={12} xs={12}>
          <div className="d-flex justify-content-between pagesubmitSecTitle mb-3">
            <div className="ms-2">
              <h2>
                Your application was submitted.{" "}
                <a href="/societies" style={{ color: "blue" }}>
                  click here
                </a>{" "}
                to check application status
              </h2>
            </div>
          </div>
        </Col>
      )}


    </>
  )
}

export default listofAmendment
