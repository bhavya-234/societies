import React, { useEffect, useState } from "react"
import styles from "@/styles/components/report.module.scss"
import { GetStatusCount } from "@/axios"
import { PopupAction } from "@/redux/commonSlice"
import { useAppDispatch, useAppSelector } from "@/hooks/reduxHooks"
import CryptoJS from "crypto-js"
import Head from "next/head"
import { Button, Col, Container, Row, Tabs } from "react-bootstrap"
import DepartmentTab from "../components/Tabs"
import { useRouter } from "next/router"
// import DepartmentTab from "@/components/tabs"
// import DepartmentTab from "@/components/tabs"

const Report = () => {
  const dispatch = useAppDispatch()
  const [statuscount, setstatuscount] = useState<any>()
  const [sno, setsno] = useState<number>(0)
  let initialLoginDetails = useAppSelector((state) => state.login.loginDetails)
  const router = useRouter()
  const popupState = () => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (!data || data == null || data == "") {
      router.push("/")
    }
  }
  useEffect(() => {
    window.addEventListener("popstate", () => {
      popupState()
    })
    return () => {
      window.removeEventListener("popstate", () => {
        popupState()
      })
    }
  }, [])
  const ShowAlert = (type: any, message: any, redirectOnSuccess: string) => {
    dispatch(PopupAction({ enable: true, type, message, redirectOnSuccess }))
  }

  const handlecountstatus = async () => {
    let result: any = await GetStatusCount()
    console.log(result)
    if (result.success) {
      setstatuscount(result.data.reports)
      console.log("result::", result)
    } else {
      ShowAlert(false, result.message, "")
    }
  }
  const [locData, setLocData] = useState<any>({})
  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))    
    }
    if (data && data.token) {
      setLocData(data)
      handlecountstatus()
    }
  }, [])

  let srno = 0

  return (
    <>
      <Head>
        <title>Reports</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>
      <DepartmentTab active={0}/>
      <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-end align-items-center page-title mt-2 me-4">
                  <div className="pageTitleRight">
                    <div className="page-header-btns">
                      <a
                        className="btn btn-primary new-user"
                        onClick={() => router.push("societies/dataentry")}
                      >
                        Data Entry for Societies
                      </a>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
      {locData && locData?.userType && locData?.userType != "user" && (
        <div className="societyRegSec" >
          <Container>
           <div className={styles.tableFixHeadstatus}>
              <table className={styles.tablecontainerstatus}>
                <thead>
                  <tr>
                    <th className={styles.box1}>S.No</th>
                    <th className={styles.box2}>District</th>
                    <th className={styles.box4}>Approved</th>
                    <th className={styles.box5}>Rejected</th>
                    <th className={styles.box6}>Forwarded</th>
                    <th className={styles.box7}>Open </th>
                    <th className={styles.box7}>Not Viewed</th>
                  </tr>
                </thead>
                <tbody>
                  {statuscount != undefined && (
                    <tr style={{ backgroundColor: "#F7F7F7" }}>
                      <td>{(srno = srno + 1)}</td>
                      <td>{statuscount.district} </td>
                      <td>{statuscount.approved} </td>
                      <td>{statuscount.rejected} </td>
                      <td>{statuscount.forwarded} </td>
                      <td>{statuscount.open} </td>
                      <td>{statuscount.notViewed} </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Container>
        </div>
      )}
      {(!locData?.userType || locData?.userType == "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}

export default Report
