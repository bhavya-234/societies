import { CallingAxios, ShowMessagePopup } from "@/GenericFunctions"
import { UseGetAadharOTP, useUserLoginData } from "@/axios"
import Button from "@/components/Button"
import Captcha from "@/components/Captcha"
import TableText from "@/components/TableText"
import { PopupAction, setCaptcha } from "@/redux/commonSlice"
import { useAppDispatch, useAppSelector } from "@/redux/hooks"
import { resetLoginDetails, saveLoginDetails, userLogin, verifyUser } from "@/redux/loginSlice"
import styles from "@/styles/pages/Forms.module.scss"
import CryptoJS, { AES } from "crypto-js"
import { get } from "lodash"
import Head from "next/head"
import { useRouter } from "next/router"
import castyles from '../styles/pages/Mixins.module.scss'
import { useEffect, useState } from "react"
import { Col, Container, Form, Row } from "react-bootstrap"
import { ALPHANUMERIC, checkCaptcha, randomString } from "@/utils"

interface LoginPageProps {
  isregType: any
  setIsRegType: any
  setISLogin: any
}

const initialLoginDetails: any = {
  maskedAadhar: "",
  aadharNumber: "",
  captchaVal:"",
  registrationType: "society",
}

const LoginPage = ({ isregType, setIsRegType, setISLogin }: LoginPageProps) => {
  const dispatch = useAppDispatch()
  const router = useRouter()
  const [LoginDetails, setLoginDetails] = useState(initialLoginDetails)
  const [inputValue, setInputValue] = useState<any>("");
  const [FormError, setFormError] = useState<string>("")
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [otp, setOTP] = useState<string>("")
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const [loading, setLoading] = useState<boolean>(false)
  const [isFieldAdded, setIsFieldAdded] = useState<boolean>(false)
  const [refId, setRefId] = useState<string>("")
  const verifyUserData = useAppSelector((state) => state.login.verifyUserData)
  const verifyUserLoading = useAppSelector((state) => state.login.verifyUserLoading)
  const verifyUserMsg = useAppSelector((state) => state.login.verifyUserMsg)

  const loginData = useAppSelector((state) => state.login.loginData)
  const loginLoading = useAppSelector((state) => state.login.loginLoading)
  const loginMsg = useAppSelector((state) => state.login.loginMsg)

  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid && event.key != "Backspace") {
      event.preventDefault()
    }
  }

  const onChange = (e: any) => {
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (e.target.value.length > 0 && e.target.value.length > LoginDetails.aadharNumber.length) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          LoginDetails.aadharNumber.substring(0, startpos) +
          LoginDetails.aadharNumber.substring(startpos + 1, LoginDetails.aadharNumber.length)
      }
      setLoginDetails({
        ...LoginDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? LoginDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      setLoginDetails({
        ...LoginDetails,
        [e.target.name]: e.target.value,
      })
    }
    if (LoginDetails.aadharNumber.length == 11) {
      setIsFieldAdded(true)
    } else {
      setIsFieldAdded(false)
    }
    if (FormError) {
      setFormError("")
    }
  }

  const backToLogin = () => {
    setLoginDetails({ ...initialLoginDetails })
    setOTP("")
    setSentOTP(false)
    // proceedpopup()
  }

  const redirectToPage = (location: string) => {
    router.push({
      pathname: location,
    })
  }

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data) {
      if (data.userType == "user") {
        router.push("/societies/dashboard")
      } else {
        router.push("/societies")
      }
    } else {
      localStorage.clear()
      const resetLoginDetails = {
        firstName: "",
        lastName: "",
        email: "",
        alternateEmail: "",
        mobileNumber: "",
        token: "",
        aadharNumber: "",
        registrationType: "",
        status: "",
        applicationId: "",
        applicationNumber: "",
        userType: "",
      }
      dispatch(saveLoginDetails(resetLoginDetails))
    }
  }, [])
  // const captchaStr = useAppSelector(state => state.common.captchaStr);
  const onSubmit = async (e: any) => {
    e.preventDefault()
    let myError: any = validate(LoginDetails)
    if (inputValue == "") {
      ShowMessagePopup(false, "Please Enter The Capctha");
    } else {
      let captchaCheck: any = await checkCaptcha(inputValue);
      if (captchaCheck === false) {
        ShowMessagePopup(false, "Please Enter Valid Capctha");
        dispatch(setCaptcha(randomString(6, ALPHANUMERIC)));
      } else {
        if (!myError) {
          let data:any={
            secretkey:process.env.SECRET_KEY,
          }
          let obj: any = {
            registrationType: LoginDetails.registrationType,
            aadharNumber: LoginDetails.aadharNumber,
            captchaVal:inputValue,
            userKey: CryptoJS.AES.encrypt(inputValue,data.secretkey).toString()
          }
          dispatch(verifyUser(obj))
        }
      }
      setInputValue("")
      
    }
   
  }

  useEffect(() => {
    if (Object.keys(verifyUserData).length && verifyUserData.success == true) {
      ;(async () => {
        if (process.env.IGRS_SECRET_KEY) {
          setLoading(true)
          setRefId(verifyUserData.data.refId)
          const ciphertext = AES.encrypt(LoginDetails.aadharNumber, process.env.IGRS_SECRET_KEY)
          let result = await UseGetAadharOTP(ciphertext.toString())

          if (result && result.status === "Success") {
            ShowMessagePopup(true, "OTP Sent to Aadhaar Registered Mobile Number.")
            setSentOTP(true)
            setAadhaarOTPResponse(result)
          } else {
            // setSentOTP(true)
            ShowMessagePopup(false, get(result, "message", "Aadhaar API failed"))
            setAadhaarOTPResponse({})
            dispatch(setCaptcha(randomString(6, ALPHANUMERIC)));
          }
          setLoading(false)
        }
      })()
    } else if (verifyUserData.success == false) {
      ShowMessagePopup(false, verifyUserData.message, "")
      dispatch(setCaptcha(randomString(6, ALPHANUMERIC)));
    }
  }, [verifyUserData])

  useEffect(() => {
    if (verifyUserMsg) {
      ShowAlert(false, verifyUserMsg)
    }
  }, [verifyUserMsg])

  const validate = (values: any) => {
    let error = ""
    if (values.aadharNumber.length < 12) {
      error = "*Please enter a valid aadhaar number."
    }
    setFormError(error)
    return error
  }

  const UserLoginAction = async () => {
    try {
      let data = {
        aadharNumber: LoginDetails.aadharNumber,
        registrationType: LoginDetails.registrationType,
      }
      await CallLogin2(data)
    } catch (error) {
      ShowAlert(false, "Error:" + error)
    }
  }

  const CallLogin2 = async (value: any) => {
    let result: any = await CallingAxios(useUserLoginData(value))

    if (result && result.success == true) {
      let query = {
        firstName: result.data.firstName,
        lastName: result.data.lastName,
        email: result.data.email,
        alternateEmail: result.data.alternateEmail,
        mobileNumber: result.data.mobileNumber,
        aadharNumber: result.data.aadharNumber,
        registrationType: result.data.registrationType,
        status: result.data.status,
        applicationId: result.data.applicationId,
        applicationNumber: result.data.applicationNumber,
        userType: result.data.userType,
        token: result.data.token,
      }
      localStorage.setItem("FASPLoginDetails", JSON.stringify(query))
      dispatch(saveLoginDetails(query))
      if (result.data.registrationType == "firm") {
        router.push("/firms/dashboard")
      }
      if (result.data.registrationType == "society") {
        router.push("/societies/dashboard")
      }
    } else {
      ShowAlert(false, result.message)
    }
  }

  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }

  const callLoginAPI = (result: any) => {
    if (process.env.SECRET_KEY) {
      let ciphertext = CryptoJS.AES.encrypt(
        JSON.stringify(result),
        process.env.SECRET_KEY
      ).toString()
      let object: any = {
        otp: ciphertext,
      }
      dispatch(userLogin({ ...object }))
    }
  }

  const onLogin = async (e: any) => {
    e.preventDefault()
    {
      
      if (LoginDetails.aadharNumber) {
        setLoading(true)
        let secretkey:any=process.env.IGRS_SECRET_KEY;
        let result = {
          aadharNumber: CryptoJS.AES.encrypt( LoginDetails.aadharNumber,secretkey).toString(),
          transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
          otp: otp,
          refId: refId,
        }
        callLoginAPI(result)
      }
      setLoading(false)
    }
  }
  useEffect(() => {
    if (
      Object.keys(loginData).length &&
      Object.keys(loginData.data)?.length &&
      process.env.SECRET_KEY
    ) {
      let bytes = CryptoJS.AES.decrypt(loginData.data, process.env.SECRET_KEY)
      let data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
      if(data.otp==otp){
      let query = {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        alternateEmail: data.alternateEmail,
        mobileNumber: data.mobileNumber,
        aadharNumber: data.aadharNumber,
        registrationType: data.registrationType,
        status: data.status,
        applicationId: data.applicationId,
        applicationNumber: data.applicationNumber,
        userType: data.userType,
        token: data.token,
        lastLogin: data.lastLogin,
      }
      const userDetailsEnc = CryptoJS.AES.encrypt(
        JSON.stringify(query),
        process.env.SECRET_KEY
      ).toString()
      localStorage.setItem("FASPLoginDetails", userDetailsEnc)
      dispatch(saveLoginDetails(query))
      router.push("/societies/dashboard")
    }else{
      ShowMessagePopup(false,"Invalid OTP")
    }
    } else if (Object.keys(loginData).length && !Object.keys(loginData?.data)?.length) {
      ShowMessagePopup(false, "Error occurred while login")
    }
  }, [loginData])

  useEffect(() => {
    if (loginMsg) {
      ShowAlert(false, loginMsg)
    }
  }, [loginMsg])

  useEffect(() => {
    return () => {
      dispatch(resetLoginDetails())
    }
  }, [])

  return (
    <>
      <Head>
        <title>Login - Societies</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      <div className="logiRegMainSec">
        <div className="societyRegSec">
          <Container>
            <div className="regContainerSec">
              <div className="regFieldsMain formsec loginFieldsSec">
                <Row className="d-flex align-items-center">
                  <Col lg={12} md={12} xs={12}>
                    <div className={` ${styles.RegistrationInput} ${styles.LoginPageInput}`}>
                      {sentOTP ? (
                        <form
                          onSubmit={onLogin}
                          className={loading || loginLoading ? styles.disableForm : ""}
                        >
                          <div className="d-flex justify-content-between mb-3">
                            <div className="formSectionTitle">
                              <h3 className="p-0 d-flex align-items-center">
                                <button
                                  className={styles.rightButton}
                                  onClick={backToLogin}
                                  type="button"
                                >
                                  <img className="enterBackImg" src="/assets/back-icon.svg" />
                                </button>{" "}
                                <span className={styles.enterOTPText}>Enter OTP</span>
                              </h3>
                            </div>
                          </div>

                          <div className="mb-3">
                            <Form.Control
                              type="text"
                              placeholder="Enter OTP"
                              required={true}
                              name="otp"
                              value={otp}
                              maxLength={6}
                              onChange={(e) => {
                                setOTP(e.target.value)
                              }}
                              onKeyPress={onNumberOnlyChange}
                            />
                          </div>
                          <Row className="p">
                            <Col lg={4} md={6} xs={6}>
                              <div className={styles.pdesingleColumn}>
                                <Button
                                  status={loading || loginLoading}
                                  type="submit"
                                  btnName="Login"
                                  disabled={verifyUserLoading || loading}
                                ></Button>
                              </div>
                            </Col>
                            <Col lg={8} md={6} xs={6} className={styles.flexColumn}>
                              <div className={styles.flexColumn}>
                                <span className={`${styles.checkText} ${styles.scheckText}`}>
                                  Did not receive OTP?
                                </span>
                                <button
                                  type="button"
                                  onClick={onSubmit}
                                  className={styles.rightButton}
                                  disabled={verifyUserLoading || loading}
                                >
                                  Resend OTP
                                </button>
                              </div>
                            </Col>
                          </Row>
                        </form>
                      ) : (
                        <form
                          className={verifyUserLoading || loading ? styles.disableForm : ""}
                          onSubmit={onSubmit}
                        >
                          <div className="d-flex justify-content-between mb-3">
                            <div className="formSectionTitle">
                              <h3>User Login</h3>
                            </div>
                          </div>

                          <div className="mb-3">
                            <TableText label={"Aadhaar Number"} required={true} LeftSpace={false} />
                            <Form.Control
                              type="text"
                              placeholder="Enter Aadhaar Number"
                              required={true}
                              name="maskedAadhar"
                              value={LoginDetails.maskedAadhar}
                              onChange={onChange}
                              maxLength={12}
                              autoComplete="off"
                              onKeyPress={onNumberOnlyChange}
                              onPaste={(e) => e.preventDefault()}
                            />
                            {FormError && <span className={styles.warningText}>{FormError}</span>}

                            <Form.Control
                              type="hidden"
                              placeholder="Registration Type"
                              name="registrationType"
                              value={LoginDetails.registrationType}
                            />
                          </div>
                          <Row className={`mt-4 ${castyles.captchaCon}`}>
                                <Col lg={4} md={6} xs={6}><Captcha /></Col>
                                <Col lg={8} md={6} xs={6}>
                                  <div className='d-flex'>
                                    <input value={inputValue} className={castyles.captchaInput} onChange={(e) => { setInputValue(e.target.value); }} />
                                  </div>
                                </Col>
                              </Row>
                          <Row className="p">
                            <Col lg={6} md={6} xs={6}>
                              <div className={styles.pdesingleColumn} style={{ cursor: "pointer" }}>
                                {!isFieldAdded && (
                                  <div className="btn btn-secondary disabled">Get OTP</div>
                                )}
                                {isFieldAdded && (
                                  <Button
                                    type="submit"
                                    status={verifyUserLoading || loading}
                                    btnName="Get OTP"
                                  ></Button>
                                )}
                              </div>
                            </Col>
                            <Col lg={6} md={6} xs={6} className={styles.flexColumn}>
                              <div className={styles.flexColumn}>
                                <span className={`${styles.checkText} ${styles.scheckText}`}>
                                  Don’t have an account?
                                </span>
                                {LoginDetails.registrationType == "society" && (
                                  <a href="/societyRegistration" className={styles.rightButton}>
                                    New Registration!
                                  </a>
                                )}
                                {LoginDetails.registrationType == undefined && (
                                  <a href="/societyRegistration" className={styles.rightButton}>
                                    New Registration!
                                  </a>
                                )}
                              </div>
                            </Col>
                          </Row>
                        </form>
                      )}
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </Container>
        </div>
      </div>
    </>
  )
}

export default LoginPage
