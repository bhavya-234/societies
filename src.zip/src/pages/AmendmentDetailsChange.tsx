import TableInputText from "@/components/TableInputText"
import TableText from "@/components/TableText"
import React, { useEffect, useRef, useState } from "react"
import { Button, Col, Container, Form, Modal, Row, Table } from "react-bootstrap"
import styles from "@/styles/components/Table.module.scss"
import { LoadingAction, PopupAction } from "@/redux/commonSlice"
import { useAppDispatch } from "@/hooks/reduxHooks"
import CryptoJS, { AES } from "crypto-js"
import router, { useRouter } from "next/router"
import Image from "next/image"
import DynamicVillages from "@/pages/societies/dynamicCities"
import instance from "@/redux/api"
import {
  UseGetAadharDetails,
  UseGetAadharOTP,
  getSocietyDetails,
  updateSocietyDetails,
} from "@/axios"
import DynamicMandals from "@/pages/societies/dynamicMandals"
import { store } from "@/redux/store"
import Swal from "sweetalert2"
import { get } from "lodash"
import { ShowMessagePopup } from "@/GenericFunctions"
import { useAppSelector } from "@/redux/hooks"
import { ISAmendmentSocietyDetailsModel, ISApplicantDetailModel } from "@/models/types"
import moment from "moment"

interface ChangeDetailProps {
  checklist?: any
  setIsPreview?: any
}

const ChangeDetails = ({ checklist, setIsPreview }: ChangeDetailProps) => {
  const dispatch = useAppDispatch()
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [changenamedata, setchangenamedata] = useState<boolean>(false)
  const [changeaim, setchangeaim] = useState<boolean>(false)
  const [changebyelaws, setchangebyelaws] = useState<boolean>(false)
  const [list, setlist] = useState<boolean>(false)
  const [changeplace, setchangeplace] = useState<boolean>(false)
  const [amalgamation, setamalgamation] = useState<boolean>(false)
  const [division, setdivision] = useState<boolean>(false)
  const [winding, setwinding] = useState<boolean>(false)
  const [dissolution, setdissolution] = useState<boolean>(false)

  const [file, setFile] = useState<any>({})
  // const [file, setFile] = useState<boolean>({})
  const [docdisplay, setdocdisplay] = useState<boolean>(false)
  const [errors, setErrors] = useState<any>({})
  const [showPaymentModal, setShowPaymentModal] = useState<boolean>(false)
  const [addSociety, setAddSociety] = useState<string>("")
  const [isError, setIsError] = useState<boolean>(false)
  const [errorMessage, setErrorMessage] = useState<string>("")
  const [districtList, setDistricts] = useState<any>([])
  const [token, setToken] = useState<string>("")
  const [loggedInAadhar, setLoggedInAadhar] = useState<string>("")
  const [sentOTP, setSentOTP] = useState<boolean>(false)
  const [isPayNowClicked, setIsPayNowClicked] = useState<boolean>(false)
  const [display, setdisplay] = useState<boolean>(false)
  const [display1, setdisplay1] = useState<boolean>(false)
  const [display2, setdisplay2] = useState<boolean>(false)
  const [display3, setdisplay3] = useState<boolean>(false)
  const [display4, setdisplay4] = useState<boolean>(false)
  const [aadhaarOTPResponse, setAadhaarOTPResponse] = useState<any>({})
  const [aadhaarUserResponse, setAadhaarUserResponse] = useState<any>({})
  const [existingSocietyDetail, setExistingSocietyDetail] = useState<any>({})
  const [currentDistrict, setCurrentDistrict] = useState<string>("")
  const [currentmemberDistrict, setCurrentmemberDistrict] = useState<any>([])
  const [currentmemberMandal, setCurrentmemberMandal] = useState<any>([])
  const [relationtypelist] = useState<any>(["S/O", "D/O", "W/O", "H/O"])
  const [TempMemoryterminate, setTempMemoryterminate] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  const [roleList] = useState<any>([
    "President",
    "Vice President",
    "Secretary",
    "Joint Secretary",
    "Treasurer",
    "Member",
  ])
  const [ReadMore, setReadMore] = useState(false)
  const [currentMandal, setCurrentMandal] = useState<string>("")
  const [TempMemory, setTempMemory] = useState<any>({ OTPRequested: false, AadharVerified: false })
  const [TempMemorymember, setTempMemorymember] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  const [TempMemorymemberremove, setTempMemorymemberremove] = useState<any>({
    OTPRequested: false,
    AadharVerified: false,
  })
  const router = useRouter()
  const [selectedOption, setSelectedOption] = useState<string>("")
  const [applicantDetails, setApplicantDetails] = useState<ISApplicantDetailModel>({
    aadharNumber: "",
    name: "",
    relationName: "",
    role: "",
    doorNo: "",
    relationType: "",
    age: "",
    gender: "",
    street: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    pinCode: "",
    phone: "",
    mobileNumber: "",
    maskedAadhar: "",
    email: "",
  })
  const refUpdate = useRef(null)
  const [societyDetails, setSocietyDetails] = useState<ISAmendmentSocietyDetailsModel>({
    societyName: "",
    category: "",
    aim: "",
    objective: "",
    newAim: "",
    newObjective: "",
    newNameDateEffect: "",
    societyNewName: "",
    street: "",
    annualmeeting: "",
    venue: "",
    memberattended: "",
    governingbody: "",
    newDate: "",
    memoradumByelaws: "",
    doorNo: "",
    district: "",
    mandal: "",
    villageOrCity: "",
    joiningofnewmember: "",
    membersagreedwithbyelaws: "",
    joiningofnewmemberapprovedbyQuorum: "",

    pinCode: "",
    majority: "",
    acceptorapprove: "",
    majority1: "",
    acceptorapprove1: "",
  })
  const [membersDetails, setmembersDetails] = useState<any>([
    {
      HonoraryMember: "",
      aadharNumber: "",
      newDate: "",
      mode: "",
      date: "",
      ElectionDetails: "",
      modeofelection: "",
      Aadharnumber: "",
    },
  ])
  const [requestType, setrequestType] = useState<any>({
    isAimChange: "",
    isNameChange: "",
    placeChange: "",
    isMemorandumChange: ""
  })
  const [displayOption, setDisplayOption] = useState<string>("display")
  const [typelist] = useState<any>(["Individual", "Coorporate"])
  const [isCheckSoc, setIsCheckSoc] = useState<boolean>(false)
  let Documentsoption: any = useAppSelector((state) => state.form.DocumentDetails)
  const [IndexData, setIndexData] = useState<any>({})
  const handleOptionChange = (event: any) => {
    setSelectedOption(event.target.value)
    setIsCheckSoc(false)
    setSocietyDetails({
      societyName: existingSocietyDetail.societyName,
      category: "",
      aim: "",
      objective: "",
      newAim: "",
      newObjective: "",
      joiningofnewmember: "",
      membersagreedwithbyelaws: "",
      joiningofnewmemberapprovedbyQuorum: "",

      newNameDateEffect: "",
      societyNewName: "",
      street: "",
      annualmeeting: "",
      venue: "",
      memberattended: "",
      governingbody: "",
      newDate: "",
      memoradumByelaws: "",
      doorNo: "",
      district: existingSocietyDetail.district,
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      majority: "",
      acceptorapprove: "",
      majority1: "",
      acceptorapprove1: ""
    })
  }
  const [reasonlist] = useState<any>(["RESIGNED", "TERMINATED", "DEATH"])
  const [SelectedMemberDetails, setSelectedMemberDetails] =
    useState<any>({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
  const [SelectedMemberDetailsremove, setSelectedMemberDetailsremove] = useState<any>({
    maskedAadhar: "",
    noticeTime: "",
    aadharNumber: "",
    termination: "",
    firstNoticeDate: "",
    secondNoticeDate: "",
    thirdNoticeDate: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",
    reasonForOutgoing: "",
  })
  const [byelawDetails, setbyelawDetails] = useState<any>("")
  const [outgoingMembersDetails, setoutgoingMembersDetails] = useState<any>([])
  const [deleteindex, setDeleteIndex] = useState<any>(-1)
  const [showVerification, setShowVerification] = useState(false);
  const [FormErrors, setFormErrors] = useState<any>({})
  const handleMemberRemove = (index: number) => {
    const errors: any = {}
    if (SelectedMemberDetailsremove.reasonForOutgoing == "") {
      setShowVerification(true)
      errors["reasonForOutgoing"] = "*please select reason for outgoing."
      ShowMessagePopup(false, "please select reason for outgoing")
    } else if (TempMemorymemberremove.AadharVerified != true && SelectedMemberDetailsremove.reasonForOutgoing != "TERMINATED") {
      setShowVerification(true)
      errors["maskedAadhar"] = "*please validate aadhar."
      ShowMessagePopup(false, "please validate aadhar number")
    } else {
      setShowVerification(false)
      let data: any = [...membersDetails]
      let details: any = [...outgoingMembersDetails]

      details.push({ ...data[index], reasonForOutgoing: SelectedMemberDetailsremove.reasonForOutgoing })
      setIndexData(data[index])
      data.splice(index, 1)
      setmembersDetails(data)
      setoutgoingMembersDetails(details)
      setDeleteIndex(-1)

      setTempMemorymemberremove({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetailsremove({
        maskedAadhar: "",
        aadharNumber: "",
        termination: "",
        otpStatus: "",
        otpCode: "",
        otpVerified: "",
        reasonForOutgoing: "",
      })

    }
    setFormErrors({ ...errors })
    return errors
  }

  const handleMemberRemoveoutgoing = (index: number) => {
    let data: any = [...membersDetails]
    let details: any = [...outgoingMembersDetails]
    let removedmember = { ...details[index], reasonForOutgoing: "" }
    data.push(removedmember)
    details.splice(index, 1)
    setmembersDetails(data)
    setoutgoingMembersDetails(details)
  }
  const [AadharValidate, setAadharValidate] = useState<any>([{
    aadharNumber: "",
    makedAadhar: "",
    otpStatus: "",
    otpCode: "",
    otpVerified: "",

  },],)
  const [displayaadhar, setdisplayaadhar] = useState<boolean>(false)
  const ReqDetails = async (MyKey: any) => {
    let result = await CallingAxios(
      UseGetAadharDetails({
        aadharNumber: btoa(MyKey.aadharNumber),
        transactionNumber: MyKey?.OTPResponse?.transactionNumber,
        otp: MyKey.otpCode,
      })
    )
    if (
      result.status &&
      result.status === "Success" &&
      MyKey?.OTPResponse?.transactionNumber == result.transactionNumber.split(":")[1]
    ) {
      let latestData: any = {
        ...MyKey,
        name: result.userInfo.name ? result.userInfo.name : "",
        memberName: result.userInfo.name ? result.userInfo.name : "",
        relationType: result.userInfo.co ? result.userInfo.co.substring(0, 3) : "",
        relationName: result.userInfo.co ? result.userInfo.co.substring(4) : "",
        age: result.userInfo.dob ? ageCalculator(result.userInfo.dob) : "",
        gender: result.userInfo.gender == "M" ? "Male" : "Female",
        district: result.userInfo.dist ? result.userInfo.dist : "",
        pinCode: result.userInfo.pc ? result.userInfo.pc : "",
        street: result.userInfo.loc ? result.userInfo.street : "",
        villageOrCity: result.userInfo.vtc ? result.userInfo.vtc : "",
        doorNo: result.userInfo.house ? result.userInfo.house : "",
        address:
          (result.userInfo.lm ? result.userInfo.lm + ", \n" : "") +
          (result.userInfo.loc ? result.userInfo.loc + ", \n" : "") +
          (result.userInfo.dist ? result.userInfo.dist + ", \n" : "") +
          (result.userInfo.vtc ? result.userInfo.vtc : "") +
          (result.userInfo.pc ? "-" + result.userInfo.pc : ""),
        OTPResponse: result,
      }

      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails(latestData)
          setTempMemory({ OTPRequested: false, AadharVerified: true })
          break
        case SelectedMemberDetails:
          setSelectedMemberDetails(latestData)
          setTempMemorymember({ OTPRequested: false, AadharVerified: true })
          break
        case SelectedMemberDetailsremove:
          setSelectedMemberDetailsremove(latestData)
          setTempMemorymemberremove({ OTPRequested: false, AadharVerified: true })
          break
        case AadharValidate:
          setAadharValidate(latestData)
          setTempMemoryterminate({ OTPRequested: false, AadharVerified: true })
          break
        default:
          break
      }
    } else {
      ShowMessagePopup(false, "Please Enter Valid OTP", "")
    }
  }

  const verifyOtp = async (index: number) => {

    if (AadharValidate[index].otpCode) {

      Loading(true)
      let result: any = await UseGetAadharDetails({
        aadharNumber: btoa(AadharValidate[index].aadharNumber),
        transactionNumber: get(aadhaarOTPResponse, "transactionNumber", ""),
        otp: AadharValidate[index].otpCode,
      })
      Loading(false)
      if (result.status && result.status === "Success") {
        let data = [...AadharValidate]
        data[index]["otpVerified"] = "true"
        data[index]["memberName"] = result.userInfo.name
        // data[index]["fatherOrHusbandName"] = result.userInfo.co.split(":").pop().trim()
        data[index]["gender"] = result.userInfo.gender == "M" ? "Male" : "Female"
        data[index]["age"] = ageCalculator(result.userInfo.dob)
        data[index]["country"] = result.userInfo.country
        data[index]["state"] = result.userInfo.state
        data[index]["doorNo"] = result.userInfo.house + " " + result.userInfo.loc
        data[index]["street"] = result.userInfo.street
        data[index]["district"] = result.userInfo.dist.toUpperCase()
        data[index]["pinCode"] = result.userInfo.pc
        data[index]["relationName"] = result.userInfo.co
        setAadharValidate(data)
      } else {
        let data = [...AadharValidate]
        data[index]["otpVerified"] = "false"
        setAadharValidate(data)
        ShowMessagePopup(false, "Aadhaar API Failed")
      }
    }
  }
  const terminaMemberChange = (e: any, index: any) => {
    let datanew = AadharValidate
    if (e.target.name == "maskedAadhar") {

      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (e.target.value.length > 0 && e.target.value.length > datanew[index]?.aadharNumber?.length) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }

      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          datanew[index].aadharNumber.substring(0, startpos) +
          datanew[index].aadharNumber.substring(startpos + 1, datanew[index].aadharNumber.length)
      }

      const det = {
        ...datanew[index],
        maskedAadhar: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? datanew[index].aadharNumber + newNo : aadharNo,
      }

      let aadhardata = [...AadharValidate]
      aadhardata[index] = det

      setAadharValidate(aadhardata)
    } else {
      const det = {
        ...datanew[index],
        [e.target.name]: e.target.value
      }

      let aadhardata = [...AadharValidate]
      aadhardata[index] = det

      setAadharValidate(aadhardata)
    }

  }
  const generateOtp = async (index: any) => {

    if (
      AadharValidate[index].aadharNumber &&
      AadharValidate[index].aadharNumber.length == 12 &&
      process.env.IGRS_SECRET_KEY
    ) {
      const ciphertext = AES.encrypt(
        AadharValidate[index].aadharNumber,
        process.env.IGRS_SECRET_KEY
      )
      let result = await UseGetAadharOTP(ciphertext.toString())

      if (result && result.status === "Success") {
        ShowMessagePopup(true, "OTP Sent Successfully")
        setSentOTP(true)
        setAadhaarOTPResponse(result)
        let data = [...AadharValidate]
        data[index]["otpStatus"] = "1"
        setAadharValidate(data)
      } else {
        ShowMessagePopup(false, get(result, "message", "Aadhaar API failed"))
        setAadhaarOTPResponse({})
        let data = [...AadharValidate]
        data[index]["otpStatus"] = "2"
        setAadharValidate(data)
      }
      // const newInput = () => ({ ...membersDetails, ["otpStatus"]: "1" })
      // membersDetails[index].otpCode = ""
      // setApplicantDetails(newInput)
    } else {
      ShowMessagePopup(false, "Kindly enter valid Aadhar number")
    }
  }
  const ReqOTP = (MyKey: any) => {
    if (MyKey.aadharNumber && MyKey.aadharNumber.length == 12) {
      CallGetOTP(MyKey)
    } else {
      ShowMessagePopup(false, "Kindly enter valid Aadhar number", "")
    }
  }
  const CallingAxios = async (myFunction: any) => {
    Loading(true)
    let result = await myFunction
    Loading(false)
    return result
  }

  const CallGetOTP = async (MyKey: any) => {
    if (process.env.IGRS_SECRET_KEY) {

      const ciphertext = AES.encrypt(MyKey.aadharNumber, process.env.IGRS_SECRET_KEY)
      let result = await CallingAxios(UseGetAadharOTP(ciphertext.toString()))

      if (result && result.status != "Failure") {
        switch (MyKey) {
          case applicantDetails:
            setTempMemory({ OTPRequested: true, AadharVerified: false })
            break
          case SelectedMemberDetails:
            setTempMemorymember({ OTPRequested: true, AadharVerified: false })
            break
          case SelectedMemberDetailsremove:
            setTempMemorymemberremove({ OTPRequested: true, AadharVerified: false })
            break
          case AadharValidate:
            setTempMemoryterminate({ OTPRequested: true, AadharVerified: false })
            break
          default:
            break
        }
        switch (MyKey) {
          case applicantDetails:
            setApplicantDetails({ ...MyKey, OTPResponse: result })
            break
          case SelectedMemberDetails:
            setSelectedMemberDetails({ ...MyKey, OTPResponse: result })
            break
          case SelectedMemberDetailsremove:
            setSelectedMemberDetailsremove({ ...MyKey, OTPResponse: result })
            break
          case AadharValidate:
            setAadharValidate({ ...MyKey, OTPResponse: result })
            break
          default:
            break
        }
        ShowMessagePopup(
          true,
          "OTP Sent to Aadhaar Registered Mobile Number.",
          ""
        )
      }
    } else {
      switch (MyKey) {
        case applicantDetails:
          setApplicantDetails({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemory({ OTPRequested: false, AadharVerified: false })
          break
        case SelectedMemberDetails:
          setSelectedMemberDetails({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemorymember({ OTPRequested: false, AadharVerified: false })
          break
        case AadharValidate:
          setAadharValidate({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemoryterminate({ OTPRequested: false, AadharVerified: false })
          break
        case SelectedMemberDetailsremove:
          setSelectedMemberDetailsremove({
            ...MyKey,
            otpCode: "",
            OTPResponse: { transactionNumber: "" },
            KYCResponse: {},
          })
          setTempMemorymemberremove({ OTPRequested: false, AadharVerified: false })
          break
        default:
          break
      }
      ShowMessagePopup(false, "Please Enter Valid Aadhar", "")
    }
  }
  const handleMemberAdd = () => {

    let object: any = { ...SelectedMemberDetails }
    if (
      object.aadharNumber == "" ||
      object.relationType == "" ||
      object.gender == "" ||
      object.age == "" ||
      object.doorNo == "" ||
      object.district == "" ||
      object.mandal == "" ||
      object.villageOrCity == "" ||
      object.pinCode == "" ||
      object.relationName == "" ||
      object.mobileNumber == "" ||
      object.joiningDate == "" ||
      object.role == "" ||
      object.qualification == "" ||
      object.memberType == "" ||

      object.occupation == ""
    ) {
      return ShowMessagePopup(false, "Kindly fill all inputs for New member", "")
    } else if (object.soundMind !== "Yes") {
      return ShowMessagePopup(false, "Please select validate option for soundMind", "")
    } else if (object.inSolvent !== "No") {
      return ShowMessagePopup(false, "Please select validate option for insolvent", "")
    } else if (!object.memberType) {
      return ShowMessagePopup(false, "Please select member type", "")
    }
    else if (object.offense !== "No") {
      return ShowMessagePopup(false, "Please select validate option for offense", "")
    } else if (object.appointment !== "No") {
      return ShowMessagePopup(false, "Please select validate option for appointment", "")
    } else if (!object.mandal) {
      return ShowMessagePopup(false, "Please select mandal", "")
    } else if (!object.villageOrCity) {
      return ShowMessagePopup(false, "Please select village or city", "")
    } else if (
      object.mobileNumber &&
      (object.mobileNumber.length != 10 ||
        (object.mobileNumber.length == 10 &&
          object.mobileNumber.charAt(0) != "6" &&
          object.mobileNumber.charAt(0) != "7" &&
          object.mobileNumber.charAt(0) != "8" &&
          object.mobileNumber.charAt(0) != "9"))
    ) {
      return ShowMessagePopup(false, "Please enter vaild mobile number", "")
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some((x: any) => x.aadharNumber?.toString() == object.aadharNumber?.toString() && x.status == "Active")
    ) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }

      )
      return ShowMessagePopup(
        false,
        "Aadhaar number is already exist. Please enter new aadhaar number",
        ""
      )
    } else if (parseInt(object.age) < 18) {
      setTempMemorymember({ OTPRequested: false, AadharVerified: false })
      setSelectedMemberDetails(
        {
          //   OTPResponse: { transactionNumber: "" },
          // KYCResponse: {},
          memberType: "",
          relationName: "",
          joiningDate: "",
          qualification: "",
          soundMind: "",
          inSolvent: "",
          offense: "",
          appointment: "",
          maskedAadhar: "",
          aadharNumber: "",
          gender: "",
          role: "",
          age: "",
          otpStatus: "",
          otpCode: "",
          otpVerified: "",
          occupation: "",
          doorNo: "",
          street: "",
          country: "India",
          state: "Andhra Pradesh",
          district: "",
          mandal: "",
          villageOrCity: "",
          pinCode: "",
          mobileNumber: "",
          email: "",
          memberName: "",
          relationType: "",
        }
      )
      return ShowMessagePopup(false, "Minimum age of partner should be 18", "")
    } else if (parseInt(object.share) < 0 || parseInt(object.share) >= 100) {
      return ShowMessagePopup(false, "share should be above 0 and less than 100 percent", "")
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some((x: any) => parseInt(x.mobileNumber) == parseInt(object.mobileNumber))
    ) {
      return ShowMessagePopup(
        false,
        "Mobile number is already exist. Please enter new mobile number",
        ""
      )
    } else if (
      membersDetails?.length > 0 &&
      membersDetails.some(
        (x: any) =>
          x.email != "" &&
          x.email?.length > 0 &&
          x.email.trim() != "" &&
          object.email != "" &&
          object.email.length > 0 &&
          object.email.trim() != "" &&
          x.email.toLowerCase() == object.email.toLowerCase()
      )
    ) {
      return ShowMessagePopup(false, "email is already exist. Please enter new email", "")
    }
    let Details: any[] = [...membersDetails]
    Details.push(object)
    setmembersDetails(Details)
    setTempMemorymember({ OTPRequested: false, AadharVerified: false })
    setSelectedMemberDetails({
      memberType: "",
      relationName: "",
      joiningDate: "",
      qualification: "",
      soundMind: "",
      inSolvent: "",
      offense: "",
      appointment: "",
      maskedAadhar: "",
      aadharNumber: "",
      gender: "",
      role: "",
      age: "",
      otpStatus: "",
      otpCode: "",
      otpVerified: "",
      occupation: "",
      doorNo: "",
      street: "",
      country: "India",
      state: "Andhra Pradesh",
      district: "",
      mandal: "",
      villageOrCity: "",
      pinCode: "",
      mobileNumber: "",
      email: "",
      memberName: "",
      relationType: "",
    })
    ShowMessagePopup(true, "New Member Added Successfully", "")
  }
  const ShowAlert = (type: boolean, message: string,redirectOnSuccess:any) => {
    dispatch(PopupAction({ enable: true, type: type, message: message,redirectOnSuccess}))
  }
  const districtmemberChange = (e: any) => {
    setCurrentmemberDistrict(e.target.value)
    setCurrentmemberMandal("")
  }
  const mandalmemberChange = (e: any) => {
    setCurrentmemberMandal(e.target.value)
  }
  const membersDetailsChange = (e: any) => {
    let tempDetails: any = { ...SelectedMemberDetails }
    let AddName = e.target.name
    let AddValue = e.target.value

    if (AddName == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        // SelectedMemberDetails.aadharNumber &&
        e.target.value.length > 0 &&
        e.target.value.length > SelectedMemberDetails?.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value && e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          SelectedMemberDetails?.aadharNumber?.substring(0, startpos) +
          SelectedMemberDetails?.aadharNumber?.substring(
            startpos + 1,
            SelectedMemberDetails?.aadharNumber?.length
          )
      }
      setSelectedMemberDetails({
        ...tempDetails,
        [AddName]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? SelectedMemberDetails?.aadharNumber + newNo : aadharNo,
      })
    } else {
      setSelectedMemberDetails({ ...tempDetails, [AddName]: AddValue })
    }
  }
  const membersDetailsremove = (e: any) => {
    let tempDetails: any = { ...SelectedMemberDetailsremove }
    let AddName = e.target.name
    let AddValue = e.target.value

    if (AddName == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        // SelectedMemberDetails.aadharNumber &&
        e.target.value.length > 0 &&
        e.target.value.length > SelectedMemberDetailsremove?.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value && e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          SelectedMemberDetailsremove?.aadharNumber?.substring(0, startpos) +
          SelectedMemberDetailsremove?.aadharNumber?.substring(
            startpos + 1,
            SelectedMemberDetailsremove?.aadharNumber?.length
          )
      }
      setSelectedMemberDetailsremove({
        ...tempDetails,
        [AddName]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? SelectedMemberDetailsremove?.aadharNumber + newNo : aadharNo,
      })
    } else {
      setSelectedMemberDetailsremove({ ...tempDetails, [AddName]: AddValue })
    }
  }
  const file2Base64 = (file: File): Promise<string> => {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      if (reader && reader != null && file) {
        reader.readAsDataURL(file)
        reader.onload = () => resolve(reader.result?.toString() || "")
        reader.onerror = (error) => reject(error)
      }
      else {
        resolve("")
      }
    })
  }

  // const dispatch = useAppDispatch()
  // const popupState = () => {
  //   let data: any = localStorage.getItem("FASPLoginDetails")
  //   if (!data || data == null || data == "") {
  //     router.push("/")
  //   }
  // }

  // useEffect(() => {
  //   window.addEventListener("popstate", () => {
  //     popupState()
  //   })
  //   return () => {
  //     window.removeEventListener("popstate", () => {
  //       popupState()
  //     })
  //   }
  // }, [])

  const Loading = (value: boolean) => {
    store.dispatch(LoadingAction({ enable: value }))
  }

  const handleFileChange = (e: any) => {
    if (!e.target.files) {
      return
    }
    if (e.target.files[0].size > 1024000) {
      ShowMessagePopup(false, "File size 1MB size. please upload small size file.", "")
      e.target.value = ""
    }
    const file = e.target.files[0];
    console.log(file)
    let fileNamesSplit = file.name.split('.');
    let validFileExtensions = ["pdf"];
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[1])){
        // throw Error("Invalid File");
        ShowMessagePopup(false, "Irrelevant file type. Only image/pdf can be uploaded.");
        e.target.value = "";
    }
    const regex = /^[A-Za-z0-9\s]*$/
    if(fileNamesSplit.length != 2 || !validFileExtensions.includes(fileNamesSplit[0])){
      if(!regex){
      ShowMessagePopup(false, "Please upload proper file name");
      e.target.value = "";
    }
  }
    const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.files[0] })
    setFile(newInput)
  }

  const handleClosePaymentModal = () => {
    setShowVerification(false)
  }

  const tableHeaders = [
    "Type",
    "Aadhaar No ",
    "Name of the Member",
    "Relation Name",
    "Age / Gender",
    "Role/Position",
    "Occupation",
    "Date of Joining",
    "Address",
    "Contact Details",
  ]

  const ageCalculator = (dateOfBirth: any) => {
    const date =
      dateOfBirth.split("-")[1] +
      "/" +
      dateOfBirth.split("-")[0] +
      "/" +
      dateOfBirth.split("-").pop()
    let dob = new Date(date)
    //calculate month difference from current date in time
    let month_diff = Date.now() - dob.getTime()

    //convert the calculated difference in date format
    let age_dt = new Date(month_diff)

    //extract year from date
    let year = age_dt.getUTCFullYear()

    //now calculate the age of the user
    let age = Math.abs(year - 1970)
    const finalAge = `${age}`
    return finalAge
  }
  const applicantDetailsChange = (e: any) => {
    if (e.target.name == "maskedAadhar") {
      let newNo = ""
      let newVal = ""
      let aadharNo = ""
      if (
        e.target.value.length > 0 &&
        e.target.value.length > applicantDetails.aadharNumber.length
      ) {
        newNo = e.target.value[e.target.value.length - 1]
      } else if (e.target.value.length == 0) {
        newNo = "del"
      }
      for (let i = 0; i <= e.target.value.length - 1; i++) {
        if (i < 8) {
          newVal = newVal + "X"
        } else {
          newVal = newVal + e.target.value[i]
        }
      }
      if (newNo == "") {
        let startpos = parseInt(e.target.selectionStart)
        aadharNo =
          applicantDetails.aadharNumber.substring(0, startpos) +
          applicantDetails.aadharNumber.substring(
            startpos + 1,
            applicantDetails.aadharNumber.length
          )
      }
      setApplicantDetails({
        ...applicantDetails,
        [e.target.name]: newVal,
        aadharNumber:
          newNo == "del" ? "" : newNo != "" ? applicantDetails.aadharNumber + newNo : aadharNo,
      })
    } else {
      const newInput = (data: any) => ({ ...data, [e.target.name]: e.target.value })
      setApplicantDetails(newInput)
    }
  }

  const districtChange = (e: any) => {
    setCurrentDistrict(e.target.value)
    setCurrentMandal("")
  }

  const mandalChange = (e: any) => {
    setCurrentMandal(e.target.value)
  }

  const onNumberOnlyChange = (event: any) => {
    const keyCode = event.keyCode || event.which
    const keyValue = String.fromCharCode(keyCode)
    const isValid = new RegExp("[0-9]").test(keyValue)
    if (!isValid) {
      event.preventDefault()
      return
    }
  }
  const checkDB = (e: any) => {
    e.preventDefault()

    let ob: any = {
      societyName: societyDetails.societyName.trim(),
      district: societyDetails.district,
    }

    instance
      .post("societies/check", ob)
      .then((response: any) => {
        if (
          response.data.message == "Society already exists!" &&
          response.data.success == false
        ) {
          ShowAlert(false, response.data.message,"")
        }
        if (
          response.data.message == "Society is available to register" &&
          response.data.success == true
        ) {
          ShowAlert(true, "No society name exist in current district","")
          setIsCheckSoc(true)
        } else {
          ShowAlert(false, "Already society name exist in current district","")
          setIsCheckSoc(false)
        }
      })
      .catch((error) => {
        if (error.message == "Request failed with status code 400") {
          ShowAlert(false, "Society Name is Mandatory","")
        }
      })

      .catch((error) => {
        if (error.message == "Request failed with status code 400") {
          ShowAlert(false, "Society Name & District is Mandatory","")
        }
      })
  }
  const [isCheckFirm, setIsCheckFirm] = useState<boolean>(false)
  const [isCheckNation, setIsCheckNation] = useState<boolean>(false)

  const checkFirmDB = (e: any) => {
    e.preventDefault()
    const errors: any = {}

    let ob: any = {
      societyName: societyDetails.societyNewName.trim(),
      district: existingSocietyDetail.district,
    }
    if (
      !societyDetails.societyNewName ||
      societyDetails.societyNewName.trim().length < 4 ||
      societyDetails.societyNewName.trim().length > 20
    ) {
      errors["societyName"] = "*Society Name should contain 4 - 20 characters."
    } else {
      let obj: any = {
        registrationName: societyDetails.societyNewName.trim(),
      }
      instance
        .post("checkAvailability", obj)
        .then((response: any) => {
          if (response.data.success == false) {
            ShowAlert(false, response.data.message,"")
            setIsCheckNation(false)
          }
          if (response.data.success == true) {
            instance
              .post("societies/check", ob)
              .then((response: any) => {
                if (
                  response.data.message == "Society already exists!" &&
                  response.data.success == false
                ) {
                  ShowAlert(false, response.data.message,"")
                }
                if (
                  response.data.message == "Society is available to register" &&
                  response.data.success == true
                ) {
                  ShowAlert(true, response.data.message,"")
                  setIsCheckFirm(true)
                } else {
                  setIsCheckFirm(false)
                }
              })
              .catch((error) => {
                if (error.message == "Request failed with status code 400") {
                  ShowAlert(false, "Society Name is Mandatory","")
                }
              })
          } else {
            setIsCheckNation(false)
          }
          Loading(false)
        })
        .catch((error) => {
          if (error.message == "Request failed with status code 400") {
            ShowAlert(false, "Society Name & District is Mandatory","")
          }
        })
    }
    setFormErrors({ ...errors })
  }


  const societyDetailsChange = (e: any) => {
    setSocietyDetails({ ...societyDetails, [e.target.name]: e.target.value })
    console.log("society deatils", societyDetails)
  }

  const validateInputs = () => {
    let applicantDet = { ...applicantDetails }
    let society = { ...societyDetails }
    let members = { ...membersDetails }
    const errors: any = {}

    if (TempMemory.AadharVerified != true) {
      return ShowMessagePopup(false, "Plaese verify aadhar number")
    }
    if (checklist &&
      checklist.length > 0 &&
      checklist.some((x: string) => x == "Change in the name of the society")) {
      if (!society.societyNewName) {
        return ShowMessagePopup(false, 'Please Enter Society New Name')
      }
      if (society.majority != "Yes") {
        return ShowMessagePopup(false, 'Please select validate option for majority of quorum members')
      }
      if (society.acceptorapprove != "Yes") {
        return ShowMessagePopup(false, 'Please select validate option for quorum')
      }
      if (!society.newNameDateEffect) {
        return ShowMessagePopup(false, 'Please Enter the new Name Date Effect')
      }
    }
    if (checklist &&
      checklist.length > 0 &&
      checklist.some(
        (x: string) => x == "Change in the aims and objectives of the society")) {
      if (!society.newAim) {
        return ShowMessagePopup(false, 'Please Enter the newAim')
      }
      if (!society.newObjective) {
        return ShowMessagePopup(false, 'Please Enter the new Objective')
      }
      if (society.majority1 != "Yes") {
        return ShowMessagePopup(false, 'Please select validate option for majority of quorum members')
      }
      if (society.acceptorapprove1 != "Yes") {
        return ShowMessagePopup(false, 'Please select validate option for quorum')
      }
    }
    if (checklist &&
      checklist.length > 0 &&
      checklist.some(
        (x: string) => x == "Amendment of Memorandum and Bye-laws")) {
      if (membersDetails?.length < 3) {
        return ShowMessagePopup(false, "Minimum 3 members should me there in the society")
      }
      if (SelectedMemberDetailsremove.reasonForOutgoing == "TERMINATED" && SelectedMemberDetailsremove.termination != "Yes") {
        return ShowMessagePopup(false, "Please select validate option for termination")
      }
    }

    setErrors({ ...errors })
    console.log("errors obj", errors)
    return errors
  }

  let message
  if (selectedOption === "With in the district") {
    message = (
      <div className=" page-title mb-3">
        <div className="formSectionTitle ms-2">
          <h3>Enter New Address</h3>
        </div>
        <Row>
          <Col lg={3} md={4} xs={12} >
            <TableText label="Door No" required={true} LeftSpace={false} />
            <TableInputText
              disabled={false}
              type="text"
              placeholder="Enter Door No"
              required={true}
              name={"doorNo"}
              value={societyDetails.doorNo}
              onChange={societyDetailsChange}
            />
          </Col>

          <Col lg={3} md={4} xs={12} >
            <TableText label="Street" required={true} LeftSpace={false} />
            <TableInputText
              disabled={false}
              type="text"
              placeholder="Enter Street"
              required={true}
              name={"street"}
              value={societyDetails.street}
              onChange={societyDetailsChange}
            />
          </Col>

          <Col lg={3} md={4} xs={12} >
            <TableText label="District" required={true} LeftSpace={false} />
            <select style={{ textTransform: 'uppercase' }}
              className="form-control"
              name="district"
              onChange={() => { }}
              value={societyDetails.district}
              required={true}
              disabled={true}
            >
              <option>Select</option>
              {districtList.map((item: any, i: any) => {
                return (
                  <option key={i + 1} value={item.name}>
                    {item.name}
                  </option>
                )
              })}
            </select>
          </Col>

          <Col lg={3} md={4} xs={12} >
            <TableText label="Mandal" required={true} LeftSpace={false} />
            <select style={{ textTransform: 'uppercase' }}
              className="form-control"
              name="mandal"
              onChange={(event) => {
                societyDetailsChange(event)
              }}
              value={societyDetails.mandal}
              required={true}
              defaultValue={"Select"}
            >
              <option>Select</option>
              <DynamicMandals currentDistrict={societyDetails.district}></DynamicMandals>
            </select>
          </Col>

          <Col lg={3} md={4} xs={12} className="mb-3">
            <TableText label="Village" required={true} LeftSpace={false} />
            <select style={{ textTransform: 'uppercase' }}
              className="form-control"
              name="villageOrCity"
              onChange={societyDetailsChange}
              value={societyDetails.villageOrCity}
              required={true}
              defaultValue={"Select"}
            >
              <option>Select</option>
              <DynamicVillages
                currentDistrict={societyDetails.district}
                currentMandal={societyDetails.mandal}
              ></DynamicVillages>
            </select>
          </Col>

          <Col lg={3} md={4} xs={12} className="mb-3">
            <TableText label="PIN Code" required={true} LeftSpace={false} />
            <Form.Control
              disabled={false}
              type="text"
              maxLength={6}
              placeholder="Enter PIN Code"
              required={true}
              name={"pinCode"}
              value={societyDetails.pinCode}
              onChange={societyDetailsChange}
              onKeyPress={onNumberOnlyChange}
            />
          </Col>
        </Row>
      </div>
    )
  } else if (selectedOption === "Outside the district") {
    message = (
      <div className="panelDesc formsec">
        <Row>
          <Col lg={12} md={12} xs={12}>
            <div className="regofAppBg mb-3 ">
              <div className="formsec">
                <Row className="">
                  <Col lg={3} md={3} xs={12} className="mb-3 ">
                    <Form.Group>
                      <div className="d-flex justify-content-between ">
                        <Form.Label>Select Distrcit</Form.Label>
                        <button className="availability" onClick={checkDB}>Check Availability</button>
                      </div>
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="district"
                        onChange={societyDetailsChange}
                        value={societyDetails.district}
                        required={true}
                        disabled={false}
                      >
                        <option>Select</option>
                        {districtList.map((item: any, i: any) => {
                          return (
                            <option key={i + 1} value={item.name}>
                              {item.name}
                            </option>
                          )
                        })}
                      </select>

                    </Form.Group>
                  </Col>
                </Row>
                {isCheckSoc && <div className=" page-title mb-3">
                  <div className="formSectionTitle">
                    <h3>Enter New Address</h3>
                  </div>
                  <Row className="mt-2">
                    <Col lg={3} md={3} xs={12} >
                      <TableText label="Door No" required={true} LeftSpace={false} />
                      <TableInputText
                        type="text"
                        placeholder="Enter Door No"
                        name="doorNo"
                        required
                        onChange={societyDetailsChange}
                        value={societyDetails.doorNo}

                      />
                      {/* {doorErrorMessage && <p style={{ color: 'red' }}>{doorErrorMessage}</p>} */}
                    </Col>

                    <Col lg={3} md={3} xs={12} >
                      <TableText label="Street" LeftSpace={false} required={false} />
                      <TableInputText
                        type="text"
                        placeholder="Enter Street"
                        name="street"
                        required

                        value={societyDetails.street}
                        onChange={societyDetailsChange}
                      />
                    </Col>

                    <Col lg={3} md={4} xs={12} >
                      <TableText label="District" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="district"
                        onChange={() => { }}
                        value={societyDetails.district}
                        required={true}
                        disabled={true}
                      >
                        <option>Select</option>
                        {districtList.map((item: any, i: any) => {
                          return (
                            <option key={i + 1} value={item.name}>
                              {item.name}
                            </option>
                          )
                        })}
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} >
                      <TableText label="Mandal" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="mandal"
                        onChange={(event) => {
                          societyDetailsChange(event)
                        }}
                        value={societyDetails.mandal}
                        required={true}
                        defaultValue={"Select"}
                      >
                        <option>Select</option>
                        <DynamicMandals currentDistrict={societyDetails.district}></DynamicMandals>
                      </select>
                    </Col>

                    <Col lg={3} md={4} xs={12} className="mb-3">
                      <TableText label="Village" required={true} LeftSpace={false} />
                      <select style={{ textTransform: 'uppercase' }}
                        className="form-control"
                        name="villageOrCity"
                        onChange={societyDetailsChange}
                        value={societyDetails.villageOrCity}
                        required={true}
                        defaultValue={"Select"}
                      >
                        <option>Select</option>
                        <DynamicVillages
                          currentDistrict={societyDetails.district}
                          currentMandal={societyDetails.mandal}
                        ></DynamicVillages>
                      </select>
                    </Col>

                    <Col lg={3} md={3} xs={12} className="mb-3">
                      <TableText label="Pin Code" required={true} LeftSpace={false} />
                      <TableInputText
                        type="text"
                        placeholder="Enter Pin Code"
                        name="pinCode"
                        required
                        onChange={societyDetailsChange}
                        // value={pin}
                        maxLength={6}
                        value={societyDetails.pinCode}
                      />
                      {/* {pinErrorMessage && <p style={{ color: 'red' }}>{pinErrorMessage}</p>} */}
                    </Col>
                  </Row>
                </div>}
              </div>
            </div>
          </Col>
        </Row>
      </div>
    )
  }

  async function getFileFromUrl(url: any, name: any, defaultType = "pdf") {
    const response = await instance.get(url, { responseType: "arraybuffer" })
    return new File([response.data], name, {
      type: defaultType,
    })
  }

  useEffect(() => {
    Loading(true)
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setToken(data.token)
    setLoggedInAadhar(data.aadharNumber)
    instance
      .get("/getDistricts")
      .then((response) => {
        setDistricts(response.data)
        getSocietyDetails(data.applicationId, data.token)
          .then((response) => {
            if (response?.success) {
              setExistingSocietyDetail(response.data.daSociety)
              if (checklist?.length > 0 && !checklist.some((x: string) => x == "Change of place of Registered Society Inside/Outside the District")) {
                setSocietyDetails({
                  joiningofnewmember: "",
                  membersagreedwithbyelaws: "",
                  joiningofnewmemberapprovedbyQuorum: "",

                  majority: "",
                  acceptorapprove: "",
                  majority1: "",
                  acceptorapprove1: "",
                  societyName: response.data.daSociety.societyName
                    ? response.data.daSociety.societyName
                    : "",
                  category: response.data.daSociety.category
                    ? response.data.daSociety.category
                    : "",

                  societyNewName: "",
                  newObjective: "",
                  newAim: "",

                  aim: response.data.daSociety.aim ? response.data.daSociety.aim : "",
                  objective: response.data.daSociety.objective
                    ? response.data.daSociety.objective
                    : "",
                  newNameDateEffect: response.data.daSociety.newNameDateEffect
                    ? response.data.daSociety.newNameDateEffect
                    : "",
                  street: response.data.daSociety.street ? response.data.daSociety.street : "",
                  annualmeeting: response.data.daSociety.annualmeeting
                    ? response.data.daSociety.annualmeeting
                    : "",
                  venue: response.data.daSociety.venue ? response.data.daSociety.venue : "",
                  memberattended: response.data.daSociety.memberattended
                    ? response.data.daSociety.memberattended
                    : "",
                  governingbody: response.data.daSociety.governingbody
                    ? response.data.daSociety.governingbody
                    : "",
                  newDate: response.data.daSociety.newDate ? response.data.daSociety.newDate : "",
                  memoradumByelaws: response.data.daSociety.memoradumByelaws
                    ? response.data.daSociety.memoradumByelaws
                    : "",
                  doorNo: response.data.daSociety.doorNo ? response.data.daSociety.doorNo : "",
                  district: response.data.daSociety.district ? response.data.daSociety.district : "",
                  mandal: response.data.daSociety.mandal ? response.data.daSociety.mandal : "",
                  villageOrCity: response.data.daSociety.villageOrCity
                    ? response.data.daSociety.villageOrCity
                    : "",
                  pinCode: response.data.daSociety.pinCode ? response.data.daSociety.pinCode : "",
                })
              }
              else {
                setSocietyDetails({
                  ...societyDetails,
                  district: response.data.daSociety.district,
                  societyName: response.data.daSociety.societyName
                })
              }
              if (response.data.daSociety.byeLaws) {
                let data: any = [];
                let quorumCount = 0
                response.data.daSociety.memberDetails.forEach((x: any) => {
                  if (x.status == "Active") {
                    quorumCount++
                  }
                })
                setbyelawDetails({
                  ...byelawDetails,
                  quorumSize: Math.round((quorumCount / 2) + 1),
                })

                for (let i = 0; i < Math.round((quorumCount / 2) + 1); i++) {

                  data.push({
                    aadharNumber: "",
                    maskedAadhar: "",
                    otpStatus: "",
                    otpCode: "",
                    otpVerified: "",

                  },)
                }
                setAadharValidate(data)
              }
              if (response.data.daSociety.memberDetails?.length) {
                setmembersDetails([...response.data.daSociety.memberDetails])
              }
              if (response.data.daSociety.memberDetails?.length) {
                response.data.daSociety.memberDetails.forEach(
                  (a: any) =>
                    (a.maskedAadhar = "XXXXXXXX" + a.aadharNumber.toString().substring(8, 12))
                )
                setmembersDetails([...response.data.daSociety.memberDetails])
              }
              if (response.data.daSociety.applicantDetails) {
                if (applicantDetails.district != "") {
                  DynamicMandals({ currentDistrict })
                }
                if (applicantDetails.mandal != "") {
                  DynamicVillages({
                    currentDistrict,
                    currentMandal,
                  })
                }
                setrequestType({
                  isAimChange: response.data.daSociety.isAimChange
                    ? response.data.daSociety.isAimChange
                    : "",
                  isMemorandumChange: response.data.daSociety.isMemorandumChange
                    ? response.data.daSociety.isMemorandumChange
                    : "",
                  isNameChange: response.data.daSociety.isNameChange
                    ? response.data.daSociety.isNameChange
                    : "",
                  placeChange: response.data.daSociety.placeChange
                    ? response.data.daSociety.placeChange
                    : "",
                })
              }
            }
          })
          .catch(() => {
            Loading(false)
          })
        Loading(false)
      })
      .catch(() => {
        Loading(false)
      })
  }, [])

  const handleSubmit = async (e: any) => {
    e.preventDefault()
    if (validateInputs()) {
      const data = {
        applicantDetails: applicantDetails,

        societyDetails: societyDetails,
        membersDetails: [...membersDetails.filter((x: any) => x.memberName.trim())],
        ...requestType
      }
      const newData = new FormData()
      newData.append("id", existingSocietyDetail._id)
      newData.append("applicantDetails[aadharNumber]", btoa(data.applicantDetails.aadharNumber))
      newData.append("applicantDetails[applicationNumber]", existingSocietyDetail?.applicationNumber)
      newData.append("applicantDetails[name]", existingSocietyDetail?.applicantDetails.name)
      newData.append("applicantDetails[doorNo]", existingSocietyDetail?.applicantDetails.doorNo)
      newData.append("applicantDetails[street]", existingSocietyDetail?.applicantDetails.street)
      newData.append("applicantDetails[age]", existingSocietyDetail?.applicantDetails.age)
      newData.append("applicantDetails[gender]", existingSocietyDetail?.applicantDetails.gender)
      newData.append("applicantDetails[country]", "India")
      newData.append("applicantDetails[state]", "Andhra Pradesh")
      newData.append("applicantDetails[district]", existingSocietyDetail?.applicantDetails.district)
      newData.append("applicantDetails[mandal]", existingSocietyDetail?.applicantDetails.mandal)
      newData.append("applicantDetails[villageOrCity]", existingSocietyDetail?.applicantDetails.villageOrCity)
      newData.append("applicantDetails[pinCode]", existingSocietyDetail?.applicantDetails.pinCode)
      newData.append("applicantDetails[mobileNumber]", existingSocietyDetail?.applicantDetails.mobileNumber)
      newData.append("applicantDetails[relationType]", existingSocietyDetail?.applicantDetails.relationType)
      newData.append("applicantDetails[relationName]", existingSocietyDetail?.applicantDetails.relationName)

      if (checklist &&
        checklist.length > 0 &&
        checklist.some((x: string) => x == "Amendment of Memorandum and Bye-laws")) {
        // for (let j = 0; j < data.membersDetails.length; j++) {

        //   if (data.membersDetails[j].joiningDate) {
        //     newData.append("memberDetails[" + j + "][email]", data.membersDetails[j].email)
        //     newData.append(
        //       "memberDetails[" + j + "][mobileNumber]",
        //       data.membersDetails[j].mobileNumber
        //     )
        //     newData.append(
        //       "memberDetails[" + j + "][qualification]",
        //       data.membersDetails[j].qualification
        //     )
        //     newData.append(
        //       "memberDetails[" + j + "][joiningDate]",
        //       data.membersDetails[j].joiningDate
        //     )
        //     newData.append("memberDetails[" + j + "][memberType]", data.membersDetails[j].memberType)

        //     newData.append(
        //       "memberDetails[" + j + "][aadharNumber]",
        //       data.membersDetails[j].aadharNumber
        //     )
        //     newData.append("memberDetails[" + j + "][memberName]", data.membersDetails[j].memberName)
        //     newData.append(
        //       "memberDetails[" + j + "][relationName]",
        //       data.membersDetails[j].relationName
        //     )
        //     newData.append(
        //       "memberDetails[" + j + "][relationType]",
        //       data.membersDetails[j].relationType
        //     )
        //     newData.append("memberDetails[" + j + "][occupation]", data.membersDetails[j].occupation)
        //     newData.append("memberDetails[" + j + "][age]", data.membersDetails[j].age)
        //     newData.append("memberDetails[" + j + "][gender]", data.membersDetails[j].gender)
        //     newData.append("memberDetails[" + j + "][role]", data.membersDetails[j].role)
        //     newData.append("memberDetails[" + j + "][doorNo]", data.membersDetails[j].doorNo)
        //     newData.append("memberDetails[" + j + "][street]", data.membersDetails[j].street)
        //     newData.append("memberDetails[" + j + "][country]", "India")
        //     newData.append("memberDetails[" + j + "][state]", "Andhra Pradesh")
        //     newData.append("memberDetails[" + j + "][district]", data.membersDetails[j].district)
        //     newData.append("memberDetails[" + j + "][mandal]", data.membersDetails[j].mandal)
        //     newData.append("membersDetails[" + j + "][status]", "Active")
        //     newData.append(
        //       "memberDetails[" + j + "][villageOrCity]",
        //       data.membersDetails[j].villageOrCity
        //     )
        //     newData.append("memberDetails[" + j + "][pinCode]", data.membersDetails[j].pinCode)
        //   }
        // } 
        let memberdata = [...membersDetails, ...outgoingMembersDetails]
        for (let j = 0; j < memberdata.length; j++) {
          newData.append("memberDetails[" + j + "][email]", memberdata[j].email)
          newData.append("memberDetails[" + j + "][mobileNumber]", memberdata[j].mobileNumber)
          newData.append("memberDetails[" + j + "][qualification]", memberdata[j].qualification)
          newData.append("memberDetails[" + j + "][joiningDate]", memberdata[j].joiningDate)
          newData.append("memberDetails[" + j + "][memberType]", memberdata[j].memberType)
          newData.append("memberDetails[" + j + "][aadharNumber]",btoa(memberdata[j].aadharNumber))
          newData.append("memberDetails[" + j + "][memberName]", memberdata[j].memberName)
          newData.append("memberDetails[" + j + "][relationName]", memberdata[j].relationName)
          newData.append("memberDetails[" + j + "][relationType]", memberdata[j].relationType)
          newData.append("memberDetails[" + j + "][occupation]", memberdata[j].occupation)
          newData.append("memberDetails[" + j + "][age]", memberdata[j].age)
          newData.append("memberDetails[" + j + "][gender]", memberdata[j].gender)
          newData.append("memberDetails[" + j + "][role]", memberdata[j].role)
          newData.append("memberDetails[" + j + "][doorNo]", memberdata[j].doorNo)
          newData.append("memberDetails[" + j + "][street]", memberdata[j].street)
          newData.append("memberDetails[" + j + "][country]", "India")
          newData.append("memberDetails[" + j + "][state]", "Andhra Pradesh")
          newData.append("memberDetails[" + j + "][district]", memberdata[j].district)
          newData.append("memberDetails[" + j + "][mandal]", memberdata[j].mandal)
          newData.append("memberDetails[" + j + "][villageOrCity]", memberdata[j].villageOrCity)
          newData.append("memberDetails[" + j + "][pinCode]", memberdata[j].pinCode)
          if (memberdata[j].reasonForOutgoing != "" && memberdata[j].reasonForOutgoing != undefined) {
            newData.append("memberDetails[" + j + "][reasonForOutgoing]", memberdata[j].reasonForOutgoing)
            if (memberdata[j].reasonForOutgoing == "TERMINATED") {
              newData.append("memberDetails[" + j + "][noticeTime]", memberdata[j].noticeTime)

              newData.append("memberDetails[" + j + "][termination]", memberdata[j].termination)
              newData.append("memberDetails[" + j + "][firstNoticeDate]", memberdata[j].firstNoticeDate)
              newData.append("memberDetails[" + j + "][secondNoticeDate]", memberdata[j].secondNoticeDate)
              newData.append("memberDetails[" + j + "][thirdNoticeDate]", memberdata[j].thirdNoticeDate)
            }
            newData.append("memberDetails[" + j + "][status]", "InActive")
          } else {
            newData.append("memberDetails[" + j + "][status]", "Active")
          }
        }
      }
      if (data.societyDetails?.societyNewName != "") {
        newData.append("societyName", data.societyDetails.societyNewName)
        newData.append("newNameDateEffect", data.societyDetails.newNameDateEffect)
      }
      if (file.byeLaws) {
        newData.append("byeLaws", file.byeLaws)
      }
      Object.keys(file).forEach(async (value: any, key: any) => {
        newData.append(key, value)
      })
      if (file.moa) {
        newData.append("moa", file.moa)
      }
      if (file.declaration) {
        newData.append("declaration", file.declaration)
      }
      if (file.supportingDoc) {
        newData.append("supportingDoc", file.supportingDoc)
      }
      if (file.selfSignedDeclaration) {
        newData.append("selfSignedDeclaration", file.selfSignedDeclaration)
      }
      if (data.societyDetails?.doorNo != "") {
        newData.append("doorNo", data.societyDetails.doorNo)
        newData.append("street", data.societyDetails.street)
        newData.append("district", data.societyDetails.district)
        newData.append("mandal", data.societyDetails.mandal)
        newData.append("villageOrCity", data.societyDetails.villageOrCity)
        newData.append("state", "Andhra Pradesh")
        newData.append("country", "India")
      }
      if (data.societyDetails?.newAim != "") {
        newData.append("aim", data.societyDetails.newAim)
        newData.append("objective", data.societyDetails.newObjective)

      }
      newData.append("country", "India")
      newData.append("state", "Andhra Pradesh")
      if (checklist &&
        checklist.length > 0 &&
        checklist.some((x: string) => x == "Change in the name of the society")) {
        newData.append("isNameChange", "true")
      }
      if (checklist &&
        checklist.length > 0 &&
        checklist.some((x: string) => x == "Change in the aims and objectives of the society")) {
        newData.append("isAimChange", "true")
      }
      if (checklist &&
        checklist.length > 0 &&
        checklist.some((x: string) => x == "Amendment of Memorandum and Bye-laws")) {
        newData.append("isMemorandumChange", "true")
      }
      if (
        checklist &&
        checklist.length > 0 &&
        checklist.some(
          (x: string) =>
            x == "Change of place of Registered Society Inside/Outside the District"
        )) {
        newData.append("isAddressChange", "true")
      }
      Object.keys(file).forEach(async (value: any, key: any) => {
        newData.append(key, value)
      })
      let keys = Object.keys(file)
      let values: any = Object.values(file)
      let object: any = {}
      newData.forEach((value, key) => (object[key] = value))
      if (file.moa) {
        object.moa = await file2Base64(file?.moa)
      }
      if (file.byeLaws) {
        object.byeLaws = await file2Base64(file?.byeLaws)
      }
      if (file.declaration) {
        object.declaration = await file2Base64(file?.declaration)
      }
      if (file.supportingDoc) {
        object.supportingDoc = await file2Base64(file?.supportingDoc)
      }
      if (file.selfSignedDeclaration) {
        object.selfSignedDeclaration = await file2Base64(file?.selfSignedDeclaration)
      }
      let i = 0
      for await (let item of values) {
        object[keys[i]] = await file2Base64(item)
        i++
      }
      localStorage.setItem("AmendmentData", JSON.stringify(object))

      //  newData.forEach((value, key) => (object[key] = value))
      // let keys = Object.keys(file)
      // let values:any = Object.values(file)
      // let i = 0
      // for await (let item of values) {
      //   object[keys[i]] = await file2Base64(item)
      //   i++
      // }}

      // localStorage.setItem("AmendmentData", JSON.stringify(objectnew))

      let code = 0
      const dis = districtList?.find((x: any) => x.name == existingSocietyDetail.district)
      if (dis) {
        code = dis.code
      }
      let count = checklist.length
      const paymentsData = {
        type: "sra",
        source: "Society",
        deptId: existingSocietyDetail.applicationNumber,
        rmName: existingSocietyDetail.applicantDetails.name,
        rmId: Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000,
        mobile: existingSocietyDetail.applicantDetails.mobileNumber,
        email: existingSocietyDetail.applicantDetails.email,
        drNumber: code,
        rf: count > 1 ? 300 * count : 300,
        uc: 0,
        oc: 0,
        returnURL: process.env.BACKEND_URL + "/societies/redirectPayment",
      }
      let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL + "/igrsPayment?paymentData="
      // let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
      const encodedData = CryptoJS.AES.encrypt(
        JSON.stringify(paymentsData),
        'igrsSecretPhrase'
      ).toString()
      let paymentLink = document.createElement("a")
      paymentLink.href = paymentRedirectUrl +encodeURIComponent(encodedData)
      //paymentLink.target = "_blank";
      paymentLink.click()
      setIsPayNowClicked(false)
      setTimeout(function () {
        paymentLink.remove()
      }, 1000)
    }
    const ShowAlert = (type: any, message: any) => {
      dispatch(PopupAction({ enable: true, type: type, message: message ,}))
    }
  }
  return (
    <div>
      <div className="societyRegSec mx-3">
        <div className="formsec">
          <Row>
            <Col lg={12} md={12} xs={12}>
              <div className="d-flex justify-content-between align-items-center page-title mb-1 mx-3">
                <div className="pageTitleLeft">
                  <h1>Change in Amendments</h1>
                </div>
                <div className="pageTitleRight">
                  <div className="page-header-btns">
                    <a className="btn btn-secondary new-user" onClick={() => router.back()}>
                      Go Back
                    </a>
                  </div>
                </div>
              </div>
            </Col>
          </Row>

          <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
            <Container>
              <div className="regofAppBg">
                <div className="formSectionTitle">
                  <h3>Applicant Details</h3>
                </div>
                <Row>
                  <Col lg={3} md={3} xs={12} >
                    {!TempMemory.OTPRequested ? (
                      <Form.Group>
                        <TableText
                          label="Enter Aadhaar Number"
                          required={true}
                          LeftSpace={false}
                        />
                        <div className="formGroup">
                          <select style={{ textTransform: 'uppercase' }}
                            className="form-control"
                            name="aadharNumber"
                            onChange={(e: any) => {
                              if (!TempMemory.AadharVerified) {
                                applicantDetailsChange(e)
                              }
                            }}
                            disabled={TempMemory.AadharVerified}
                            required={true}
                            value={applicantDetails.aadharNumber}
                          >
                            <option>Select</option>
                            {membersDetails.map((item: any, i: any) => {
                              return (
                                <>{
                                  item.status != "InActive" ?
                                    <option key={i + 1} value={item.aadharNumber}>
                                      {item.aadharNumber}
                                    </option> : null}</>
                              )
                            })}
                          </select>
                          {!TempMemory.AadharVerified ? (
                            <div
                              style={{
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                borderRadius: "2px",
                              }}
                              onClick={() => ReqOTP(applicantDetails)}
                              className="verify btn btn-primary"
                            >
                              Get OTP
                            </div>
                          ) : null}
                        </div>
                      </Form.Group>
                    ) : (
                      <Form.Group>
                        <TableText label="Enter OTP" required={true} LeftSpace={false} />
                        <div className="formGroup">
                          <TableInputText
                            disabled={false}
                            type="number"
                            placeholder="Enter OTP Received"
                            maxLength={6}
                            required={true}
                            name={"otpCode"}
                            value={applicantDetails.otpCode}
                            onChange={applicantDetailsChange}
                          />
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                              borderRadius: "2px",
                            }}
                            onClick={() => {
                              ReqDetails(applicantDetails)
                            }}
                            className="verify btn btn-primary"
                          >
                            Verify
                          </div>
                          <div style={{ display: "flex", justifyContent: "flex-end" }}>
                            <div
                              style={{
                                cursor: "pointer",
                                marginRight: "20px",
                                color: "blue",
                                fontSize: "10px",
                              }}
                              onClick={() => {
                                setTempMemory({ ...TempMemory, OTPRequested: false })
                              }}
                            >
                              clear
                            </div>
                          </div>
                        </div>
                      </Form.Group>
                    )}
                  </Col>
                </Row>
              </div>
              <div className="regofAppBg my-1">
                <div className="formSectionTitle">
                  <h3>Society Details</h3>
                </div>
                <Row>
                  <Col lg={3} md={4} xs={12} className="mb-1">
                    <TableText label="Society Name" required={true} LeftSpace={false} />
                    <TableInputText
                      disabled={true}
                      type="text"
                      placeholder="Enter Society Name"
                      required={true}
                      name="societyName"
                      value={existingSocietyDetail?.societyName}
                      onChange={() => { }}
                    />
                  </Col>
                  <Col lg={3} md={12} sm={12} className="mb-1">
                    <TableText label={"Society Type "} required={false} LeftSpace={false} />

                    <TableInputText
                      type="text"
                      required={true}
                      placeholder="select society type"
                      name="category"
                      onChange={() => { }}
                      disabled
                      value={existingSocietyDetail.category}
                    />

                    {/* {errors.category && <span style={{ color: "red" }} className={styles.columnText}>{errors.category}</span>} */}
                  </Col>
                </Row>
                <div className="regFormBorder"></div>

                <div className="formSectionTitle">
                  <h3>
                    Request Type <span style={{ color: "red" }}>*</span>
                  </h3>
                </div>
                <Row>
                  {checklist &&
                    checklist.length > 0 &&
                    checklist.some(
                      (x: string) => x == "Change in the aims and objectives of the society"
                    ) ? (
                    <Col lg={4} md={12} sm={12}>
                      <div className="firmDuration">
                        <Form.Check
                          inline
                          label="Change in the Aims and Objectives of the Society"
                          value={requestType.isAimChange}
                          name="isAimChange"
                          type="checkbox"
                          className="fom-checkbox"
                          checked={true}
                          disabled={true}
                        // checked={}
                        />
                        {/* {errors.isAimChange && <span style={{ color: "red" }} className={styles.columnText}>{errors.isAimChange}</span>} */}
                      </div>{" "}
                    </Col>
                  ) : null}
                  {checklist &&
                    checklist.length > 0 &&
                    checklist.some((x: string) => x == "Change in the name of the society") ? (
                    <Col lg={4} md={12} sm={12}>
                      <div className="firmDuration">
                        <Form.Check
                          inline
                          label="Change in the name of the society"
                          value={requestType.isNameChange}
                          name="isNameChange"
                          type="checkbox"
                          className="fom-checkbox"
                          disabled={true}
                          checked={true}
                        />

                      </div>{" "}
                    </Col>
                  ) : null}
                  {checklist &&
                    checklist.length > 0 &&
                    checklist.some((x: string) => x == "Amendment of Memorandum and Bye-laws") ? (
                    <Col lg={4} md={4} xs={12} >
                      <div className="firmDuration">
                        <Form.Check
                          inline
                          label="Changes in the memorandum and Bye-Laws"
                          value={requestType.isMemorandumChange}
                          name="isMemorandumChange"
                          type="checkbox"
                          className="fom-checkbox"
                          onChange={undefined}
                          checked={true}
                          disabled={true}
                        />
                      </div>{" "}
                    </Col>
                  ) : null}
                  {checklist &&
                    checklist.length > 0 &&
                    checklist.some(
                      (x: string) =>
                        x == "Change of place of Registered Society Inside/Outside the District"
                    ) ? (
                    <Col lg={5} md={5} xs={12} >
                      <div className="firmDuration">
                        <Form.Check
                          inline
                          label="Change in the place of the society (inside/outside the district)"
                          value={requestType.isAddressChange}
                          name="isAddressChange"
                          type="checkbox"
                          className="fom-checkbox"
                          checked={true}
                          disabled={true}
                        />
                      </div>
                    </Col>
                  ) : null}
                </Row>
                {checklist &&
                  checklist.length > 0 &&
                  checklist.some(
                    (x: string) => x == "Change in the aims and objectives of the society"
                  ) ? (
                  <>
                    <div className="uploadFirmList my-1">
                      <h3>Society Aim and Objective Change(Section 21)</h3>
                    </div>

                    <Row className=" my-1">
                      <Col lg={6} md={12} sm={12}>
                        <TableText label={"New Aim"} required={true} LeftSpace={false} />
                        <textarea
                          className="form-control textarea"
                          maxLength={10000}
                          placeholder="Enter New Aim  "
                          required={true}
                          name="newAim"
                          value={societyDetails.newAim}
                          onChange={societyDetailsChange}
                        ></textarea>
                        {/* {errors.aim && <span style={{ color: "red" }} className={styles.columnText}>{errors.aim}</span>} */}
                      </Col>
                      <Col lg={6} md={12} sm={12}>
                        <TableText label={"New Objective"} required={true} LeftSpace={false} />
                        <textarea
                          className="form-control textarea"
                          placeholder="Enter New Objective"
                          required={true}
                          name="newObjective"
                          maxLength={10000}
                          value={societyDetails.newObjective}
                          onChange={societyDetailsChange}
                        ></textarea>
                        {/* {errors.objective && <span style={{ color: "red" }} className={styles.columnText}>{errors.objective}</span>} */}
                      </Col>
                    </Row>
                    <Row className="my-1">
                      <Col lg={6} md={12} sm={12}>
                        <TableText label={"Old Aim "} required={true} LeftSpace={false} />
                        <TableInputText
                          type="text"
                          placeholder=" Old Aim "
                          required={true}
                          disabled={true}
                          name="aim"
                          value={existingSocietyDetail?.aim}
                          onChange={() => { }}
                        />
                      </Col>

                      <Col lg={6} md={12} sm={12}>
                        <TableText label={"Old Objective"} required={true} LeftSpace={false} />
                        <TableInputText
                          type="text"
                          placeholder=" Old Objective "
                          required={true}
                          disabled={true}
                          name="objective"
                          value={existingSocietyDetail?.objective}
                          onChange={() => { }}
                        />
                      </Col>
                    </Row>
                  </>
                ) : null}
                {checklist &&
                  checklist.length > 0 &&
                  checklist.some(
                    (x: string) => x == "Change in the aims and objectives of the society"
                  ) && !(checklist.some((x: string) => x == "Change in the name of the society")) ? (
                  <>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new aim and objective has been accepted by the majority of members in the
                              society?
                            </p>
                          </label>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="majority1"
                            onChange={societyDetailsChange}
                            type="radio"
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority1 === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="majority1"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority1 === "No"}
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new aim and objective has been accepted and approved by the Quorum?
                            </p>
                          </label>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="acceptorapprove1"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove1 === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="acceptorapprove1"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove1 === "No"}
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col lg={3} md={3} xs={12} >
                        <TableText label="Declaration" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            required={true}
                            name="declaration"
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                      <Col lg={3} md={3} xs={12} >
                        <TableText label="MOA" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="moa"
                            ref={inputRef}
                            required={true}
                            // value={upload}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                    </Row>
                  </>
                ) : null}

                {checklist &&
                  checklist.length > 0 &&
                  checklist.some((x: string) => x == "Change in the name of the society") ? (
                  <>
                    <div className="uploadFirmList my-1">
                      <h3>Society Name Change(Section 6(3))</h3>
                    </div>
                    <Row>

                      <Col lg={3} md={3} xs={12} className="my-2">
                        <Form.Group>
                          <TableText
                            label="New Society Name"
                            required={true}
                            LeftSpace={false}

                          />
                          <div className="formGroup">
                            <input
                              className="form-control"
                              type="text"
                              maxLength={50}
                              required={true}
                              placeholder="Enter Society Name"
                              name="societyNewName"
                              onChange={societyDetailsChange}
                              value={societyDetails.societyNewName}
                            />

                            <div
                              onClick={checkFirmDB}
                              className="Check Society Availability verify btn btn-primary"
                            >
                              Check
                            </div>
                          </div>
                        </Form.Group>
                      </Col>
                      <Col lg={3} md={12} sm={12} className="my-2">
                        <TableText
                          label={"New Name Date of Effect "}
                          required={true}
                          LeftSpace={false}
                        />
                        <Form.Control
                          type="date"
                          placeholder="Enter Name Date of Effect"
                          name="newNameDateEffect"
                          onChange={societyDetailsChange}
                          value={societyDetails.newNameDateEffect}
                          className="durationTo"
                        />
                        {errors.newNameDateEffect && (
                          <span style={{ color: "red" }} className={styles.columnText}>
                            {errors.newNameDateEffect}
                          </span>
                        )}
                      </Col>
                    </Row>
                  </>
                ) : null}
                {checklist &&
                  checklist.length > 0 &&
                  checklist.some((x: string) => x == "Change in the name of the society") && !(checklist.some(
                    (x: string) => x == "Change in the aims and objectives of the society")
                  ) ? (
                  <>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new name has been accepted by the majority of members in the
                              society?
                            </p>
                          </label>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="majority"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="majority"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority === "No"}
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new name has been accepted and approved by the Quorum?
                            </p>
                          </label>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="acceptorapprove"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="acceptorapprove"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove === "No"}
                          />
                        </div>
                      </Col>
                    </Row>

                    <Row>
                      <Col lg={3} md={3} xs={12} >
                        <TableText label="Declaration" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="declaration"
                            required={true}
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>

                      <Col lg={3} md={3} xs={12} >
                        <TableText label="Supporting Document" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            required={true}
                            type="file"
                            name="supportingDoc"
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                    </Row>
                  </>
                ) : null}
                {checklist &&
                  checklist.length > 0 &&
                  checklist.some((x: string) => x == "Change in the name of the society") && checklist.some(
                    (x: string) => x == "Change in the aims and objectives of the society"
                  ) ? (
                  <>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new name has been accepted by the majority of members in the
                              society?
                            </p>
                          </label>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="majority"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="majority"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority === "No"}
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new name has been accepted and approved by the Quorum?
                            </p>
                          </label>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="acceptorapprove"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="acceptorapprove"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove === "No"}
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new aim and objective has been accepted by the majority of members in the
                              society?
                            </p>
                          </label>

                          <Form.Check

                            inline
                            label="Yes"
                            value="Yes"
                            name="majority1"
                            onChange={societyDetailsChange}
                            type="radio"
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority1 === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="majority1"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.majority1 === "No"}
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row className="mb-1">
                      <Col lg={12} md={12} xs={12} >
                        <div className="firmDuration">
                          <label>
                            <p className="fom-checkbox fw-bold small text-sm me-2">
                              Whether the new aim and objective has been accepted and approved by the Quorum?
                            </p>
                          </label>
                          <Form.Check
                            inline
                            label="Yes"
                            value="Yes"
                            name="acceptorapprove1"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove1 === "Yes"}
                          />
                          <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="acceptorapprove1"
                            type="radio"
                            onChange={societyDetailsChange}
                            className="fom-checkbox fw-bold small text-sm"
                            checked={societyDetails.acceptorapprove1 === "No"}
                          />
                        </div>
                      </Col>
                    </Row>
                    <Row>
                      <Col lg={3} md={3} xs={12} >
                        <TableText label="Declaration" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            required={true}
                            name="declaration"
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>

                      <Col lg={3} md={3} xs={12} >
                        <TableText label="Supporting Document" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            required={true}
                            type="file"
                            name="supportingDoc"
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                      <Col lg={3} md={3} xs={12} >
                        <TableText label="MOA" required={true} LeftSpace={false} />

                        <div className="firmFile">
                          <Form.Control
                            required={true}
                            type="file"
                            name="moa"
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                    </Row>
                  </>
                ) : null}

                {checklist &&
                  checklist.length > 0 &&
                  checklist.some((x: string) => x == "Amendment of Memorandum and Bye-laws") ? (
                  <>
                    <div className="uploadFirmList my-1">
                      <h3>Amendment of Memorandum and Bye-laws(Section 8)</h3>
                    </div>

                    <div className="regofAppBg my-1">
                      <div className="formSectionTitle">
                        <h3>
                          Existing List of Members <span style={{ color: "red" }}>*</span>
                        </h3>
                      </div>
                      <Row>
                        {membersDetails && membersDetails?.length > 0 ? (
                          <div ref={refUpdate} className="addedPartnerSec mt-3" >
                            <Row className="mb-1">
                              <Col lg={12} md={12} xs={12}>
                                <div style={{ overflowX: "scroll" }}>
                                  <Table striped bordered className="tableData" style={{ width: "100%" }}>
                                    <thead>
                                      <tr>
                                        <th>Type</th>
                                        <th>Aadhaar No</th>
                                        <th>Name of the member</th>
                                        <th>Relation Name</th>
                                        <th>Age/Gender</th>
                                        <th>Role/Position</th>
                                        <th>Occupation</th>
                                        <th>Date of Joining</th>
                                        <th>Address</th>
                                        <th>Contact</th>
                                        <th>Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {membersDetails?.length > 0 && membersDetails.map((item: any, i: number) => {
                                        return (
                                          <>{
                                            item.status != "InActive" ?
                                              <tr>
                                                <td
                                                  className="text-wrap-table" title={item.memberType}
                                                >
                                                  {item.memberType}
                                                </td>

                                                <td className="text-wrap-table" title={item.maskedAadhar} >

                                                  {item.maskedAadhar}
                                                </td>
                                                {/* <td>{item.memberType}</td> */}

                                                <td className="text-wrap-table" title={item.memberName}>{item.memberName}</td>
                                                <td className="text-wrap-table" title={item.relationName}>{item.relationName}</td>
                                                <td className="text-wrap-table" title={`${item.age}/${item.gender}`}>{item.age} / {item.gender}</td>
                                                <td className="text-wrap-table" title={item.role}>{item.role}</td>
                                                <td className="text-wrap-table" title={item.occupation}>{item.occupation}</td>
                                                <td className="text-wrap-table" title={item.joiningDate}>{item.joiningDate}</td>
                                                <td className="text-wrap-table" title={`${item.doorNo},${item.street},${item.district},${item.mandal},${item.villageOrCity},${item.pinCode}`}
                                                >
                                                  {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                                                </td>
                                                <td
                                                  className="text-wrap-table"
                                                  title={item.mobileNumber}
                                                >
                                                  {item.mobileNumber}
                                                </td>
                                                <td>
                                                  <Image
                                                    alt="Image"
                                                    height={20}
                                                    width={20}
                                                    src="/assets/delete-icon.svg"
                                                    style={{ cursor: "pointer" }}
                                                    onClick={() => {
                                                      setShowVerification(true)
                                                      setDeleteIndex(i)
                                                      setSelectedMemberDetailsremove({ ...SelectedMemberDetails, maskedAadhar: item.maskedAadhar, aadharNumber: item.aadharNumber })

                                                      // handleMemberRemove(i)
                                                    }}
                                                  />
                                                </td>
                                              </tr> : null
                                          }</>)
                                      })}
                                    </tbody>
                                  </Table>
                                </div>
                                <Row>
                                  <Col lg={12} md={12} xs={12}>
                                    <div className="formSectionTitle my-1">
                                      <h3>Outgoing EC Member List</h3>
                                    </div>
                                  </Col>
                                </Row>
                                <Table striped bordered className="tableData listData">
                                  <thead>
                                    <tr>
                                      <th>Type</th>
                                      <th>Aadhaar No</th>
                                      <th>Name of the member</th>
                                      <th>Relation Name</th>
                                      <th>Age/Gender</th>
                                      <th>Role/Position</th>
                                      <th>Occupation</th>
                                      <th>Date of Joining</th>
                                      <th>Address</th>
                                      <th>Contact</th>
                                      <th>Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {outgoingMembersDetails?.length > 0 && outgoingMembersDetails?.map((item: any, i: number) => {
                                      return (
                                        <tr>
                                          <td
                                            className="text-wrap-table" title={item.memberType}
                                          >
                                            {item.memberType}
                                          </td>

                                          <td className="text-wrap-table" title={item.maskedAadhar} >

                                            {item.maskedAadhar}
                                          </td>
                                          {/* <td>{item.memberType}</td> */}

                                          <td className="text-wrap-table" title={item.memberName}>{item.memberName}</td>
                                          <td className="text-wrap-table" title={item.relationName}>{item.relationName}</td>
                                          <td className="text-wrap-table" title={`${item.age}/${item.gender}`}>{item.age} / {item.gender}</td>
                                          <td className="text-wrap-table" title={item.role}>{item.role}</td>
                                          <td className="text-wrap-table" title={item.occupation}>{item.occupation}</td>
                                          <td className="text-wrap-table" title={item.joiningDate}>{item.joiningDate}</td>
                                          <td className="text-wrap-table" title={`${item.doorNo},${item.street},${item.district},${item.mandal},${item.villageOrCity},${item.pinCode}`}
                                          >
                                            {item.doorNo},{item.street},{item.district},{item.mandal},{item.villageOrCity},{item.pinCode}
                                          </td>
                                          <td
                                            className="text-wrap-table"
                                            title={item.mobileNumber}
                                          >
                                            {item.mobileNumber}
                                          </td>
                                          <td>
                                            <Image
                                              alt="Image"
                                              height={20}
                                              width={20}
                                              src="/assets/delete-icon.svg"
                                              style={{ cursor: "pointer" }}
                                              onClick={() => {
                                                handleMemberRemoveoutgoing(i)
                                              }}
                                            />
                                          </td>
                                        </tr>
                                      )
                                    })}
                                  </tbody>
                                </Table>
                                <Modal show={showVerification} onHide={handleClosePaymentModal} style={{ paddingTop: "10%" }}>
                                  <Modal.Header closeButton>
                                    <Modal.Title>
                                      Aadhar verification and Reason
                                    </Modal.Title>
                                  </Modal.Header>
                                  <Modal.Body>
                                    <div className="societyRegSec">
                                      <Form className={`formsec ${styles.RegistrationInput}`} autoComplete="off">
                                        <div className="regofAppBg mx-4">
                                          <Row>
                                            <Col lg={8} md={4} xs={12} className="mb-3 mx-5">
                                              <TableText label="Reason for Outgoing" required={true} LeftSpace={false} />
                                              <select style={{ textTransform: 'uppercase' }}
                                                className="form-control"
                                                name="reasonForOutgoing"
                                                required={true}
                                                onChange={membersDetailsremove}
                                                value={SelectedMemberDetailsremove.reasonForOutgoing}
                                              >
                                                <option>Select</option>
                                                {reasonlist.map((item: any, i: number) => {
                                                  return (
                                                    <option key={i + 1} value={item}>
                                                      {item}
                                                    </option>
                                                  )
                                                })}
                                              </select>
                                              <text className={styles.warningText} style={{ color: "red", fontSize: "12px" }}>
                                                {FormErrors.reasonForOutgoing}
                                              </text>
                                            </Col>
                                            {SelectedMemberDetailsremove.reasonForOutgoing == "TERMINATED" ? null : <Col lg={8} md={3} xs={12} className="mb-3 mx-5">
                                              {!TempMemorymemberremove.OTPRequested ? (
                                                <Form.Group>
                                                  <TableText
                                                    label="Enter Aadhaar Number"
                                                    required={true}
                                                    LeftSpace={false}
                                                  />
                                                  <div className="formGroup">
                                                    <TableInputText
                                                      disabled={TempMemorymemberremove.AadharVerified}
                                                      type="text"
                                                      maxLength={12}
                                                      placeholder="Enter Aadhaar Number"
                                                      required={false}
                                                      dot={false}
                                                      name={"maskedAadhar"}
                                                      value={SelectedMemberDetailsremove.maskedAadhar}
                                                      onChange={() => {

                                                      }}
                                                      onKeyPress={true}
                                                      onPaste={(e: any) => e.preventDefault()}
                                                    />
                                                    {!TempMemorymemberremove.AadharVerified ? (
                                                      //  <Col lg={3} md={3} xs={12} className="mb-3">
                                                      <div
                                                        style={{
                                                          display: "flex",
                                                          justifyContent: "center",
                                                          alignItems: "center",
                                                          borderRadius: "2px",
                                                        }}
                                                        onClick={() => ReqOTP(SelectedMemberDetailsremove)}
                                                        className="verify btn btn-primary"
                                                      >
                                                        Get OTP
                                                      </div>
                                                    ) : null}
                                                  </div>
                                                </Form.Group>
                                              ) : (
                                                <Form.Group>
                                                  <TableText
                                                    label="Enter OTP"
                                                    required={false}
                                                    LeftSpace={false}
                                                  />
                                                  <div className="formGroup">
                                                    <TableInputText
                                                      disabled={false}
                                                      type="number"
                                                      placeholder="Enter OTP Received"
                                                      maxLength={6}
                                                      required={false}
                                                      name={"otpCode"}
                                                      value={SelectedMemberDetailsremove.otpCode}
                                                      onChange={membersDetailsremove}
                                                    />
                                                    <div
                                                      style={{
                                                        display: "flex",
                                                        justifyContent: "center",
                                                        alignItems: "center",
                                                        borderRadius: "2px",
                                                      }}
                                                      onClick={() => {
                                                        ReqDetails(SelectedMemberDetailsremove)
                                                      }}
                                                      className="verify btn btn-primary"
                                                    >
                                                      Verify
                                                    </div>
                                                    <div
                                                      style={{ display: "flex", justifyContent: "flex-end" }}
                                                    >
                                                      <div
                                                        style={{
                                                          cursor: "pointer",
                                                          marginRight: "20px",
                                                          color: "blue",
                                                          fontSize: "10px",
                                                        }}
                                                        onClick={() => {
                                                          setTempMemorymemberremove({
                                                            ...TempMemorymemberremove,
                                                            OTPRequested: false,
                                                          })
                                                        }}
                                                      >
                                                        clear
                                                      </div>
                                                    </div>
                                                  </div>
                                                </Form.Group>
                                              )}
                                              <text className={styles.warningText} style={{ color: "red", fontSize: "12px" }}>
                                                {FormErrors.maskedAadhar}
                                              </text>
                                            </Col>
                                            }

                                          </Row>
                                        </div></Form></div>
                                  </Modal.Body>
                                  <Modal.Footer style={{ justifyContent: "center" }}>
                                    <div style={{ alignItems: "center" }}>
                                      <Button variant="primary" onClick={() => { handleMemberRemove(deleteindex) }}>
                                        submit
                                      </Button>
                                    </div>
                                  </Modal.Footer>
                                </Modal>

                              </Col>
                            </Row>
                          </div>
                        ) : null}
                      </Row>
                      <Row>
                        <Col lg={10} md={12} xs={12} className="d-flex ">
                          <TableText
                            label="Any Incoming Members"
                            LeftSpace={false}
                            required={false}
                          />
                          <Form.Check
                            inline
                            label="Yes"
                            required={true}
                            name="anyincomingmembers"
                            type="radio"
                            className="fom-checkbox mx-3"
                            onChange={() => setDisplayOption("display")}
                            value="Yes"
                            checked={displayOption === "display"}

                          />
                          {docdisplay ? <></> : <Form.Check
                            inline
                            label="No"
                            value="No"
                            name="anyincomingmembers"
                            type="radio"
                            className="fom-checkbox"
                            checked={displayOption === "not-display"}
                            onChange={() => setDisplayOption("not-display")}
                          />}
                        </Col>
                      </Row>
                      {displayOption === "display" && (
                        <Form className={`formsec ${styles.RegistrationInput}`} onSubmit={handleSubmit} autoComplete="off">
                          <div className="regofAppBg mb-3 dahboardProcedureSec">
                            <>
                              <div className="societyMemberDetailsList">
                                <Row className="membersDetailsList">
                                  <div className="societyMemberDetailsList">
                                    <Row className="membersDetailsList d-flex align-items-center"></Row>
                                    <Row className="membersDetailsList">
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Member Type"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <select style={{ textTransform: 'uppercase' }}
                                            className="form-control"
                                            name="memberType"
                                            required={false}
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.memberType}
                                          >
                                            <option>Select</option>
                                            {typelist.map((item: any, i: number) => {
                                              return (
                                                <option key={i + 1} value={item}>
                                                  {item}
                                                </option>
                                              )
                                            })}
                                          </select>
                                        </Form.Group>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >

                                        {!TempMemorymember.OTPRequested ? (
                                          <Form.Group>
                                            <TableText
                                              label="Enter Aadhaar Number"
                                              required={true}
                                              LeftSpace={false}
                                            />
                                            <div className="formGroup">
                                              <TableInputText
                                                disabled={TempMemorymember.AadharVerified}
                                                type="text"
                                                maxLength={12}
                                                placeholder="Enter Aadhaar Number"
                                                required={false}
                                                dot={false}
                                                name={"maskedAadhar"}
                                                value={SelectedMemberDetails.maskedAadhar}
                                                onChange={(e: any) => {
                                                  if (!TempMemorymember.AadharVerified) {
                                                    membersDetailsChange(e)
                                                  }
                                                }}
                                                onKeyPress={true}
                                                onPaste={(e: any) => e.preventDefault()}
                                              />
                                              {!TempMemorymember.AadharVerified ? (
                                                <div
                                                  style={{
                                                    display: "flex",
                                                    justifyContent: "center",
                                                    alignItems: "center",
                                                    borderRadius: "2px",
                                                  }}
                                                  onClick={() => ReqOTP(SelectedMemberDetails)}
                                                  className="verify btn btn-primary"
                                                >
                                                  Get OTP
                                                </div>
                                              ) : null}
                                            </div>
                                          </Form.Group>
                                        ) : (
                                          <Form.Group>
                                            <TableText
                                              label="Enter OTP"
                                              required={false}
                                              LeftSpace={false}
                                            />
                                            <div className="formGroup">
                                              <TableInputText
                                                disabled={false}
                                                type="number"
                                                placeholder="Enter OTP Received"
                                                maxLength={6}
                                                required={false}
                                                name={"otpCode"}
                                                value={SelectedMemberDetails.otpCode}
                                                onChange={membersDetailsChange}
                                              />
                                              <div
                                                style={{
                                                  display: "flex",
                                                  justifyContent: "center",
                                                  alignItems: "center",
                                                  borderRadius: "2px",
                                                }}
                                                onClick={() => {
                                                  ReqDetails(SelectedMemberDetails)
                                                }}
                                                className="verify btn btn-primary"
                                              >
                                                Verify
                                              </div>
                                              <div
                                                style={{ display: "flex", justifyContent: "flex-end" }}
                                              >
                                                <div
                                                  style={{
                                                    cursor: "pointer",
                                                    marginRight: "20px",
                                                    color: "blue",
                                                    fontSize: "10px",
                                                  }}
                                                  onClick={() => {
                                                    setTempMemorymember({
                                                      ...TempMemorymember,
                                                      OTPRequested: false,
                                                    })
                                                  }}
                                                >
                                                  clear
                                                </div>
                                              </div>
                                            </div>
                                          </Form.Group>
                                        )}
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Name of the Member"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <TableInputText
                                            // className="form-control"
                                            name="memberName"
                                            disabled
                                            required={false}
                                            placeholder="Enter Name of the Member"
                                            onChange={() => { }}
                                            value={SelectedMemberDetails.memberName}
                                            type={"text"}
                                          />
                                          <Row className={styles.columnText}>
                                            <Col lg={9} md={4} xs={12}>
                                              Gender:{SelectedMemberDetails.gender}/Age:
                                              {SelectedMemberDetails.age}
                                            </Col>
                                          </Row>
                                        </Form.Group>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group className="inline">
                                          <TableText
                                            label="Relation Name"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <div className="inline formGroup">
                                            <Form.Select
                                              name="relationType"
                                              onChange={(event) => membersDetailsChange(event)}
                                              disabled={false}
                                              required={false}
                                              value={SelectedMemberDetails.relationType}
                                            >
                                              <option>Select</option>
                                              {relationtypelist.map((item: any, i: number) => {
                                                return (
                                                  <option key={i + 1} value={item}>
                                                    {item}
                                                  </option>
                                                )
                                              })}
                                            </Form.Select>
                                            <input

                                              className="form-control"
                                              type="text"
                                              name="relationName"
                                              onChange={() => { }}
                                              value={SelectedMemberDetails.relationName}
                                              disabled={true}
                                              required={false}
                                            />
                                          </div>
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={2} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Role/Position"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <select style={{ textTransform: 'uppercase' }}
                                            className="form-control"
                                            name="role"
                                            required={false}
                                            onChange={(event) =>
                                              membersDetailsChange(event)
                                            }
                                            value={SelectedMemberDetails.role}
                                          >
                                            <option>Select</option>
                                            {roleList.map((item: any) => {
                                              return <option value={item}>{item}</option>
                                            })}
                                          </select>
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Occupation"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <TableInputText
                                            type="text"
                                            required={false}
                                            name="occupation"
                                            placeholder="Enter Occupation"
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.occupation}
                                          />
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Qualification"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <TableInputText
                                            type="text"
                                            required={false}
                                            name="qualification"
                                            placeholder="Enter Qualification"
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.qualification}
                                          />
                                        </Form.Group>
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <Form.Group>
                                          <TableText
                                            label="Date of Joining as a Member"
                                            required={true}
                                            LeftSpace={false}
                                          />
                                          <input
                                            required={false}
                                            type="date"
                                            className="form-control"
                                            name="joiningDate"
                                            placeholder="DD/MM/YYYY"
                                            onChange={(event) => membersDetailsChange(event)}
                                            value={SelectedMemberDetails.joiningDate}
                                          />
                                        </Form.Group>
                                      </Col>
                                      <div className="formSectionTitle">
                                        <h3>Address</h3>
                                      </div>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText label="Door No" required={true} LeftSpace={false} />
                                        <TableInputText
                                          disabled={false}
                                          type="text"
                                          placeholder="Enter Door No"
                                          required={false}
                                          name="doorNo"
                                          onChange={(event: any) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.doorNo}
                                        />
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText
                                          label="Street Name"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <TableInputText
                                          disabled={false}
                                          type="text"
                                          placeholder="Enter Street Name"
                                          required={false}
                                          name="street"
                                          onChange={(event: any) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.street}
                                        />
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <TableText label="District" required={true} LeftSpace={false} />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="district"
                                          onChange={(event) => {
                                            membersDetailsChange(event)
                                            districtmemberChange(event)
                                          }}
                                          value={SelectedMemberDetails.district}
                                        >
                                          <option>Select</option>
                                          {districtList.map((item: any, i: any) => {
                                            return (
                                              <option key={i + 1} value={item.name}>
                                                {item.name}
                                              </option>
                                            )
                                          })}
                                        </select>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText label="Mandal" required={true} LeftSpace={false} />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="mandal"
                                          id={"mandal"}
                                          placeholder="Mandal"
                                          onChange={(event) => {
                                            membersDetailsChange(event)
                                            mandalmemberChange(event)
                                          }}
                                          value={SelectedMemberDetails.mandal}
                                        // defaultValue={"Select"}
                                        >
                                          <option>Select</option>
                                          {currentmemberDistrict && (
                                            <DynamicMandals
                                              currentDistrict={currentmemberDistrict}
                                              setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                            ></DynamicMandals>
                                          )}</select>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} className="mb-3">
                                        <TableText label="Village" required={true} LeftSpace={false} />
                                        <select style={{ textTransform: 'uppercase' }}
                                          className="form-control"
                                          name="villageOrCity"
                                          id={"villageOrCity"}
                                          placeholder="Village/City"
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.villageOrCity}
                                        // defaultValue={"Select"}
                                        >
                                          <option>Select</option>
                                          {currentmemberDistrict && currentmemberMandal && <DynamicVillages
                                            currentDistrict={currentmemberDistrict}
                                            currentMandal={currentmemberMandal}
                                            setDetails={() => setSelectedMemberDetails({ ...SelectedMemberDetails })}
                                          ></DynamicVillages>}

                                        </select>
                                      </Col>

                                      <Col lg={3} md={3} xs={12} className="mb-3">
                                        <TableText label="PIN Code" required={true} LeftSpace={false} />
                                        <Form.Control
                                          disabled={false}
                                          type="text"
                                          maxLength={6}
                                          placeholder="Enter PIN Code"
                                          required={false}
                                          name={"pinCode"}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.pinCode}
                                          onKeyPress={onNumberOnlyChange}
                                        />
                                      </Col>
                                      <div className="formSectionTitle">
                                        <h3>Contact Details</h3>
                                      </div>

                                      <Col lg={3} md={3} xs={12} >
                                        <TableText
                                          label="Mobile Number"
                                          required={true}
                                          LeftSpace={false}
                                        />
                                        <Form.Control
                                          disabled={false}
                                          type="text"
                                          maxLength={10}
                                          placeholder="Enter Mobile Number"
                                          required={false}
                                          name={"mobileNumber"}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.mobileNumber}
                                          onKeyPress={onNumberOnlyChange}
                                        />
                                      </Col>
                                      <Col lg={3} md={3} xs={12} >
                                        <TableText
                                          label="Email Address"
                                          required={false}
                                          LeftSpace={false}
                                        />
                                        <Form.Control
                                          disabled={false}
                                          type="text"
                                          placeholder="Enter Email Address"
                                          required={false}
                                          maxLength={40}
                                          minLength={15}
                                          name={"email"}
                                          onChange={(event) => membersDetailsChange(event)}
                                          value={SelectedMemberDetails.email}
                                        />
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is of sound mind?"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="soundMind"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.soundMind === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="soundMind"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.soundMind === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is declared to be insolvent or an undischarged insolvent?"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="inSolvent"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.inSolvent === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="inSolvent"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.inSolvent === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is convicted of an offense of moral turpitude? "
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="offense"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.offense === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="offense"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.offense === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                    <Row>
                                      <Col>
                                        <div className="mb-3 d-flex">
                                          <TableText
                                            label="Whether the member is disqualified for such an appointment by an order of a court?"
                                            required={false}
                                            LeftSpace={false}
                                          />
                                          <div className="firmChangeList px-4">
                                            <Form.Check
                                              inline
                                              label="Yes"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="appointment"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="Yes"
                                              checked={SelectedMemberDetails.appointment === "Yes"}
                                            />
                                            <Form.Check
                                              inline
                                              label="No"
                                              disabled={false}
                                              type="radio"
                                              required={false}
                                              name="appointment"
                                              onChange={(event) => membersDetailsChange(event)}
                                              value="No"
                                              checked={SelectedMemberDetails.appointment === "No"}
                                            />
                                          </div>
                                        </div>
                                      </Col>
                                    </Row>
                                  </div>
                                </Row>

                              </div>{" "}
                            </>
                            <Row>
                              <Col lg={12} md={12} xs={12} className="mb-4">
                                <div className="addotherBtnInfo text-center">
                                  <div onClick={() => { handleMemberAdd(); setdocdisplay(true) }} className="btn btn-primary addPartner">
                                    Add Member
                                  </div>
                                </div>
                              </Col>
                            </Row>

                          </div>
                        </Form>
                      )}
                      {displayOption === "not-display" ? <></> : <>
                        <Row>
                          <Col>
                            <div className="mb-3 d-flex">
                              <TableText
                                label="Whether the joining of the new member has been approved by General body?"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check

                                  inline
                                  label="Yes"
                                  disabled={false}
                                  type="radio"
                                  required={true}
                                  name="joiningofnewmember"
                                  onChange={(event) => { societyDetailsChange(event) }}
                                  value="Yes"
                                  checked={societyDetails.joiningofnewmember === "Yes"}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  disabled={false}
                                  type="radio"
                                  required={true}
                                  name="joiningofnewmember"
                                  onChange={(event) => societyDetailsChange(event)}
                                  value="No"
                                  checked={societyDetails.joiningofnewmember === "No"}
                                />
                              </div>
                            </div>
                          </Col>
                        </Row>
                        <Row>
                          <Col>
                            <div className="mb-3 d-flex">
                              <TableText
                                label="Has the joining of the new member has been approved by the Quorum"
                                required={false}
                                LeftSpace={false}
                              />
                              <div className="firmChangeList px-4">
                                <Form.Check
                                  inline
                                  label="Yes"
                                  disabled={false}
                                  type="radio"
                                  required={true}
                                  name="joiningofnewmemberapprovedbyQuorum"
                                  onChange={(event) => societyDetailsChange(event)}
                                  value="Yes"
                                  checked={societyDetails.joiningofnewmemberapprovedbyQuorum === "Yes"}
                                />
                                <Form.Check
                                  inline
                                  label="No"
                                  disabled={false}
                                  type="radio"
                                  required={true}
                                  name="joiningofnewmemberapprovedbyQuorum"
                                  onChange={(event) => societyDetailsChange(event)}
                                  value="No"
                                  checked={societyDetails.joiningofnewmemberapprovedbyQuorum === "No"}
                                />
                              </div>
                            </div>
                          </Col>
                        </Row></>}
                      {/* <Row>
                        <Col>
                          <div className="mb-3 d-flex">
                            <TableText
                              label="Whether the joining of the new member has been approved by General body?"
                              required={false}
                              LeftSpace={false}
                            />
                            <div className="firmChangeList px-4">
                              <Form.Check

                                inline
                                label="Yes"
                                disabled={false}
                                type="radio"
                                required={true}
                                name="membersagreedwithbyelaws"
                                onChange={(event) => societyDetailsChange(event)}
                                value="Yes"
                                checked={societyDetails.membersagreedwithbyelaws === "Yes"}
                              />
                              <Form.Check
                                inline
                                label="No"
                                disabled={false}
                                type="radio"
                                required={true}
                                name="membersagreedwithbyelaws"
                                onChange={(event) => societyDetailsChange(event)}
                                value="No"
                                checked={societyDetails.membersagreedwithbyelaws === "No"}
                              />
                            </div>
                          </div>
                        </Col>
                      </Row> */}

                      <div className="regofAppBg my-2">
                        <Row>
                          {displayOption === "not-display" ? <></> : <>
                            <div className="formSectionTitle">
                              <h3>
                                Documents
                              </h3>
                            </div>
                            <Col lg={3} md={3} xs={12}>
                              <TableText label="Self Signed Declaration of New Member" required={false} LeftSpace={false} />
                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  required={true}
                                  name="selfSignedDeclaration"
                                  ref={inputRef}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col>
                            <Col lg={3} md={3} xs={12}>
                              <TableText label="Declaration by Quorum & Members" required={true} LeftSpace={false} />

                              <div className="firmFile">
                                <Form.Control
                                  type="file"
                                  name="declaration"
                                  ref={inputRef}
                                  required={true}
                                  onChange={handleFileChange}
                                  accept="application/pdf"
                                />
                              </div>
                            </Col></>}
                        </Row>
                        <div className="uploadFirmList my-1">
                          <h3>
                            Upload Society Related Documents-(All Uploaded Documents should be in PDF format
                            only upto 5MB )
                          </h3>
                        </div>
                        {outgoingMembersDetails?.length > 0 && outgoingMembersDetails?.map((item: any, i: number) => {
                          return (
                            <Row>
                              {item.reasonForOutgoing === "RESIGNED" &&
                                <Col lg={3} md={6} xs={12}>
                                  <div className="firmFile">
                                    <Form.Group controlId="formFile">
                                      <Form.Label>
                                        {item.memberName} Resigned
                                      </Form.Label>
                                      <Form.Control
                                        type="file"
                                        id={`${item.memberName}_resigned`}
                                        name={`${item.memberName}_resigned`}
                                        ref={inputRef}
                                        required={true}
                                        onChange={handleFileChange}
                                        accept="application/pdf"
                                      />
                                    </Form.Group>
                                  </div>
                                </Col>}
                              {item.reasonForOutgoing === "TERMINATED" && <>
                                <Col lg={3} md={6} xs={12}>

                                  <div className="firmFile">
                                    <Form.Group controlId="formFile">
                                      <Form.Label>
                                        <TableText label={`${item.memberName}_Terminated`} required={true} LeftSpace={false} />

                                      </Form.Label>
                                      <Form.Control
                                        type="file"
                                        required={true}
                                        id={`${item.memberName}_Terminated`}
                                        name={`${item.memberName}_Terminated`}
                                        ref={inputRef}
                                        onChange={handleFileChange}
                                        accept="application/pdf"
                                      />
                                    </Form.Group>
                                  </div>
                                </Col>

                                <Col lg={3} md={3} xs={12} className="mt-1">
                                  <TableText label={`${item.memberName}_SelfSignedDeclaration of outgoing Member`} required={true} LeftSpace={false} />
                                  <div className="firmFile">
                                    <Form.Control
                                      type="file"
                                      required={true}
                                      id={`${item.memberName}_selfSignedDeclaration`}
                                      name={`${item.memberName}_selfSignedDeclaration`}
                                      ref={inputRef}
                                      onChange={handleFileChange}
                                      accept="application/pdf"
                                    />
                                  </div>
                                </Col>
                                <Col lg={10} md={4} xs={12}>
                                  <div className="firmDuration d-flex">
                                    <label>
                                      <p className="fom-checkbox fw-bold small text-sm me-2">
                                        Whether the Termination of an Member has been accepted by the majority of members in the
                                        society?
                                      </p>
                                    </label>
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      value="Yes"
                                      name="termination"
                                      onChange={(e: any) => {
                                        const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                        if (index > -1) { outgoingMembersDetails[index].termination = "Yes" }
                                        membersDetailsremove(e);
                                        setdisplayaadhar(true)
                                      }
                                      }
                                      // onChange={(e: any) => { membersDetailsremove(e); setdisplayaadhar(true) }}
                                      type="radio"
                                      className="fom-checkbox fw-bold small text-sm"
                                      checked={SelectedMemberDetailsremove.termination === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      value="No"
                                      name="termination"
                                      type="radio"
                                      // onChange={(e: any) => { membersDetailsremove(e); setdisplayaadhar(false) }}
                                      onChange={(e: any) => {
                                        const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                        if (index > -1) { outgoingMembersDetails[index].termination = "No" }
                                        membersDetailsremove(e);
                                        setdisplayaadhar(false)
                                      }
                                      }
                                      className="fom-checkbox fw-bold small text-sm"
                                      checked={SelectedMemberDetailsremove.termination === "No"}
                                    />
                                  </div>
                                </Col>
                                {/* <Row> */}
                                {displayaadhar && AadharValidate?.length > 0 &&
                                  <>
                                    <Row>
                                      {AadharValidate.map((form, index) => {
                                        return (
                                          <>
                                            <Col lg={3} md={3} xs={12} className="mb-3">
                                              <Form.Group>
                                                <TableText
                                                  label="Aadhaar Number"
                                                  required={true}
                                                  LeftSpace={false}
                                                />
                                                <div className="formGroup">
                                                  {(!form.otpStatus ||
                                                    form.otpStatus == "2" ||
                                                    form.otpVerified == "true") && (
                                                      <div>
                                                        <TableInputText
                                                          type="text"
                                                          placeholder="Enter Aadhaar Number"
                                                          name="maskedAadhar"
                                                          required={true}
                                                          maxLength={12}
                                                          onKeyPress={true}
                                                          onPaste={(e: any) => e.preventDefault()}
                                                          disabled={form.otpVerified == "true"}
                                                          onChange={(event: any) =>
                                                            terminaMemberChange(event, index)
                                                          }
                                                          value={form.maskedAadhar}
                                                        />
                                                        {!form.otpStatus && (
                                                          <div
                                                            className="verify btn btn-primary"
                                                            onClick={() => {
                                                              if (form.maskedAadhar?.length == 12) {
                                                                let count = 0;
                                                                AadharValidate.forEach((x: any) => {
                                                                  if (x.maskedAadhar == form.maskedAadhar) {
                                                                    count++;
                                                                  }
                                                                })
                                                                if (count < 2) {
                                                                  membersDetails.some((x: any) => {
                                                                    if (x.maskedAadhar == form.maskedAadhar && x.status == "Active") {
                                                                      generateOtp(index)
                                                                    } else {
                                                                      ShowMessagePopup(false, "Aadhar is not in the existing EC Members")
                                                                    }
                                                                  })

                                                                }
                                                                else {
                                                                  ShowMessagePopup(false, "Aadhar is already taken")
                                                                }
                                                              }
                                                            }}
                                                          >
                                                            Get OTP
                                                          </div>
                                                        )}
                                                      </div>
                                                    )}
                                                  {form.otpStatus == "1" &&
                                                    form.otpVerified != "true" && (
                                                      <div>
                                                        <TableInputText
                                                          type="number"
                                                          placeholder="Enter OTP"
                                                          name="otpCode"
                                                          onKeyPress={true}
                                                          required
                                                          onChange={(event) =>
                                                            terminaMemberChange(event, index)
                                                          }
                                                          value={form.otpCode}
                                                        />
                                                        <div
                                                          className="verify btn btn-primary"
                                                          onClick={() => verifyOtp(index)}
                                                        >
                                                          Verify
                                                        </div>
                                                        <div
                                                          style={{
                                                            display: "flex",
                                                            justifyContent: "flex-end",
                                                          }}
                                                        >
                                                          <div
                                                            style={{
                                                              cursor: "pointer",
                                                              marginRight: "20px",
                                                              color: "blue",
                                                              fontSize: "10px",
                                                            }}
                                                            onClick={(e: any) => {
                                                              let datanew = AadharValidate
                                                              const det = {
                                                                ...datanew[index],
                                                                otpStatus: "", otpVerified: "", aadharNo: "", maskedAadhar: ""
                                                              }
                                                              let aadhardata = [...AadharValidate]
                                                              aadhardata[index] = det
                                                              setAadharValidate(aadhardata)
                                                            }}
                                                          >
                                                            clear
                                                          </div>
                                                        </div>
                                                      </div>
                                                    )}
                                                </div>
                                              </Form.Group>
                                            </Col>
                                          </>
                                        )
                                      })}
                                    </Row>
                                  </>
                                }
                                {/* </Row> */}
                                <Row>
                                  <Col lg={3} md={6} xs={12}>
                                    <div className="firmFile">
                                      <Form.Group controlId="formFile">
                                        <Form.Label>
                                          <TableText label={`${item.memberName}_Notice 1`} required={true} LeftSpace={false} />
                                        </Form.Label>
                                        <Form.Control
                                          type="file"
                                          required={true}
                                          id={`${item.memberName}_firstNotice`}
                                          name={`${item.memberName}_firstNotice`}
                                          ref={inputRef}
                                          onChange={handleFileChange}
                                          accept="application/pdf"
                                        />
                                      </Form.Group>
                                    </div>
                                  </Col>
                                  <Col lg={3} md={12} sm={12} className="my-2">
                                    <TableText label={`${item.memberName}_Notice 1 Date`} required={true} LeftSpace={false} />
                                    <TableInputText
                                      disabled={false}
                                      type="date"
                                      placeholder="Enter Door No"
                                      required={true}
                                      max={moment(moment().toDate()).format("YYYY-MM-DD")}
                                      // id={`${item.memberName}_firstNoticeDate`}
                                      name={"firstNoticeDate"}
                                      onChange={(e: any) => {

                                        const index: any = outgoingMembersDetails.findIndex((x: any) => x._id == IndexData._id)
                                        if (index > -1) { outgoingMembersDetails[index].firstNoticeDate = e.target.value }
                                      }}
                                      value={SelectedMemberDetailsremove.firstNoticeDate} />
                                  </Col>
                                </Row>
                                <Row>
                                  <Col lg={3} md={6} xs={12}>
                                    <div className="firmFile">
                                      <Form.Group controlId="formFile">
                                        <Form.Label>
                                          <TableText label={`${item.memberName}_Notice 2`} required={true} LeftSpace={false} />
                                        </Form.Label>
                                        <Form.Control
                                          type="file"
                                          required={true}

                                          id={`${item.memberName}_secondNotice`}
                                          name={`${item.memberName}_secondNotice`}
                                          ref={inputRef}
                                          onChange={handleFileChange}
                                          accept="application/pdf"
                                        />
                                      </Form.Group>
                                    </div>
                                  </Col>
                                  <Col lg={3} md={12} sm={12} className="my-2">
                                    <TableText label={`${item.memberName}_Notice 2 Date`} required={true} LeftSpace={false} />
                                    <TableInputText
                                      disabled={false}
                                      type="date"
                                      max={moment(moment().toDate()).format("YYYY-MM-DD")}
                                      placeholder="Enter Date"
                                      required={true}
                                      // id={`${item.memberName}_firstNoticeDate`}
                                      name={"secondNoticeDate"}
                                      onChange={(e: any) => {
                                        const index: any = outgoingMembersDetails.findIndex((x: any) => x._id == IndexData._id)
                                        if (index > -1) { outgoingMembersDetails[index].secondNoticeDate = e.target.value }
                                      }}
                                      // onChange={membersDetailsremove}
                                      value={SelectedMemberDetailsremove.secondNoticeDate} />
                                  </Col></Row>
                                <Row>
                                  <Col lg={3} md={6} xs={12}>
                                    <div className="firmFile">
                                      <Form.Group controlId="formFile">
                                        <Form.Label>
                                          <TableText label={`${item.memberName}_Notice 3`} required={true} LeftSpace={false} />
                                        </Form.Label>
                                        <Form.Control
                                          type="file"
                                          required={true}
                                          id={`${item.memberName}_thirdNotice`}
                                          name={`${item.memberName}_thirdNotice`}
                                          ref={inputRef}
                                          onChange={handleFileChange}
                                          accept="application/pdf"
                                        />
                                      </Form.Group>
                                    </div>
                                  </Col>
                                  <Col lg={3} md={12} sm={12} className="my-2">
                                    <TableText label={`${item.memberName}_Notice 3 Date`} required={true} LeftSpace={false} />
                                    <TableInputText
                                      disabled={false}
                                      type="date"
                                      placeholder="Enter Date"
                                      max={moment(moment().toDate()).format("YYYY-MM-DD")}
                                      required={true}
                                      // id={`${item.memberName}_firstNoticeDate`}
                                      name={"thirdNoticeDate"}
                                      onChange={(e: any) => {

                                        const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                        if (index > -1) { outgoingMembersDetails[index].thirdNoticeDate = e.target.value }
                                      }}
                                      // onChange={membersDetailsremove}
                                      value={SelectedMemberDetailsremove.thirdNoticeDate} />
                                  </Col>
                                </Row>
                                <Col lg={3} md={6} xs={12}>
                                  <div className="firmFile">
                                    <Form.Group controlId="formFile">
                                      <Form.Label>
                                        <TableText label={`${item.memberName}_Resolution of Committee`} required={true} LeftSpace={false} />
                                      </Form.Label>
                                      <Form.Control
                                        type="file"
                                        required={true}
                                        id={`${item.memberName}_committeeResolution`}
                                        name={`${item.memberName}_committeeResolution`}
                                        ref={inputRef}
                                        onChange={handleFileChange}
                                        accept="application/pdf"
                                      />
                                    </Form.Group>
                                  </div>
                                </Col>
                                <Col lg={10} md={4} xs={12}>
                                  <div className="firmDuration d-flex">
                                    <label>
                                      <p className="fom-checkbox fw-bold small text-sm me-2">
                                        Whether the EC Members followed the 15 days time period in between each notice or not?
                                      </p>
                                    </label>
                                    <Form.Check
                                      inline
                                      label="Yes"
                                      value="Yes"
                                      name="noticeTime"
                                      onChange={(e: any) => {
                                        const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                        if (index > -1) { outgoingMembersDetails[index].noticeTime = "Yes" }
                                        membersDetailsremove(e)
                                      }
                                      }
                                      type="radio"
                                      className="fom-checkbox fw-bold small text-sm"
                                      checked={SelectedMemberDetailsremove.noticeTime === "Yes"}
                                    />
                                    <Form.Check
                                      inline
                                      label="No"
                                      value="No"
                                      name="noticeTime"
                                      type="radio"
                                      onChange={(e: any) => {
                                        const index: any = outgoingMembersDetails?.findIndex((x: any) => x._id == IndexData._id)
                                        if (index > -1) { outgoingMembersDetails[index].noticeTime = "No" }
                                        membersDetailsremove(e)
                                      }
                                      }
                                      className="fom-checkbox fw-bold small text-sm"
                                      checked={SelectedMemberDetailsremove.noticeTime === "No"}
                                    />
                                  </div>
                                </Col>
                              </>}
                              {item.reasonForOutgoing === "DEATH" &&
                                <Col lg={3} md={6} xs={12}>
                                  <div className="firmFile">
                                    <Form.Group controlId="formFile">
                                      <Form.Label>
                                        {item.memberName} Death
                                      </Form.Label>
                                      <Form.Control
                                        type="file"
                                        required={true}
                                        id={`${item.memberName}_Death`}
                                        name={`${item.memberName}_Death`}
                                        ref={inputRef}
                                        onChange={handleFileChange}
                                        accept="application/pdf"
                                      />
                                    </Form.Group>
                                  </div>
                                </Col>}
                            </Row>
                          )
                        })}
                      </div>
                      {/* </Row>
                    </Row> */}
                    </div>
                  </>
                ) : null}
                {checklist &&
                  checklist.length > 0 &&
                  checklist.some(
                    (x: string) =>
                      x == "Change of place of Registered Society Inside/Outside the District"
                  ) ? (
                  <>
                    <div className="regofAppBg mb-3">
                      <div className="uploadFirmList my-1">
                        <h3>Change of place of Society(Section 10)</h3>
                      </div>
                      <div className="firmDuration">
                        <Form.Check
                          inline
                          label=" With in the district"
                          value="With in the district"
                          checked={selectedOption === "With in the district"}
                          onChange={handleOptionChange}
                          name="atwill"
                          type="radio"
                          className="fom-checkbox fw-bold small text-sm"
                        />
                        <Form.Check
                          inline
                          label="Outside the district"
                          value="Outside the district"
                          name="atwill"
                          type="radio"
                          checked={selectedOption === "Outside the district"}
                          onChange={handleOptionChange}
                          className="fom-checkbox fw-bold small text-sm"
                        />
                      </div>
                      {message && <p>{message}</p>}
                      <div className="uploadFirmList my-1">
                        <h3>Documents</h3>
                      </div>
                      <Col lg={3} md={12} sm={12} className="my-2">
                        <TableText
                          label={"Affidavit  /  Lease Agreement "}
                          required={true}
                          LeftSpace={false}
                        />
                        <div className="firmFile">
                          <Form.Control
                            type="file"
                            name="affidavit"
                            required={true}
                            ref={inputRef}
                            onChange={handleFileChange}
                            accept="application/pdf"
                          />
                        </div>
                      </Col>
                    </div>
                  </>
                ) : null}

              </div>

              <div className="text-center my-2">
                {checklist &&
                  checklist.length > 0 &&
                  checklist.some((x: string) => x == "Change in the name of the society") ? <>
                  {isCheckFirm && <button type="submit" className="verify btn btn-primary">
                    Make Payment
                  </button>}</>
                  : <>{checklist && selectedOption === "Outside the district" &&
                    checklist.length > 0 &&
                    checklist.some((x: string) => x == "Change of place of Registered Society Inside/Outside the District") ?
                    <>{isCheckSoc && <Button type="submit" className="verify btn btn-primary">
                      Make Payment
                    </Button>}</> : <><Button type="submit" className="verify btn btn-primary">
                      Make Payment
                    </Button></>}</>}

              </div>
            </Container>
          </Form>
        </div>
      </div>
    </div >
  )
}

export default ChangeDetails
