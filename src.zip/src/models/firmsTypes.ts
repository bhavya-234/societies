export interface ApplicantDetailsModel {
  aadhaarNumber: string
  applicantName: string
  surName: string
  relationType: string
  relation: string
  gender: string
  role: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  otpCode: string
  otpStatus: string
}

export interface ApplicantMinimalDetailsModel {
  aadhaarNumber: string
  applicantName: string
  relationType: string
  relation: string
  role: string
}

export interface ApplicantContactDetailsModel {
  landPhoneNumber: string
  mobileNumber: string
  email: string
  faxNumber?: string
  fieldName?: string
}

export interface FirmDetailsModel {
  firmName: string
  firmDurationFrom: string
  firmDurationTo: string
  industryType: string
  businessType: string
}

export interface BusinessDetailModel {
  doorNo: string
  street: string
  state: string
  country: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  registrationDistrict: string
  branch: BranchTypesEnum
}

export enum BranchTypesEnum {
  Main = "Main",
  Sub = "Sub",
}

export interface PartnerDetailsModel {
  aadharNumber: string
  partnerName: string
  partnerSurname: string
  age: string
  relationType: string
  relation: string
  gender: string
  role: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  landPhoneNumber: string
  mobileNumber: string
  email: string
  otpCode?: string
  otpStatus?: string
  deliveryType?: string
  faxNumber?: any
  partnerAge?: string
  partnerJoiningdate?: string
}

export interface ExistPartnerDetailsModel {
  aadharNumber: string
  partnerName: string
  partnerSurname: string
  partnerAge: string
  partnerJoiningdate: string
  doorNo: string
  street: string
  country: string
  state: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
}

export interface AddressModel {
  deliveryType: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  fieldName?: string
}

export interface MinBusinessDetailModel {
  doorNo: string
  street: string
  state: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  country?: string
  fieldName?: string
  role?: any
  newPlaceEffectDate?: string
}

export interface PartnerModel extends ApplicantContactDetailsModel {
  aadharNumber: string
  partnerName: string
  partnerSurname: string
  relation: string
  relationType: string
  role: any
  age: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
}

export interface MinPartnerDetailModel {
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
}
