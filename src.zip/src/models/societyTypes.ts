export interface IApplicationDetailsModel {
  maskedAadhar: string
  aadharNumber: string
  otpStatus: string
  otpCode: string
  otpVerified: string
  applicationNumber: string
  name: string
  relationType: string
  relationName: string
  role: string
  gender: string
  age: string
  doorNo: string
  street: string
  country: string
  state: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  email: string
  mobileNumber: string
}
export interface IAAdditionalDetailsModel {
  submissionResponse: string
  applicationProcessedDate: string
  registrationYear: string
}
export interface ISocitiesDetailsModel {
  societyName: string
  category: string
  generalBodyMeeting: string
  doorNo: string
  street: string
  state: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  aim: string
  objective: string
  mobileNumber: string
  email: string
  // phone: string
  nameOfRegistrationDistrict: string
}

export interface IByLawsDetailsModel {
  name?: string
  gender?: any
  country?: string
  age?: string
  maskedAadhar: string
  societyName: string
  otpStatus: string
  otpCode: string
  otpVerified: string
  relationType: string
  doorNo: string
  street: string
  state: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  quorumSize: string
  memberName: string
  memberType: string
  aadharNumber: string
  relationName: string
  joiningDate: string
  qualification: string
  occupation: string
  role: string
  mobileNumber: string
  email: string
  // phone: string
  membershipConditions: string
  finance: string
  auditor: string
  raisingFunds: string
  officeBearers: string
  liabilityConditions: string
  meetingConditions: string
  otherMatters: string
}

export interface IContactDetailsModel {
  mobileNumber: string
  email: string
  phone: string
  fax: string
  deliveryType: string
}
export interface IMemberconditionDetailsModel {
  soundMind: string
  inSolvent: string
  offense: string
  appointment: string
}
export interface IMemberDetailsModel {
  memberType: string
  relationName: string
  joiningDate: string
  qualification: string
  soundMind: string
  inSolvent: string
  offense: string
  appointment: string
  maskedAadhar: string
  aadharNumber: string
  gender: string
  role: string
  age: string
  otpStatus: string
  otpCode: string
  otpVerified: string
  occupation: string
  doorNo: string
  street: string
  country: string
  state: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  // phone: string
  mobileNumber: string
  email: string
  memberName: string
  relationType: string
}

export interface IExistingMemberDetailsModel {
  memberType: string
  relationName: string
  joiningDate: string
  maskedAadhar: string
  aadharNumber: string
  gender: string
  
  age: string
  address: string
  role: string
  occupation: string
  mobileNumber: string
  memberName: string
}

export interface IApplicationDetailsSMModel {
  maskedAadhar: string
  aadharNumber: string
  otpStatus: string
  otpVerified: string
  otpCode: string
  applicationNumber: string
  name: string
  gender: string
  doorNo: string
  street: string
  country: string
  state: string
  applicantDistrict: string
  applicantMandal: string
  applicantVillageOrCity: string
  pinCode: string
}

export interface INewApplicationDetailsModel {
  maskedAadhar: string
  aadharNumber: string
  otpStatus: string
  otpVerified: string
  otpCode: string
  memberName: string
  gender: string
  fatherOrHusbandName: string
  age: string
  occupation: string
  role: string
  doorNo: string
  street: string
  country: string
  state: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
}
