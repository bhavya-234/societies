export interface ISApplicantDetailModel {
  gender: string
  age: string
  maskedAadhar: string
  aadharNumber: string
  name: string
  role: string
  relationType: string
  relationName: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  phone: string
  mobileNumber: string
  email: string
  otpStatus: string
  otpCode: string
  otpVerified: string
  landPhoneNumber?: string
  reasonForDissolution?: string
  effectDate?: string
  disposedDetails?: string
}

export interface ISSocietyDetailsModel {
 
  state: string
  reasonForAmalgam: string
  applicationNumber:string
  incomingsociety: string
  aim: string
  objective: string
  address: string
  members: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  amalgamationProcess: string
  majority: string
  quorum: string
}

export interface ISByLawsModel {
  bearers: string
  auditor: string
  finance: string
  funds: string
  liabilities: string
  settlements: string
}

export interface ISIncomingMemberDetailsModel {
  memberType: string
  relationName: string
  joiningDate: string
  maskedAadhar: string
  aadharNumber: string
  gender: string

  age: string
  // address: string
  role: string
  occupation: string
  mobileNumber: string
  memberName: string
  OTPRequested?: boolean
  AadharVerified?: boolean
  otpStatus?: string
  otpVerified?: string
  otpCode?: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
}

export interface ISAmalgamationMemberDetails {
  memberType: string
  relationName: string
  joiningDate: string
  maskedAadhar: string
  aadharNumber: string
  gender: string
  doorNo: string
  street: string
  district: string
  address: string
  mandal: string
  villageOrCity: string
  state: string
  country: string
  pinCode: string

  age: string
  // address: string
  role: string
  occupation: string
  mobileNumber: string
  memberName: string
}

export interface ISSocietyDetailsAmalgamationModel {
  Address: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  amalgamationname: string
  effectDate: string
  newaim:string
  newobjective:string
}

export interface ISAmendmentSocietyDetailsModel {
  joiningofnewmember:string
  membersagreedwithbyelaws:string
  joiningofnewmemberapprovedbyQuorum:string
  category:string
  societyName: string
  aim: string
  objective: string
  newAim: string
  newObjective: string
  newNameDateEffect: string
  societyNewName: string
  street: string
  annualmeeting: string
  venue: string
  memberattended: string
  governingbody: string
  newDate: string
  memoradumByelaws: string
  doorNo: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  majority: string
  acceptorapprove: string
  majority1: string
  acceptorapprove1: string
}

export interface ISAnnualListApplicantDetails {
  aadharNumber: string
  name: string
  applicationNumber: string
  relationType: string
  relationName:string
  role:string
  otpCode: string
  otpVerified: string
  age:string
  gender:string
  doorNo: string
  otpStatus:string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  phone: string
  maskedAadhar:string
  mobileNumber: string
  email: string
}

export interface ISAnnualListSocietyDetails {
  societyName: string
  societytype: string
 docType: string
  docName: string
  uploadedDoc: File,
  venue: string
  dateOfAnnualMeeting:string

}

export interface ChangePasswordModel {
  currentPassword: string
  newPassword: string
  confirmPassword: string
}

export interface ISChangeNameSocietyModel {
  societyName: string
  societyType: string
  societyNameChange: boolean
  newName: string
  newNameDate: string
  docType?: string
}

export interface ISDeptLoginModel {
  userNameOrEmail: string
  password: string
}

export interface ISDissolutionSocietyModel {
  generalBodyMeetingDate:string
  societyName?: string
  underSection:string
  category?: string
  requestType?: string
  newDate?: string
  docType?: string
  docName?: string
  disposedDetails:string
  uploadedDoc?: any
  aim?: string
  objective?: string
  effectDate: string
  reasonForDissolution: string
  isSocietyProperties:string
  isSettlementByeLaws:string
  isScoietyLiabilities:string
  isByeLawsProperties: string
  isDissolutionAgreed:string
  isDissolutionApproved:string
}

export interface ISChangesInMemoRandumModel {
  societyName?: string
  category?: string
  requestType?: string
  newDate?: string
  docType?: string
  docName?: string
  disposedDetails:string
  uploadedDoc?: any
  aim?: string
  objective?: string
  effectDate: string
  reasonForDissolution: string
  isSocietyProperties:string
  isSettlementByeLaws:string
  isScoietyLiabilities:string
  isByeLawsProperties: string
  isDissolutionAgreed:string
  isDissolutionApproved:string
  isJoiningNewMemberApprovedByGeneralBody: string,
  isJoiningNewMemberApprovedByQuorum: string,
  isMemberAgreedWithByeLaws: string,
}

export interface ISRequestTypeModel {
  isAimChange: any
  isSocietyDissolved:any
  societyNameChange: any
  placeChange: any
  filing: any
}

export interface ISDivisionOfTheSocietyApplicantDetailsModel {
  aadhaarNumber: string
  applicantName: string
  role: string
  relationName: string
  relationType:string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  landPhoneNumber: string
  mobileNumber: string
  email: string
  reasonfordivision: string
  dividesociety: string
  society1: string
  society2: string
}

export interface ISDivisionOfTheSocietyFirmDetailsModel {
  firmName: string
  firmDurationFrom: string
  firmDurationTo: string
  industryType: string
  businessType: string
}

export interface ISFillingListOfMembersApplicantDetailsModel extends ISApplicantDetailModel {
  otpStatus1: string
  otpCode1: string
  otpVerified1: string
}

export interface ISFillingListOfMembersSocietyDetailsModel {
  societyName: string
  isClaimsSociety:string
  isSocietyProperties:string
    isWindingMember:string
    liabilityConditions:string
    isByeLawsProperties:string
  category:string

}

export interface ISFillingListOfMembersOTPModel {
  otp: string
  reasonofoutgoing: string
}

export interface ISRegistrationLoginDetailsModel {
  registrationType: string
  firstName: string
  lastName: string
  email: string
  mobileNumber: string
  aadharNumber: string
  firmName: string
  alternateEmail: string
  district: string
}

export interface ISLoginDetailsModel {
  firstName: string
  lastName: string
  email: string
  alternateEmail: string
  mobileNumber: string
  token: string
  aadharNumber: string
  registrationType: string
  status: string
  applicationId: string
  applicationNumber: string
  userType: string
}

export interface ISFirmDetailsModel {
  firmName: string
  district: string
  firstName: string
  lastName: string
  emailID: string
  alternameEmailID: string
  aadharNumber: string
  mobileNumber: string
  relationwithFirm: string
}

export interface ISSocietyDetailsSMModel {
  societyName: string
  district: string
  firstName: string
  lastName: string
  emailID: string
  alternameEmailID: string
  aadharNumber: string
  mobileNumber: string
  relationwithFirm: string
}

export interface ISFirmDetailsSMModel {
  firmName: string
  firmDurationFrom: string
  firmDurationTo: string
  industryType: string
  businessType: string
}

export interface ISDefaultLoginDetailsModel {
  maskedAadhar: string
  registrationType: string
  firstName: string
  lastName: string
  email: string
  mobileNumber: string
  aadharNumber: string
  societyName: string
  alternateEmail: string
  district: string
}

export interface ISPartnerDetailsModel {
  aadharNumber: string
  applicantName: string
  relationType: string
  relationName: string
  role: string
  deliveryType: string
  doorNo: string
  street: string
  district: string
  mandal: string
  villageOrCity: string
  pinCode: string
  landPhoneNumber: string
  mobileNo: string
  fax: string
  emailID: string
}

export interface RequestTypeDetailsModel {
  date: string
  propertydisposal: string
  generalbody: string
  minutesofmeeting: string
}

export interface WindingDetailsModel {
  dateOfDissolution: string
  propertyDisposal: string
  dateOfMeeting: string
  minutesOfMeetingDesc: string
}
