import CryptoJS from "crypto-js"
import { store } from "./redux/store"

export const encryptWithAES = (text: any) => {
  return CryptoJS.AES.encrypt(text, "!Gr$@PdEApP&").toString()
}
export function randomString(length, chars) {
	var result = '';
	for (var i = length; i > 0; --i) result += chars[Math.round(Math.random() * (chars.length - 1))];
	return result;
}
export const NameValidation = (text: string) => {
  text = text.replace(/[^\w\s]/gi, "")
  text = text.replace(/[0-9]/gi, "")
  text = text.replace(/[_]/gi, "")
  if (text.length > 40) {
    text = text.substring(0, 40)
  }
  return text
}
export const ALPHANUMERIC = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
export const checkCaptcha = (str) => {
	if(store.getState().common.captchaStr === str){
		return true;
	}else{
		return false;
	}
}